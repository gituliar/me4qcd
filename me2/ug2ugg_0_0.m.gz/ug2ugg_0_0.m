(amp[1,1]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      num[ - 16*sp[k1,p1] + 24*sp[k1,p1]*m - 8*sp[k1,p1]*m^2] + amp[1,1
      ]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      num[ - 16*sp[k1,p1] + 24*sp[k1,p1]*m - 8*sp[k1,p1]*m^2] + amp[1,1
      ]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*num[
      32*sp[k1,p1] - 48*sp[k1,p1]*m + 16*sp[k1,p1]*m^2] + amp[1,1]*
      color[Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*num[32*sp[
      k1,p1] - 48*sp[k1,p1]*m + 16*sp[k1,p1]*m^2] + amp[1,2]*color[1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[sp[ - k3 + p1]]
      *num[ - 96*sp[k1,k2]*sp[k3,p1] + 80*sp[k1,k2]*sp[k3,p1]*m - 16*
      sp[k1,k2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k3]*
      sp[k1,p1]*m + 160*sp[k1,k3]*sp[k2,p1] - 112*sp[k1,k3]*sp[k2,p1]*m
       + 16*sp[k1,k3]*sp[k2,p1]*m^2 - 64*sp[k1,p1]^2 + 32*sp[k1,p1]^2*m
       - 96*sp[k1,p1]*sp[k2,k3] + 80*sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,
      p1]*sp[k2,k3]*m^2 - 64*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,p1]*sp[k2,
      p1]*m] + amp[1,3]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[k1 - p1]]*den[sp[ - k3 + p2]]*num[ - 48*sp[k1,k2]*sp[k3,p1] + 
      24*sp[k1,k2]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[p1,p2] - 24*sp[k1,k2]*
      sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1] - 24*sp[k1,k3]*sp[k1,p1]*m
       - 48*sp[k1,p1]*sp[k1,p2] + 24*sp[k1,p1]*sp[k1,p2]*m + 48*sp[k1,
      p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m - 48*sp[k1,p1]*sp[k2,p2]
       + 24*sp[k1,p1]*sp[k2,p2]*m] + amp[1,3]*color[ - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[sp[ - k3 + p2]]*num[ - 48*
      sp[k1,k2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[
      p1,p2] - 24*sp[k1,k2]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1] - 24*
      sp[k1,k3]*sp[k1,p1]*m - 48*sp[k1,p1]*sp[k1,p2] + 24*sp[k1,p1]*sp[
      k1,p2]*m + 48*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m - 48
      *sp[k1,p1]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,p2]*m] + amp[1,4]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[
      sp[p1 + p2]]*num[ - 96*sp[k1,k2]*sp[p1,p2] + 80*sp[k1,k2]*sp[p1,
      p2]*m - 16*sp[k1,k2]*sp[p1,p2]*m^2 + 64*sp[k1,p1]^2 - 32*sp[k1,p1
      ]^2*m + 64*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,p1]*sp[k1,p2]*m + 64*
      sp[k1,p1]*sp[k2,p1] - 32*sp[k1,p1]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[
      k2,p2] + 80*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*m^2 + 
      160*sp[k1,p2]*sp[k2,p1] - 112*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p2
      ]*sp[k2,p1]*m^2] + amp[1,5]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]
      ]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*num[64*sp[k1,k2]*sp[k1,p1]
       - 32*sp[k1,k2]*sp[k1,p1]*m + 160*sp[k1,k2]*sp[k3,p1] - 112*sp[k1
      ,k2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[
      k2,p1] + 80*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*m^2 - 
      64*sp[k1,p1]^2 + 32*sp[k1,p1]^2*m - 96*sp[k1,p1]*sp[k2,k3] + 80*
      sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k2,k3]*m^2 - 64*sp[k1,p1]
      *sp[k3,p1] + 32*sp[k1,p1]*sp[k3,p1]*m] + amp[1,6]*color[ - 1/2*
      Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]
      *num[48*sp[k1,k2]*sp[k1,p1] - 24*sp[k1,k2]*sp[k1,p1]*m - 48*sp[k1
      ,k3]*sp[k2,p1] + 24*sp[k1,k3]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[p1,p2
      ] - 24*sp[k1,k3]*sp[p1,p2]*m - 48*sp[k1,p1]*sp[k1,p2] + 24*sp[k1,
      p1]*sp[k1,p2]*m + 48*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]
      *m - 48*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k3,p2]*m] + amp[1,6
      ]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[
      sp[ - k2 + p2]]*num[16*sp[k1,k2]*sp[k1,p1] - 8*sp[k1,k2]*sp[k1,p1
      ]*m - 24*sp[k1,k2]*sp[k3,p1] + 20*sp[k1,k2]*sp[k3,p1]*m - 4*sp[k1
      ,k2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p1] - 4*sp[k1,k3]*sp[k2,p1
      ]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2 + 40*sp[k1,k3]*sp[p1,p2] - 28*sp[
      k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[
      k1,p2] + 16*sp[k1,p1]*sp[k1,p2]*m + 40*sp[k1,p1]*sp[k2,k3] - 28*
      sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k2,k3]*m^2 - 8*sp[k1,p1]*
      sp[k3,p2] - 4*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*m^2
       - 24*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2
      ]*sp[k3,p1]*m^2] + amp[1,6]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]
      ]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*num[ - 32*sp[k1,k2]*sp[k1,
      p1] + 16*sp[k1,k2]*sp[k1,p1]*m - 24*sp[k1,k2]*sp[k3,p1] + 20*sp[
      k1,k2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]*m^2 + 40*sp[k1,k3]*sp[
      k2,p1] - 28*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2 - 8
      *sp[k1,k3]*sp[p1,p2] - 4*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[
      p1,p2]*m^2 + 16*sp[k1,p1]*sp[k1,p2] - 8*sp[k1,p1]*sp[k1,p2]*m - 8
      *sp[k1,p1]*sp[k2,k3] - 4*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[
      k2,k3]*m^2 + 40*sp[k1,p1]*sp[k3,p2] - 28*sp[k1,p1]*sp[k3,p2]*m + 
      4*sp[k1,p1]*sp[k3,p2]*m^2 - 24*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p2]
      *sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,7]*color[ - 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[sp[p1 + p2]]*
      num[ - 48*sp[k1,k3]*sp[p1,p2] + 40*sp[k1,k3]*sp[p1,p2]*m - 8*sp[
      k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2 - 16*sp[k1,p1]^2*m + 32*sp[
      k1,p1]*sp[k1,p2] - 16*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,p1]*sp[k3,
      p1] - 16*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[k3,p2] + 40*sp[
      k1,p1]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k3,p2]*m^2 + 80*sp[k1,p2]*sp[
      k3,p1] - 56*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k3,p1]*m^2] + 
      amp[1,7]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1]]*
      den[sp[p1 + p2]]*num[48*sp[k1,k3]*sp[p1,p2] - 40*sp[k1,k3]*sp[p1,
      p2]*m + 8*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]^2 + 16*sp[k1,p1]
      ^2*m - 32*sp[k1,p1]*sp[k1,p2] + 16*sp[k1,p1]*sp[k1,p2]*m - 32*sp[
      k1,p1]*sp[k3,p1] + 16*sp[k1,p1]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k3,
      p2] - 40*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k3,p2]*m^2 - 80*
      sp[k1,p2]*sp[k3,p1] + 56*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[
      k3,p1]*m^2] + amp[1,8]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*
      den[sp[k1 - p1]]*den[sp[ - k2 - k3]]*num[24*sp[k1,k2]*sp[k1,p1]
       - 12*sp[k1,k2]*sp[k1,p1]*m + 48*sp[k1,k2]*sp[k2,p1] - 24*sp[k1,
      k2]*sp[k2,p1]*m + 48*sp[k1,k2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k3,p1]
      *m + 12*sp[k1,k2]*sp[p1,p2] - 12*sp[k1,k2]*sp[p1,p2]*m + 24*sp[k1
      ,k3]*sp[k1,p1] - 12*sp[k1,k3]*sp[k1,p1]*m + 48*sp[k1,k3]*sp[k2,p1
      ] - 24*sp[k1,k3]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k3,p1] - 24*sp[k1,
      k3]*sp[k3,p1]*m + 12*sp[k1,k3]*sp[p1,p2] - 12*sp[k1,k3]*sp[p1,p2]
      *m - 96*sp[k1,p1]*sp[k2,k3] + 48*sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1
      ,p1]*sp[k2,p1] + 12*sp[k1,p1]*sp[k2,p1]*m - 12*sp[k1,p1]*sp[k2,p2
      ] + 12*sp[k1,p1]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k3,p1] + 12*sp[k1,
      p1]*sp[k3,p1]*m - 12*sp[k1,p1]*sp[k3,p2] + 12*sp[k1,p1]*sp[k3,p2]
      *m + 12*sp[k1,p2]*sp[k2,p1] - 12*sp[k1,p2]*sp[k2,p1]*m + 12*sp[k1
      ,p2]*sp[k3,p1] - 12*sp[k1,p2]*sp[k3,p1]*m] + amp[1,8]*color[ - 1/
      2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2
       - k3]]*num[ - 8*sp[k1,k2]*sp[k1,p1] + 12*sp[k1,k2]*sp[k1,p1]*m
       - 4*sp[k1,k2]*sp[k1,p1]*m^2 + 24*sp[k1,k2]*sp[k2,p1] - 16*sp[k1,
      k2]*sp[k2,p1]*m + 24*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]
      *m + 16*sp[k1,k2]*sp[p1,p2] - 12*sp[k1,k2]*sp[p1,p2]*m + 32*sp[k1
      ,k3]*sp[k1,p1] - 24*sp[k1,k3]*sp[k1,p1]*m + 4*sp[k1,k3]*sp[k1,p1]
      *m^2 + 24*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[k2,p1]*m + 24*sp[
      k1,k3]*sp[k3,p1] - 8*sp[k1,k3]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[p1,p2
      ] - 48*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,p1]*sp[k2,k3]*m + 8*sp[k1,
      p1]*sp[k2,p1] - 12*sp[k1,p1]*sp[k2,p1]*m + 4*sp[k1,p1]*sp[k2,p1]*
      m^2 - 32*sp[k1,p1]*sp[k2,p2] + 28*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1
      ,p1]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,p1]*sp[k3,
      p1]*m - 4*sp[k1,p1]*sp[k3,p1]*m^2 + 20*sp[k1,p1]*sp[k3,p2] - 16*
      sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*m^2 + 16*sp[k1,p2]*
      sp[k2,p1] - 12*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,p2]*sp[k3,p1]] + 
      amp[1,8]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1
      ]]*den[sp[ - k2 - k3]]*num[ - 32*sp[k1,k2]*sp[k1,p1] + 24*sp[k1,
      k2]*sp[k1,p1]*m - 4*sp[k1,k2]*sp[k1,p1]*m^2 - 24*sp[k1,k2]*sp[k2,
      p1] + 8*sp[k1,k2]*sp[k2,p1]*m - 24*sp[k1,k2]*sp[k3,p1] + 12*sp[k1
      ,k2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[p1,p2] + 8*sp[k1,k3]*sp[k1,p1]
       - 12*sp[k1,k3]*sp[k1,p1]*m + 4*sp[k1,k3]*sp[k1,p1]*m^2 - 24*sp[
      k1,k3]*sp[k2,p1] + 12*sp[k1,k3]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k3,
      p1] + 16*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[p1,p2] + 12*sp[
      k1,k3]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,
      k3]*m + 32*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,p1]*sp[k2,p1]*m + 4*sp[
      k1,p1]*sp[k2,p1]*m^2 - 20*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[
      k2,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*m^2 - 8*sp[k1,p1]*sp[k3,p1] + 12
      *sp[k1,p1]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[k3,p1]*m^2 + 32*sp[k1,p1]
      *sp[k3,p2] - 28*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*m^2
       + 4*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p2]*sp[k3,p1] + 12*sp[k1,p2]*
      sp[k3,p1]*m] + amp[1,9]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*num[32*sp[k1,k2]*sp[k1,
      p1] - 24*sp[k1,k2]*sp[k1,p1]*m + 4*sp[k1,k2]*sp[k1,p1]*m^2 + 24*
      sp[k1,k2]*sp[k2,p1] - 8*sp[k1,k2]*sp[k2,p1]*m + 4*sp[k1,k2]*sp[k3
      ,p1] - 24*sp[k1,k2]*sp[p1,p2] + 12*sp[k1,k2]*sp[p1,p2]*m + 4*sp[
      k1,k3]*sp[k2,p1] + 16*sp[k1,k3]*sp[p1,p2] - 12*sp[k1,k3]*sp[p1,p2
      ]*m + 8*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1]*sp[k1,p2]*m + 4*sp[k1,
      p1]*sp[k1,p2]*m^2 - 20*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,p1]*sp[k2,
      k3]*m - 4*sp[k1,p1]*sp[k2,k3]*m^2 - 32*sp[k1,p1]*sp[k2,p1] + 24*
      sp[k1,p1]*sp[k2,p1]*m - 4*sp[k1,p1]*sp[k2,p1]*m^2 + 48*sp[k1,p1]*
      sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[k3,p2] + 
      28*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 8*sp[k1,p1
      ]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[p1,p2]*
      m^2 - 24*sp[k1,p2]*sp[k2,p1] + 12*sp[k1,p2]*sp[k2,p1]*m + 16*sp[
      k1,p2]*sp[k3,p1] - 12*sp[k1,p2]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[p1,
      p2] - 16*sp[k1,p2]*sp[p1,p2]*m] + amp[1,9]*color[1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*num[8*
      sp[k1,k2]*sp[k1,p1] - 12*sp[k1,k2]*sp[k1,p1]*m + 4*sp[k1,k2]*sp[
      k1,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p1] + 16*sp[k1,k2]*sp[k2,p1]*m + 
      16*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*m + 24*sp[k1,k2]*
      sp[p1,p2] - 12*sp[k1,k2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p1] - 
      12*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[p1,p2] + 32*sp[k1,p1]*
      sp[k1,p2] - 24*sp[k1,p1]*sp[k1,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*m^2
       - 32*sp[k1,p1]*sp[k2,k3] + 28*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,p1
      ]*sp[k2,k3]*m^2 - 8*sp[k1,p1]*sp[k2,p1] + 12*sp[k1,p1]*sp[k2,p1]*
      m - 4*sp[k1,p1]*sp[k2,p1]*m^2 - 48*sp[k1,p1]*sp[k2,p2] + 24*sp[k1
      ,p1]*sp[k2,p2]*m - 20*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p2
      ]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[p1,p2] + 24*sp[
      k1,p1]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[p1,p2]*m^2 + 24*sp[k1,p2]*sp[
      k2,p1] - 12*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k3,p1] - 24*
      sp[k1,p2]*sp[p1,p2] + 8*sp[k1,p2]*sp[p1,p2]*m] + amp[1,9]*color[
      Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + 
      p2]]*num[ - 24*sp[k1,k2]*sp[k1,p1] + 12*sp[k1,k2]*sp[k1,p1]*m - 
      48*sp[k1,k2]*sp[k2,p1] + 24*sp[k1,k2]*sp[k2,p1]*m + 12*sp[k1,k2]*
      sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[p1,p2] - 
      24*sp[k1,k2]*sp[p1,p2]*m + 12*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,k3]*
      sp[k2,p1]*m - 12*sp[k1,k3]*sp[p1,p2] + 12*sp[k1,k3]*sp[p1,p2]*m
       + 24*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1]*sp[k1,p2]*m - 12*sp[k1,
      p1]*sp[k2,k3] + 12*sp[k1,p1]*sp[k2,k3]*m + 24*sp[k1,p1]*sp[k2,p1]
       - 12*sp[k1,p1]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,
      p1]*sp[k2,p2]*m + 12*sp[k1,p1]*sp[k3,p2] - 12*sp[k1,p1]*sp[k3,p2]
      *m - 24*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1
      ,p2]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,p1]*m - 12*sp[k1,p2]*sp[k3,p1
      ] + 12*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[p1,p2] + 24*sp[k1,
      p2]*sp[p1,p2]*m] + amp[1,10]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1
       + p1]]*den[sp[k1 - p1]]*den[sp[ - k3 + p2]]*num[12*sp[k1,k2]*sp[
      k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*m - 12*sp[k1,k2]*sp[p1,p2] + 12*
      sp[k1,k2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k1,p1] + 12*sp[k1,k3]*sp[
      k1,p1]*m + 12*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[k2,p1]*m - 48
      *sp[k1,k3]*sp[k3,p1] + 24*sp[k1,k3]*sp[k3,p1]*m + 48*sp[k1,k3]*
      sp[p1,p2] - 24*sp[k1,k3]*sp[p1,p2]*m + 24*sp[k1,p1]*sp[k1,p2] - 
      12*sp[k1,p1]*sp[k1,p2]*m - 12*sp[k1,p1]*sp[k2,k3] + 12*sp[k1,p1]*
      sp[k2,k3]*m + 12*sp[k1,p1]*sp[k2,p2] - 12*sp[k1,p1]*sp[k2,p2]*m
       + 24*sp[k1,p1]*sp[k3,p1] - 12*sp[k1,p1]*sp[k3,p1]*m - 96*sp[k1,
      p1]*sp[k3,p2] + 48*sp[k1,p1]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[p1,p2]
       + 12*sp[k1,p1]*sp[p1,p2]*m - 12*sp[k1,p2]*sp[k2,p1] + 12*sp[k1,
      p2]*sp[k2,p1]*m + 48*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[k3,p1]
      *m - 48*sp[k1,p2]*sp[p1,p2] + 24*sp[k1,p2]*sp[p1,p2]*m] + amp[1,
      10]*color[Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[
      sp[ - k3 + p2]]*num[12*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,
      p1]*m - 12*sp[k1,k2]*sp[p1,p2] + 12*sp[k1,k2]*sp[p1,p2]*m - 24*
      sp[k1,k3]*sp[k1,p1] + 12*sp[k1,k3]*sp[k1,p1]*m + 12*sp[k1,k3]*sp[
      k2,p1] - 12*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,k3]*sp[k3,p1] + 24*
      sp[k1,k3]*sp[k3,p1]*m + 48*sp[k1,k3]*sp[p1,p2] - 24*sp[k1,k3]*sp[
      p1,p2]*m + 24*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1]*sp[k1,p2]*m - 12
      *sp[k1,p1]*sp[k2,k3] + 12*sp[k1,p1]*sp[k2,k3]*m + 12*sp[k1,p1]*
      sp[k2,p2] - 12*sp[k1,p1]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[k3,p1] - 
      12*sp[k1,p1]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k3,p2] + 48*sp[k1,p1]*
      sp[k3,p2]*m - 24*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]*m
       - 12*sp[k1,p2]*sp[k2,p1] + 12*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,
      p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[p1,p2]
       + 24*sp[k1,p2]*sp[p1,p2]*m] + amp[1,11]*color[ - 1/4*Ca^2*Na*Tf]
      *den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*num[32*sp[
      k1,k2]*sp[k1,p1] - 16*sp[k1,k2]*sp[k1,p1]*m - 24*sp[k1,k2]*sp[p1,
      p2] + 20*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 + 16*
      sp[k1,k3]*sp[k1,p1] - 8*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k3]*sp[
      p1,p2] - 20*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*m^2 - 8
      *sp[k1,p1]*sp[k2,p2] - 4*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[
      k2,p2]*m^2 - 40*sp[k1,p1]*sp[k3,p2] + 28*sp[k1,p1]*sp[k3,p2]*m - 
      4*sp[k1,p1]*sp[k3,p2]*m^2 + 40*sp[k1,p2]*sp[k2,p1] - 28*sp[k1,p2]
      *sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2 + 8*sp[k1,p2]*sp[k3,p1]
       + 4*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,
      11]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[
      sp[ - k2 - k3]]*num[ - 16*sp[k1,k2]*sp[k1,p1] + 8*sp[k1,k2]*sp[k1
      ,p1]*m - 24*sp[k1,k2]*sp[p1,p2] + 20*sp[k1,k2]*sp[p1,p2]*m - 4*
      sp[k1,k2]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1] + 16*sp[k1,k3]*
      sp[k1,p1]*m + 24*sp[k1,k3]*sp[p1,p2] - 20*sp[k1,k3]*sp[p1,p2]*m
       + 4*sp[k1,k3]*sp[p1,p2]*m^2 + 40*sp[k1,p1]*sp[k2,p2] - 28*sp[k1,
      p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*m^2 + 8*sp[k1,p1]*sp[k3,
      p2] + 4*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 8*sp[
      k1,p2]*sp[k2,p1] - 4*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1
      ]*m^2 - 40*sp[k1,p2]*sp[k3,p1] + 28*sp[k1,p2]*sp[k3,p1]*m - 4*sp[
      k1,p2]*sp[k3,p1]*m^2] + amp[1,11]*color[1/2*Ca^2*Na*Tf]*den[sp[k1
       - p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*num[ - 48*sp[k1,k2]*
      sp[k1,p1] + 24*sp[k1,k2]*sp[k1,p1]*m - 48*sp[k1,k3]*sp[k1,p1] + 
      24*sp[k1,k3]*sp[k1,p1]*m + 48*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,p1]*
      sp[k2,p2]*m + 48*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,p1]*sp[k3,p2]*m
       - 48*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p2]*sp[k2,p1]*m - 48*sp[k1,
      p2]*sp[k3,p1] + 24*sp[k1,p2]*sp[k3,p1]*m] + amp[1,12]*color[ - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1
      ]]*num[ - 64*sp[k1,k2]*sp[k1,p1] + 32*sp[k1,k2]*sp[k1,p1]*m + 160
      *sp[k1,k2]*sp[p1,p2] - 112*sp[k1,k2]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[p1,p2]*m^2 + 64*sp[k1,p1]^2 - 32*sp[k1,p1]^2*m - 96*sp[k1,p1]*
      sp[k2,p2] + 80*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*m^2
       - 64*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,
      p2]*sp[k2,p1] + 80*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,p1]
      *m^2] + amp[1,13]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[
      sp[k1 - p2]]*den[sp[ - k3 + p1]]*num[ - 32*sp[k1,k3]*sp[k1,p1] + 
      16*sp[k1,k3]*sp[k1,p1]*m + 80*sp[k1,k3]*sp[p1,p2] - 56*sp[k1,k3]*
      sp[p1,p2]*m + 8*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2 - 16*sp[
      k1,p1]^2*m - 48*sp[k1,p1]*sp[k3,p2] + 40*sp[k1,p1]*sp[k3,p2]*m - 
      8*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,p1]
      *sp[p1,p2]*m - 48*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,p2]*sp[k3,p1]*m
       - 8*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,13]*color[1/4*Ca^2*Na*Tf]*
      den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]*num[32*sp[
      k1,k3]*sp[k1,p1] - 16*sp[k1,k3]*sp[k1,p1]*m - 80*sp[k1,k3]*sp[p1,
      p2] + 56*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[p1,p2]*m^2 - 32*
      sp[k1,p1]^2 + 16*sp[k1,p1]^2*m + 48*sp[k1,p1]*sp[k3,p2] - 40*sp[
      k1,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[
      p1,p2] - 16*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[k3,p1] - 40*
      sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,14]*
      color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 - k3]]*
      den[sp[p1 + p2]]*num[48*sp[k1,k2]*sp[p1,p2] - 24*sp[k1,k2]*sp[p1,
      p2]*m + 48*sp[k1,k3]*sp[p1,p2] - 24*sp[k1,k3]*sp[p1,p2]*m - 48*
      sp[k1,p1]*sp[k2,p1] + 24*sp[k1,p1]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[
      k2,p2] + 24*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1,p1]*sp[k3,p1] + 24*
      sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[
      k3,p2]*m] + amp[1,14]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*
      den[sp[ - k2 - k3]]*den[sp[p1 + p2]]*num[8*sp[k1,k2]*sp[p1,p2] + 
      4*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 + 40*sp[k1,k3
      ]*sp[p1,p2] - 28*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*
      m^2 - 16*sp[k1,p1]*sp[k2,p1] + 8*sp[k1,p1]*sp[k2,p1]*m - 40*sp[k1
      ,p1]*sp[k2,p2] + 28*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,p2]
      *m^2 - 32*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,p1]*sp[k3,p1]*m - 8*sp[
      k1,p1]*sp[k3,p2] - 4*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p2
      ]*m^2 + 24*sp[k1,p2]*sp[k2,p1] - 20*sp[k1,p2]*sp[k2,p1]*m + 4*sp[
      k1,p2]*sp[k2,p1]*m^2 - 24*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p2]*sp[
      k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,14]*color[1/4*Ca^2*
      Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 - k3]]*den[sp[p1 + p2]]*num[
       - 40*sp[k1,k2]*sp[p1,p2] + 28*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2
      ]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[p1,p2] - 4*sp[k1,k3]*sp[p1,p2]*m
       + 4*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,
      p1]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,p2]*m
       - 4*sp[k1,p1]*sp[k2,p2]*m^2 + 16*sp[k1,p1]*sp[k3,p1] - 8*sp[k1,
      p1]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[k3,p2] - 28*sp[k1,p1]*sp[k3,p2]
      *m + 4*sp[k1,p1]*sp[k3,p2]*m^2 + 24*sp[k1,p2]*sp[k2,p1] - 20*sp[
      k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2 - 24*sp[k1,p2]*sp[
      k3,p1] + 20*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + 
      amp[1,15]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + 
      p1]]*den[sp[ - k3 + p2]]*num[48*sp[k1,k3]*sp[k2,p1] - 24*sp[k1,k3
      ]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,p1]*sp[k2,k3]*m
       + 48*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p2]*m + 48*sp[k1,
      p1]*sp[k3,p1] - 24*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[p1,p2]
       + 24*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,
      p2]*sp[k2,p1]*m] + amp[1,15]*color[1/2*Ca^2*Na*Tf]*den[sp[k1 - p1
      ]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*num[48*sp[k1,k3]*sp[k2
      ,p1] - 24*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k2,k3] + 24*sp[
      k1,p1]*sp[k2,k3]*m + 48*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,
      p2]*m + 48*sp[k1,p1]*sp[k3,p1] - 24*sp[k1,p1]*sp[k3,p1]*m - 48*
      sp[k1,p1]*sp[p1,p2] + 24*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,p2]*sp[
      k2,p1] + 24*sp[k1,p2]*sp[k2,p1]*m] + amp[1,16]*color[ - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*
      num[ - 40*sp[k1,k2]*sp[k3,p1] + 28*sp[k1,k2]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k3,p1]*m^2 + 24*sp[k1,k3]*sp[k2,p1] - 20*sp[k1,k3]*sp[
      k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2 + 24*sp[k1,k3]*sp[p1,p2] - 
      20*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*m^2 + 8*sp[k1,p1
      ]*sp[k2,k3] + 4*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k2,k3]*m^2
       - 32*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,p1]*sp[k2,p1]*m - 40*sp[k1,
      p1]*sp[k3,p2] + 28*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*
      m^2 + 16*sp[k1,p1]*sp[p1,p2] - 8*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,
      p2]*sp[k3,p1] + 4*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*
      m^2] + amp[1,16]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[
       - k2 + p2]]*den[sp[ - k3 + p1]]*num[8*sp[k1,k2]*sp[k3,p1] + 4*
      sp[k1,k2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]*m^2 + 24*sp[k1,k3]*
      sp[k2,p1] - 20*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2
       + 24*sp[k1,k3]*sp[p1,p2] - 20*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3
      ]*sp[p1,p2]*m^2 - 40*sp[k1,p1]*sp[k2,k3] + 28*sp[k1,p1]*sp[k2,k3]
      *m - 4*sp[k1,p1]*sp[k2,k3]*m^2 + 16*sp[k1,p1]*sp[k2,p1] - 8*sp[k1
      ,p1]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k3,p2] + 4*sp[k1,p1]*sp[k3,p2]*
      m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[p1,p2] + 16*sp[k1
      ,p1]*sp[p1,p2]*m - 40*sp[k1,p2]*sp[k3,p1] + 28*sp[k1,p2]*sp[k3,p1
      ]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[1,16]*color[1/2*Ca^2*Na*Tf
      ]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*num[48
      *sp[k1,k2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k3,p1]*m - 48*sp[k1,p1]*
      sp[k2,k3] + 24*sp[k1,p1]*sp[k2,k3]*m + 48*sp[k1,p1]*sp[k2,p1] - 
      24*sp[k1,p1]*sp[k2,p1]*m + 48*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,p1]*
      sp[k3,p2]*m - 48*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,p1]*sp[p1,p2]*m
       - 48*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,p2]*sp[k3,p1]*m] + amp[2,1]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]*
      den[sp[p1 + p2]]*num[ - 48*sp[k1,k2]*sp[p1,p2] + 40*sp[k1,k2]*sp[
      p1,p2]*m - 8*sp[k1,k2]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2 - 16*sp[k1,
      p1]^2*m + 32*sp[k1,p1]*sp[k1,p2] - 16*sp[k1,p1]*sp[k1,p2]*m + 32*
      sp[k1,p1]*sp[k2,p1] - 16*sp[k1,p1]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[
      k2,p2] + 40*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*m^2 + 
      80*sp[k1,p2]*sp[k2,p1] - 56*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,p2]*
      sp[k2,p1]*m^2] + amp[2,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1
      ]]*den[sp[k1 + k2]]*den[sp[p1 + p2]]*num[48*sp[k1,k2]*sp[p1,p2]
       - 40*sp[k1,k2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[p1,p2]*m^2 - 32*sp[
      k1,p1]^2 + 16*sp[k1,p1]^2*m - 32*sp[k1,p1]*sp[k1,p2] + 16*sp[k1,
      p1]*sp[k1,p2]*m - 32*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,p1]*sp[k2,p1]
      *m + 48*sp[k1,p1]*sp[k2,p2] - 40*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,
      p1]*sp[k2,p2]*m^2 - 80*sp[k1,p2]*sp[k2,p1] + 56*sp[k1,p2]*sp[k2,
      p1]*m - 8*sp[k1,p2]*sp[k2,p1]*m^2] + amp[2,2]*color[ - Cf^2*Na*Tf
       + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*den[sp[ - k3 + p1]]*den[
      sp[p1 + p2]]*num[128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 160*sp[k1,k2
      ]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 
      8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^3 - 128*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1] + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p1]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 288*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k2
      ]*sp[k2,p1]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^3] + amp[2,3]*
      color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*den[sp[ - k3 + p2]]*
      den[sp[p1 + p2]]*num[ - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 128*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 64*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 
      16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[
      p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2
       - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2] + amp[2,4]*
      color[ - Cf^2*Na*Tf]*den[sp[k1 + k2]]^2*den[sp[p1 + p2]]^2*num[
      128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 192*sp[k1,k2]*sp[k2,p2]*sp[p1
      ,p2]*m + 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 16*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2]*m^3] + amp[2,5]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - 
      k2 + p1]]*den[sp[p1 + p2]]*num[256*sp[k1,k2]^2*sp[p1,p2] - 128*
      sp[k1,k2]^2*sp[p1,p2]*m + 16*sp[k1,k2]^2*sp[p1,p2]*m^2 + 64*sp[k1
      ,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 
      256*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p1]*m - 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 128*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 64*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 
      64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k1
      ,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2
      ]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 
      128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 640*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2] + 416*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 
      640*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 480*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1]*m + 112*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m^3 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 64
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
      *m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k2,p1]^2 - 128*sp[k1,
      k3]*sp[k2,p1]^2*m + 16*sp[k1,k3]*sp[k2,p1]^2*m^2 + 256*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p1]^2*sp[k2,
      k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 32*
      sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1]
      ^2*sp[k3,p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
      *m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1] + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p1]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 
      608*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^3 + 128*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m + 640*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 480*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^3 + 128*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[2,6]*color[ - 1/2*Ca*Cf*Na*Tf
       + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2
       + p2]]*den[sp[p1 + p2]]*num[ - 128*sp[k1,k2]^2*sp[p1,p2] + 48*
      sp[k1,k2]^2*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m^2 + 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p1]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 
      8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 160*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2]*m^2 - 320*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 176*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 
      64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 96*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 16
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]^2 + 
      112*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2 - 192*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
      *m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2] - 160*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 
      24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3]
       + 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] - 32*sp[
      k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 32*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 
      32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3
      ,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2
      ]*sp[k3,p2] + 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 + 256*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 144
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p1]*m^2 + 448*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 224*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 96*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 112*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2
       + 96*sp[k1,p2]^2*sp[k2,p1] - 32*sp[k1,p2]^2*sp[k2,p1]*m + 96*sp[
      k1,p2]^2*sp[k3,p1] - 80*sp[k1,p2]^2*sp[k3,p1]*m + 16*sp[k1,p2]^2*
      sp[k3,p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 80*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 224
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] - 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m
       + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[2,7]*color[ - Cf^2
      *Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[
      sp[p1 + p2]]^2*num[128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 128*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2
       - 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 8*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 128
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,k3]*sp[k2
      ,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 8*sp[k1
      ,k3]*sp[k2,p2]*sp[p1,p2]*m^3 + 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       - 288*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3] + amp[2,8]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]*
      den[sp[ - k2 - k3]]*den[sp[p1 + p2]]*num[32*sp[k1,k2]^2*sp[p1,p2]
       + 8*sp[k1,k2]^2*sp[p1,p2]*m - 4*sp[k1,k2]^2*sp[p1,p2]*m^2 + 176*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 72*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]^
      2 - 16*sp[k1,k2]*sp[k1,p1]^2*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]
       - 16*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 24*sp[k1,k2]*sp[k1
      ,p1]*sp[k2,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 144*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m
       - 192*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 96
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1] - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 144*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]
      *sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k2]
      *sp[k3,p1]^2 - 24*sp[k1,k2]*sp[k3,p1]^2*m + 64*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 40*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m^2 + 80*sp[k1,k3]^2*sp[p1,p2] - 32*sp[k1,k3]^2*sp[p1,p2]*
      m + 64*sp[k1,k3]*sp[k1,p1]^2 - 32*sp[k1,k3]*sp[k1,p1]^2*m + 64*
      sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*
      m - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 80
      *sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
      *m + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 16*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]
       - 40*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[
      k2,p1]^2 + 8*sp[k1,k3]*sp[k2,p1]^2*m - 32*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p1] + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 144*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m + 80*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2
      ,k3]*m + 16*sp[k1,p1]^2*sp[k2,p2]*m + 8*sp[k1,p1]^2*sp[k3,p2]*m
       + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 8*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1
      ] + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*
      m - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m^2 + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[
      k2,p2]^2 + 24*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*
      m^2 - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 64*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]
      ^2*sp[k2,p1]*m - 32*sp[k1,p2]^2*sp[k3,p1] + 8*sp[k1,p2]^2*sp[k3,
      p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]^2*m - 4*sp[
      k1,p2]*sp[k2,p1]^2*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 24*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
      *m^2 - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 8*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[2,10]*color[1/4*Ca^2*Na*Tf
      ]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]*den[sp[ - k3 + p2]]*den[
      sp[p1 + p2]]*num[ - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 40*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 24*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 8*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 32*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*
      m - 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 40*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2
       - 80*sp[k1,k2]*sp[k3,p1]^2 + 32*sp[k1,k2]*sp[k3,p1]^2*m - 80*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m
       + 176*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 72*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 16*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[p1,p2]^2 - 8*sp[k1,k2]*sp[p1,
      p2]^2*m + 4*sp[k1,k2]*sp[p1,p2]^2*m^2 - 64*sp[k1,k3]^2*sp[p1,p2]
       + 24*sp[k1,k3]^2*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m
       - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 144*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 8*sp[k1,k3]*sp[
      k1,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,p1]^2 + 8*sp[k1,k3
      ]*sp[k2,p1]^2*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 96*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m + 144*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,p1]^2*sp[k2,k3]*m - 16*sp[k1,p1
      ]^2*sp[k2,p2]*m + 64*sp[k1,p1]^2*sp[k3,p1] - 32*sp[k1,p1]^2*sp[k3
      ,p1]*m + 80*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 
      32*sp[k1,p1]^2*sp[p1,p2] + 16*sp[k1,p1]^2*sp[p1,p2]*m + 8*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 
      8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p2]*m^2 - 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 24*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m
       + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 80*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 
      192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1]*m + 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]
       + 16*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p2]^2
       - 24*sp[k1,p1]*sp[k2,p2]^2*m + 4*sp[k1,p1]*sp[k2,p2]^2*m^2 + 48*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 64*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 8*sp[k1,p2]^2*sp[k2,p1]*m + 4*
      sp[k1,p2]^2*sp[k2,p1]*m^2 - 32*sp[k1,p2]^2*sp[k3,p1] + 8*sp[k1,p2
      ]^2*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1]*m^2 + 144*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 
      48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 112*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] + 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,
      p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m - 32*sp[k1,p2]*sp[k2,p1]*sp[k2
      ,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 96
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m + 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m^2 - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m] + amp[2,11]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]
      ]*den[sp[p1 + p2]]*num[32*sp[k1,k2]^2*sp[p1,p2] - 16*sp[k1,k2]^2*
      sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]^2 + 32*sp[k1,k2]*sp[
      k1,p1]^2*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 192*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 256*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2] + 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1
      ,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 48
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2
      ]*m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1
      ]*sp[p1,p2]*m + 256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 160*sp[k1,k2]
      *sp[k3,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 
      128*sp[k1,k3]*sp[k1,p1]^2 + 64*sp[k1,k3]*sp[k1,p1]^2*m - 128*sp[
      k1,k3]*sp[k1,p1]*sp[k1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m
       - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1]*m - 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p2]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 320*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2] + 208*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p2
      ]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]
      *sp[k2,p1]*sp[p1,p2]*m - 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 112*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m^2 - 64*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,k3]*m - 
      64*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k3,p2] - 64*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1
      ,p2]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 64*sp[k1,p1]*sp[k2,p2]^2 - 48*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[
      k1,p1]*sp[k2,p2]^2*m^2 + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*
      m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,
      p1] - 32*sp[k1,p2]^2*sp[k2,p1]*m + 64*sp[k1,p2]^2*sp[k3,p1] - 16*
      sp[k1,p2]^2*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 96*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 32*sp[k1,p2]*sp[k2,p1]^2 + 16*sp[k1,p2]*sp[k2,p1]^2*m - 
      64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
      *m] + amp[2,12]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[
      sp[p1 + p2]]*num[ - 128*sp[k1,k2]^2*sp[p1,p2] + 96*sp[k1,k2]^2*
      sp[p1,p2]*m - 16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k1,
      p1]^2 + 64*sp[k1,k2]*sp[k1,p1]^2*m - 128*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 256*sp[k1,k2]*sp[k1
      ,p1]*sp[k2,p1] - 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
       - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p2]*sp[p1
      ,p2] + 96*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2
      ]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 96*sp[k1,k2
      ]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 
      1024*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 704*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m + 144*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 8*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m^3 - 128*sp[k1,k2]*sp[p1,p2]^2 + 96*sp[k1,k2
      ]*sp[p1,p2]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2*m^2 + 128*sp[k1,p1]^3
       - 64*sp[k1,p1]^3*m + 128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*
      sp[k1,p2]*m + 128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]^2*sp[k2,p1
      ]*m + 256*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k2,p2]*m - 
      128*sp[k1,p1]^2*sp[p1,p2] + 64*sp[k1,p1]^2*sp[p1,p2]*m - 128*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 
      96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p2]*m^2 + 256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 192*sp[k1,p1]*sp[
      k1,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p1
      ]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 1024*sp[k1,p1]
      *sp[k2,p2]^2 + 704*sp[k1,p1]*sp[k2,p2]^2*m - 144*sp[k1,p1]*sp[k2,
      p2]^2*m^2 + 8*sp[k1,p1]*sp[k2,p2]^2*m^3 + 128*sp[k1,p1]*sp[k2,p2]
      *sp[p1,p2] - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 96*sp[k1,p2
      ]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1,p2]*
      sp[k2,p1]^2 - 96*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]
      ^2*m^2 + 1024*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 704*sp[k1,p2]*sp[k2
      ,p1]*sp[k2,p2]*m + 144*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[
      k1,p2]*sp[k2,p1]*sp[k2,p2]*m^3 + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ] - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m^2] + amp[2,13]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1
      ]]*den[sp[p1 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m^2 - 128*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 256*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[p1,
      p2]^2 - 128*sp[k1,k2]*sp[p1,p2]^2*m + 16*sp[k1,k2]*sp[p1,p2]^2*
      m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m^2 + 64*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*
      m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,k3]
      *sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 
      128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 640*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 480*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 112*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*
      m^3 + 64*sp[k1,p1]^2*sp[k2,k3] - 64*sp[k1,p1]^2*sp[k2,k3]*m + 16*
      sp[k1,p1]^2*sp[k2,k3]*m^2 - 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,
      p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[
      k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 
      64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1]*m + 256*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 128*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m^2 - 256*sp[
      k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m
       - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 896*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2] - 608*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 128*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^3 - 
      256*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,p1]*sp[k2,p2]*sp[p1
      ,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 256*sp[k1,p2]^2*
      sp[k3,p1] + 128*sp[k1,p2]^2*sp[k3,p1]*m - 16*sp[k1,p2]^2*sp[k3,p1
      ]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 416*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2]*m^3 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 
      64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p1]*m^2 - 640*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 480*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m - 112*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^3 - 64*sp[k1,p2]*sp[k2,p1]*sp[p1,
      p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 256*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[2,14]*color[ - 1/2*Ca*Cf*Na*
      Tf]*den[sp[k1 + k2]]*den[sp[ - k2 - k3]]*den[sp[p1 + p2]]^2*num[
       - 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ] - 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 128*sp[k1,k3]
      *sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 
      64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2]*m^2] + amp[2,15]*color[ - 1/2*Ca*Cf*Na*Tf
       + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + p1]]*den[sp[
       - k3 + p2]]*den[sp[p1 + p2]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2] - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 160*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 64*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 128*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2
       + 320*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 208*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[p1
      ,p2] + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1
      ,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2
       - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,
      k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 128*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 32
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m - 64*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[k1,k3]*sp[k2,p1]^2*m - 64*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*
      m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]^2*sp[k2,k3]
       - 64*sp[k1,p1]^2*sp[k2,p2] + 128*sp[k1,p1]^2*sp[k3,p1] - 64*sp[
      k1,p1]^2*sp[k3,p1]*m + 64*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]^2*
      sp[k3,p2]*m - 64*sp[k1,p1]^2*sp[p1,p2] + 32*sp[k1,p1]^2*sp[p1,p2]
      *m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p1
      ] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]
       + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,
      p1]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 64
      *sp[k1,p1]*sp[k2,p2]^2 - 48*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]
      *sp[k2,p2]^2*m^2 + 160*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,p2]^2*sp[k2,p1] + 16*
      sp[k1,p2]^2*sp[k2,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]^2 - 
      32*sp[k1,p2]*sp[k2,p1]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 
      48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]
      *sp[k2,p1]*sp[p1,p2]*m] + amp[2,16]*color[ - 1/2*Ca*Cf*Na*Tf + 1/
      4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + p2]]*den[sp[ - k3
       + p1]]*den[sp[p1 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 48*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2
       - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[
      p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1
      ,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2
       - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 224*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] + 160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m^2 + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]
      *sp[p1,p2]*m - 128*sp[k1,k2]*sp[p1,p2]^2 + 48*sp[k1,k2]*sp[p1,p2]
      ^2*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 80*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]
      *m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1
      ]^2 + 80*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2
       - 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 80*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 320
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 176*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2*sp[k2
      ,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] + 32
      *sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m + 32*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p2] + 144*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1
      ] - 80*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1]*m^2 + 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 112*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 
      32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,p1]*sp[k2,
      p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 448*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 224*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p1
      ]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 192*
      sp[k1,p2]^2*sp[k3,p1] - 112*sp[k1,p2]^2*sp[k3,p1]*m + 16*sp[k1,p2
      ]^2*sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m - 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 
      96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m^2 + 96*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m
       - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m + 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1
      ,p2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 
      192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[3,1]*color[1/
      4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[p1 + p2
      ]]*num[96*sp[k1,k3]*sp[p1,p2] - 80*sp[k1,k3]*sp[p1,p2]*m + 16*sp[
      k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]^2 + 32*sp[k1,p1]^2*m - 64*sp[
      k1,p1]*sp[k1,p2] + 32*sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,p1]*sp[k3,
      p1] + 32*sp[k1,p1]*sp[k3,p1]*m + 96*sp[k1,p1]*sp[k3,p2] - 80*sp[
      k1,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k3,p2]*m^2 - 160*sp[k1,p2]*
      sp[k3,p1] + 112*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k3,p1]*
      m^2] + amp[3,2]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*
      Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k3 + p1]]*den[sp[
      p1 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p1]*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 
      96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3
      ,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[k1
      ,k2]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 
      16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k3,p1]^2
       - 128*sp[k1,k2]*sp[k3,p1]^2*m + 16*sp[k1,k2]*sp[k3,p1]^2*m^2 + 
      256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 256*sp[k1
      ,k3]^2*sp[p1,p2] - 128*sp[k1,k3]^2*sp[p1,p2]*m + 16*sp[k1,k3]^2*
      sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m^2 - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1]*m - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 128*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
      *m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 64*sp[k1,k3]
      *sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 + 
      256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 640*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 480*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m + 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2]*m^3 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k3]
      *sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 
      640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 416*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m^3 + 64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*
      sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[k2,p2]
      *m - 16*sp[k1,p1]^2*sp[k2,p2]*m^2 - 64*sp[k1,p1]^2*sp[k3,p2] + 32
      *sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 128*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1
      ]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 608*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 8*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 480*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 
      96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p1]*m^2] + amp[3,3]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k3 + p2]]*den[sp[p1
       + p2]]*num[ - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*
      m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 48*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2
      ]*m^2 - 192*sp[k1,k2]*sp[k3,p1]^2 + 112*sp[k1,k2]*sp[k3,p1]^2*m
       - 16*sp[k1,k2]*sp[k3,p1]^2*m^2 - 192*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2] + 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 
      160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m^2 - 128*sp[k1,k3]^2*sp[p1,p2] + 48*sp[k1,k3]^2*sp[p1,p2]
      *m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 192*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*
      m + 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 48*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1
      ,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 160*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1] + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 - 320*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] + 176*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m^2 + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*
      sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]
      ^2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p2] + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m
       - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k1
      ,p2]*sp[k3,p2]*m + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 144*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2
       + 448*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 224*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 96*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 112*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 96*
      sp[k1,p2]^2*sp[k2,p1] - 80*sp[k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]
      ^2*sp[k2,p1]*m^2 + 96*sp[k1,p2]^2*sp[k3,p1] - 32*sp[k1,p2]^2*sp[
      k3,p1]*m - 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 224*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2] + 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m
       - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2] - 80*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 
      32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[3,4]*color[ - Cf^2*Na*
      Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[p1
       + p2]]^2*num[128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 128*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 
      128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 8*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 128*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*
      m^2 - 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,k3]*sp[k2,p2]
      *sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 8*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2]*m^3 + 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 
      288*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3] + amp[3,5]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[
       - k2 + p1]]*den[sp[p1 + p2]]*num[128*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] - 160*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 - 128*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 
      32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 - 
      256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 288*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m^3 + 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 128*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*
      m^2] + amp[3,6]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[
      sp[ - k2 + p2]]*den[sp[p1 + p2]]*num[ - 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 128
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p1]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 
      16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2] + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 64*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2]
       + amp[3,7]*color[ - Cf^2*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[p1 + 
      p2]]^2*num[128*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 192*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 16*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^3] + amp[3,8]*color[1/4*Ca^2*Na*
      Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*den[
      sp[p1 + p2]]*num[ - 80*sp[k1,k2]^2*sp[p1,p2] + 32*sp[k1,k2]^2*sp[
      p1,p2]*m - 176*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 72*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1
      ,k2]*sp[k1,p1]^2 + 32*sp[k1,k2]*sp[k1,p1]^2*m - 64*sp[k1,k2]*sp[
      k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 96*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 80
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
      *m + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1]*m - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m
       + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 128*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p1] - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2] + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 144*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[
      k1,k2]*sp[k3,p1]^2 - 8*sp[k1,k2]*sp[k3,p1]^2*m + 32*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 64
      *sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
      *m - 32*sp[k1,k3]^2*sp[p1,p2] - 8*sp[k1,k3]^2*sp[p1,p2]*m + 4*sp[
      k1,k3]^2*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1]^2 + 16*sp[k1,k3]*
      sp[k1,p1]^2*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 16*sp[k1,k3]*
      sp[k1,p1]*sp[k1,p2]*m + 144*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 192*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]
      *sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 32*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 
      16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 24*sp[k1,k3]*sp[k1,p2]*sp[k3
      ,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k1
      ,p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,p1]^2 + 24*sp[k1,k3]*
      sp[k2,p1]^2*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 24*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 8*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 144*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] - 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m^2 + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 40*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p2]*sp[
      p1,p2]*m^2 - 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 8*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m^2 - 80*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m - 8*
      sp[k1,p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m - 80*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 8*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 16
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 128*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m
       - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 8*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 + 32*sp[
      k1,p1]*sp[k3,p2]^2 - 24*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[
      k3,p2]^2*m^2 + 32*sp[k1,p2]^2*sp[k2,p1] - 8*sp[k1,p2]^2*sp[k2,p1]
      *m + 64*sp[k1,p2]^2*sp[k3,p1] - 16*sp[k1,p2]^2*sp[k3,p1]*m + 96*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ]*m + 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k3,p1]
      ^2*m + 4*sp[k1,p2]*sp[k3,p1]^2*m^2 - 32*sp[k1,p2]*sp[k3,p1]*sp[k3
      ,p2] + 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1]
      *sp[k3,p2]*m^2] + amp[3,9]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[p1 + p2]]*num[
       - 64*sp[k1,k2]^2*sp[p1,p2] + 24*sp[k1,k2]^2*sp[p1,p2]*m - 48*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 
      144*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,k2]*sp[k1,p2]
      *sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 8*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ] + 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1] - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k3,p1]^2 + 8*sp[k1,k2]*
      sp[k3,p1]^2*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 144*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       - 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2
      ] + 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 80*
      sp[k1,k3]*sp[k2,p1]^2 + 32*sp[k1,k3]*sp[k2,p1]^2*m - 80*sp[k1,k3]
      *sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 96*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m + 176*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 72*sp[k1,k3]*sp[k2
      ,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 32*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 96*sp[k1,k3]*sp[k3,p1]*sp[p1,
      p2] + 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*
      sp[p1,p2]^2 - 8*sp[k1,k3]*sp[p1,p2]^2*m + 4*sp[k1,k3]*sp[p1,p2]^2
      *m^2 + 8*sp[k1,p1]^2*sp[k2,k3]*m + 64*sp[k1,p1]^2*sp[k2,p1] - 32*
      sp[k1,p1]^2*sp[k2,p1]*m + 80*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]
      ^2*sp[k2,p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]^2*sp[
      p1,p2] + 16*sp[k1,p1]^2*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,k3]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 24*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 8*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]
      *m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p1] - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 32*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 48*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m
       + 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 80*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 64*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m
       - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[
      p1,p2]*m + 32*sp[k1,p1]*sp[k3,p2]^2 - 24*sp[k1,p1]*sp[k3,p2]^2*m
       + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 64*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]
       - 24*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*sp[
      p1,p2]*m^2 - 32*sp[k1,p2]^2*sp[k2,p1] + 8*sp[k1,p2]^2*sp[k2,p1]*m
       - 8*sp[k1,p2]^2*sp[k3,p1]*m + 4*sp[k1,p2]^2*sp[k3,p1]*m^2 + 144*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 40*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 40*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[
      k3,p1]^2*m - 32*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 + 24*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*
      m^2] + amp[3,11]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[p1 + p2]]*
      num[32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]^2 - 64*sp[k1,k2]*sp[k1,p1]^2*m
       + 128*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p1]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 48*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 320*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2] - 208*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 32*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 192*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] - 112*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p2
      ]*sp[p1,p2]*m^2 - 32*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1
      ,p2]*m + 64*sp[k1,k3]*sp[k1,p1]^2 - 32*sp[k1,k3]*sp[k1,p1]^2*m + 
      64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,
      p2]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,p1]*m - 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 32*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1]*m + 256*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 128
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2
       - 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2]*m + 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k3,
      p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 64*sp[k1,
      p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[
      k2,p2] + 64*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p1] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 128*sp[k1
      ,p1]*sp[k1,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 
      64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 32*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*
      m - 64*sp[k1,p1]*sp[k3,p2]^2 + 48*sp[k1,p1]*sp[k3,p2]^2*m - 8*sp[
      k1,p1]*sp[k3,p2]^2*m^2 - 64*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^
      2*sp[k2,p1]*m - 128*sp[k1,p2]^2*sp[k3,p1] + 32*sp[k1,p2]^2*sp[k3,
      p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 64
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[k3,p1]
      ^2*m + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 48*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2] + amp[3,12]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[p1 + p2]]*num[64
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2
      ] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1
      ]*sp[p1,p2]*m^2 - 640*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 480*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 112*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2
       + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^3 - 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m^2 + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 
      128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[
      p1,p2]*m^2 + 256*sp[k1,k3]*sp[p1,p2]^2 - 128*sp[k1,k3]*sp[p1,p2]^
      2*m + 16*sp[k1,k3]*sp[p1,p2]^2*m^2 + 64*sp[k1,p1]^2*sp[k2,k3] - 
      64*sp[k1,p1]^2*sp[k2,k3]*m + 16*sp[k1,p1]^2*sp[k2,k3]*m^2 - 64*
      sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]
      ^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 256*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p2] - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p2]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m + 896*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 608*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 8*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m^3 - 256*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 
      128*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k3,p2]*sp[
      p1,p2]*m^2 - 256*sp[k1,p2]^2*sp[k2,p1] + 128*sp[k1,p2]^2*sp[k2,p1
      ]*m - 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] - 416*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3 - 64*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 256*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2] + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 640*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 480
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m^2 + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^3 - 64*sp[k1,p2]*sp[
      k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[
      3,13]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]*den[sp[p1
       + p2]]*num[ - 128*sp[k1,k3]^2*sp[p1,p2] + 96*sp[k1,k3]^2*sp[p1,
      p2]*m - 16*sp[k1,k3]^2*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p1]^2
       + 64*sp[k1,k3]*sp[k1,p1]^2*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]
       + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 256*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1] - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 96*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2
      ]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k1,
      p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]
      *sp[k1,p2]*sp[k3,p1]*m^2 - 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 96
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 96*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 1024*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2] - 704*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m
       + 144*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2]*m^3 - 128*sp[k1,k3]*sp[p1,p2]^2 + 96*sp[k1,k3]*sp[p1,p2
      ]^2*m - 16*sp[k1,k3]*sp[p1,p2]^2*m^2 + 128*sp[k1,p1]^3 - 64*sp[k1
      ,p1]^3*m + 128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*sp[k1,p2]*m
       + 128*sp[k1,p1]^2*sp[k3,p1] - 64*sp[k1,p1]^2*sp[k3,p1]*m + 256*
      sp[k1,p1]^2*sp[k3,p2] - 64*sp[k1,p1]^2*sp[k3,p2]*m - 128*sp[k1,p1
      ]^2*sp[p1,p2] + 64*sp[k1,p1]^2*sp[p1,p2]*m - 128*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 96*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m^2 + 
      256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 192*sp[k1,p1]*sp[k1,p2]*sp[p1
      ,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2] + 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]
       + 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 1024*sp[k1,p1]*sp[k3,p2]^
      2 + 704*sp[k1,p1]*sp[k3,p2]^2*m - 144*sp[k1,p1]*sp[k3,p2]^2*m^2
       + 8*sp[k1,p1]*sp[k3,p2]^2*m^3 + 128*sp[k1,p1]*sp[k3,p2]*sp[p1,p2
      ] - 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2]*m^2 + 128*sp[k1,p2]^2*sp[k3,p1] - 96*sp[k1,p2]^2*sp[k3,
      p1]*m + 16*sp[k1,p2]^2*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k3,p1]^2
       - 96*sp[k1,p2]*sp[k3,p1]^2*m + 16*sp[k1,p2]*sp[k3,p1]^2*m^2 + 
      1024*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 704*sp[k1,p2]*sp[k3,p1]*sp[
      k3,p2]*m + 144*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 8*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2]*m^3 + 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 96*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2
      ]*m^2] + amp[3,14]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[
      sp[ - k2 - k3]]*den[sp[p1 + p2]]^2*num[128*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 64*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ]*m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,k3]*sp[k1,p2]
      *sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 
      32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k3,p2]*sp[
      p1,p2] - 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,
      p2]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2]
       + amp[3,15]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*den[sp[p1 + p2]]*
      num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p2]*sp[k3
      ,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p2
      ]*sp[p1,p2] - 80*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]^2 + 80*sp[k1,k2]
      *sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1]^2*m^2 - 96*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] + 80*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 320*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] - 176*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 8*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 - 
      256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 224*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 160*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 64*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[p1,p2]^2 + 48*
      sp[k1,k3]*sp[p1,p2]^2*m + 32*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]
      ^2*sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,
      p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 256*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2] + 144*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1] + 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k1,p2]*
      sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 80*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 192*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 32*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2] - 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 192*sp[k1,p2]^2*sp[k2,
      p1] - 112*sp[k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2
       - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] - 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k3,p1]^2 - 32*sp[k1
      ,p2]*sp[k3,p1]^2*m + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[3,16]*color[ - 1/2*Ca*Cf*Na*Tf
       + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[
       - k3 + p1]]*den[sp[p1 + p2]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2] - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 128*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 64*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*m - 64*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m
       + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k3
      ]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 96*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[
      p1,p2]*m - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 320*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 208*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]
      *m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 192*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2] - 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1]*m^2 - 256*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 128*sp[k1,k3
      ]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 
      64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k3]*sp[k3,p2]*sp[p1,
      p2]*m - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k3]*sp[p1,
      p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m + 32*sp[k1,p1]^2*sp[k2,k3] + 
      128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]^2*sp[k2,p1]*m + 64*sp[k1
      ,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*
      sp[k3,p2] - 64*sp[k1,p1]^2*sp[p1,p2] + 32*sp[k1,p1]^2*sp[p1,p2]*m
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[
      k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]
       - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 160*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1
      ,p1]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 
      64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,
      p2]*m + 64*sp[k1,p1]*sp[k3,p2]^2 - 48*sp[k1,p1]*sp[k3,p2]^2*m + 8
      *sp[k1,p1]*sp[k3,p2]^2*m^2 - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 
      16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,p2]^2*sp[k3,p1] + 
      16*sp[k1,p2]^2*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1,p2]*
      sp[k3,p1]^2 - 32*sp[k1,p2]*sp[k3,p1]^2*m - 64*sp[k1,p2]*sp[k3,p1]
      *sp[k3,p2] + 48*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 16*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[4,1]*color[ - 1/4*Ca^2*Na*Tf]
      *den[sp[ - k1 + p1]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[8*sp[
      k1,k2]*sp[p1,p2] + 4*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2
      ]*m^2 + 40*sp[k1,k3]*sp[p1,p2] - 28*sp[k1,k3]*sp[p1,p2]*m + 4*sp[
      k1,k3]*sp[p1,p2]*m^2 - 16*sp[k1,p1]*sp[k2,p1] + 8*sp[k1,p1]*sp[k2
      ,p1]*m - 40*sp[k1,p1]*sp[k2,p2] + 28*sp[k1,p1]*sp[k2,p2]*m - 4*
      sp[k1,p1]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,p1]*
      sp[k3,p1]*m - 8*sp[k1,p1]*sp[k3,p2] - 4*sp[k1,p1]*sp[k3,p2]*m + 4
      *sp[k1,p1]*sp[k3,p2]*m^2 + 24*sp[k1,p2]*sp[k2,p1] - 20*sp[k1,p2]*
      sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2 - 24*sp[k1,p2]*sp[k3,p1]
       + 20*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[4,
      1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k2 + k3]]*
      den[sp[p1 + p2]]*num[ - 40*sp[k1,k2]*sp[p1,p2] + 28*sp[k1,k2]*sp[
      p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[p1,p2] - 4*
      sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p1]*
      sp[k2,p1] - 16*sp[k1,p1]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k2,p2] + 4*
      sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*m^2 + 16*sp[k1,p1]*
      sp[k3,p1] - 8*sp[k1,p1]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[k3,p2] - 28
      *sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*m^2 + 24*sp[k1,p2]
      *sp[k2,p1] - 20*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2
       - 24*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2
      ]*sp[k3,p1]*m^2] + amp[4,1]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[ - 48*sp[k1,k2]*sp[p1,
      p2] + 24*sp[k1,k2]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[p1,p2] + 24*sp[
      k1,k3]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,p1]*sp[k2,
      p1]*m + 48*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p2]*m + 48*
      sp[k1,p1]*sp[k3,p1] - 24*sp[k1,p1]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[
      k3,p2] - 24*sp[k1,p1]*sp[k3,p2]*m] + amp[4,2]*color[1/2*Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k2 + k3]]*den[sp[ - 
      k3 + p1]]*den[sp[p1 + p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 96*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 160*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 160*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p1]*m - 224*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 32
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k2]*sp[k3,p1]^2 - 48*sp[k1,k2
      ]*sp[k3,p1]^2*m + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 48*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m^2 + 192*sp[k1,k3]^2*sp[p1,p2] - 112*sp[k1,k3]^2*sp[p1,p2]*m + 
      16*sp[k1,k3]^2*sp[p1,p2]*m^2 + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]
       - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1]*m - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 144*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2
       + 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 80*sp[k1,k3]
      *sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 + 
      192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 112*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[
      k2,p1]^2 - 32*sp[k1,k3]*sp[k2,p1]^2*m + 96*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 192*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]
      ^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,
      p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 
      112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 224*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 80*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*
      m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1] - 80*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 320*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 176*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k2,p1]^2 + 80*sp[k1,p2]*sp[k2,p1]
      ^2*m - 16*sp[k1,p2]*sp[k2,p1]^2*m^2 + 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[4,3]*color[
      1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k2 + k3]]*den[sp[ - k3 + 
      p2]]*den[sp[p1 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 
      40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3
      ,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2] + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2]*m^2 + 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 48*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p1]*m + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m - 176*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 112*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*
      sp[k1,k2]*sp[k3,p1]^2 + 56*sp[k1,k2]*sp[k3,p1]^2*m - 128*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] + 56*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k3]^2*
      sp[p1,p2] + 56*sp[k1,k3]^2*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k3
      ]*sp[k1,p1]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 40*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2
      ] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1]*m - 112*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 48*sp[k1
      ,k3]*sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 
      56*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k2,p1]^2 + 
      16*sp[k1,k3]*sp[k2,p1]^2*m - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 
      16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p1] - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 128*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,k3]
      *sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 192*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 56*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p2]*sp[
      p1,p2]*m + 16*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,p2] - 
      16*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1
      ,p2]*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] - 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 224*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] - 72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m
       - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 144*sp[k1,p1]*sp[k2,p2]^2
       - 96*sp[k1,p1]*sp[k2,p2]^2*m + 16*sp[k1,p1]*sp[k2,p2]^2*m^2 + 16
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 - 48*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^2*sp[k2,
      p1]*m + 48*sp[k1,p2]^2*sp[k3,p1] - 16*sp[k1,p2]^2*sp[k3,p1]*m + 
      48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 40*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 80*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 48*
      sp[k1,p2]*sp[k2,p1]^2 + 16*sp[k1,p2]*sp[k2,p1]^2*m - 144*sp[k1,p2
      ]*sp[k2,p1]*sp[k2,p2] + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 16*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 40*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 48*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[
      4,4]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]*den[sp[k2 + k3]]*
      den[sp[p1 + p2]]^2*num[64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 64*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*
      m^2 + 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 64*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k1,p2]*sp[p1
      ,p2] - 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,
      p2]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 64*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2
       + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2] + amp[4,5]*
      color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[
      sp[ - k2 + p1]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[ - 192*sp[
      k1,k2]^2*sp[p1,p2] + 112*sp[k1,k2]^2*sp[p1,p2]*m - 16*sp[k1,k2]^2
      *sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 64
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p2] - 144*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 96*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m - 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 80*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 64*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 192*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 112*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 256*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1
      ] + 80*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k3,p1]^2 + 32*sp[k1,k2]*sp[k3,p1]
      ^2*m - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 80
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k1,p1]
      *sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 256
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k2,
      p1]^2 + 48*sp[k1,k3]*sp[k2,p1]^2*m - 128*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 160*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p1] - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 64*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m^2 + 224*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 32
      *sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
      *m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2*sp[k2,
      k3] + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m - 32*
      sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 128*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 448*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 24*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 192*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 80*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*
      m^2 - 320*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 176*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 96*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k3,
      p1]^2 - 80*sp[k1,p2]*sp[k3,p1]^2*m + 16*sp[k1,p2]*sp[k3,p1]^2*m^2
      ] + amp[4,6]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - 
      k2 + p2]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[128*sp[k1,k2]^2*
      sp[p1,p2] - 56*sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 160*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 96*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] + 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 112*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]
       - 48*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 56*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 192*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2] + 56*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 
      128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1]*m + 48*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]^2*m + 
      48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2]*m + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]
      *sp[p1,p2]*m + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 8*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m^2 + 128*sp[k1,k3]*sp[k2,p1]^2 - 56*sp[k1,k3]*sp[k2,p1]^2*m + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 56*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m - 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 40*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2
      ,p2]*sp[p1,p2]*m^2 - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 176*sp[k1
      ,k3]*sp[k3,p2]*sp[p1,p2] - 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 
      16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 16*sp[k1,p1]^2*sp[k2,k3]
       + 16*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 48*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*
      m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1] + 40*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 224*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p2] + 72*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 48*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*
      m - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 8*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m^2 - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2]*m - 144*sp[k1,p1]*sp[k3,p2]^2 + 96*sp[k1,p1]*sp[
      k3,p2]^2*m - 16*sp[k1,p1]*sp[k3,p2]^2*m^2 - 48*sp[k1,p2]^2*sp[k2,
      p1] + 16*sp[k1,p2]^2*sp[k2,p1]*m + 48*sp[k1,p2]^2*sp[k3,p1] - 16*
      sp[k1,p2]^2*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] + 40*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 40*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1]*m + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 48*sp[k1,p2]*sp[
      k3,p1]^2 - 16*sp[k1,p2]*sp[k3,p1]^2*m + 144*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2] - 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m^2] + amp[4,7]*color[ - 1/2*Ca*Cf*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]^2*num[ - 128*sp[k1
      ,k2]*sp[k1,p2]*sp[p1,p2] + 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 
      32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2] + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2
       + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k3]
      *sp[k3,p2]*sp[p1,p2] + 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2] + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2]*m^2] + amp[4,8]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[96
      *sp[k1,k2]^2*sp[p1,p2] - 40*sp[k1,k2]^2*sp[p1,p2]*m + 4*sp[k1,k2]
      ^2*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 8*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 96
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]
      *m - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m - 12*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 4*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1]*m^2 - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 104
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 40*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2
       - 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m^2 - 24*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*
      m - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 12*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2
       + 96*sp[k1,k3]^2*sp[p1,p2] - 40*sp[k1,k3]^2*sp[p1,p2]*m + 4*sp[
      k1,k3]^2*sp[p1,p2]*m^2 - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 12*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ]*m - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 24*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 - 48*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 96*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 104*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 48*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[
      k1,k3]*sp[k2,p1]^2*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2
      ,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 
      4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2] + 40*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m^2 - 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 176*sp[k1,p1]^2*sp[k2,k3] - 48*sp[
      k1,p1]^2*sp[k2,k3]*m + 176*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 48*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]
       + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 104*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 104*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 104*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m + 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 4*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,p1]*sp[k2,p2]^2 - 40
      *sp[k1,p1]*sp[k2,p2]^2*m + 4*sp[k1,p1]*sp[k2,p2]^2*m^2 + 12*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2
       + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 24*sp[k1,p1]*sp[k3
      ,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 + 96*sp[k1
      ,p1]*sp[k3,p2]^2 - 40*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3
      ,p2]^2*m^2 + 176*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m - 24*sp[k1,p2]*sp[k2,p1]^2*m + 4*sp[k1,p2]*sp[
      k2,p1]^2*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 40*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 24*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m^2 - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 4*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 48*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 24*sp[k1,p2]*sp[k3,p1]^2*m + 4*sp[
      k1,p2]*sp[k3,p1]^2*m^2 - 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 40*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]
      *m^2] + amp[4,9]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[
      sp[ - k2 + p2]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[ - 72*sp[k1
      ,k2]^2*sp[p1,p2] + 28*sp[k1,k2]^2*sp[p1,p2]*m - 48*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2] + 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 112*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 
      40*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 12*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p2]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 12*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m - 56*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 24*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
       - 28*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 40*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 80*
      sp[k1,k2]*sp[k2,p1]^2 - 32*sp[k1,k2]*sp[k2,p1]^2*m + 80*sp[k1,k2]
      *sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 48*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*
      m - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 44*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k3,p1]^2 - 24*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 12*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[p1,p2]^2 - 8*sp[k1,k2]*sp[p1,p2]^2*
      m + 104*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m - 88*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 24
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 120*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2] + 44*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]^2 + 32*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 104*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 56*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 20*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m + 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k3,p2]*sp[p1,p2
      ] - 20*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[p1,p2]^2
       + 32*sp[k1,k3]*sp[p1,p2]^2*m - 40*sp[k1,p1]^2*sp[k2,k3] + 16*sp[
      k1,p1]^2*sp[k2,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*
      sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]^2*sp[k3,p2
      ]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 8*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2]*m - 72*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 88*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p1] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 88*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 48
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m - 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m - 80*sp[k1,p1]*sp[k2,p1]^2 + 40*sp[k1,p1]*sp[k2,p1]^2
      *m + 104*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 36*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p1]*m + 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 20*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 
      32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 160*sp[k1,p1]*sp[k2,p2]^2 - 
      68*sp[k1,p1]*sp[k2,p2]^2*m - 136*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 
      40*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]
      *sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*
      sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 80*sp[
      k1,p1]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m
       - 72*sp[k1,p1]*sp[k3,p2]^2 + 28*sp[k1,p1]*sp[k3,p2]^2*m + 80*sp[
      k1,p1]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m
       + 56*sp[k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m - 56*sp[
      k1,p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m - 16*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 40*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m - 120*sp[k1,p2]*sp[k2,p1]^2 + 44*sp[k1,p2]*sp[k2,p1]^2*m
       - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 36*sp[k1,p2]*sp[k2,p1]*sp[
      k2,p2]*m - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m - 112*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 36*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 8*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] - 36*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p2]*
      sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m + 40*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2] - 12*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 64
      *sp[k1,p2]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]
      *m] + amp[4,10]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[
      sp[k2 + k3]]*den[sp[ - k3 + p2]]*den[sp[p1 + p2]]*num[48*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2] - 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 104*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*
      m - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m + 88*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m - 56*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 120*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2] - 44*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 104*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 48*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m
       - 56*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m - 56*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 20*sp[k1,k2]*sp[k2,
      p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,
      p1]^2*m + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 20*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 12*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[p1,p2]^2 - 32*
      sp[k1,k2]*sp[p1,p2]^2*m + 72*sp[k1,k3]^2*sp[p1,p2] - 28*sp[k1,k3]
      ^2*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 12*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 112*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]
       + 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 40*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2] + 12*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 56*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 72*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 28*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*
      m + 56*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[
      p1,p2]*m - 40*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 12*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,p1]^2 + 24*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[k3,p1]^2 + 32*sp[k1,k3]*sp[
      k3,p1]^2*m - 80*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[
      k3,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,
      k3]*sp[k3,p1]*sp[p1,p2]*m + 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 
      44*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[p1,p2]^2 + 8
      *sp[k1,k3]*sp[p1,p2]^2*m + 40*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1
      ]^2*sp[k2,k3]*m - 104*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[
      k2,p2]*m - 40*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m
       + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 72*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1]*m - 88*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 8*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]
       - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 88*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2] + 20*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 
      40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1]*m + 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 40*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[p1,p2
      ] + 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 72*sp[k1,p1]*sp[k2,p2]^2
       - 28*sp[k1,p1]*sp[k2,p2]^2*m - 136*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       + 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,
      p1]*sp[k3,p1]^2 - 40*sp[k1,p1]*sp[k3,p1]^2*m - 104*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2] + 36*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,
      p1]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 
      160*sp[k1,p1]*sp[k3,p2]^2 + 68*sp[k1,p1]*sp[k3,p2]^2*m - 16*sp[k1
      ,p1]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 
      56*sp[k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m - 56*sp[k1,
      p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m - 40*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1] + 12*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m - 40*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 12*sp[k1,p2]*sp[k2,p1]*sp[
      k2,p2]*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 36*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 112*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1] - 36*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p2]
      *sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m + 120*sp[k1,p2]*
      sp[k3,p1]^2 - 44*sp[k1,p2]*sp[k3,p1]^2*m + 96*sp[k1,p2]*sp[k3,p1]
      *sp[k3,p2] - 36*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*
      sp[k3,p1]*sp[p1,p2] + 8*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[
      k1,p2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m]
       + amp[4,11]*color[Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 - p2]]
      *den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[ - 96*
      sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m - 96*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 192*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 96*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*
      sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m + 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 
      32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k3
      ,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 96*sp[k1,k3]*
      sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 48*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k3
      ,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 192*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2] - 80*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 8*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 352*sp[k1,p1]^2*sp[k2,k3] + 
      96*sp[k1,p1]^2*sp[k2,k3]*m - 352*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 
      96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 352*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k2,
      p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 192*
      sp[k1,p1]*sp[k2,p2]^2 + 80*sp[k1,p1]*sp[k2,p2]^2*m - 8*sp[k1,p1]*
      sp[k2,p2]^2*m^2 - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ]*m^2 - 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]
      *sp[k3,p2]*m - 192*sp[k1,p1]*sp[k3,p2]^2 + 80*sp[k1,p1]*sp[k3,p2]
      ^2*m - 8*sp[k1,p1]*sp[k3,p2]^2*m^2 - 704*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] + 368*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m^2 + 96*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[
      k2,p1]^2*m + 192*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 80*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 96*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]
      *sp[k3,p1]^2*m + 192*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 80*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2] + 
      amp[4,12]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 - 
      p2]]*den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[32
      *sp[k1,k2]^2*sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 32*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 64*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]
      *sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 16*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[
      p1,p2]^2 + 32*sp[k1,k2]*sp[p1,p2]^2*m + 128*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1
      ,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 
      64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2] - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[p1,p2]
      ^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 64*sp[k1,p1]^2*sp[k2,k3] + 32*
      sp[k1,p1]^2*sp[k2,k3]*m + 64*sp[k1,p1]^2*sp[k2,p1] - 32*sp[k1,p1]
      ^2*sp[k2,p1]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 128*sp[k1,p1]^2*sp[k3
      ,p1] - 64*sp[k1,p1]^2*sp[k3,p1]*m - 32*sp[k1,p1]^2*sp[k3,p2] - 64
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
      *m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m + 160*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]
       - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 192*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[
      k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,
      p1]*sp[k2,p2]^2 - 48*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,
      p2]^2*m^2 + 160*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2
       + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2]*m - 128*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,p1]*sp[k3
      ,p1]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p1
      ]*sp[k3,p2]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 96*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 32*sp[k1,p2]*sp[k2,p1]^2 + 16*sp[k1,p2]*sp[k2,p1]^2*m - 
      64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 256*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 24*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 256*sp[k1,p2]*sp[k2,p1]*sp[p1
      ,p2] - 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,
      p1]*sp[p1,p2]*m^2 - 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 112*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2
       + 320*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 208*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m + 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[4,13]*
      color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]]*den[sp[
      k2 + k3]]*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[32*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 128*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*
      m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 64*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 64
      *sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 32*sp[k1,k3
      ]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 32*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k3,p1
      ]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[p1,p2]^2 - 32*
      sp[k1,k3]*sp[p1,p2]^2*m + 64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]
      ^2*sp[k2,k3]*m - 128*sp[k1,p1]^2*sp[k2,p1] + 64*sp[k1,p1]^2*sp[k2
      ,p1]*m + 32*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k3,p1] + 32
      *sp[k1,p1]^2*sp[k3,p1]*m + 64*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 160*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m - 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m - 160*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 
      64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2
      ] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*
      sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[
      k3,p2]^2 + 48*sp[k1,p1]*sp[k3,p2]^2*m - 8*sp[k1,p1]*sp[k3,p2]^2*
      m^2 - 128*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 32
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m + 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 320*sp[k1,p2
      ]*sp[k2,p1]*sp[p1,p2] + 208*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 32*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 256*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1] + 160*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[k3
      ,p1]^2*m + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 48*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 256*sp[k1
      ,p2]*sp[k3,p1]*sp[p1,p2] + 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 
      16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[4,14]*color[Ca*Cf*Na*
      Tf]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]^2*num[
      192*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p2]*sp[p1
      ,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 
      16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2]*m^2 + 192*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 128*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 352*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 272*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2] + amp[5,1]*color[1/2*
      Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k2 - p2]]
      *num[ - 24*sp[k1,k2]*sp[k1,p1] + 12*sp[k1,k2]*sp[k1,p1]*m - 48*
      sp[k1,k2]*sp[k2,p1] + 24*sp[k1,k2]*sp[k2,p1]*m + 12*sp[k1,k2]*sp[
      k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[p1,p2] - 24*
      sp[k1,k2]*sp[p1,p2]*m + 12*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[
      k2,p1]*m - 12*sp[k1,k3]*sp[p1,p2] + 12*sp[k1,k3]*sp[p1,p2]*m + 24
      *sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1]*sp[k1,p2]*m - 12*sp[k1,p1]*
      sp[k2,k3] + 12*sp[k1,p1]*sp[k2,k3]*m + 24*sp[k1,p1]*sp[k2,p1] - 
      12*sp[k1,p1]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,p1]*
      sp[k2,p2]*m + 12*sp[k1,p1]*sp[k3,p2] - 12*sp[k1,p1]*sp[k3,p2]*m
       - 24*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,
      p2]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,p1]*m - 12*sp[k1,p2]*sp[k3,p1]
       + 12*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[p1,p2] + 24*sp[k1,
      p2]*sp[p1,p2]*m] + amp[5,1]*color[Ca^2*Na*Tf]*den[sp[ - k1 + p1]]
      *den[sp[k1 - p1]]*den[sp[k2 - p2]]*num[ - 24*sp[k1,k2]*sp[k1,p1]
       + 12*sp[k1,k2]*sp[k1,p1]*m - 48*sp[k1,k2]*sp[k2,p1] + 24*sp[k1,
      k2]*sp[k2,p1]*m + 12*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]
      *m + 48*sp[k1,k2]*sp[p1,p2] - 24*sp[k1,k2]*sp[p1,p2]*m + 12*sp[k1
      ,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[k2,p1]*m - 12*sp[k1,k3]*sp[p1,p2
      ] + 12*sp[k1,k3]*sp[p1,p2]*m + 24*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,
      p1]*sp[k1,p2]*m - 12*sp[k1,p1]*sp[k2,k3] + 12*sp[k1,p1]*sp[k2,k3]
      *m + 24*sp[k1,p1]*sp[k2,p1] - 12*sp[k1,p1]*sp[k2,p1]*m - 96*sp[k1
      ,p1]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,p2]*m + 12*sp[k1,p1]*sp[k3,p2
      ] - 12*sp[k1,p1]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,
      p1]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,p1]
      *m - 12*sp[k1,p2]*sp[k3,p1] + 12*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1
      ,p2]*sp[p1,p2] + 24*sp[k1,p2]*sp[p1,p2]*m] + amp[5,2]*color[1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[sp[k2 - p2]]*
      den[sp[ - k3 + p1]]*num[32*sp[k1,k2]^2*sp[k3,p1] + 8*sp[k1,k2]^2*
      sp[k3,p1]*m - 4*sp[k1,k2]^2*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 24*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 96*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*
      m - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]^2 + 16*sp[k1,k2]*sp[k1,p1]^2*m
       - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,p1]*sp[
      k2,k3]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 + 64*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 192*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 
      144*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2]*m - 176*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 72*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k2]
      *sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 
      144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 112*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 32*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m
       + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m^2 + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2
       + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 24*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m - 64*sp[k1,k2]*sp[p1,p2]^2 + 24*sp[k1,k2]*sp[p1,p2]^2*m
       + 64*sp[k1,k3]^2*sp[k2,p1] - 16*sp[k1,k3]^2*sp[k2,p1]*m - 32*sp[
      k1,k3]^2*sp[p1,p2] + 8*sp[k1,k3]^2*sp[p1,p2]*m - 64*sp[k1,k3]*sp[
      k1,p1]*sp[k1,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 16
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,k3]*sp[k1,p1]
      *sp[k3,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1
      ,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2
       + 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 40*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,
      k3]*sp[k2,p1] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m^2 - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]^2*m - 4*
      sp[k1,k3]*sp[k2,p1]^2*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 24
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 32*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m + 64*sp[k1,p1]^2*sp[k1,p2] - 32*sp[k1,p1]^2*sp[k1,p2]*m + 16*
      sp[k1,p1]^2*sp[k2,k3]*m + 80*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]
      ^2*sp[k2,p2]*m - 8*sp[k1,p1]^2*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 4*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1
      ] + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 80*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[
      k1,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,
      p1]*sp[k2,k3]^2 - 24*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,
      k3]^2*m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 
      24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m^2 + 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 8*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,p2]^2*
      sp[k3,p1] - 32*sp[k1,p2]^2*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 80*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2] - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 32
      *sp[k1,p2]*sp[k2,p1]^2 + 8*sp[k1,p2]*sp[k2,p1]^2*m - 16*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 144*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m + 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1]*m] + amp[5,3]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 - p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[
       - 80*sp[k1,k2]^2*sp[k3,p1] + 32*sp[k1,k2]^2*sp[k3,p1]*m - 32*sp[
      k1,k2]^2*sp[p1,p2] + 8*sp[k1,k2]^2*sp[p1,p2]*m + 80*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1] - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 64
      *sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
      *m + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k1,p2]*m + 80*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 88*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 40*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 56*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 
      48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 20*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,k2]*sp[
      k2,k3]*sp[k2,p1]*m - 56*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 20*sp[k1,
      k2]*sp[k2,k3]*sp[k3,p1]*m + 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 
      32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k2,
      p2]*m + 56*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m + 56*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
       - 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 112*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2] - 44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 120*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] - 44*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 40*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 12*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m + 72*sp[k1,k2]*sp[p1,p2]^2 - 28*sp[k1,k2]*sp[p1,p2]^2*m
       + 24*sp[k1,k3]^2*sp[p1,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 
      32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 72*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 136*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 88*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m
       - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m - 104*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 32*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] + 12*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 56*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[k1,k3]*sp[k2,p1]^2*m
       + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 36*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m - 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 12*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 104*sp[k1,p1]^2*sp[k2,k3]
       - 32*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2] + 16*sp[
      k1,p1]^2*sp[k2,p2]*m - 40*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*
      sp[k3,p2]*m + 80*sp[k1,p1]*sp[k1,p2]^2 - 40*sp[k1,p1]*sp[k1,p2]^2
      *m + 136*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 20*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 8*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1]*m - 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 36*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,p2]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 
      48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3
      ,p2] - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 112*sp[k1,p1]*sp[k1,p2
      ]*sp[p1,p2] + 40*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 72*sp[k1,p1]*
      sp[k2,k3]^2 - 28*sp[k1,p1]*sp[k2,k3]^2*m + 88*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m
       - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 12*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,
      p1]*sp[k2,p2]*m - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k2,p2]^2 + 68*sp[k1,p1]
      *sp[k2,p2]^2*m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 4*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
       + 12*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 120*sp[k1,p2]^2*sp[k2,p1]
       - 44*sp[k1,p2]^2*sp[k2,p1]*m - 16*sp[k1,p2]^2*sp[k3,p1] + 32*sp[
      k1,p2]^2*sp[k3,p1]*m - 80*sp[k1,p2]^2*sp[p1,p2] + 32*sp[k1,p2]^2*
      sp[p1,p2]*m - 112*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 36*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m - 56*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 56*sp[k1,p2]*sp[k2,p1]^2
       + 16*sp[k1,p2]*sp[k2,p1]^2*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
       - 36*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 56*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 72*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2] + 28*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 16
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
      *m - 80*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*
      sp[p1,p2]*m] + amp[5,5]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*num[ - 8*
      sp[k1,k2]^2*sp[k3,p1]*m + 4*sp[k1,k2]^2*sp[k3,p1]*m^2 + 32*sp[k1,
      k2]^2*sp[p1,p2] - 8*sp[k1,k2]^2*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 4*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1]*m^2 + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]
      *m - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 + 64*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 8*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k2
      ,p1] + 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m
       - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 112*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m - 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*m
       + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 144*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*
      m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[
      k2,p1]^2 - 8*sp[k1,k3]*sp[k2,p1]^2*m + 4*sp[k1,k3]*sp[k2,p1]^2*
      m^2 + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 176*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       - 72*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 40
      *sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[p1,p2]^2 + 32*
      sp[k1,k3]*sp[p1,p2]^2*m + 16*sp[k1,p1]^2*sp[k2,k3]*m + 32*sp[k1,
      p1]^2*sp[k2,p1] - 16*sp[k1,p1]^2*sp[k2,p1]*m + 80*sp[k1,p1]^2*sp[
      k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m - 8*sp[k1,p1]^2*sp[k3,p2]*m
       - 64*sp[k1,p1]^2*sp[p1,p2] + 32*sp[k1,p1]^2*sp[p1,p2]*m - 4*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 144*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k1
      ,p2]*sp[k3,p1]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,p1
      ]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,k3]^2 - 24*sp[k1,p1]
      *sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 64*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p1] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m^2 + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 24*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*
      m^2 + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1]*m - 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[
      k3,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 80*sp[k1,
      p1]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 64
      *sp[k1,p2]^2*sp[k2,p1] - 24*sp[k1,p2]^2*sp[k2,p1]*m - 144*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 32
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 24*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 24*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k3,p1]^2 - 8*
      sp[k1,p2]*sp[k3,p1]^2*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]] + 
      amp[5,6]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1
      ]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*num[24*sp[k1,k2]^2*sp[k3,
      p1]*m - 4*sp[k1,k2]^2*sp[k3,p1]*m^2 + 24*sp[k1,k2]^2*sp[p1,p2] - 
      16*sp[k1,k2]^2*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 
      40*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1]*m^2 - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 24*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 + 
      96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p1]*m + 104*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,p2]*m + 12*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m^2 - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1
      ] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 24*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1] - 40*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m
       + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] - 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 
      16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 128
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
      *m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[
      k1,p2]*sp[p1,p2] - 40*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 4*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m
       - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 12*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*
      sp[k2,p1]^2 + 40*sp[k1,k3]*sp[k2,p1]^2*m - 4*sp[k1,k3]*sp[k2,p1]^
      2*m^2 - 104*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,k3]*sp[k2,p1
      ]*sp[k2,p2]*m - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m^2 + 176*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1]*m + 104*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 4*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[p1,p2]^2 + 40
      *sp[k1,k3]*sp[p1,p2]^2*m - 4*sp[k1,k3]*sp[p1,p2]^2*m^2 + 176*sp[
      k1,p1]^2*sp[k2,p2] - 48*sp[k1,p1]^2*sp[k2,p2]*m + 12*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 48*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m - 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 48*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 16*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k2,k3]^2 + 40*
      sp[k1,p1]*sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 24*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m^2
       + 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 8*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 12*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2
       - 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 176*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m - 104*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k3,p2]^2 + 40*sp[k1,
      p1]*sp[k3,p2]^2*m - 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 24*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 - 24*
      sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^2*sp[k2,p1]*m + 24*sp[k1,p2]
      ^2*sp[k3,p1]*m - 4*sp[k1,p2]^2*sp[k3,p1]*m^2 - 48*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m^2 + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1
      ] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 40*sp[k1,
      p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2
       + 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,p2]*sp[k3,p1]*sp[
      p1,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[5,7]*color[
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[sp[k2 - 
      p2]]*den[sp[p1 + p2]]*num[64*sp[k1,k2]^2*sp[p1,p2] - 24*sp[k1,k2]
      ^2*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 40*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m^2 + 144*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,
      k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 24
      *sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k1,p2
      ]*sp[p1,p2] + 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 64*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 
      24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k3,p1
      ]^2 - 8*sp[k1,k2]*sp[k3,p1]^2*m + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2
      ] - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 144*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 4*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m^2 + 80*sp[k1,k3]*sp[k2,p1]^2 - 32*sp[k1,k3]*sp[k2,p1]^2*
      m + 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m - 176*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 72*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m^2 - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 96*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2
       + 32*sp[k1,k3]*sp[p1,p2]^2 + 8*sp[k1,k3]*sp[p1,p2]^2*m - 4*sp[k1
      ,k3]*sp[p1,p2]^2*m^2 - 8*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2
      *sp[k2,p1] + 32*sp[k1,p1]^2*sp[k2,p1]*m - 80*sp[k1,p1]^2*sp[k2,p2
      ] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 16*sp[k1,p1]^2*sp[k3,p2]*m + 32*
      sp[k1,p1]^2*sp[p1,p2] - 16*sp[k1,p1]^2*sp[p1,p2]*m - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 80*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m
       + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 24*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 
      192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]
      *sp[k3,p1]*m - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 80*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,
      p1]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p2]^2 + 24*sp[k1,
      p1]*sp[k3,p2]^2*m - 4*sp[k1,p1]*sp[k3,p2]^2*m^2 - 64*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2] + 24*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[
      k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 + 32*sp[k1,p2]^2*sp[k2,p1] - 8*sp[
      k1,p2]^2*sp[k2,p1]*m + 8*sp[k1,p2]^2*sp[k3,p1]*m - 4*sp[k1,p2]^2*
      sp[k3,p1]*m^2 - 144*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 4*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 112*sp[k1,p2]*sp[k2,k3]*sp[p1
      ,p2] - 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] + 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k3,p1]^2
       + 16*sp[k1,p2]*sp[k3,p1]^2*m + 32*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]
       - 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[
      k3,p2]*m^2 - 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*sp[
      k3,p1]*sp[p1,p2]*m^2] + amp[5,8]*color[1/2*Ca^2*Na*Tf]*den[sp[ - 
      k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 - k3]]*den[sp[k2 - p2]]*
      num[ - 56*sp[k1,k2]^2*sp[k1,p1] + 28*sp[k1,k2]^2*sp[k1,p1]*m + 24
      *sp[k1,k2]^2*sp[k3,p1] - 12*sp[k1,k2]^2*sp[k3,p1]*m - 24*sp[k1,k2
      ]^2*sp[p1,p2] + 12*sp[k1,k2]^2*sp[p1,p2]*m - 40*sp[k1,k2]*sp[k1,
      k3]*sp[k1,p1] + 20*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 24*sp[k1,k2]
      *sp[k1,k3]*sp[k2,p1] + 12*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 8*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 
      8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m + 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k2]*sp[k1,p1]*
      sp[k1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 4*sp[k1,k2]*sp[k1
      ,p1]*sp[k2,k3]*m + 224*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 56*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 4*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1
      ] - 20*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 24*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 12*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2]*m + 72*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,k2]*sp[k2,k3]
      *sp[k2,p1]*m - 44*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2]*m - 72*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 
      32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p1] - 12*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 200*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2] + 12*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 
      44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k2,p2]*sp[p1,
      p2]*m - 8*sp[k1,k2]*sp[k3,p1]^2 + 4*sp[k1,k2]*sp[k3,p1]^2*m - 4*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2] - 8*sp[k1,k2]*sp[p1,p2]^2 + 4*sp[k1,k2]*sp[p1,p2]^2*m + 8*
      sp[k1,k3]^2*sp[k2,p1] - 4*sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^
      2*sp[p1,p2] + 8*sp[k1,k3]^2*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k1,p1]*
      sp[k1,p2] - 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 80*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1] - 20*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
      *m + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m - 160*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 40*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 8*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 8*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[
      p1,p2] + 8*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 44*sp[k1,k3]*sp[k2,
      k3]*sp[k2,p1] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 32*sp[k1,k3]
      *sp[k2,k3]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 52*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m - 24*sp[k1,k3]*sp[k2,p1]^2 + 12*sp[k1,k3]*sp[k2,p1]^2*m + 4*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]
      *m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 52*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*
      sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*
      m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 8*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2]*m + 72*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k3,
      p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[p1,p2]^2 + 8*sp[k1,k3]*sp[p1,p2
      ]^2*m - 104*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,k3]*m + 
      104*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k2,p2]*m + 208*sp[
      k1,p1]^2*sp[k3,p2] - 64*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 80*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m
       - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p2]*m - 160*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p2]*m + 52*sp[k1,p1]*sp[k2,k3]^2 - 28*sp[k1,p1]*
      sp[k2,k3]^2*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 4*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 56*sp[k1,p1]*sp[
      k2,p1]^2 + 28*sp[k1,p1]*sp[k2,p1]^2*m + 8*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2] - 4*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 40*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p1] + 20*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 40*
      sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 20*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*
      m + 52*sp[k1,p1]*sp[k2,p2]^2 - 28*sp[k1,p1]*sp[k2,p2]^2*m + 32*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 72*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,p1]
      *sp[k3,p1]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 40*
      sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 88*sp[k1,p1]*sp[k3,p2]^2 + 40*
      sp[k1,p1]*sp[k3,p2]^2*m + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16*
      sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,p2]^2*sp[k2,p1] - 4*sp[
      k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k3,p1] - 8*sp[k1,p2]^2*
      sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m - 52*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,p2]*sp[k2,p1]^2 - 12*
      sp[k1,p2]*sp[k2,p1]^2*m - 44*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 24*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2] + 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m + 52*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,
      p2]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]^2 - 8*sp[k1,p2
      ]*sp[k3,p1]^2*m + 72*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 8*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]
       - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[5,9]*color[Ca^2*Na*
      Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[
      sp[k2 - p2]]*num[48*sp[k1,k2]^2*sp[k1,p1] - 32*sp[k1,k2]^2*sp[k1,
      p1]*m + 4*sp[k1,k2]^2*sp[k1,p1]*m^2 - 24*sp[k1,k2]^2*sp[p1,p2] + 
      16*sp[k1,k2]^2*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 8
      *sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k1,p2
      ]*m^2 - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,p1]
      *sp[k2,k3]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 192*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,p1] + 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 8*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m^2 - 104*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 48*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 8*sp[k1
      ,k2]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2
       + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1]*m - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m - 128*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 64*
      sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 80*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 24*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 24*
      sp[k1,k2]*sp[p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2*m - 128*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 48*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m
       + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k2,p1
      ]*sp[k2,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 176*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 48*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 40*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] + 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 304*sp[k1,p1]^2*
      sp[k2,p2] + 112*sp[k1,p1]^2*sp[k2,p2]*m + 48*sp[k1,p1]*sp[k1,p2]^
      2 - 32*sp[k1,p1]*sp[k1,p2]^2*m + 4*sp[k1,p1]*sp[k1,p2]^2*m^2 + 48
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 96*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p1]*m^2 + 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 48*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 
      64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p2]*m^2 - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k1,
      p2]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 + 96*sp[k1,
      p1]*sp[k2,k3]^2 - 40*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,
      k3]^2*m^2 + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m^2 - 40*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 
      96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 48*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m^2 + 48*sp[k1,p1]*sp[k2,p1]^2 - 32*sp[k1,p1]*
      sp[k2,p1]^2*m + 4*sp[k1,p1]*sp[k2,p1]^2*m^2 + 104*sp[k1,p1]*sp[k2
      ,p1]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 48*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]
       + 8*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 208*sp[k1,p1]*sp[k2,p2]^2 + 96*sp[k1,p1]*sp[k2,p2]^2
      *m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m + 40*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 104*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 48*sp[k1
      ,p1]*sp[k2,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k3,p2]^2 - 40*sp[k1,
      p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 96*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[
      k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 + 48*sp[k1,p1]*sp[p1,p2]^2 - 32*
      sp[k1,p1]*sp[p1,p2]^2*m + 4*sp[k1,p1]*sp[p1,p2]^2*m^2 + 24*sp[k1,
      p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m + 24*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p2]
      *sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m + 80*sp[k1,p2]*sp[k2,p1
      ]*sp[k2,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 40*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m
       - 128*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,p2]*sp[
      p1,p2]*m - 48*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2]*m] + amp[5,10]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1
       + p1]]*den[sp[k1 - p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*
      num[16*sp[k1,k2]^2*sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,p1]*m - 8*sp[
      k1,k2]^2*sp[p1,p2] + 4*sp[k1,k2]^2*sp[p1,p2]*m - 80*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m
       + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2]*m + 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k2]*sp[k1,p1
      ]*sp[k1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 8*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       - 40*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k2,
      k3]*sp[k2,p1]*m + 72*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,k2]
      *sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[
      k1,k2]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 8*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p1]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m - 52*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1]*m - 44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 24
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]^2 + 8*
      sp[k1,k2]*sp[k3,p1]^2*m - 52*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2] - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[p1,
      p2]^2 + 12*sp[k1,k2]*sp[p1,p2]^2*m + 16*sp[k1,k3]^2*sp[k2,p1] - 8
      *sp[k1,k3]^2*sp[k2,p1]*m - 8*sp[k1,k3]^2*sp[p1,p2] + 4*sp[k1,k3]^
      2*sp[p1,p2]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k3]*
      sp[k1,p1]*sp[k1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[
      k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]
       - 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 8*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k3,
      p1]*m - 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 12*sp[k1,k3]*sp[k1,p2]
      *sp[p1,p2]*m + 72*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 32*sp[
      k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 
      16*sp[k1,k3]*sp[k2,p1]^2 + 8*sp[k1,k3]*sp[k2,p1]^2*m - 52*sp[k1,
      k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m - 52*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1
      ,k3]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 
      16*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k3,p1]*sp[p1,
      p2] + 4*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 44*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[
      p1,p2]^2 + 12*sp[k1,k3]*sp[p1,p2]^2*m - 208*sp[k1,p1]^2*sp[k2,k3]
       + 64*sp[k1,p1]^2*sp[k2,k3]*m + 104*sp[k1,p1]^2*sp[k2,p2] - 32*
      sp[k1,p1]^2*sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1
      ]^2*sp[k3,p2]*m - 56*sp[k1,p1]*sp[k1,p2]^2 + 28*sp[k1,p1]*sp[k1,
      p2]^2*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 4*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 20*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p2] - 4*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 224*sp[k1,p1]*sp[k1,
      p2]*sp[p1,p2] - 56*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 88*sp[k1,p1]
      *sp[k2,k3]^2 + 40*sp[k1,p1]*sp[k2,k3]^2*m + 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 72*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m
       + 72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 40*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*
      sp[p1,p2] - 20*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 52*sp[k1,p1]*sp[
      k2,p2]^2 - 28*sp[k1,p1]*sp[k2,p2]^2*m + 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] + 4*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m
       + 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 20*sp[k1,p1]*sp[k3,p1]*sp[
      p1,p2]*m + 52*sp[k1,p1]*sp[k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2*m
       - 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 4*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2]*m - 56*sp[k1,p1]*sp[p1,p2]^2 + 28*sp[k1,p1]*sp[p1,p2]^2*m + 
      24*sp[k1,p2]^2*sp[k2,p1] - 12*sp[k1,p2]^2*sp[k2,p1]*m + 24*sp[k1,
      p2]^2*sp[k3,p1] - 12*sp[k1,p2]^2*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1] - 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 200*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,p2]*sp[k2,p1]^2 - 4*sp[k1,p2]*sp[k2,p1]^2*m - 44*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       + 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 12*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 8*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m - 72*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2]*
      sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k3,p1]^2 - 4*sp[k1,p2]*sp[
      k3,p1]^2*m - 44*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m + 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 12*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2]*m - 72*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 32
      *sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[5,11]*color[ - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[
      sp[k2 - p2]]*num[80*sp[k1,k2]^2*sp[k1,p1] - 40*sp[k1,k2]^2*sp[k1,
      p1]*m + 80*sp[k1,k2]^2*sp[k2,p1] - 32*sp[k1,k2]^2*sp[k2,p1]*m - 
      16*sp[k1,k2]^2*sp[k3,p1] + 32*sp[k1,k2]^2*sp[k3,p1]*m - 120*sp[k1
      ,k2]^2*sp[p1,p2] + 44*sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 48*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 
      104*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,
      p1]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3]*m - 112*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 
      40*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 104*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2] - 36*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 104*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 136*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2] - 20*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 24
      *sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 20*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 8*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 4*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]
       + 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 72*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2] - 28*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 96
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m - 56*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m + 56*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m + 112*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 36*sp[k1
      ,k2]*sp[k3,p2]*sp[p1,p2]*m + 56*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,
      k2]*sp[p1,p2]^2*m - 24*sp[k1,k3]^2*sp[k2,p1] - 80*sp[k1,k3]*sp[k1
      ,p1]*sp[k1,p2] + 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 88*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 24*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*
      m - 136*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 40*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2]*m + 72*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2]*m + 160*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 
      48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k3
      ,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2
      ]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] + 12*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m
       + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2] + 36*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 40*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m
       - 56*sp[k1,k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m + 40*sp[
      k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*
      sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m - 104*sp[k1,p1]^2*sp[k3,p2
      ] + 32*sp[k1,p1]^2*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 56*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 88*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 80
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]
      *m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 12*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k2,p2]^
      2 + 68*sp[k1,p1]*sp[k2,p2]^2*m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 40*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[k1,
      p1]*sp[k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2*m + 88*sp[k1,p1]*sp[k3
      ,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,p2
      ]^2*sp[k2,p1] - 8*sp[k1,p2]^2*sp[k2,p1]*m - 80*sp[k1,p2]^2*sp[k3,
      p1] + 32*sp[k1,p2]^2*sp[k3,p1]*m - 40*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1] + 12*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 120*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1] - 44*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 72*sp[
      k1,p2]*sp[k2,p1]^2 + 28*sp[k1,p2]*sp[k2,p1]^2*m + 112*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2] - 44*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 56*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] + 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,
      p2]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m - 56
      *sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 20*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]
      *m + 56*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m - 64*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[
      k3,p2]*sp[p1,p2]*m] + amp[5,13]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 - p1]]*den[sp[k1 - p2]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*
      num[ - 80*sp[k1,k2]^2*sp[k3,p1] + 32*sp[k1,k2]^2*sp[k3,p1]*m - 64
      *sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]
      *m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 96*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1] - 40*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 128*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] + 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]^2 - 32*
      sp[k1,k2]*sp[k1,p1]^2*m + 80*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1
      ] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 
      16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 176*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1] - 72*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m^2 - 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 24
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] - 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2]*m - 32*sp[k1,k2]*sp[p1,p2]^2 + 8*sp[k1,k2]*sp[p1,p2]^2*m - 
      32*sp[k1,k3]^2*sp[k2,p1] + 8*sp[k1,k3]^2*sp[k2,p1]*m + 64*sp[k1,
      k3]^2*sp[p1,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 8*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 32
      *sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 16*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,
      k3]*sp[k2,p1]*sp[k2,p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 32
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*
      m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 24
      *sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2
      ]*m^2 - 8*sp[k1,k3]*sp[p1,p2]^2*m + 4*sp[k1,k3]*sp[p1,p2]^2*m^2
       - 32*sp[k1,p1]^2*sp[k1,p2] + 16*sp[k1,p1]^2*sp[k1,p2]*m - 8*sp[
      k1,p1]^2*sp[k2,k3]*m - 80*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*
      sp[k2,p2]*m + 16*sp[k1,p1]^2*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 144*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 
      24*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p2]*m^2 - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 32*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 4*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*
      m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
      *m - 32*sp[k1,p1]*sp[k3,p2]^2 + 24*sp[k1,p1]*sp[k3,p2]^2*m - 4*
      sp[k1,p1]*sp[k3,p2]^2*m^2 + 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 4
      *sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 - 32*sp[k1,p2]^2*sp[k3,p1] - 8
      *sp[k1,p2]^2*sp[k3,p1]*m + 4*sp[k1,p2]^2*sp[k3,p1]*m^2 + 64*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 
      64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m - 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 112*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2] - 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,p2
      ]*sp[k2,p1]^2 + 24*sp[k1,p2]*sp[k2,p1]^2*m - 48*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] + 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 - 144*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ] - 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3
      ,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 24*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2]
       + amp[5,14]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2
       - k3]]*den[sp[k2 - p2]]*den[sp[p1 + p2]]*num[ - 72*sp[k1,k2]^2*
      sp[p1,p2] + 28*sp[k1,k2]^2*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] + 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 112*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 40*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] - 12*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 12*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m - 56*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,k2]
      *sp[k1,p1]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 28*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,k2]
      *sp[k2,p1]^2 - 32*sp[k1,k2]*sp[k2,p1]^2*m + 80*sp[k1,k2]*sp[k2,p1
      ]*sp[k2,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 24*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m
       + 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k2,p1]*sp[p1
      ,p2]*m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 44*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k3,p1]^2 - 24*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 48*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 12*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m
       + 32*sp[k1,k2]*sp[p1,p2]^2 - 8*sp[k1,k2]*sp[p1,p2]^2*m + 104*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m
       + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 88*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 120*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 44*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]
      ^2 + 32*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 104*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 56*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] - 20*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 48
      *sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
      *m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 20*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[p1,p2]^2 + 32*sp[k1,
      k3]*sp[p1,p2]^2*m - 40*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[
      k2,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m
       + 104*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]^2*sp[k3,p2]*m - 40*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 8*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2]*m - 72*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1]*m + 88*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1
      ] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 88*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 40
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
      *m - 80*sp[k1,p1]*sp[k2,p1]^2 + 40*sp[k1,p1]*sp[k2,p1]^2*m + 104*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 36*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p1]*m + 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2
      ,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p1
      ]*sp[k2,p1]*sp[p1,p2]*m + 160*sp[k1,p1]*sp[k2,p2]^2 - 68*sp[k1,p1
      ]*sp[k2,p2]^2*m - 136*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 8*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2
      ] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[
      k3,p1]*sp[p1,p2] - 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 72*sp[k1,
      p1]*sp[k3,p2]^2 + 28*sp[k1,p1]*sp[k3,p2]^2*m + 80*sp[k1,p1]*sp[k3
      ,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 56*sp[k1,p2
      ]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m - 56*sp[k1,p2]^2*sp[k3
      ,p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1] - 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 40*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 120*sp[k1
      ,p2]*sp[k2,p1]^2 + 44*sp[k1,p2]*sp[k2,p1]^2*m - 96*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2] + 36*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 112
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 36*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 36*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p2]
      *sp[k2,p2]*sp[p1,p2]*m + 40*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 12*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2
      ] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k3,p2]*
      sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[5,15]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[
      sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[ - 56*sp[k1,k2]^2*sp[k3,p1]
       + 16*sp[k1,k2]^2*sp[k3,p1]*m - 56*sp[k1,k2]^2*sp[p1,p2] + 16*sp[
      k1,k2]^2*sp[p1,p2]*m + 56*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 56*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       - 24*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 88*sp[k1,k2]*sp[k1,p1]*
      sp[k2,k3] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 40*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 72*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 40
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
      *m - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 8*sp[k1,k2]*sp[k1,p1]*sp[
      p1,p2]*m + 56*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m - 72*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 28*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m + 40*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1] - 12*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 112*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] - 36*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 8*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 36*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
       + 36*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] - 12*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 120
      *sp[k1,k2]*sp[p1,p2]^2 - 44*sp[k1,k2]*sp[p1,p2]^2*m + 88*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m - 104*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 20*sp[k1,
      k3]*sp[k2,k3]*sp[k2,p1]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[k2,p1]^2 + 32*
      sp[k1,k3]*sp[k2,p1]^2*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 12*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 120*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 44*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 20*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 48*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m - 104*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2]*m - 16*sp[k1,k3]*sp[p1,p2]^2 + 32*sp[k1,k3]*sp[p1,p2]^2
      *m - 104*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,k3]*m + 40*
      sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m + 40*sp[k1,p1]
      ^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] + 12*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 56*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 40*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p2] + 12*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m
       + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p1]*m + 112*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 40*sp[k1,p1]*sp[k1
      ,p2]*sp[p1,p2]*m - 72*sp[k1,p1]*sp[k2,k3]^2 + 28*sp[k1,p1]*sp[k2,
      k3]^2*m + 80*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 8*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       - 20*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 136*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 80*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 40
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p1]*
      sp[p1,p2]*m + 160*sp[k1,p1]*sp[k2,p2]^2 - 68*sp[k1,p1]*sp[k2,p2]^
      2*m - 136*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 4*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 104*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 36*sp[k1
      ,p1]*sp[k2,p2]*sp[p1,p2]*m - 88*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 
      32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*sp[p1
      ,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p2
      ]*sp[p1,p2] - 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,p1]*
      sp[p1,p2]^2 + 40*sp[k1,p1]*sp[p1,p2]^2*m + 72*sp[k1,p2]^2*sp[k2,
      p1] - 28*sp[k1,p2]^2*sp[k2,p1]*m - 12*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p2]*
      sp[k2,p1]^2 + 8*sp[k1,p2]*sp[k2,p1]^2*m - 112*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2] + 44*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 160*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 40*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2] + 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       - 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,p2]*sp[k2,p1]*sp[p1
      ,p2]*m + 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m + 80*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*
      sp[k2,p2]*sp[p1,p2]*m + 24*sp[k1,p2]*sp[k3,p1]^2 - 48*sp[k1,p2]*
      sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 80*sp[
      k1,p2]*sp[p1,p2]^2 + 32*sp[k1,p2]*sp[p1,p2]^2*m] + amp[5,16]*
      color[1/2*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[
      sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 96*sp[k1,k2]^2*sp[k3,p1]
       + 40*sp[k1,k2]^2*sp[k3,p1]*m - 4*sp[k1,k2]^2*sp[k3,p1]*m^2 + 96*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*
      m + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 12*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 48*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 
      8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] - 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 
      16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,k2]*sp[k2,p1]*sp[p1
      ,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 104*sp[k1,k2]*sp[k2,
      p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 12*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 48
      *sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[
      p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2*m + 176*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 40
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2
      ]*m^2 - 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 40*sp[k1,k3]*sp[k2,k3]
      *sp[k2,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 48*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k2,p1]^2*m - 4*
      sp[k1,k3]*sp[k2,p1]^2*m^2 + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 4*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m^2 - 24*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]
      *sp[p1,p2]*m^2 - 176*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 40*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]
      *m^2 + 24*sp[k1,k3]*sp[p1,p2]^2*m - 4*sp[k1,k3]*sp[p1,p2]^2*m^2
       - 176*sp[k1,p1]^2*sp[k2,p2] + 48*sp[k1,p1]^2*sp[k2,p2]*m - 12*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
      *m^2 + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]^2 - 40*
      sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 24*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m^2
       - 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 12*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2
       + 104*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m + 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2
      ,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p1]*m + 104*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 
      48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 104*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k3,
      p2]^2 - 40*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2
       - 24*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*sp[
      p1,p2]*m^2 - 96*sp[k1,p2]^2*sp[k3,p1] + 40*sp[k1,p2]^2*sp[k3,p1]*
      m - 4*sp[k1,p2]^2*sp[k3,p1]*m^2 - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ] + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 12*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 24*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[
      k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m - 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 104*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 + 96*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m
       + 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[6,1]*color[ - 1/2*
      Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k3 - p2]]
      *num[4*sp[k1,k2]*sp[k3,p1] + 16*sp[k1,k2]*sp[p1,p2] - 12*sp[k1,k2
      ]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p1] - 24*sp[k1,k3]*sp[k1,p1]*m
       + 4*sp[k1,k3]*sp[k1,p1]*m^2 + 4*sp[k1,k3]*sp[k2,p1] + 24*sp[k1,
      k3]*sp[k3,p1] - 8*sp[k1,k3]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[p1,p2]
       + 12*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1
      ]*sp[k1,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*m^2 - 20*sp[k1,p1]*sp[k2,k3
      ] + 16*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k2,k3]*m^2 - 32*sp[
      k1,p1]*sp[k2,p2] + 28*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,
      p2]*m^2 - 32*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,p1]*sp[k3,p1]*m - 4*
      sp[k1,p1]*sp[k3,p1]*m^2 + 48*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,p1]*
      sp[k3,p2]*m - 8*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]*m - 
      4*sp[k1,p1]*sp[p1,p2]*m^2 + 16*sp[k1,p2]*sp[k2,p1] - 12*sp[k1,p2]
      *sp[k2,p1]*m - 24*sp[k1,p2]*sp[k3,p1] + 12*sp[k1,p2]*sp[k3,p1]*m
       + 24*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,p2]*sp[p1,p2]*m] + amp[6,1]*
      color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[
      sp[k3 - p2]]*num[16*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*
      m + 4*sp[k1,k2]*sp[p1,p2] + 8*sp[k1,k3]*sp[k1,p1] - 12*sp[k1,k3]*
      sp[k1,p1]*m + 4*sp[k1,k3]*sp[k1,p1]*m^2 + 16*sp[k1,k3]*sp[k2,p1]
       - 12*sp[k1,k3]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k3,p1] + 16*sp[k1,
      k3]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[p1,p2] - 12*sp[k1,k3]*sp[p1,p2]
      *m + 32*sp[k1,p1]*sp[k1,p2] - 24*sp[k1,p1]*sp[k1,p2]*m + 4*sp[k1,
      p1]*sp[k1,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3] + 28*sp[k1,p1]*sp[k2,
      k3]*m - 4*sp[k1,p1]*sp[k2,k3]*m^2 - 20*sp[k1,p1]*sp[k2,p2] + 16*
      sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*m^2 - 8*sp[k1,p1]*
      sp[k3,p1] + 12*sp[k1,p1]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[k3,p1]*m^2
       - 48*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,
      p1]*sp[p1,p2] + 24*sp[k1,p1]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[p1,p2]*
      m^2 + 4*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p2]*sp[k3,p1] - 12*sp[k1,
      p2]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[p1,p2] + 8*sp[k1,p2]*sp[p1,p2]*
      m] + amp[6,1]*color[Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - 
      p1]]*den[sp[k3 - p2]]*num[12*sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*
      sp[k3,p1]*m - 12*sp[k1,k2]*sp[p1,p2] + 12*sp[k1,k2]*sp[p1,p2]*m
       - 24*sp[k1,k3]*sp[k1,p1] + 12*sp[k1,k3]*sp[k1,p1]*m + 12*sp[k1,
      k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,k3]*sp[k3,p1]
       + 24*sp[k1,k3]*sp[k3,p1]*m + 48*sp[k1,k3]*sp[p1,p2] - 24*sp[k1,
      k3]*sp[p1,p2]*m + 24*sp[k1,p1]*sp[k1,p2] - 12*sp[k1,p1]*sp[k1,p2]
      *m - 12*sp[k1,p1]*sp[k2,k3] + 12*sp[k1,p1]*sp[k2,k3]*m + 12*sp[k1
      ,p1]*sp[k2,p2] - 12*sp[k1,p1]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[k3,p1
      ] - 12*sp[k1,p1]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k3,p2] + 48*sp[k1,
      p1]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[p1,p2] + 12*sp[k1,p1]*sp[p1,p2]
      *m - 12*sp[k1,p2]*sp[k2,p1] + 12*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1
      ,p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[p1,p2
      ] + 24*sp[k1,p2]*sp[p1,p2]*m] + amp[6,2]*color[1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[sp[ - k3 + p1]]*den[sp[k3
       - p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 24*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 + 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*
      m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,k2]*
      sp[k3,p1]^2 - 8*sp[k1,k2]*sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]^2
      *m^2 + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 176*sp[k1,k2]*sp[k3,p1]
      *sp[p1,p2] - 72*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m^2 + 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 32*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[p1,p2]^2 + 32*sp[
      k1,k2]*sp[p1,p2]^2*m - 8*sp[k1,k3]^2*sp[k2,p1]*m + 4*sp[k1,k3]^2*
      sp[k2,p1]*m^2 + 32*sp[k1,k3]^2*sp[p1,p2] - 8*sp[k1,k3]^2*sp[p1,p2
      ]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3]*m^2 - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 8*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m
       - 80*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m^2 - 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 24*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[k1,k3]*
      sp[k2,p1]^2*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 4*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2] + 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m^2 + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 40*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 144*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2] + 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]^2*sp[k2,
      k3]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3,p1] - 16
      *sp[k1,p1]^2*sp[k3,p1]*m + 80*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1
      ]^2*sp[k3,p2]*m - 64*sp[k1,p1]^2*sp[p1,p2] + 32*sp[k1,p1]^2*sp[p1
      ,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 8*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1]*m - 144*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 8*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2
      ] - 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,k3]^2
       - 24*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*
      m + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1
      ,p1]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 
      16*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 80*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p1
      ]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 192*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m
       + 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2]*m + 64*sp[k1,p2]^2*sp[k3,p1] - 24*sp[k1,p2]^2*sp[k3,p1]*m
       - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1]*m - 144*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 24*sp[k1,p2]
      *sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p2]*sp[k2,p1]^2 - 8*sp[k1,p2]*
      sp[k2,p1]^2*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 24*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1]*m] + amp[6,3]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*
      den[sp[k1 - p1]]*den[sp[ - k3 + p2]]*den[sp[k3 - p2]]*num[96*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] - 40*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m
       + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 4
      *sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ]*m^2 + 96*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 40*sp[k1,k2]*sp[k1,p2]
      *sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 24*sp[k1,k2]
      *sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 12
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 + 176*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2]*m - 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 4*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]^2 + 40
      *sp[k1,k2]*sp[k3,p1]^2*m - 4*sp[k1,k2]*sp[k3,p1]^2*m^2 - 104*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m
       + 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 8*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 104*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 96*sp[k1,
      k2]*sp[p1,p2]^2 + 40*sp[k1,k2]*sp[p1,p2]^2*m - 4*sp[k1,k2]*sp[p1,
      p2]^2*m^2 + 24*sp[k1,k3]^2*sp[k2,p1]*m - 4*sp[k1,k3]^2*sp[k2,p1]*
      m^2 + 24*sp[k1,k3]^2*sp[p1,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m - 24*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]
      *m^2 + 12*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p1]*m + 104*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 48*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 24*sp[k1,k3]*
      sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 24*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m
       + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 40*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 24*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,
      k3]*sp[k2,p1]*sp[k2,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 4*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p1] - 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1]*m^2 - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 24*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m + 176*sp[k1,p1]^2*sp[k3,p2] - 48*sp[k1,p1]^2*sp[k3,p2]*m + 12*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
      *m^2 - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p2]*m^2 - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m - 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 48*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2
      ] - 16*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k2,k3]^2
       + 40*sp[k1,p1]*sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 96*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m
       - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 24*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 104*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 12*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
      *m^2 + 176*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p1]
      *sp[k3,p2]*m - 96*sp[k1,p1]*sp[k2,p2]^2 + 40*sp[k1,p1]*sp[k2,p2]^
      2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 12*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 104*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 24*sp[k1,p1
      ]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 
      24*sp[k1,p2]^2*sp[k2,p1]*m - 4*sp[k1,p2]^2*sp[k2,p1]*m^2 - 24*sp[
      k1,p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m - 48*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2] - 40*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2]*m^2 - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 4*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2
       + 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 24*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[6,4]
      *color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[
      sp[k3 - p2]]*den[sp[p1 + p2]]*num[48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ] - 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 8*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 64*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 4*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p1] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m
       + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m^2 + 80*sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,p1]^2*
      m + 80*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m - 176*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 72*sp[k1,k2]*sp[k3
      ,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 16*sp[k1
      ,k2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[p1,p2]^2 + 8*sp[k1,k2]
      *sp[p1,p2]^2*m - 4*sp[k1,k2]*sp[p1,p2]^2*m^2 + 64*sp[k1,k3]^2*sp[
      p1,p2] - 24*sp[k1,k3]^2*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p1]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k3
      ]*sp[k1,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 144*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*
      m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m^2 - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 8*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 24
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p1]^2 - 8*
      sp[k1,k3]*sp[k2,p1]^2*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 8*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m - 144*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 48*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,p1]^2*sp[k2,k3]*m + 16*
      sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p1] + 32*sp[k1,p1]
      ^2*sp[k3,p1]*m - 80*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,
      p2]*m + 32*sp[k1,p1]^2*sp[p1,p2] - 16*sp[k1,p1]^2*sp[p1,p2]*m - 8
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p2]*m^2 + 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 24*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]
       - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 80*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p1]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,
      p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p2]
      ^2 + 24*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 
      48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 64*sp[k1,p1
      ]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 4*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 8*sp[k1,p2]^2*sp[k2,p1]*m - 4
      *sp[k1,p2]^2*sp[k2,p1]*m^2 + 32*sp[k1,p2]^2*sp[k3,p1] - 8*sp[k1,
      p2]^2*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 144*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       + 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,p2]*sp[
      k2,p1]^2 + 16*sp[k1,p2]*sp[k2,p1]^2*m + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2] - 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 40*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 8*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[6,5]*color[1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[k3
       - p2]]*num[64*sp[k1,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m
       - 32*sp[k1,k2]^2*sp[p1,p2] + 8*sp[k1,k2]^2*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k1,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m
       - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,p1]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,p1]*m^2 - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32
      *sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,
      k3] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 
      96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1]*m + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 40*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 16*sp[k1,k2
      ]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 24*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*
      m^2 - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1
      ,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k2]*sp[k3,p1]^2*m - 4*sp[
      k1,k2]*sp[k3,p1]^2*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 24*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p2]
      *sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,k3]^2*
      sp[k2,p1] + 8*sp[k1,k3]^2*sp[k2,p1]*m - 4*sp[k1,k3]^2*sp[k2,p1]*
      m^2 - 32*sp[k1,k3]*sp[k1,p1]^2 + 16*sp[k1,k3]*sp[k1,p1]^2*m - 64*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*
      m - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 144*sp[k1
      ,k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 
      176*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 72*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 8*sp[k1,k3]*sp[k2,
      k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 144*sp[k1
      ,k3]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 
      64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p1] - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m^2 + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 112*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1] - 40*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 
      64*sp[k1,k3]*sp[p1,p2]^2 + 24*sp[k1,k3]*sp[p1,p2]^2*m + 64*sp[k1,
      p1]^2*sp[k1,p2] - 32*sp[k1,p1]^2*sp[k1,p2]*m + 16*sp[k1,p1]^2*sp[
      k2,k3]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m + 80*sp[k1,p1]^2*sp[k3,p2]
       - 16*sp[k1,p1]^2*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m^2 - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,
      p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,k3]
      ^2 - 24*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 
      32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 8*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p1]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 128*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 4
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 16*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 16*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 8*
      sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p2]^2*sp[k2,p1] - 32*
      sp[k1,p2]^2*sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 24*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 80*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 80*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 
      144*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m - 32*sp[k1,p2]*sp[k3,p1]^2 + 8*sp[k1,p2]*sp[k3,p1]^2*m + 64
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]
      *m] + amp[6,6]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[
      k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k3 - p2]]*num[24*sp[k1,k2]^2
      *sp[p1,p2] + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 40*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16
      *sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2] - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]
      *sp[k1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 88*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       - 72*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m - 136*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p2]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2]*m - 104*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k2]*sp[
      k2,k3]*sp[k3,p1] + 12*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 40*sp[k1,k2]*sp[k2,p2]*sp[k3,p1
      ] + 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k3,p1]^2
       + 16*sp[k1,k2]*sp[k3,p1]^2*m + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       - 36*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,k3]
      ^2*sp[k2,p1] + 32*sp[k1,k3]^2*sp[k2,p1]*m - 32*sp[k1,k3]^2*sp[p1,
      p2] + 8*sp[k1,k3]^2*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2
      ] + 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 80*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 88*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 40*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 16
      *sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
      *m + 56*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 20*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 4*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 56*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] + 20*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m + 12*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m + 120*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 44*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2]*m + 56*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 
      16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2] - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2] + 20*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 40*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m
       - 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[
      k3,p2]*m + 56*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m + 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 44*sp[k1,k3
      ]*sp[k3,p2]*sp[p1,p2]*m + 72*sp[k1,k3]*sp[p1,p2]^2 - 28*sp[k1,k3]
      *sp[p1,p2]^2*m + 104*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2
      ,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m - 
      40*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m + 80*sp[k1,
      p1]*sp[k1,p2]^2 - 40*sp[k1,p1]*sp[k1,p2]^2*m + 136*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3] - 20*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 104*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 
      32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 8*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 36*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 112*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 40*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 72*sp[k1,p1]*sp[k2,k3]^2 - 28*
      sp[k1,p1]*sp[k2,k3]^2*m - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 20*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 88*sp[k1,p1]*sp[k2,k3]*sp[k3,p1
      ] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] + 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 40
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m + 40*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 8*sp[k1,p1]*sp[k3,
      p1]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k3,p2]^2 + 68*sp[k1,p1]*sp[k3,
      p2]^2*m - 40*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2]*m - 16*sp[k1,p2]^2*sp[k2,p1] + 32*sp[k1,p2]^2*sp[k2
      ,p1]*m + 120*sp[k1,p2]^2*sp[k3,p1] - 44*sp[k1,p2]^2*sp[k3,p1]*m
       - 80*sp[k1,p2]^2*sp[p1,p2] + 32*sp[k1,p2]^2*sp[p1,p2]*m - 56*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       - 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m + 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 24*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 56*sp[k1,p2]*sp[k3,p1]^2
       + 16*sp[k1,p2]*sp[k3,p1]^2*m + 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]
       - 36*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 72*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] + 28*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 80*sp[k1,p2]*sp[
      k3,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[6,8]
      *color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      den[sp[ - k2 - k3]]*den[sp[k3 - p2]]*num[ - 8*sp[k1,k2]^2*sp[k3,
      p1] + 4*sp[k1,k2]^2*sp[k3,p1]*m + 16*sp[k1,k2]^2*sp[p1,p2] - 8*
      sp[k1,k2]^2*sp[p1,p2]*m + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 20*
      sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
       - 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1] - 12*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 80*sp[k1,k2]*
      sp[k1,p1]*sp[k1,p2] + 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 
      32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p2]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 20*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 40*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1
      ] + 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,
      k2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m + 44
      *sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
      *m + 52*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[
      k2,p1]*sp[k2,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1] - 72*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p2
      ]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,p1]^2 - 12*sp[k1,k2]*sp[k3,p1]
      ^2*m - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 8*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3
      ,p1]*sp[p1,p2]*m - 52*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[p1,p2]^2 - 8*sp[k1,k2]*
      sp[p1,p2]^2*m + 56*sp[k1,k3]^2*sp[k1,p1] - 28*sp[k1,k3]^2*sp[k1,
      p1]*m - 24*sp[k1,k3]^2*sp[k2,p1] + 12*sp[k1,k3]^2*sp[k2,p1]*m + 
      24*sp[k1,k3]^2*sp[p1,p2] - 12*sp[k1,k3]^2*sp[p1,p2]*m - 40*sp[k1,
      k3]*sp[k1,p1]*sp[k1,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 8*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m
       - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 20*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m - 224*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 56*sp[k1,k3
      ]*sp[k1,p1]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 4*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
       - 20*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k1,
      p2]*sp[k3,p1] + 12*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2] - 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 44*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m
       - 72*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,k3]*sp[
      k3,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]^2 - 4*sp[k1,k3]*sp[k2,p1]^2
      *m + 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1] + 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 200*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m
       - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 72*sp[k1,k3]*sp[k3,p1]*sp[k3
      ,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m + 24*sp[k1,k3]*sp[k3,p1
      ]*sp[p1,p2] - 12*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 44*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[p1,p2]^2 - 4*sp[k1,k3]*sp[p1,p2]^2*m + 104*sp[k1,p1]^2*
      sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 208*sp[k1,p1]^2*sp[k2,p2
      ] + 64*sp[k1,p1]^2*sp[k2,p2]*m - 104*sp[k1,p1]^2*sp[k3,p2] + 32*
      sp[k1,p1]^2*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 160*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1] - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 80*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1] - 20*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 
      52*sp[k1,p1]*sp[k2,k3]^2 + 28*sp[k1,p1]*sp[k2,k3]^2*m - 16*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 72*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 4*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p1]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]
       - 20*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[
      k2,p1]*sp[p1,p2] + 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 88*sp[k1,
      p1]*sp[k2,p2]^2 - 40*sp[k1,p1]*sp[k2,p2]^2*m + 32*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 72*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*
      m + 56*sp[k1,p1]*sp[k3,p1]^2 - 28*sp[k1,p1]*sp[k3,p1]^2*m - 8*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2] + 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 
      40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 20*sp[k1,p1]*sp[k3,p1]*sp[p1,
      p2]*m - 52*sp[k1,p1]*sp[k3,p2]^2 + 28*sp[k1,p1]*sp[k3,p2]^2*m - 
      16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2
      ]*m - 16*sp[k1,p2]^2*sp[k2,p1] + 8*sp[k1,p2]^2*sp[k2,p1]*m - 8*
      sp[k1,p2]^2*sp[k3,p1] + 4*sp[k1,p2]^2*sp[k3,p1]*m + 52*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 
      64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m - 16*sp[k1,p2]*sp[k2,p1]^2 + 8*sp[k1,p2]*sp[k2,p1]^2*m - 72
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
      *m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m - 52*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 8*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 64*sp[
      k1,p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m
       - 24*sp[k1,p2]*sp[k3,p1]^2 + 12*sp[k1,p2]*sp[k3,p1]^2*m + 44*sp[
      k1,p2]*sp[k3,p1]*sp[k3,p2] - 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m
       - 8*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1,p2]*sp[k3,p1]*sp[p1,
      p2]*m - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p2]
      *sp[p1,p2]*m] + amp[6,9]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]
      ]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k3 - p2]]*num[16*
      sp[k1,k2]^2*sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,p1]*m - 8*sp[k1,k2]^2
      *sp[p1,p2] + 4*sp[k1,k2]^2*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k1,k3]*
      sp[k1,p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k3,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       + 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,
      p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 8*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 40*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2
      ] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2
      ]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 24*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*
      m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k2,k3]*sp[
      k2,p1]*m + 72*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,
      k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*
      sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1] - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 
      64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2]*m - 52*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m - 44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]^2 + 8*sp[k1,k2
      ]*sp[k3,p1]^2*m - 52*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 
      8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[p1,p2]^2 + 12
      *sp[k1,k2]*sp[p1,p2]^2*m + 16*sp[k1,k3]^2*sp[k2,p1] - 8*sp[k1,k3]
      ^2*sp[k2,p1]*m - 8*sp[k1,k3]^2*sp[p1,p2] + 4*sp[k1,k3]^2*sp[p1,p2
      ]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k3]*sp[k1,p1]*
      sp[k1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 40*sp[k1
      ,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 
      16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k3
      ,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k3]*sp[k1,p1]
      *sp[p1,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 24*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 12*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*
      m + 72*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,
      k3]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*
      sp[k2,p1]^2 + 8*sp[k1,k3]*sp[k2,p1]^2*m - 52*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 52*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1,k3]*sp[k2,p2
      ]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k3]*
      sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1
      ,k3]*sp[k3,p1]*sp[p1,p2]*m - 44*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 
      24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[p1,p2]^2 + 
      12*sp[k1,k3]*sp[p1,p2]^2*m - 208*sp[k1,p1]^2*sp[k2,k3] + 64*sp[k1
      ,p1]^2*sp[k2,k3]*m + 104*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*
      sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]^2*sp[k3,p2
      ]*m - 56*sp[k1,p1]*sp[k1,p2]^2 + 28*sp[k1,p1]*sp[k1,p2]^2*m + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 4*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p2]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 4*sp[k1
      ,p1]*sp[k1,p2]*sp[k3,p2]*m + 224*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 
      56*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 88*sp[k1,p1]*sp[k2,k3]^2 + 
      40*sp[k1,p1]*sp[k2,k3]^2*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 
      16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 72*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 72*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 32*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,p1]*sp[k2
      ,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 20*sp[
      k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 52*sp[k1,p1]*sp[k2,p2]^2 - 28*sp[
      k1,p1]*sp[k2,p2]^2*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2] + 4*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k3,
      p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 40*sp[k1,p1]*
      sp[k3,p1]*sp[p1,p2] - 20*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 52*sp[
      k1,p1]*sp[k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2*m - 8*sp[k1,p1]*sp[
      k3,p2]*sp[p1,p2] + 4*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 56*sp[k1,
      p1]*sp[p1,p2]^2 + 28*sp[k1,p1]*sp[p1,p2]^2*m + 24*sp[k1,p2]^2*sp[
      k2,p1] - 12*sp[k1,p2]^2*sp[k2,p1]*m + 24*sp[k1,p2]^2*sp[k3,p1] - 
      12*sp[k1,p2]^2*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 4*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 200*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]^2
       - 4*sp[k1,p2]*sp[k2,p1]^2*m - 44*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
       + 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,p2]
      *sp[k2,p1]*sp[p1,p2] - 12*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 
      72*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,
      p2]*m + 8*sp[k1,p2]*sp[k3,p1]^2 - 4*sp[k1,p2]*sp[k3,p1]^2*m - 44*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*
      m + 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 12*sp[k1,p2]*sp[k3,p1]*sp[
      p1,p2]*m - 72*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k3,
      p2]*sp[p1,p2]*m] + amp[6,10]*color[Ca^2*Na*Tf]*den[sp[ - k1 + p1]
      ]*den[sp[k1 - p1]]*den[sp[ - k3 + p2]]*den[sp[k3 - p2]]*num[ - 
      128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1]*m + 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2]*m - 176*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 8
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k2,p2]*sp[p1,
      p2] + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 40*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 48*sp[k1,
      k3]^2*sp[k1,p1] - 32*sp[k1,k3]^2*sp[k1,p1]*m + 4*sp[k1,k3]^2*sp[
      k1,p1]*m^2 - 24*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*
      m - 48*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[
      k1,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m^2 - 96*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 8*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 
      8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2]*m^2 - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 80*sp[k1,k3]*sp[k1,
      p1]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m^2 - 104*sp[k1
      ,k3]*sp[k1,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 
      96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[p1,p2
      ]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k1,p2
      ]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 48*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 
      24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ]*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m - 128*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k3]*
      sp[k3,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]
       - 32*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[p1,p2]^2
       + 16*sp[k1,k3]*sp[p1,p2]^2*m - 304*sp[k1,p1]^2*sp[k3,p2] + 112*
      sp[k1,p1]^2*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k1,p2]^2 - 32*sp[k1,p1]
      *sp[k1,p2]^2*m + 4*sp[k1,p1]*sp[k1,p2]^2*m^2 + 48*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
      *m^2 + 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m^2 + 104*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 192*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*
      m - 8*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]^
      2 - 40*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 96
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m^2 - 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p2]^2 - 40*sp[k1,p1]*sp[
      k2,p2]^2*m + 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 48*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 40*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
       - 64*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2]*m^2 + 48*sp[k1,p1]*sp[k3,p1]^2 - 32*sp[k1,p1]*sp[k3,p1]^2*
      m + 4*sp[k1,p1]*sp[k3,p1]^2*m^2 + 104*sp[k1,p1]*sp[k3,p1]*sp[k3,
      p2] - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k3,p1]
      *sp[p1,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[
      k3,p1]*sp[p1,p2]*m^2 - 208*sp[k1,p1]*sp[k3,p2]^2 + 96*sp[k1,p1]*
      sp[k3,p2]^2*m - 104*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[p1,p2]^2 - 32*sp[k1,p1]*
      sp[p1,p2]^2*m + 4*sp[k1,p1]*sp[p1,p2]^2*m^2 + 24*sp[k1,p2]^2*sp[
      k3,p1] - 16*sp[k1,p2]^2*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 48*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2] + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 40*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[
      k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[k3,p1]^2*m + 80*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 24*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m
       - 128*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 64*sp[k1,p2]*sp[k3,p2]*sp[
      p1,p2]*m] + amp[6,11]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[
      sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[k3 - p2]]*num[24*sp[k1,k2
      ]^2*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k1,p1]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,p1
      ] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[
      k1,p1]*sp[k1,p2] - 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 88*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 32
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
      *m - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1]*m + 136*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 40*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m - 72*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
       - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 160*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 40*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 48
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2] - 12*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 96*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m + 56*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 80*
      sp[k1,k3]^2*sp[k1,p1] + 40*sp[k1,k3]^2*sp[k1,p1]*m + 16*sp[k1,k3]
      ^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m - 80*sp[k1,k3]^2*sp[k3,
      p1] + 32*sp[k1,k3]^2*sp[k3,p1]*m + 120*sp[k1,k3]^2*sp[p1,p2] - 44
      *sp[k1,k3]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*
      sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3
      ] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 104*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 136*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 112*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*
      m - 104*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 36*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 8*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 4*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2
      ] + 8*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 56
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m - 112*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 36*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 32*sp[
      k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 72*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
       + 28*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 36*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 56*sp[k1,k3]*sp[
      p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 40*sp[k1,p1]^2*sp[k2,k3]
       + 16*sp[k1,p1]^2*sp[k2,k3]*m + 104*sp[k1,p1]^2*sp[k2,p2] - 32*
      sp[k1,p1]^2*sp[k2,p2]*m + 40*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]
      ^2*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 88*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 24*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 56*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 48*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m - 72*sp[k1,p1]*sp[k2,p2]^2 + 28*sp[k1,p1]*sp[k2,
      p2]^2*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 12*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m - 88*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 40*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]
       + 12*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 160*sp[k1,p1]*sp[k3,p2]^2
       - 68*sp[k1,p1]*sp[k3,p2]^2*m + 40*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]
       - 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p2]^2*sp[k2,p1]
       - 32*sp[k1,p2]^2*sp[k2,p1]*m - 32*sp[k1,p2]^2*sp[k3,p1] + 8*sp[
      k1,p2]^2*sp[k3,p1]*m - 120*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 44*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 40*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2] - 20*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 48*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] - 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m - 56*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m + 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*
      sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[
      k1,p2]*sp[k3,p1]^2 - 28*sp[k1,p2]*sp[k3,p1]^2*m - 112*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2] + 44*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 56*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m
       + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p2]*sp[
      p1,p2]*m] + amp[6,12]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*
      den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*num[ - 32*
      sp[k1,k2]^2*sp[k3,p1] + 8*sp[k1,k2]^2*sp[k3,p1]*m + 64*sp[k1,k2]^
      2*sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,k3]
      *sp[k1,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 96*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 
      40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 16*sp[k1,k2]*sp[k1,
      p1]*sp[k1,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m
       + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 24
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2
      ]*m^2 - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 8*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
       - 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 
      24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[p1,p2]^2*m + 
      4*sp[k1,k2]*sp[p1,p2]^2*m^2 - 80*sp[k1,k3]^2*sp[k2,p1] + 32*sp[k1
      ,k3]^2*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]^2 - 32*sp[k1,k3]*sp[
      k1,p1]^2*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 24*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]
      *sp[k3,p1]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m + 176*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 72*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m^2 - 144*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 24*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,
      k3]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 32
      *sp[k1,k3]*sp[p1,p2]^2 + 8*sp[k1,k3]*sp[p1,p2]^2*m - 32*sp[k1,p1]
      ^2*sp[k1,p2] + 16*sp[k1,p1]^2*sp[k1,p2]*m - 8*sp[k1,p1]^2*sp[k2,
      k3]*m + 16*sp[k1,p1]^2*sp[k2,p2]*m - 80*sp[k1,p1]^2*sp[k3,p2] + 
      16*sp[k1,p1]^2*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 
      64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p1] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 24*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 144*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32
      *sp[k1,p1]*sp[k2,p2]^2 + 24*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]
      *sp[k2,p2]^2*m^2 - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m
       + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2]*m^2 + 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 8*sp[k1,p1]*sp[k3
      ,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,p1
      ]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,p2]^2*sp[k2,p1] - 8*sp[k1,p2]^
      2*sp[k2,p1]*m + 4*sp[k1,p2]^2*sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 24*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2] - 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
       - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 144*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[
      k1,p2]*sp[k3,p1]^2 + 24*sp[k1,p2]*sp[k3,p1]^2*m + 32*sp[k1,p2]*
      sp[k3,p1]*sp[p1,p2] - 8*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[6,
      14]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 - k3]]
      *den[sp[k3 - p2]]*den[sp[p1 + p2]]*num[48*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2] - 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 104*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 88*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m - 56*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m - 56*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m + 120*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 44*sp[k1,k2
      ]*sp[k2,k3]*sp[p1,p2]*m - 104*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 32*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 56*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 56*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2] + 20*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 16
      *sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,p1]^2*m + 16*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 48*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m + 80*sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,k2]*sp[p1,p2]^2*m
       + 72*sp[k1,k3]^2*sp[p1,p2] - 28*sp[k1,k3]^2*sp[p1,p2]*m + 24*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m
       + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 12*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 112*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 40*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1]*m - 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 12*sp[k1,k3
      ]*sp[k1,p1]*sp[k3,p2]*m + 56*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 24*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 72*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1] + 28*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 56*sp[k1,k3]*sp[k1,
      p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2] + 12*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*
      sp[k1,k3]*sp[k2,p1]^2 + 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 48*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m
       + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m - 160*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2
      ,p1]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 80
      *sp[k1,k3]*sp[k3,p1]^2 + 32*sp[k1,k3]*sp[k3,p1]^2*m - 80*sp[k1,k3
      ]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 24*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m
       + 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 44*sp[k1,k3]*sp[k3,p2]*sp[
      p1,p2]*m - 32*sp[k1,k3]*sp[p1,p2]^2 + 8*sp[k1,k3]*sp[p1,p2]^2*m
       + 40*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 104*
      sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 40*sp[k1,p1]
      ^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 72*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 88*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m
       + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 8*sp[k1,p1]*sp[k1,p2]*sp[k3
      ,p1]*m + 40*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p2]*m - 88*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 20*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]
      *sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 64*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*
      m + 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 40*sp[k1,p1]*sp[
      k2,p1]*sp[p1,p2]*m + 72*sp[k1,p1]*sp[k2,p2]^2 - 28*sp[k1,p1]*sp[
      k2,p2]^2*m - 136*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 20*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 8*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[k3,p1]^2 - 40*
      sp[k1,p1]*sp[k3,p1]^2*m - 104*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 36*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2
      ] + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 160*sp[k1,p1]*sp[k3,p2]^
      2 + 68*sp[k1,p1]*sp[k3,p2]^2*m - 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]
       + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 56*sp[k1,p2]^2*sp[k2,p1]
       - 16*sp[k1,p2]^2*sp[k2,p1]*m - 56*sp[k1,p2]^2*sp[k3,p1] + 16*sp[
      k1,p2]^2*sp[k3,p1]*m - 40*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 12*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 40*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2] + 12*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 48*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 96*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2] + 36*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m + 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 36*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2
      ]*sp[k2,p2]*sp[p1,p2]*m + 120*sp[k1,p2]*sp[k3,p1]^2 - 44*sp[k1,p2
      ]*sp[k3,p1]^2*m + 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 36*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 8*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]
       + 16*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[6,15]*color[1/2*Ca^2
      *Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*
      den[sp[k3 - p2]]*num[96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 40*sp[k1,
      k2]*sp[k1,k3]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2
       - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 176*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] - 40*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 40*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 48*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 176*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] + 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 40
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2
      ]*m^2 + 24*sp[k1,k2]*sp[k3,p1]^2*m - 4*sp[k1,k2]*sp[k3,p1]^2*m^2
       - 24*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 + 24*sp[k1,k2]*sp[p1,p2]^2*m - 4*sp[k1,k2]*sp[p1,p2]^2
      *m^2 - 96*sp[k1,k3]^2*sp[k2,p1] + 40*sp[k1,k3]^2*sp[k2,p1]*m - 4*
      sp[k1,k3]^2*sp[k2,p1]*m^2 + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 
      4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 12*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 48*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 96
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 24*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 12*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 96*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m + 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 104*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1
      ,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 24*sp[k1,
      k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 176*sp[k1,p1]^2*
      sp[k3,p2] + 48*sp[k1,p1]^2*sp[k3,p2]*m - 12*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 24*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 48*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*
      m - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[
      p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]^2 - 40*sp[k1,p1]*sp[k2,k3]^2*m
       + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m^2 - 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       + 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[
      k2,p2]^2 - 40*sp[k1,p1]*sp[k2,p2]^2*m + 4*sp[k1,p1]*sp[k2,p2]^2*
      m^2 + 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 104*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 4*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 104*sp[k1,p1]*sp[k3,p1]*sp[k3
      ,p2] - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 104*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2] + 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 96*sp[k1,p2]
      ^2*sp[k2,p1] + 40*sp[k1,p2]^2*sp[k2,p1]*m - 4*sp[k1,p2]^2*sp[k2,
      p1]*m^2 + 12*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m^2 - 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 48*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 - 104*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ] - 40*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m^2 + 24*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[k3,p1]
      ^2*m + 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m] + amp[6,16]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*
      den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*den[sp[k3 - p2]]*num[56*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*
      m + 56*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m + 88*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 24*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2]*m - 104*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 48*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] + 20*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 56*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1] - 20*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 56*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 48
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m - 104*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2]*m - 120*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 44*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k3,p1]^2 + 32*sp[k1,k2]*
      sp[k3,p1]^2*m + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 12*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 20*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[p1,p2]^2
       + 32*sp[k1,k2]*sp[p1,p2]^2*m - 56*sp[k1,k3]^2*sp[k2,p1] + 16*sp[
      k1,k3]^2*sp[k2,p1]*m - 56*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*
      sp[p1,p2]*m + 88*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3]*m + 72*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m - 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,k3]
      *sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 72*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 28*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*
      m + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,
      k3]*sp[k3,p1]*m + 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 36*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2]*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 12*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 36*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*
      m + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[
      k3,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 8*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 36*sp[k1,k3]
      *sp[k3,p2]*sp[p1,p2]*m + 120*sp[k1,k3]*sp[p1,p2]^2 - 44*sp[k1,k3]
      *sp[p1,p2]^2*m - 104*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2
      ,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m + 
      40*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 16*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3] + 12*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 24
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]
      *m - 56*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 12*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2]*m + 112*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 40*sp[k1
      ,p1]*sp[k1,p2]*sp[p1,p2]*m - 72*sp[k1,p1]*sp[k2,k3]^2 + 28*sp[k1,
      p1]*sp[k2,k3]^2*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 20
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 80*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 136*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 88*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m
       - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p1]*m - 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 40*sp[k1,p1]*sp[k2
      ,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p1
      ]*sp[k2,p1]*sp[p1,p2]*m - 40*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] + 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,
      p1]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 
      160*sp[k1,p1]*sp[k3,p2]^2 - 68*sp[k1,p1]*sp[k3,p2]^2*m - 104*sp[
      k1,p1]*sp[k3,p2]*sp[p1,p2] + 36*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m
       - 80*sp[k1,p1]*sp[p1,p2]^2 + 40*sp[k1,p1]*sp[p1,p2]^2*m + 72*sp[
      k1,p2]^2*sp[k3,p1] - 28*sp[k1,p2]^2*sp[k3,p1]*m - 24*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m
       + 24*sp[k1,p2]*sp[k2,p1]^2 + 160*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 40*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 32
      *sp[k1,p2]*sp[k3,p1]^2 + 8*sp[k1,p2]*sp[k3,p1]^2*m - 112*sp[k1,p2
      ]*sp[k3,p1]*sp[k3,p2] + 44*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 24*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m
       + 80*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p2]*sp[
      p1,p2]*m - 80*sp[k1,p2]*sp[p1,p2]^2 + 32*sp[k1,p2]*sp[p1,p2]^2*m]
       + amp[7,1]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - 
      p1]]*den[sp[k2 + k3]]*num[24*sp[k1,k2]*sp[k1,p1] - 12*sp[k1,k2]*
      sp[k1,p1]*m + 48*sp[k1,k2]*sp[k2,p1] - 24*sp[k1,k2]*sp[k2,p1]*m
       + 48*sp[k1,k2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k3,p1]*m + 12*sp[k1,
      k2]*sp[p1,p2] - 12*sp[k1,k2]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k1,p1]
       - 12*sp[k1,k3]*sp[k1,p1]*m + 48*sp[k1,k3]*sp[k2,p1] - 24*sp[k1,
      k3]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k3,p1] - 24*sp[k1,k3]*sp[k3,p1]
      *m + 12*sp[k1,k3]*sp[p1,p2] - 12*sp[k1,k3]*sp[p1,p2]*m - 96*sp[k1
      ,p1]*sp[k2,k3] + 48*sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1,p1]*sp[k2,p1
      ] + 12*sp[k1,p1]*sp[k2,p1]*m - 12*sp[k1,p1]*sp[k2,p2] + 12*sp[k1,
      p1]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k3,p1] + 12*sp[k1,p1]*sp[k3,p1]
      *m - 12*sp[k1,p1]*sp[k3,p2] + 12*sp[k1,p1]*sp[k3,p2]*m + 12*sp[k1
      ,p2]*sp[k2,p1] - 12*sp[k1,p2]*sp[k2,p1]*m + 12*sp[k1,p2]*sp[k3,p1
      ] - 12*sp[k1,p2]*sp[k3,p1]*m] + amp[7,1]*color[ - 1/2*Ca^2*Na*Tf]
      *den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k2 + k3]]*num[32*sp[
      k1,k2]*sp[k1,p1] - 24*sp[k1,k2]*sp[k1,p1]*m + 4*sp[k1,k2]*sp[k1,
      p1]*m^2 + 24*sp[k1,k2]*sp[k2,p1] - 8*sp[k1,k2]*sp[k2,p1]*m + 24*
      sp[k1,k2]*sp[k3,p1] - 12*sp[k1,k2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[
      p1,p2] - 8*sp[k1,k3]*sp[k1,p1] + 12*sp[k1,k3]*sp[k1,p1]*m - 4*sp[
      k1,k3]*sp[k1,p1]*m^2 + 24*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,k3]*sp[
      k2,p1]*m + 24*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k3]*sp[k3,p1]*m + 16
      *sp[k1,k3]*sp[p1,p2] - 12*sp[k1,k3]*sp[p1,p2]*m - 48*sp[k1,p1]*
      sp[k2,k3] + 24*sp[k1,p1]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k2,p1] + 
      24*sp[k1,p1]*sp[k2,p1]*m - 4*sp[k1,p1]*sp[k2,p1]*m^2 + 20*sp[k1,
      p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*
      m^2 + 8*sp[k1,p1]*sp[k3,p1] - 12*sp[k1,p1]*sp[k3,p1]*m + 4*sp[k1,
      p1]*sp[k3,p1]*m^2 - 32*sp[k1,p1]*sp[k3,p2] + 28*sp[k1,p1]*sp[k3,
      p2]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 4*sp[k1,p2]*sp[k2,p1] + 16*
      sp[k1,p2]*sp[k3,p1] - 12*sp[k1,p2]*sp[k3,p1]*m] + amp[7,1]*color[
      1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k2 + 
      k3]]*num[8*sp[k1,k2]*sp[k1,p1] - 12*sp[k1,k2]*sp[k1,p1]*m + 4*sp[
      k1,k2]*sp[k1,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p1] + 16*sp[k1,k2]*sp[
      k2,p1]*m - 24*sp[k1,k2]*sp[k3,p1] + 12*sp[k1,k2]*sp[k3,p1]*m - 16
      *sp[k1,k2]*sp[p1,p2] + 12*sp[k1,k2]*sp[p1,p2]*m - 32*sp[k1,k3]*
      sp[k1,p1] + 24*sp[k1,k3]*sp[k1,p1]*m - 4*sp[k1,k3]*sp[k1,p1]*m^2
       - 24*sp[k1,k3]*sp[k2,p1] + 12*sp[k1,k3]*sp[k2,p1]*m - 24*sp[k1,
      k3]*sp[k3,p1] + 8*sp[k1,k3]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[p1,p2]
       + 48*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m - 8*sp[k1,p1
      ]*sp[k2,p1] + 12*sp[k1,p1]*sp[k2,p1]*m - 4*sp[k1,p1]*sp[k2,p1]*
      m^2 + 32*sp[k1,p1]*sp[k2,p2] - 28*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1
      ,p1]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k3,p1] - 24*sp[k1,p1]*sp[k3,
      p1]*m + 4*sp[k1,p1]*sp[k3,p1]*m^2 - 20*sp[k1,p1]*sp[k3,p2] + 16*
      sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 16*sp[k1,p2]*
      sp[k2,p1] + 12*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k3,p1]] + 
      amp[7,3]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1
      ]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[32*sp[k1,k2]^2*sp[k3,
      p1] - 8*sp[k1,k2]^2*sp[k3,p1]*m + 80*sp[k1,k2]^2*sp[p1,p2] - 32*
      sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1
      ] - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 24*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1] - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2] - 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 80*sp[k1,
      k2]*sp[k1,p1]*sp[k1,p2] + 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]
      *m - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m - 56*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m + 88*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 24
      *sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 160*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m
       + 112*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 44*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k2]
      *sp[k2,p1]*sp[k2,p2]*m - 56*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 56*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 12*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 20*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[k3,p1]^2 - 28*sp[k1,
      k2]*sp[k3,p1]^2*m - 40*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 12*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 20
      *sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 120*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] + 44*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,k3]^2*sp[k1,
      p1] - 40*sp[k1,k3]^2*sp[k1,p1]*m + 120*sp[k1,k3]^2*sp[k2,p1] - 44
      *sp[k1,k3]^2*sp[k2,p1]*m + 80*sp[k1,k3]^2*sp[k3,p1] - 32*sp[k1,k3
      ]^2*sp[k3,p1]*m + 16*sp[k1,k3]^2*sp[p1,p2] - 32*sp[k1,k3]^2*sp[p1
      ,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k3]*sp[k1,p1
      ]*sp[k1,p2]*m - 104*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 36*sp[k1,k3]*
      sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 8*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 136*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       - 20*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 112*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1] + 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 104*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 48
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 48*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m + 104*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1
      ,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 36*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,p1]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ] - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k2,p1]^2
       - 16*sp[k1,k3]*sp[k2,p1]^2*m - 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       + 36*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 72*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1] + 28*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 56*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 24
      *sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
      *m + 56*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m + 40*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]
      *m - 104*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 40*
      sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m - 136*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 72*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m + 88*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 32*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k2,k3]^2 + 68*sp[k1,p1]
      *sp[k2,k3]^2*m - 40*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 8*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       + 12*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 48*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 88*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 40
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m + 72*sp[k1,p1]*sp[k2,p2]^2 - 28*sp[k1,p1]*sp[k2,p2]^2*m - 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m - 24*sp[k1,p2]^2*sp[k3,p1] + 96*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1] - 36*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,p2]
      *sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 56*
      sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m - 40*sp[k1,p2]
      *sp[k2,p1]*sp[k2,p2] + 12*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      40*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p2]*m - 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]] + amp[7,4]*color[ - 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p1]]*den[sp[k2 + k3]]*
      den[sp[p1 + p2]]*num[32*sp[k1,k2]^2*sp[p1,p2] + 8*sp[k1,k2]^2*sp[
      p1,p2]*m - 4*sp[k1,k2]^2*sp[p1,p2]*m^2 + 176*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 72*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]^2 - 16*sp[k1,k2]*
      sp[k1,p1]^2*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 64*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 144*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 192*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       + 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 48*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 8*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k2,p1]
      *sp[p1,p2] - 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m^2 + 144*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 48*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p1]^2
       - 24*sp[k1,k2]*sp[k3,p1]^2*m + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] + 40*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m^2 + 80*sp[k1,k3]^2*sp[p1,p2] - 32*sp[k1,k3]^2*sp[p1,p2]*m + 64*
      sp[k1,k3]*sp[k1,p1]^2 - 32*sp[k1,k3]*sp[k1,p1]^2*m + 64*sp[k1,k3]
      *sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 80*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*
      m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 80*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 32
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
      *m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 16*sp[k1,k3]*
      sp[k1,p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 40*sp[k1
      ,k3]*sp[k1,p2]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 
      32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,p1]^2 + 8
      *sp[k1,k3]*sp[k2,p1]^2*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 144*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m + 80*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m + 16*
      sp[k1,p1]^2*sp[k2,p2]*m + 8*sp[k1,p1]^2*sp[k3,p2]*m + 80*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 24*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 
      48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1
      ,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2
       + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]^2
       + 24*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 4*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 - 64*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^2*sp[k2,
      p1]*m - 32*sp[k1,p2]^2*sp[k3,p1] + 8*sp[k1,p2]^2*sp[k3,p1]*m + 96
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
      *m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]^2*m - 4*sp[k1,p2]*sp[
      k2,p1]^2*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 24*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m^2 + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m] + amp[7,6]*color[1/4*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*
      num[ - 80*sp[k1,k2]^2*sp[k1,p1] + 40*sp[k1,k2]^2*sp[k1,p1]*m - 80
      *sp[k1,k2]^2*sp[k2,p1] + 32*sp[k1,k2]^2*sp[k2,p1]*m - 120*sp[k1,
      k2]^2*sp[k3,p1] + 44*sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]^2*sp[
      p1,p2] + 32*sp[k1,k2]^2*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[
      k1,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1] + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 48*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 20*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2]*m + 104*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 36*sp[k1,k2]*sp[k1
      ,p1]*sp[k2,k3]*m + 112*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 40*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 8*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1
      ] - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 136*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 104*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k3
      ,p1]*m - 104*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,k2]
      *sp[k2,k3]*sp[k2,p1]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 36*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ] + 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1] - 28*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 24*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 56*
      sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*m + 112*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] - 36*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 56*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m - 56*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m - 32*sp[k1,k3]^2*sp[k2,p1] + 8*sp[k1,k3]^2*sp[k2,p1]*m
       - 80*sp[k1,k3]^2*sp[p1,p2] + 32*sp[k1,k3]^2*sp[p1,p2]*m + 80*sp[
      k1,k3]*sp[k1,p1]*sp[k1,p2] - 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,k3]*m + 56*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p1]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 32*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 88*sp[k1,k3]*sp[k1,p1]*sp[p1,p2
      ] + 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 160*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,
      k3]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 
      112*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 44*sp[k1,k3]*sp[k2,k3]*sp[k2,
      p1]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,k3]
      *sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 12*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m - 72*sp[k1,k3]*sp[k2,p1]^2 + 28*sp[k1,k3]*
      sp[k2,p1]^2*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 12*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 56*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 20*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m + 120*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 44*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 32*
      sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m + 56*sp[k1,k3]*sp[k3,p1]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] - 20*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 40*sp[k1,p1]^2*
      sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2]
       - 16*sp[k1,p1]^2*sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2] - 32*
      sp[k1,p1]^2*sp[k3,p2]*m + 136*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 40*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 88*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 72*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 
      160*sp[k1,p1]*sp[k2,k3]^2 - 68*sp[k1,p1]*sp[k2,k3]^2*m + 40*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p1] - 12*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 
      16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2
      ]*m + 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 12
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] + 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 88*sp[k1,p1]*
      sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 72*sp[
      k1,p1]*sp[k3,p2]^2 + 28*sp[k1,p1]*sp[k3,p2]^2*m + 24*sp[k1,p2]^2*
      sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2] - 40*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m - 56*sp[k1,p2]*sp[k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]
      ^2*m + 40*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 12*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2]*m] + amp[7,7]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[k1 - p1]]*den[sp[k2 + k3]]*den[sp[p1 + p2]]*num[ - 80*sp[
      k1,k2]^2*sp[p1,p2] + 32*sp[k1,k2]^2*sp[p1,p2]*m - 176*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] + 72*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]^2 + 32*
      sp[k1,k2]*sp[k1,p1]^2*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*
      sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1
      ] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 80*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 80*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 4*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p2]
      *sp[k2,p1] + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 40*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m
       - 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2]*m + 144*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 48*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k3,p1]^2 - 8*
      sp[k1,k2]*sp[k3,p1]^2*m + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 8*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k3]^2*
      sp[p1,p2] - 8*sp[k1,k3]^2*sp[p1,p2]*m + 4*sp[k1,k3]^2*sp[p1,p2]*
      m^2 - 32*sp[k1,k3]*sp[k1,p1]^2 + 16*sp[k1,k3]*sp[k1,p1]^2*m - 32*
      sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*
      m + 144*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m
       + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1]*m + 24*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 
      32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2] - 64*sp[k1,k3]*sp[k2,p1]^2 + 24*sp[k1,k3]*sp[k2,p1]^2*m - 64
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
      *m - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 8*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1]*m - 144*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,k3
      ]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 
      112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 40*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p2]
      *sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,k3]
      *sp[k3,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 80*sp[k1,p1]^2*sp[k2,k3
      ] + 16*sp[k1,p1]^2*sp[k2,k3]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m - 16*
      sp[k1,p1]^2*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]
      *m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 8*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 64*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p1]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k3,p2]^2 - 24*sp[k1,p1]
      *sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 32*sp[k1,p2]^2*sp[
      k2,p1] - 8*sp[k1,p2]^2*sp[k2,p1]*m + 64*sp[k1,p2]^2*sp[k3,p1] - 
      16*sp[k1,p2]^2*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 
      24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1] + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1]*m^2 - 8*sp[k1,p2]*sp[k3,p1]^2*m + 4*sp[k1,p2]*sp[k3,p1]^2*
      m^2 - 32*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2] + amp[7,8]*
      color[ - Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[
       - k2 - k3]]*den[sp[k2 + k3]]*num[ - 48*sp[k1,k2]^2*sp[k1,p1] + 
      32*sp[k1,k2]^2*sp[k1,p1]*m - 4*sp[k1,k2]^2*sp[k1,p1]*m^2 - 24*sp[
      k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m - 48*sp[k1,k2]*
      sp[k1,k3]*sp[k1,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 8*sp[k1
      ,k2]*sp[k1,k3]*sp[k1,p1]*m^2 + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 24*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 104*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 192*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m^2 - 96*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 8*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m^2
       - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 8*sp[k1,k2]*sp[k1,p1]*sp[k3
      ,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[
      k2,k3]*sp[k2,p1] + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m - 80*sp[k1,
      k2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 40
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 48*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[
      k3,p1]^2*m + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m - 48*sp[k1,k3]^2*sp[k1,p1] + 32*sp[k1,k3]^2*sp[
      k1,p1]*m - 4*sp[k1,k3]^2*sp[k1,p1]*m^2 - 24*sp[k1,k3]^2*sp[k2,p1]
       + 16*sp[k1,k3]^2*sp[k2,p1]*m - 104*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]
       + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 96*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p1]*m^2 - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2
       + 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 80*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p1]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p2]*m^2 - 80*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 
      32*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[
      k3,p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 40*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]
      *sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m - 24*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 48*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2] - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 
      304*sp[k1,p1]^2*sp[k2,k3] + 112*sp[k1,p1]^2*sp[k2,k3]*m + 128*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m
       + 208*sp[k1,p1]*sp[k2,k3]^2 - 96*sp[k1,p1]*sp[k2,k3]^2*m + 104*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*
      m + 40*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p1]*sp[k2,p1]^2 + 32*
      sp[k1,p1]*sp[k2,p1]^2*m - 4*sp[k1,p1]*sp[k2,p1]^2*m^2 + 96*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 8*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p1] + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*
      sp[k1,p1]*sp[k2,p2]^2 + 40*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*
      sp[k2,p2]^2*m^2 + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m
       + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 48*sp[k1,p1]*sp[k3,p1]^2
       + 32*sp[k1,p1]*sp[k3,p1]^2*m - 4*sp[k1,p1]*sp[k3,p1]^2*m^2 + 96*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*
      m + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k3,p2]^
      2 + 40*sp[k1,p1]*sp[k3,p2]^2*m - 4*sp[k1,p1]*sp[k3,p2]^2*m^2 - 40
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
      *m - 40*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m - 176*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 8*sp[
      k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
       + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1] + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m] + amp[7,9]*
      color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*num[56*sp[k1,k2]^2*sp[k1,p1]
       - 28*sp[k1,k2]^2*sp[k1,p1]*m - 24*sp[k1,k2]^2*sp[k3,p1] + 12*sp[
      k1,k2]^2*sp[k3,p1]*m + 24*sp[k1,k2]^2*sp[p1,p2] - 12*sp[k1,k2]^2*
      sp[p1,p2]*m + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 20*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 12*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 4*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 8*sp[k1,k2]*sp[k1,
      p1]*sp[k2,k3] + 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 224*sp[k1,k2]
      *sp[k1,p1]*sp[k2,p1] + 56*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 8*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 
      80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 20*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2]*m + 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 20*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 12*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 
      4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] - 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 72*sp[k1,k2]*sp[k2,k3]*
      sp[k2,p1] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m + 44*sp[k1,k2]*sp[
      k2,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 72*
      sp[k1,k2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*
      m - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 12*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m + 200*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 12*sp[k1,k2
      ]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 8*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
       - 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]^2
       - 4*sp[k1,k2]*sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 
      16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[p1,p2]^2
       - 4*sp[k1,k2]*sp[p1,p2]^2*m - 8*sp[k1,k3]^2*sp[k2,p1] + 4*sp[k1,
      k3]^2*sp[k2,p1]*m + 16*sp[k1,k3]^2*sp[p1,p2] - 8*sp[k1,k3]^2*sp[
      p1,p2]*m - 80*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 40*sp[k1,k3]*sp[k1,
      p1]*sp[k1,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,k3]*
      sp[k1,p1]*sp[k2,k3]*m - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 20*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 160*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2] - 40*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 
      16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 8*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2]*m + 44*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 24*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,
      k3]*sp[k2,k3]*sp[k3,p1]*m + 52*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,p1]^2 - 12*
      sp[k1,k3]*sp[k2,p1]^2*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 8*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 
      4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 52*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 32*
      sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2
      ] - 8*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 72*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 32*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[
      p1,p2]^2 - 8*sp[k1,k3]*sp[p1,p2]^2*m + 104*sp[k1,p1]^2*sp[k2,k3]
       - 32*sp[k1,p1]^2*sp[k2,k3]*m - 104*sp[k1,p1]^2*sp[k2,p2] + 32*
      sp[k1,p1]^2*sp[k2,p2]*m - 208*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1
      ]^2*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 20*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 160*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 40*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 52*sp[k1,
      p1]*sp[k2,k3]^2 + 28*sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1] - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 24*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 
      72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2]*m + 56*sp[k1,p1]*sp[k2,p1]^2 - 28*sp[k1,p1]*sp[k2,p1]^
      2*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 20*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 20*
      sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 52*sp[k1,p1]*sp[k2,p2]^2 + 28*
      sp[k1,p1]*sp[k2,p2]^2*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 72*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 80*sp[k1,
      p1]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 88
      *sp[k1,p1]*sp[k3,p2]^2 - 40*sp[k1,p1]*sp[k3,p2]^2*m - 32*sp[k1,p1
      ]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 8*
      sp[k1,p2]^2*sp[k2,p1] + 4*sp[k1,p2]^2*sp[k2,p1]*m - 16*sp[k1,p2]^
      2*sp[k3,p1] + 8*sp[k1,p2]^2*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 52*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 24
      *sp[k1,p2]*sp[k2,p1]^2 + 12*sp[k1,p2]*sp[k2,p1]^2*m + 44*sp[k1,p2
      ]*sp[k2,p1]*sp[k2,p2] - 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[p1,
      p2] + 4*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 52*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[
      k2,p2]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,
      p2]*sp[k3,p1]^2 + 8*sp[k1,p2]*sp[k3,p1]^2*m - 72*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2] + 32*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p2]
      *sp[k3,p1]*sp[p1,p2] + 8*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[
      k1,p2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m]
       + amp[7,10]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1
       - p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[8*sp[k1,k2]^2*
      sp[k3,p1] - 4*sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]^2*sp[p1,p2]
       + 8*sp[k1,k2]^2*sp[p1,p2]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]
       + 20*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[
      k2,p1] + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 24*sp[k1,k2]*sp[k1,
      k3]*sp[k3,p1] + 12*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 80*sp[
      k1,k2]*sp[k1,p1]*sp[k1,p2] - 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m
       - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,k3]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,p2]*m + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 20*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       + 40*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1] - 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1] - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 32*
      sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*
      m - 44*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m - 52*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k2]
      *sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 4*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] + 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1] + 72*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k3,p1]^2 + 12*sp[k1,k2]*
      sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2]*m + 52*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[p1,p2]^2 + 8*
      sp[k1,k2]*sp[p1,p2]^2*m - 56*sp[k1,k3]^2*sp[k1,p1] + 28*sp[k1,k3]
      ^2*sp[k1,p1]*m + 24*sp[k1,k3]^2*sp[k2,p1] - 12*sp[k1,k3]^2*sp[k2,
      p1]*m - 24*sp[k1,k3]^2*sp[p1,p2] + 12*sp[k1,k3]^2*sp[p1,p2]*m + 
      40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 20*sp[k1,k3]*sp[k1,p1]*sp[k1,
      p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 4*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 20*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m + 224*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 
      56*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p2] + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 80*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 24*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1] - 12*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 8*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m
       - 44*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 24*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1]*m + 72*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,
      k3]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]^2 + 4*sp[k1,k3]*sp[
      k2,p1]^2*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 24*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p1] - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 
      200*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 72*sp[k1,k3]*sp[k3,p1]*
      sp[k3,p2] + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2] + 12*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 44*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 8*
      sp[k1,k3]*sp[p1,p2]^2 + 4*sp[k1,k3]*sp[p1,p2]^2*m - 104*sp[k1,p1]
      ^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,k3]*m + 208*sp[k1,p1]^2*sp[k2
      ,p2] - 64*sp[k1,p1]^2*sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2] - 
      32*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 
      16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 160*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1] + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 80*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1] + 20*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 8*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m
       + 52*sp[k1,p1]*sp[k2,k3]^2 - 28*sp[k1,p1]*sp[k2,k3]^2*m + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 
      72*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 4*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16
      *sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p1] + 20*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p1]
      *sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 80*sp[k1,p1]*
      sp[k2,p1]*sp[p1,p2] - 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 88*sp[
      k1,p1]*sp[k2,p2]^2 + 40*sp[k1,p1]*sp[k2,p2]^2*m - 32*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 72*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m
       + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2]*m - 56*sp[k1,p1]*sp[k3,p1]^2 + 28*sp[k1,p1]*sp[k3,p1]^2*m
       + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 4*sp[k1,p1]*sp[k3,p1]*sp[k3,
      p2]*m + 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 20*sp[k1,p1]*sp[k3,p1]
      *sp[p1,p2]*m + 52*sp[k1,p1]*sp[k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^
      2*m + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 8*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2]*m + 16*sp[k1,p2]^2*sp[k2,p1] - 8*sp[k1,p2]^2*sp[k2,p1]*
      m + 8*sp[k1,p2]^2*sp[k3,p1] - 4*sp[k1,p2]^2*sp[k3,p1]*m - 52*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]^2 - 8*sp[k1,p2]*sp[k2,p1]^2
      *m + 72*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 4*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p1]*m + 52*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 8*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
       + 64*sp[k1,p2]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[
      p1,p2]*m + 24*sp[k1,p2]*sp[k3,p1]^2 - 12*sp[k1,p2]*sp[k3,p1]^2*m
       - 44*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[k3,p1]*sp[
      k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,p2]*sp[k3,p1
      ]*sp[p1,p2]*m + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p2]*
      sp[k3,p2]*sp[p1,p2]*m] + amp[7,11]*color[1/2*Ca^2*Na*Tf]*den[sp[
      k1 - p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*
      num[24*sp[k1,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m + 24*
      sp[k1,k2]^2*sp[p1,p2]*m - 4*sp[k1,k2]^2*sp[p1,p2]*m^2 - 24*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 24
      *sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
      *m + 24*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m^2 + 104*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 48*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       + 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 48*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 12*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 96*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       + 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 48*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1
      ,p2]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 40
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ]*m^2 - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1]*m - 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 40*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 48*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 48*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m^2 + 24*sp[k1,k3]^2*sp[k2,p1] - 16*sp[k1,k3]^2*
      sp[k2,p1]*m + 24*sp[k1,k3]^2*sp[p1,p2]*m - 4*sp[k1,k3]^2*sp[p1,p2
      ]*m^2 + 104*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 48*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m - 12*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 4*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[k1,p1]
      *sp[k3,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 48*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 40*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m^2 - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2
       + 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m - 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,
      k3]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 4*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k3,p2]*sp[p1,
      p2] + 40*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2]*m^2 + 176*sp[k1,p1]^2*sp[k2,k3] - 48*sp[k1,p1]^2*sp[k2,
      k3]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3]*m - 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m - 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 176*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 + 12*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 96
      *sp[k1,p1]*sp[k2,p2]^2 - 40*sp[k1,p1]*sp[k2,p2]^2*m + 4*sp[k1,p1]
      *sp[k2,p2]^2*m^2 + 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 
      8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2]*m^2 + 24*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,
      p1]*sp[k3,p2]*m^2 + 96*sp[k1,p1]*sp[k3,p2]^2 - 40*sp[k1,p1]*sp[k3
      ,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 104*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 104*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 176*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m - 96*sp[k1,p2]*sp[k2,p1]^2 + 40*sp[k1,p2]*sp[k2,p1]^2*m - 4*sp[
      k1,p2]*sp[k2,p1]^2*m^2 - 24*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m^2 - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 4*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k3,p1]^2 + 40
      *sp[k1,p2]*sp[k3,p1]^2*m - 4*sp[k1,p2]*sp[k3,p1]^2*m^2 - 24*sp[k1
      ,p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2]
       + amp[7,12]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[k1
       - p2]]*den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*num[32*sp[k1,k2]^2*
      sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,p1]*m - 8*sp[k1,k2]^2*sp[p1,p2]*m
       + 4*sp[k1,k2]^2*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1] - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 64
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 80*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       - 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 
      24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2]*m^2 - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 144
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
      *m + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 64*
      sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 64*sp[k1,k3]
      ^2*sp[k2,p1] + 24*sp[k1,k3]^2*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 144*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 4*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]
       + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 96*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 
      144*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2]*m - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 24*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2] + 32*sp[k1,k3]*sp[p1,p2]^2 - 8*sp[k1,k3]*sp[p1,p2]^2*m + 
      80*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,
      p1]^2*sp[k2,p1] + 16*sp[k1,p1]^2*sp[k2,p1]*m + 16*sp[k1,p1]^2*sp[
      k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p1] + 32*sp[k1,p1]^2*sp[k3,p1]*m
       + 8*sp[k1,p1]^2*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2
      ]*sp[k3,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2]*m^2 + 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]
       - 16*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p2]^2
       + 24*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 48*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]
       - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*
      sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[
      k3,p2]*sp[p1,p2] + 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1] + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]^2
       - 8*sp[k1,p2]*sp[k2,p1]^2*m + 4*sp[k1,p2]*sp[k2,p1]^2*m^2 + 8*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
      *m^2 - 176*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 72*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] - 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 80*sp[k1,p2]*sp[
      k3,p1]^2 + 32*sp[k1,p2]*sp[k3,p1]^2*m - 96*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] + 40*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[7,13]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[k1 - p2]]*den[sp[k2
       + k3]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]^2*sp[k3,p1] - 24*sp[
      k1,k2]^2*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 24*sp[
      k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
       - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[
      k1,p1]*sp[k2,k3] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 96*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 
      144*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 96
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 144*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 
      48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2]*m + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 32*sp[k1,k2]*sp[p1,p2]^2 + 8*sp[k1,k2]*sp[p1,p2]^2*
      m - 32*sp[k1,k3]^2*sp[k2,p1] + 8*sp[k1,k3]^2*sp[k2,p1]*m + 8*sp[
      k1,k3]^2*sp[p1,p2]*m - 4*sp[k1,k3]^2*sp[p1,p2]*m^2 - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k2,k3] + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 80*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*
      m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1] - 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p2]*m^2 + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 144*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2
      ]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 40*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 112*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1] - 40*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m^2 - 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p1]
      *sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 64*
      sp[k1,k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 80*sp[k1,p1]
      ^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 64*sp[k1,p1]^2*sp[k2,
      p1] - 32*sp[k1,p1]^2*sp[k2,p1]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m + 32
      *sp[k1,p1]^2*sp[k3,p1] - 16*sp[k1,p1]^2*sp[k3,p1]*m - 16*sp[k1,p1
      ]^2*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 24*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       - 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] - 24*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*
      sp[k2,p1]*sp[p1,p2]*m - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 24*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*
      m^2 - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p1]*
      sp[p1,p2]*m + 32*sp[k1,p1]*sp[k3,p2]^2 - 24*sp[k1,p1]*sp[k3,p2]^2
      *m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 64*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2] - 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 80*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1
      ,p2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,
      p2]*sp[k2,p1]^2*m + 176*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 72*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2
       - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,p2]*sp[k2,
      p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32
      *sp[k1,p2]*sp[k3,p1]^2 + 8*sp[k1,p2]*sp[k3,p1]^2*m - 4*sp[k1,p2]*
      sp[k3,p1]^2*m^2 - 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m^2 + 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 32*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[7,14]*color[ - 1/2*Ca^2*Na
      *Tf]*den[sp[k1 - p1]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[
      sp[p1 + p2]]*num[ - 96*sp[k1,k2]^2*sp[p1,p2] + 40*sp[k1,k2]^2*sp[
      p1,p2]*m - 4*sp[k1,k2]^2*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 
      4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 48*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 12*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 96*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 4*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m^2 - 104*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] - 40*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k3,p1]^2 - 16*
      sp[k1,k2]*sp[k3,p1]^2*m + 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 + 12*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]^2*sp[p1,p2] + 40*sp[k1,k3]^2*
      sp[p1,p2]*m - 4*sp[k1,k3]^2*sp[p1,p2]*m^2 + 48*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 12*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*
      m + 24*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m^2 + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 96*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 40*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*
      m + 4*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 104*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]*
      sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m + 24*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 24*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 48*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 
      4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 24*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 12*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,
      k3]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 4*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*sp[k3,p2]*sp[p1,
      p2]*m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 176*sp[k1,p1]^2*sp[
      k2,k3] + 48*sp[k1,p1]^2*sp[k2,k3]*m - 176*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 104*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p1] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 104*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 
      104*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1]*m + 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 12*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k2,
      p2]^2 + 40*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2
       - 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m^2 - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 24*sp[k1
      ,p1]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2
       - 96*sp[k1,p1]*sp[k3,p2]^2 + 40*sp[k1,p1]*sp[k3,p2]^2*m - 4*sp[
      k1,p1]*sp[k3,p2]^2*m^2 - 176*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 48*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,p2]*sp[k2,p1]^2*m - 4*
      sp[k1,p2]*sp[k2,p1]^2*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 40
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p1]*m^2 + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 48*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m
       - 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 24*sp[k1,p2]*sp[k3,p1]^2
      *m - 4*sp[k1,p2]*sp[k3,p1]^2*m^2 + 96*sp[k1,p2]*sp[k3,p1]*sp[k3,
      p2] - 40*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2]*m^2] + amp[7,15]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]
      *den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[56*
      sp[k1,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m + 56*sp[k1,k2]
      ^2*sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 56*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 72*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] + 28*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 8*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 
      40*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3
      ]*m - 88*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m - 72*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16
      *sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 56*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 24*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*
      sp[k2,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m - 96*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m
       - 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 36*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k2,
      p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 8*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 112*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] - 36*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 40*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 120*sp[k1
      ,k2]*sp[k3,p1]^2 - 44*sp[k1,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 40*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m + 72*sp[k1,k3]^2*sp[k2,p1] - 28*sp[k1,k3]^2*sp[k2,p1]*m - 40*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 12*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*
      m + 56*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 12*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m + 112*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 40*sp[k1,k3
      ]*sp[k1,p1]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] + 20*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 112*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1] + 44*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 80*sp[k1,k3]*sp[
      k2,k3]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 24*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 32
      *sp[k1,k3]*sp[k2,p1]^2 - 8*sp[k1,k3]*sp[k2,p1]^2*m - 12*sp[k1,k3]
      *sp[k2,p1]*sp[k2,p2]*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 4*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 160*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,k3]*sp[k3,p1]^2 - 32*sp[k1,k3]
      *sp[k3,p1]^2*m + 48*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[p1,p2]^2 - 40*sp[k1,p1]^2
      *sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 104*sp[k1,p1]^2*sp[k2,
      p2] - 32*sp[k1,p1]^2*sp[k2,p2]*m + 40*sp[k1,p1]^2*sp[k3,p2] - 16*
      sp[k1,p1]^2*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 24*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 88*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 104*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 160*sp[k1,p1]*
      sp[k2,k3]^2 - 68*sp[k1,p1]*sp[k2,k3]^2*m + 16*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 104*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m
       - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2]*m - 136*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 40*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]
      *sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k2,p1]*
      sp[p1,p2] - 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 72*sp[k1,p1]*sp[
      k2,p2]^2 + 28*sp[k1,p1]*sp[k2,p2]^2*m + 136*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 32*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 80
      *sp[k1,p1]*sp[k3,p1]^2 + 40*sp[k1,p1]*sp[k3,p1]^2*m + 32*sp[k1,p1
      ]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*
      sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*
      m + 88*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[
      p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 12*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[k2,p1]^2 - 32*
      sp[k1,p2]*sp[k2,p1]^2*m + 56*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 20*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1
      ] - 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 120*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 44*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 56*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16
      *sp[k1,p2]*sp[k3,p1]^2 - 32*sp[k1,p2]*sp[k3,p1]^2*m + 104*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + 
      amp[7,16]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2
       + p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[ - 72*sp[k1,k2]^
      2*sp[k3,p1] + 28*sp[k1,k2]^2*sp[k3,p1]*m + 72*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1] - 28*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 56*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 
      40*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 12*sp[k1,k2]*sp[k1,p1]*sp[k2,
      k3]*m - 112*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,p1]*m - 56*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 12*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 20*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 80*sp[k1,k2]*sp[
      k2,k3]*sp[k2,p1] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m + 112*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,p1] - 44*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 
      24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m - 80*sp[k1,k2]*sp[k2,p1]^2 + 32*sp[k1,k2]*sp[k2,p1]^2*m + 
      24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1
      ]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 48*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m - 40*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k3,p1]^2 + 8*sp[k1,k2
      ]*sp[k3,p1]^2*m + 12*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 160*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 24
      *sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[p1,p2]^2 - 56*
      sp[k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m - 56*sp[k1,k3]
      ^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m + 40*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 40*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       + 88*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p2]*m + 72*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2]*m - 56*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] - 36*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k2,k3]*
      sp[k3,p1] - 16*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] - 36*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 120*sp[k1
      ,k3]*sp[k2,p1]^2 + 44*sp[k1,k3]*sp[k2,p1]^2*m + 16*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p1] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 112
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 36*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m + 40*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 32*
      sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 12*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 40*sp[k1,p1]^2*
      sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2]
       + 16*sp[k1,p1]^2*sp[k2,p2]*m - 104*sp[k1,p1]^2*sp[k3,p2] + 32*
      sp[k1,p1]^2*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 24*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 88*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 160*sp[k1,p1]*
      sp[k2,k3]^2 + 68*sp[k1,p1]*sp[k2,k3]^2*m + 104*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p1] - 36*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m
       + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2]*m + 136*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 40*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[k2,p1]^2 - 40*sp[k1,p1]*sp[k2,
      p1]^2*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,p1
      ]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1]*m - 136*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 20*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2
      ] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 40*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 88*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80
      *sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]
      *m - 80*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,p1]*sp[k3,p1]*
      sp[p1,p2]*m + 72*sp[k1,p1]*sp[k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2
      *m - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 12*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,p1]^2 + 32*
      sp[k1,p2]*sp[k2,p1]^2*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 20*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 104*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 120*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] + 44*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 80*sp[
      k1,p2]*sp[k3,p1]^2 + 32*sp[k1,p2]*sp[k3,p1]^2*m - 56*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2] + 20*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m]
       + amp[8,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[
      k1 - p2]]*den[sp[ - k2 + p1]]*num[ - 32*sp[k1,k2]*sp[k1,p1] + 16*
      sp[k1,k2]*sp[k1,p1]*m + 80*sp[k1,k2]*sp[p1,p2] - 56*sp[k1,k2]*sp[
      p1,p2]*m + 8*sp[k1,k2]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2 - 16*sp[k1,
      p1]^2*m - 48*sp[k1,p1]*sp[k2,p2] + 40*sp[k1,p1]*sp[k2,p2]*m - 8*
      sp[k1,p1]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,p1]*
      sp[p1,p2]*m - 48*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,p2]*sp[k2,p1]*m
       - 8*sp[k1,p2]*sp[k2,p1]*m^2] + amp[8,1]*color[1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*num[32*
      sp[k1,k2]*sp[k1,p1] - 16*sp[k1,k2]*sp[k1,p1]*m - 80*sp[k1,k2]*sp[
      p1,p2] + 56*sp[k1,k2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[p1,p2]*m^2 - 
      32*sp[k1,p1]^2 + 16*sp[k1,p1]^2*m + 48*sp[k1,p1]*sp[k2,p2] - 40*
      sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*
      sp[p1,p2] - 16*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[k2,p1] - 
      40*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*m^2] + amp[8,2]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*
      num[ - 256*sp[k1,k2]^2*sp[k3,p1] + 128*sp[k1,k2]^2*sp[k3,p1]*m - 
      16*sp[k1,k2]^2*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2] + 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 128
      *sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,
      k3]*m^2 - 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p1]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2
      ]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]
      *sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m + 640*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 480*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 112*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^3 - 640*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] + 416*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m^3 + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]
      *sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 
      64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*
      m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k1,p2]
      *sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m^2 + 640*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 480
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^3 + 128*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1
      ,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*
      sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1]^2*sp[k3,p2]
      *m - 16*sp[k1,p1]^2*sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1
      ]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 608*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 8*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2]*m^3 - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 256*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2] - 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 64*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 256*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 
      16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 256*sp[k1,p2]*sp[k2,p1]^2
       + 128*sp[k1,p2]*sp[k2,p1]^2*m - 16*sp[k1,p2]*sp[k2,p1]^2*m^2 - 
      64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m] + amp[8,3]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]
      ]*num[ - 64*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m + 
      128*sp[k1,k2]^2*sp[p1,p2] - 32*sp[k1,k2]^2*sp[p1,p2]*m - 128*sp[
      k1,k2]*sp[k1,k3]*sp[k1,p1] + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m
       + 320*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 208*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 96*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 64*
      sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*
      m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k2,k3]*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1
      ,p1]*sp[k2,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 64*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 256*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
       + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*
      m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 64*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*
      m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[
      p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2*m + 128*sp[k1,k3]*sp[k1,p1]^2
       - 64*sp[k1,k3]*sp[k1,p1]^2*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]
       - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 160*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 
      192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,
      p1]^2*sp[k1,p2] + 32*sp[k1,p1]^2*sp[k1,p2]*m - 32*sp[k1,p1]^2*sp[
      k2,k3] + 64*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k3,p2] + 32
      *sp[k1,p1]^2*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 128*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[
      k1,p1]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m
       - 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p2]^2 + 48*sp[k1,p1]
      *sp[k2,p2]^2*m - 8*sp[k1,p1]*sp[k2,p2]^2*m^2 - 16*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1
      ]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]
      ^2*sp[k2,p1]*m + 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 160*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 
      64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2
      ]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m] + 
      amp[8,4]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[p1
       + p2]]*num[ - 128*sp[k1,k2]^2*sp[p1,p2] + 96*sp[k1,k2]^2*sp[p1,
      p2]*m - 16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k1,p1]^2
       + 64*sp[k1,k2]*sp[k1,p1]^2*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]
       + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 256*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1] - 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2
      ]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 96
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 96*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 1024*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2] - 704*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m
       + 144*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 8*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m^3 - 128*sp[k1,k2]*sp[p1,p2]^2 + 96*sp[k1,k2]*sp[p1,p2
      ]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2*m^2 + 128*sp[k1,p1]^3 - 64*sp[k1
      ,p1]^3*m + 128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*sp[k1,p2]*m
       + 128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]^2*sp[k2,p1]*m + 256*
      sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k2,p2]*m - 128*sp[k1,p1
      ]^2*sp[p1,p2] + 64*sp[k1,p1]^2*sp[p1,p2]*m - 128*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 96*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 
      256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 192*sp[k1,p1]*sp[k1,p2]*sp[p1
      ,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]
       + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 1024*sp[k1,p1]*sp[k2,p2]^
      2 + 704*sp[k1,p1]*sp[k2,p2]^2*m - 144*sp[k1,p1]*sp[k2,p2]^2*m^2
       + 8*sp[k1,p1]*sp[k2,p2]^2*m^3 + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2
      ] - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 96*sp[k1,p2]^2*sp[k2,
      p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]^2
       - 96*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]^2*m^2 + 
      1024*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 704*sp[k1,p2]*sp[k2,p1]*sp[
      k2,p2]*m + 144*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m^3 + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 96*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ]*m^2] + amp[8,5]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[
      k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]^2*num[128*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p2]*sp[k2
      ,p1] + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 288*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2
       + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^3 + 
      128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 160*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 8*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m^3] + amp[8,6]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[
      sp[ - k2 + p2]]*num[ - 96*sp[k1,k2]^2*sp[k3,p1] + 80*sp[k1,k2]^2*
      sp[k3,p1]*m - 16*sp[k1,k2]^2*sp[k3,p1]*m^2 + 96*sp[k1,k2]^2*sp[p1
      ,p2] - 32*sp[k1,k2]^2*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 80*sp[
      k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*
      m^2 - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 
      160*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]
      *sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 32*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 224*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] + 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 80*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 64
      *sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m - 192*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 80*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       + 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2] + 112*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[p1,p2]^2 - 
      112*sp[k1,k3]*sp[p1,p2]^2*m + 16*sp[k1,k3]*sp[p1,p2]^2*m^2 - 32*
      sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 32*sp[k1,p1]
      ^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2
      ]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 128*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*
      m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p1]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k1
      ,p2]*sp[p1,p2]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 112*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2
       + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m + 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1] + 448*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 224
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2]*m^2 - 256*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 144*sp[k1,p1]*sp[k3
      ,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[
      k1,p2]^2*sp[k2,p1] + 48*sp[k1,p2]^2*sp[k2,p1]*m + 64*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 8*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m - 320*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 176*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,p2]
      *sp[k3,p1]*sp[p1,p2] - 80*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[8,7]*color[ - Cf^2*Na*Tf
       + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]
      ]*den[sp[ - k2 + p1]]*den[sp[p1 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 64*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1
      ]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 96*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 96*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2
       - 640*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 480*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 112*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 8*sp[k1,k2]
      *sp[k3,p2]*sp[p1,p2]*m^3 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 64*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1
      ]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 64*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 64
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 
      256*sp[k1,k3]*sp[p1,p2]^2 - 128*sp[k1,k3]*sp[p1,p2]^2*m + 16*sp[
      k1,k3]*sp[p1,p2]^2*m^2 + 64*sp[k1,p1]^2*sp[k2,k3] - 64*sp[k1,p1]^
      2*sp[k2,k3]*m + 16*sp[k1,p1]^2*sp[k2,k3]*m^2 - 64*sp[k1,p1]^2*sp[
      k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 
      32*sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 
      64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1]*m + 256*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 128*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2
       + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p1]*m - 256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k1
      ,p2]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 
      128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 896*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2] - 608*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 
      128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m^3 - 256*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 128*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 - 
      256*sp[k1,p2]^2*sp[k2,p1] + 128*sp[k1,p2]^2*sp[k2,p1]*m - 16*sp[
      k1,p2]^2*sp[k2,p1]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 416*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3 - 64*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m^2 - 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 
      128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m^2 - 640*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 480*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 8
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^3 - 64*sp[k1,p2]*sp[k3,p1]*sp[p1
      ,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[8,8]*color[
       - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[
       - k2 - k3]]*den[sp[ - k2 + p1]]*num[32*sp[k1,k2]^2*sp[k3,p1] - 8
      *sp[k1,k2]^2*sp[k3,p1]*m - 8*sp[k1,k2]^2*sp[p1,p2]*m + 4*sp[k1,k2
      ]^2*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 8*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 24*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]
      *sp[k2,k3] - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 64*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 
      16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k2,k3]*sp[p1
      ,p2] - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 32
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k2]*sp[k2,p2]*sp[
      p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 144*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*
      sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 64*sp[k1,k3]^2*sp[k2,
      p1] + 24*sp[k1,k3]^2*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,
      k3] - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 144*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m
       + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 144*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]
      *sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 8*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
       + 32*sp[k1,k3]*sp[p1,p2]^2 - 8*sp[k1,k3]*sp[p1,p2]^2*m + 80*sp[
      k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,p1]^2*
      sp[k2,p1] + 16*sp[k1,p1]^2*sp[k2,p1]*m + 16*sp[k1,p1]^2*sp[k2,p2]
      *m - 64*sp[k1,p1]^2*sp[k3,p1] + 32*sp[k1,p1]^2*sp[k3,p1]*m + 8*
      sp[k1,p1]^2*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 8*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2
      ] - 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m^2 + 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 16*sp[
      k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p2]^2 + 24*sp[
      k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 48*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p1] + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 32
      *sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2] + 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]^2 - 8*sp[k1,p2]*
      sp[k2,p1]^2*m + 4*sp[k1,p2]*sp[k2,p1]^2*m^2 + 8*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 176*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1] + 72*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 24*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 80*sp[k1,p2]*sp[k3,p1]^2 + 32*sp[
      k1,p2]*sp[k3,p1]^2*m - 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 40*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[8,10]*color[1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[
       - k3 + p2]]*num[32*sp[k1,k2]^2*sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,
      p1]*m - 64*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,
      p1]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 128*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] - 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,k3] + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p2]
      *sp[k2,p1]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 4*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 96*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] - 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m
       + 8*sp[k1,k2]*sp[p1,p2]^2*m - 4*sp[k1,k2]*sp[p1,p2]^2*m^2 + 80*
      sp[k1,k3]^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m - 64*sp[k1,k3]
      *sp[k1,p1]^2 + 32*sp[k1,k3]*sp[k1,p1]^2*m - 80*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 48*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] + 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 80*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 176*sp[k1
      ,k3]*sp[k1,p2]*sp[k2,p1] + 72*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 144*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2] - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 80*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 16*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m - 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 24*sp[k1,k3]
      *sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[p1,p2]^2 - 8*sp[k1,k3]*
      sp[p1,p2]^2*m + 32*sp[k1,p1]^2*sp[k1,p2] - 16*sp[k1,p1]^2*sp[k1,
      p2]*m + 8*sp[k1,p1]^2*sp[k2,k3]*m - 16*sp[k1,p1]^2*sp[k2,p2]*m + 
      80*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m + 192*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 
      32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p2] + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m^2 - 144*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m
       + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]^2 - 24*sp[k1,
      p1]*sp[k2,p2]^2*m + 4*sp[k1,p1]*sp[k2,p2]^2*m^2 + 4*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m
       + 4*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[
      k3,p2]*sp[p1,p2] - 24*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,
      p2]^2*sp[k2,p1] + 8*sp[k1,p2]^2*sp[k2,p1]*m - 4*sp[k1,p2]^2*sp[k2
      ,p1]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 
      112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 40*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2]*m^2 + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 40*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 16*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       - 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m^2 + 144*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k3,p1]^2 - 24*sp[k1,p2]*sp[
      k3,p1]^2*m - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 8*sp[k1,p2]*sp[k3
      ,p1]*sp[p1,p2]*m] + amp[8,11]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 - 
      p2]]^2*den[sp[ - k2 - k3]]*den[sp[ - k2 + p1]]*num[64*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
       - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,
      p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1] - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 
      128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k3,p1]*sp[
      p1,p2]*m^2] + amp[8,12]*color[ - Cf^2*Na*Tf]*den[sp[k1 - p2]]^2*
      den[sp[ - k2 + p1]]^2*num[128*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 192
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m^2 - 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^3] + amp[8,13]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p2]]^2*den[sp[
       - k2 + p1]]*den[sp[ - k3 + p1]]*num[256*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] - 288*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3 - 128*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2]*m^3 - 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,p2
      ]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 
      128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 160*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1]*m^3 - 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 128*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*
      m^2] + amp[8,14]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + p1]]*den[sp[p1 + p2]
      ]*num[ - 32*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m + 
      32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 96*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 64*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*
      m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*
      sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,k2]*sp[p1,p2]^2*m - 128*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2
      ] - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,
      k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m + 64*sp[k1,p1]^2*sp[
      k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p1] + 
      32*sp[k1,p1]^2*sp[k2,p1]*m + 64*sp[k1,p1]^2*sp[k2,p2] - 128*sp[k1
      ,p1]^2*sp[k3,p1] + 64*sp[k1,p1]^2*sp[k3,p1]*m + 32*sp[k1,p1]^2*
      sp[k3,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m - 160*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 
      64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1
      ,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p1
      ]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 192*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[
      k1,p1]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m
       - 64*sp[k1,p1]*sp[k2,p2]^2 + 48*sp[k1,p1]*sp[k2,p2]^2*m - 8*sp[
      k1,p1]*sp[k2,p2]^2*m^2 - 160*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 48*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 64*
      sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k3,p2]*sp[p1,p2
      ] + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*
      sp[k2,p1]^2*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m - 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,p2
      ]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 16*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1] - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1]*m^2 - 320*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 208*sp[k1
      ,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2
      ] + amp[8,15]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p2]]*den[sp[ - 
      k2 + p1]]^2*den[sp[ - k3 + p2]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1]*m^2 - 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2
       - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2] + 
      amp[8,16]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]
      ]*den[sp[ - k2 + p1]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*
      num[ - 192*sp[k1,k2]^2*sp[k3,p1] + 112*sp[k1,k2]^2*sp[k3,p1]*m - 
      16*sp[k1,k2]^2*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
       + 80*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 144*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3
      ]*m^2 - 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,p1]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m^2 + 192*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 80*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 256*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1] - 112*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k3,p2]
      *sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,k2]*
      sp[p1,p2]^2 - 32*sp[k1,k2]*sp[p1,p2]^2*m - 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1
      ,k3]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 
      48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m^2 + 320*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 176*sp[k1,k3]*sp[k2
      ,p1]*sp[k2,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 16*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m^2 - 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]
      *sp[p1,p2]^2 - 80*sp[k1,k3]*sp[p1,p2]^2*m + 16*sp[k1,k3]*sp[p1,p2
      ]^2*m^2 + 32*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m
       + 32*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1
      ,p1]^2*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 80*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 224*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2
       - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2
      ,p1]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 
      64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1]*m + 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1
      ,p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 
      96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2]*m - 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 224*sp[k1
      ,p2]*sp[k2,k3]*sp[p1,p2] - 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 
      8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]^2
       + 48*sp[k1,p2]*sp[k2,p1]^2*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 160*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*
      m - 256*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 160*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p2]
      *sp[k3,p1]*sp[p1,p2] - 48*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[9,1]*color[ - 1/2*Ca^2*
      Na*Tf]*den[sp[ - k1 + p1]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*
      num[ - 48*sp[k1,k3]*sp[k2,p1] + 24*sp[k1,k3]*sp[k2,p1]*m + 48*sp[
      k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m - 48*sp[k1,p1]*sp[k2,
      p2] + 24*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1,p1]*sp[k3,p1] + 24*sp[
      k1,p1]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,p1]*sp[p1,
      p2]*m + 48*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,p1]*m] + amp[
      9,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[ - k2 + 
      p1]]*den[sp[k3 - p2]]*num[ - 24*sp[k1,k2]*sp[k3,p1] + 20*sp[k1,k2
      ]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[p1,p2
      ] + 20*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 - 8*sp[
      k1,k3]*sp[k2,p1] - 4*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1
      ]*m^2 + 40*sp[k1,p1]*sp[k2,k3] - 28*sp[k1,p1]*sp[k2,k3]*m + 4*sp[
      k1,p1]*sp[k2,k3]*m^2 - 8*sp[k1,p1]*sp[k2,p2] - 4*sp[k1,p1]*sp[k2,
      p2]*m + 4*sp[k1,p1]*sp[k2,p2]*m^2 - 16*sp[k1,p1]*sp[k3,p1] + 8*
      sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,p1]*sp[
      p1,p2]*m + 40*sp[k1,p2]*sp[k2,p1] - 28*sp[k1,p2]*sp[k2,p1]*m + 4*
      sp[k1,p2]*sp[k2,p1]*m^2] + amp[9,1]*color[1/4*Ca^2*Na*Tf]*den[sp[
       - k1 + p1]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*num[ - 24*sp[k1
      ,k2]*sp[k3,p1] + 20*sp[k1,k2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]
      *m^2 - 24*sp[k1,k2]*sp[p1,p2] + 20*sp[k1,k2]*sp[p1,p2]*m - 4*sp[
      k1,k2]*sp[p1,p2]*m^2 + 40*sp[k1,k3]*sp[k2,p1] - 28*sp[k1,k3]*sp[
      k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2 - 8*sp[k1,p1]*sp[k2,k3] - 4*
      sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k2,k3]*m^2 + 40*sp[k1,p1]*
      sp[k2,p2] - 28*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*m^2
       + 32*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,
      p1]*sp[p1,p2] + 8*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,p1]
       - 4*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2] + amp[9,2
      ]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*den[sp[k3 - p2]]*num[ - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*
      m + 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,k3]
      *sp[k3,p1] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 112*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m
       - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 320*sp[k1,k2]*sp[k2,p1]
      *sp[p1,p2] - 208*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 160
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1]*m^2 - 32*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*m
       - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m + 32*sp[k1,k3]^2*sp[k2,p1] - 16*sp[k1,k3]^2*sp[k2,p1]*m
       - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,k3]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1] - 48*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p1]^2 - 32*sp[k1,k3]*
      sp[k2,p1]^2*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,p1]^2*sp[k2,k3]
       + 32*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k3,p1] + 32*sp[k1
      ,p1]^2*sp[k3,p1]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]^2*
      sp[k3,p2]*m + 128*sp[k1,p1]^2*sp[p1,p2] - 64*sp[k1,p1]^2*sp[p1,p2
      ]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p1] + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,k3]^2 + 48*sp[k1,p1]*sp[
      k2,k3]^2*m - 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 128*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 160*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 64
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m + 128*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,p1]*
      sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p2]*sp[k2,p1]^2 + 16*sp[
      k1,p2]*sp[k2,p1]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]] + amp[9,
      3]*color[ - Ca*Cf*Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*den[sp[k3 - p2]]*num[96*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 
      48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m + 352*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 16*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
       + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 704*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] + 368*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m
       - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1
      ,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2
       + 96*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]^2*m - 96*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 96*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 96*sp[
      k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m + 96*sp[k1,k3]*
      sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 48*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m - 192*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 80*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 48*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       - 352*sp[k1,p1]^2*sp[k3,p2] + 96*sp[k1,p1]^2*sp[k3,p2]*m - 48*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1
      ]*sp[k1,p2]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,k3]^2 - 80*sp[k1,p1
      ]*sp[k2,k3]^2*m + 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 192*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 
      16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,k3]*sp[p1
      ,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 352*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 192*sp[k1,p1
      ]*sp[k2,p2]^2 - 80*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2
      ]^2*m^2 + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]
      *sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^
      2*sp[k2,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 192
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 80*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
      *m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 48*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 96*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m] + amp[9
      ,4]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*
      den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*den[sp[p1 + p2]]*num[128*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       - 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2
      ] - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 320*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 208
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p1]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m
       - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 112*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 48*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2
      *m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[
      k1,k3]*sp[k2,p1]^2*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       + 32*sp[k1,p1]^2*sp[k2,k3] - 64*sp[k1,p1]^2*sp[k2,p2] + 128*sp[
      k1,p1]^2*sp[k3,p1] - 64*sp[k1,p1]^2*sp[k3,p1]*m + 64*sp[k1,p1]^2*
      sp[k3,p2] - 32*sp[k1,p1]^2*sp[k3,p2]*m - 64*sp[k1,p1]^2*sp[p1,p2]
       + 32*sp[k1,p1]^2*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]
      *sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*
      m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 192*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 128*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,
      p1]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p2]^2 - 48*sp[k1,
      p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 160*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m
       - 32*sp[k1,p2]^2*sp[k2,p1] + 16*sp[k1,p2]^2*sp[k2,p1]*m + 32*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m^2 + 128*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m - 64
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
      *m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m] + amp[9
      ,5]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]
      ]^2*den[sp[k3 - p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 64
      *sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1]*m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,k2]*sp[k1
      ,p2]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 128*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2] + amp[9,6]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]*den[
      sp[ - k2 + p2]]*den[sp[k3 - p2]]*num[ - 48*sp[k1,k2]^2*sp[k3,p1]
       + 16*sp[k1,k2]^2*sp[k3,p1]*m - 48*sp[k1,k2]^2*sp[p1,p2] + 16*sp[
      k1,k2]^2*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 32*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k2,k3]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 112*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2] + 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 144*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,p1] + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,p1]*m^2 - 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 40*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 48*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*
      sp[k3,p1]^2*m + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 40*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 48*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m
       - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m - 176*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 112*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 32*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 16*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1] - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 56*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 48*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[p1,p2]^2 + 56*
      sp[k1,k3]*sp[p1,p2]^2*m - 16*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]
      ^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 48*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2] + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 160*sp[k1,p1]*sp[k1,p2]*sp[p1,p2
      ] - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 144*sp[k1,p1]*sp[k2,k3]^
      2 - 96*sp[k1,p1]*sp[k2,k3]^2*m + 16*sp[k1,p1]*sp[k2,k3]^2*m^2 + 
      24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p2]*m^2 - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 8*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 72*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 40
      *sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 128*sp[k1,p2]^2*sp[k2,p1] - 56
      *sp[k1,p2]^2*sp[k2,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 192*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 56*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p2] - 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 
      128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m + 48*sp[k1,p2]*sp[k3,p1]^2 - 16*sp[k1,p2]*sp[k3,p1]^2*m + 
      64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,p2]*sp[k3,p1]*sp[p1,
      p2]*m] + amp[9,7]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*den[sp[p1 + p2]
      ]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]^2 + 80*sp[k1
      ,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1]^2*m^2 - 96*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 80*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 320*sp[k1,k2]*sp[k3,p2
      ]*sp[p1,p2] - 176*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 8*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 - 
      256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 224*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 160*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 64*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[p1,p2]^2 + 48*
      sp[k1,k3]*sp[p1,p2]^2*m + 32*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]
      ^2*sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,
      p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 256*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2] + 144*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1] + 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k1,p2]*
      sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 80*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 192*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 32*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2] - 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 192*sp[k1,p2]^2*sp[k2,
      p1] - 112*sp[k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2
       - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] - 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k3,p1]^2 - 32*sp[k1
      ,p2]*sp[k3,p1]^2*m + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[9,8]*color[1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 + p1]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + p1]]*den[sp[k3
       - p2]]*num[56*sp[k1,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m
       + 56*sp[k1,k2]^2*sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 56*sp[
      k1,k2]*sp[k1,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m
       - 72*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 28*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 8*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m - 88*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 72*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 56*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 56*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*
      m - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k2,k3]*sp[
      k2,p1]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,k2]*sp[k2,
      k3]*sp[k3,p1]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 36*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] - 32*
      sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1
      ] - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 112*sp[k1
      ,k2]*sp[k2,p2]*sp[k3,p1] - 36*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 
      40*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,p2]*sp[p1,
      p2]*m + 120*sp[k1,k2]*sp[k3,p1]^2 - 44*sp[k1,k2]*sp[k3,p1]^2*m - 
      16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2
      ]*m - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m - 40*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m + 72*sp[k1,k3]^2*sp[k2,p1] - 28*sp[k1,k3]^2*
      sp[k2,p1]*m - 40*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 12*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 12
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 112*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p1] - 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k1,p1]
      *sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] + 20*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 112*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 44*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*
      m - 80*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,k3]*sp[
      k3,p1]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p1]^2 - 8*sp[k1,k3]*sp[k2,p1
      ]^2*m - 12*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 24*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p1] - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 40*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 160*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,k3]*sp[k3,
      p1]^2 - 32*sp[k1,k3]*sp[k3,p1]^2*m + 48*sp[k1,k3]*sp[k3,p1]*sp[p1
      ,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[p1,p2
      ]^2 - 40*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 104
      *sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k2,p2]*m + 40*sp[k1,p1
      ]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 88*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 104*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*
      m + 160*sp[k1,p1]*sp[k2,k3]^2 - 68*sp[k1,p1]*sp[k2,k3]^2*m + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*
      m - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m - 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 36*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 4*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m - 136*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 40*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k2,p2
      ] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 40*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 80*sp[k1,
      p1]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 72
      *sp[k1,p1]*sp[k2,p2]^2 + 28*sp[k1,p1]*sp[k2,p2]^2*m + 136*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1] - 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 48
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
      *m + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2]*m - 80*sp[k1,p1]*sp[k3,p1]^2 + 40*sp[k1,p1]*sp[k3,p1]^2
      *m + 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2]*m + 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,
      p1]*sp[p1,p2]*m + 88*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,p1]
      *sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 12*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[
      k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m + 56*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2] - 20*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] - 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 120*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p2] - 44*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 
      64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,
      p2]*m - 56*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1]*m + 16*sp[k1,p2]*sp[k3,p1]^2 - 32*sp[k1,p2]*sp[k3,p1]^
      2*m + 104*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m] + amp[9,9]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[ - k2 + p1]]*den[sp[ - k2 + p2]]*den[sp[k3 - p2]]*
      num[56*sp[k1,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m + 56*
      sp[k1,k2]^2*sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 56*sp[k1,k2]
      *sp[k1,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 56*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m - 88*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,p1]*sp[
      k2,k3]*m - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2]*m - 72*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p1]*m + 40*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2
      ] - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 56*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 72*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2] - 28*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 64
      *sp[k1,k2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]
      *m - 40*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 12*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1]*m - 112*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 36*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 16*sp[
      k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]
       + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 96*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] - 36*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 96
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m - 40*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 12*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 4*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 120*sp[k1,k2]*sp[p1,p2]^2 + 44*sp[k1,
      k2]*sp[p1,p2]^2*m - 88*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 24*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 24
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 104*sp[k1,k3]*sp[k1,p1]*sp[p1,
      p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]
      *sp[k2,p1] - 20*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 56*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1] + 20*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 56*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m
       + 80*sp[k1,k3]*sp[k2,p1]^2 - 32*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] - 12*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m
       - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1]*m + 120*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 44*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 20*sp[k1,k3
      ]*sp[k2,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 104*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[
      p1,p2]^2 - 32*sp[k1,k3]*sp[p1,p2]^2*m + 104*sp[k1,p1]^2*sp[k2,k3]
       - 32*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2] + 16*sp[
      k1,p1]^2*sp[k2,p2]*m - 40*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*
      sp[k3,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 12*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3]*m + 56*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 12
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 112*sp[k1,p1]*sp[k1,p2
      ]*sp[p1,p2] + 40*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 72*sp[k1,p1]*
      sp[k2,k3]^2 - 28*sp[k1,p1]*sp[k2,k3]^2*m - 80*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 32*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m
       - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2]*m - 136*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 20*sp[k1,p1]*sp[k2
      ,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1
      ]*sp[k2,p1]*sp[k2,p2]*m + 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 40*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*
      sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 160*sp[k1,p1]*
      sp[k2,p2]^2 + 68*sp[k1,p1]*sp[k2,p2]^2*m + 136*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1] - 40*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 104*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2] - 36*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m
       + 88*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2]*m - 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,
      p1]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[p1,p2]^2 - 40*sp[k1,p1]*
      sp[p1,p2]^2*m - 72*sp[k1,p2]^2*sp[k2,p1] + 28*sp[k1,p2]^2*sp[k2,
      p1]*m + 12*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p2]*sp[k2,p1]^2 - 8*sp[k1,p2]*
      sp[k2,p1]^2*m + 112*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 44*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m - 160*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ] - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2] + 4*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 24*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 80*sp[k1,
      p2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m - 24
      *sp[k1,p2]*sp[k3,p1]^2 + 48*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 32*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[p1,p2]^2 - 32*
      sp[k1,p2]*sp[p1,p2]^2*m] + amp[9,10]*color[ - 1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 + p1]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*den[
      sp[k3 - p2]]*num[ - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 40*sp[k1,
      k2]*sp[k1,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2
       + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 176*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] + 40*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 40*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 48*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m
       + 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 176*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 40
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2
      ]*m^2 - 24*sp[k1,k2]*sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]^2*m^2
       + 24*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 - 24*sp[k1,k2]*sp[p1,p2]^2*m + 4*sp[k1,k2]*sp[p1,p2]^2
      *m^2 + 96*sp[k1,k3]^2*sp[k2,p1] - 40*sp[k1,k3]^2*sp[k2,p1]*m + 4*
      sp[k1,k3]^2*sp[k2,p1]*m^2 - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 
      4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 12*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 96
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 24*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 12*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 - 104*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1
      ,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 24*sp[k1,
      k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m + 176*sp[k1,p1]^2*
      sp[k3,p2] - 48*sp[k1,p1]^2*sp[k3,p2]*m + 12*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 24*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 - 48*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*
      m + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      p1,p2]*m - 96*sp[k1,p1]*sp[k2,k3]^2 + 40*sp[k1,p1]*sp[k2,k3]^2*m
       - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m^2 + 104*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[
      k2,p2]^2 + 40*sp[k1,p1]*sp[k2,p2]^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*
      m^2 - 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 104*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m + 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 4*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 104*sp[k1,p1]*sp[k3,p1]*sp[k3
      ,p2] + 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 104*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2] - 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,p2]
      ^2*sp[k2,p1] - 40*sp[k1,p2]^2*sp[k2,p1]*m + 4*sp[k1,p2]^2*sp[k2,
      p1]*m^2 - 12*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m^2 + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 48*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 + 104*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ] + 40*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m^2 - 24*sp[k1,p2]*sp[k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]
      ^2*m - 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m] + amp[9,11]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]
      ]*den[sp[ - k2 - k3]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*num[
       - 48*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m - 48*sp[
      k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m + 112*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m
       + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[
      k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 
      32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 40*sp[k1,k2]*sp[k2,k3]
      *sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 80*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 48*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m + 144*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 96*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ] - 40*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 - 48*sp[k1,k2]*sp[p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]
      ^2*m - 128*sp[k1,k3]^2*sp[k2,p1] + 56*sp[k1,k3]^2*sp[k2,p1]*m + 
      96*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 40*sp[k1,k3]*sp[k1,p1]*sp[k2,
      k3]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 8*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1
      ,k3]*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 
      64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 56*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 192*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] + 56*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,
      k3]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 48
      *sp[k1,k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m - 16*sp[k1,p1
      ]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k3,
      p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 
      8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 224*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2] + 72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 144*sp[k1,p1]*sp[k2,p2]^2 + 96*sp[k1,p1]*
      sp[k2,p2]^2*m - 16*sp[k1,p1]*sp[k2,p2]^2*m^2 - 16*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 48
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
      *m + 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 40*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2]*m - 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[
      k3,p2]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2
       + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 56*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m + 176*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 112*sp[k1,
      p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2
       - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 16*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 16*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k3,p1]^2 + 56*
      sp[k1,p2]*sp[k3,p1]^2*m - 112*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 48*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[9,12]*color[1/2*Ca*Cf*Na*
      Tf]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]^2*den[sp[k3 - p2]]*num[
      128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 64*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 
      64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2] - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2]*m^2] + amp[9,13]*color[1/2*Ca*Cf*Na*Tf - 1/4*
      Ca^2*Na*Tf]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + 
      p1]]*den[sp[k3 - p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 
      80*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,p1]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 320*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] - 176*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 24*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] + 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]
      *sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2
      ]*sp[p1,p2]^2*m + 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 192*sp[k1,k3]^2*
      sp[k2,p1] + 112*sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^2*sp[k2,p1
      ]*m^2 + 256*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 144*sp[k1,k3]*sp[k1,
      p1]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 96*sp[k1
      ,k3]*sp[k1,p1]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 
      32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2]*m - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 192
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 80*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2] - 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 16*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[p1,p2]^2 - 32*sp[
      k1,k3]*sp[p1,p2]^2*m + 32*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*
      sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]
      *m + 32*sp[k1,p1]^2*sp[k3,p2] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m^2 + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 
      224*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ]*m^2 + 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1
      ,p1]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 
      16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2] - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[
      k3,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 128*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 
      224*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 112*sp[k1,p2]*sp[k2,k3]*sp[p1
      ,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m^2 - 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 
      160*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*
      m - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k3,p1]
      ^2 + 48*sp[k1,p2]*sp[k3,p1]^2*m - 160*sp[k1,p2]*sp[k3,p1]*sp[p1,
      p2] + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[9,15]*color[ - Ca
      *Cf*Na*Tf]*den[sp[ - k2 + p1]]^2*den[sp[ - k3 + p2]]*den[sp[k3 - 
      p2]]*num[ - 352*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 272*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 192*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[k2,p1
      ]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ]*m^2 - 192*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 128*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2] + amp[10,
      1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*
      den[sp[ - k2 + p1]]*num[ - 64*sp[k1,k2]*sp[k1,p1] + 32*sp[k1,k2]*
      sp[k1,p1]*m - 160*sp[k1,k2]*sp[k3,p1] + 112*sp[k1,k2]*sp[k3,p1]*m
       - 16*sp[k1,k2]*sp[k3,p1]*m^2 + 96*sp[k1,k3]*sp[k2,p1] - 80*sp[k1
      ,k3]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p1]^2 - 
      32*sp[k1,p1]^2*m + 96*sp[k1,p1]*sp[k2,k3] - 80*sp[k1,p1]*sp[k2,k3
      ]*m + 16*sp[k1,p1]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k3,p1] - 32*
      sp[k1,p1]*sp[k3,p1]*m] + amp[10,2]*color[ - Cf^2*Na*Tf + 3/2*Ca*
      Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[
      sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*num[128*sp[k1,k2]^2*sp[k3,p1]
       - 96*sp[k1,k2]^2*sp[k3,p1]*m + 16*sp[k1,k2]^2*sp[k3,p1]*m^2 + 
      128*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,
      p1]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 96*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 128*sp[k1,
      k2]*sp[k1,k3]*sp[k3,p1] + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16
      *sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p1]^2 + 
      64*sp[k1,k2]*sp[k1,p1]^2*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 
      96*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,k3]*m^2 + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 192*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m^2 + 128*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 1024*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ] - 704*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 144*sp[k1,k2]*sp[k2,k3]
      *sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 16
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k3,p1]^2 + 
      96*sp[k1,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1]^2*m^2 + 128*
      sp[k1,k3]^2*sp[k2,p1] - 96*sp[k1,k3]^2*sp[k2,p1]*m + 16*sp[k1,k3]
      ^2*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k1,p1]^2 + 64*sp[k1,k3]*sp[k1
      ,p1]^2*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 96*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 128*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] + 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 
      192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p1]*m^2 + 1024*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 704*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m + 144*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 8
      *sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^3 - 128*sp[k1,k3]*sp[k2,p1]^2 + 
      96*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2 + 128*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,p1]^3 - 64*
      sp[k1,p1]^3*m - 256*sp[k1,p1]^2*sp[k2,k3] + 64*sp[k1,p1]^2*sp[k2,
      k3]*m + 128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]^2*sp[k2,p1]*m + 
      128*sp[k1,p1]^2*sp[k3,p1] - 64*sp[k1,p1]^2*sp[k3,p1]*m - 1024*sp[
      k1,p1]*sp[k2,k3]^2 + 704*sp[k1,p1]*sp[k2,k3]^2*m - 144*sp[k1,p1]*
      sp[k2,k3]^2*m^2 + 8*sp[k1,p1]*sp[k2,k3]^2*m^3 + 128*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p1] - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1]*m] + amp[10,3]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]
      ]*den[sp[ - k3 + p2]]*num[128*sp[k1,k2]^2*sp[k3,p1] - 32*sp[k1,k2
      ]^2*sp[k3,p1]*m - 64*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1
      ,p2]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,p1]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 128*sp[k1,k2]
      *sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,
      p1]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p1
      ]*sp[k1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 128*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 64*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2] + 320*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 208*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 
      96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,k3]
      *sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 128*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]
      *sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]^2*m + 32*sp[k1,k2]*sp[k3,p1
      ]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,k3]^2
      *sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p1]^
      2 + 32*sp[k1,k3]*sp[k1,p1]^2*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 128*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 192*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m
       - 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,k3]
      *sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 
      256*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 160*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2]*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 128*sp[k1
      ,k3]*sp[k2,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 
      128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*sp[k1,p2]*m + 64*sp[k1
      ,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[
      k3,p2] - 32*sp[k1,p1]^2*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 160*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*
      sp[k1,p1]*sp[k2,k3]^2 - 48*sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[k1,p1]*
      sp[k2,k3]^2*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 32
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
      *m + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] + 192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 112*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2
       + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m] + amp[10,4]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]
      *den[sp[p1 + p2]]*num[256*sp[k1,k2]^2*sp[p1,p2] - 128*sp[k1,k2]^2
      *sp[p1,p2]*m + 16*sp[k1,k2]^2*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 256*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 256*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
      *m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k2
      ]*sp[k1,p2]*sp[k3,p1] + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k2,k3]*sp[p1
      ,p2] - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 640*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       + 416*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 640*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] - 480*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 
      112*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m^3 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*
      m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 64*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 16*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1] - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]
      *sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k2,p1]^2 - 128*sp[k1,k3]*sp[k2,
      p1]^2*m + 16*sp[k1,k3]*sp[k2,p1]^2*m^2 + 256*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p1]^2*sp[k2,k3] - 32*
      sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]
      ^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 64*sp[k1,p1]^2*sp[k3,
      p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p1] + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 608*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^3 + 128*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 64*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1]*m + 640*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 480*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 8
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m^2] + amp[10,5]*color[ - Cf^2*Na*Tf]*den[sp[k1 + 
      k3]]^2*den[sp[ - k2 + p1]]^2*num[128*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] - 192*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1]*m^2 - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^3] + amp[10,6]
      *color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 + p1]]*
      den[sp[ - k2 + p2]]*num[64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 64*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*
      m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2
       + 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 128*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2] + amp[10,7]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[
       - k2 + p1]]*den[sp[p1 + p2]]*num[128*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] - 160*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 - 128*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 
      32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 - 
      256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 288*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m^3 + 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 128*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*
      m^2] + amp[10,9]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*
      den[sp[k1 + k3]]*den[sp[ - k2 + p1]]*den[sp[ - k2 + p2]]*num[8*
      sp[k1,k2]^2*sp[k3,p1]*m - 4*sp[k1,k2]^2*sp[k3,p1]*m^2 - 32*sp[k1,
      k2]^2*sp[p1,p2] + 8*sp[k1,k2]^2*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]
      *m + 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 24*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 8*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p2]*m + 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 
      16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2
      ,p1] - 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m
       + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 112*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m + 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]^2*m
       - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 144*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2] - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1] - 40*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*
      m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[
      k2,p1]^2 + 8*sp[k1,k3]*sp[k2,p1]^2*m - 4*sp[k1,k3]*sp[k2,p1]^2*
      m^2 - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 176*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       + 72*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m - 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 40
      *sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[p1,p2]^2 - 32*
      sp[k1,k3]*sp[p1,p2]^2*m - 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,
      p1]^2*sp[k2,p1] + 16*sp[k1,p1]^2*sp[k2,p1]*m - 80*sp[k1,p1]^2*sp[
      k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 8*sp[k1,p1]^2*sp[k3,p2]*m
       + 64*sp[k1,p1]^2*sp[p1,p2] - 32*sp[k1,p1]^2*sp[p1,p2]*m + 4*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 144*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k1
      ,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1
      ]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,k3]^2 + 24*sp[k1,p1]
      *sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 64*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p1] + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p1]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m^2 - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 24*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*
      m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1]*m + 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k3,p1]*
      sp[k3,p2] - 8*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[
      k3,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 80*sp[k1,
      p1]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 64
      *sp[k1,p2]^2*sp[k2,p1] + 24*sp[k1,p2]^2*sp[k2,p1]*m + 144*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 32
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 24*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k3,p1]^2 + 8*
      sp[k1,p2]*sp[k3,p1]^2*m - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]] + 
      amp[10,10]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1
       + k3]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*num[ - 64*sp[k1,
      k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m + 32*sp[k1,k2]^2*sp[
      p1,p2] - 8*sp[k1,k2]^2*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k1
      ,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 96*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 24*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 + 48*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,
      p1]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 80*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*
      m - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 128*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1
      ]*m^2 - 8*sp[k1,k2]*sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]^2*m^2
       + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 24*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 24*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k3]^2*sp[k2,p1] - 8*sp[k1,k3
      ]^2*sp[k2,p1]*m + 4*sp[k1,k3]^2*sp[k2,p1]*m^2 + 32*sp[k1,k3]*sp[
      k1,p1]^2 - 16*sp[k1,k3]*sp[k1,p1]^2*m + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 192*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 144*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 176*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1] - 72*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 4*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 144*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2] - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p1
      ]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 24*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]
      *m^2 - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] + 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m^2 - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 40*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2] + 8*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[
      p1,p2]^2 - 24*sp[k1,k3]*sp[p1,p2]^2*m - 64*sp[k1,p1]^2*sp[k1,p2]
       + 32*sp[k1,p1]^2*sp[k1,p2]*m - 16*sp[k1,p1]^2*sp[k2,k3]*m + 8*
      sp[k1,p1]^2*sp[k2,p2]*m - 80*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]
      ^2*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 24*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2]*m + 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,k3]^2 + 24*sp[k1,p1]*
      sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 32*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 4*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 4*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2]*m^2 + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*
      m + 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 24*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2]*m - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2]*m - 80*sp[k1,p2]^2*sp[k2,p1] + 32*sp[k1,p2]^2*sp[k2
      ,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 24*sp[k1,p2]*sp[k2,k3
      ]*sp[k2,p1]*m - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 24*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 80*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 144*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[
      k1,p2]*sp[k3,p1]^2 - 8*sp[k1,p2]*sp[k3,p1]^2*m - 64*sp[k1,p2]*sp[
      k3,p1]*sp[p1,p2] + 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[10,
      11]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[
      sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + p1]]*num[ - 96*
      sp[k1,k2]^2*sp[k3,p1] + 32*sp[k1,k2]^2*sp[k3,p1]*m + 96*sp[k1,k2]
      ^2*sp[p1,p2] - 80*sp[k1,k2]^2*sp[p1,p2]*m + 16*sp[k1,k2]^2*sp[p1,
      p2]*m^2 + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]
      *sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,
      k3] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p2] + 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*
      m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 32*sp[k1
      ,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 
      96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 224*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] + 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 192*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] - 80*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2]*m - 128*sp[k1,k3]^2*sp[k2,p1] + 48*sp[k1,
      k3]^2*sp[k2,p1]*m + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 48*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m^2 + 320*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 176*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 64
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
      *m + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 80*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 32
      *sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^
      2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,
      p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]
      *sp[k2,k3]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 48*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       + 112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2]*m^2 - 448*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 224*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 
      32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p2] - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m + 256*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 144*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2
      ]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 160*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 192*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 192*sp[k1,p2]
      *sp[k3,p1]^2 + 112*sp[k1,p2]*sp[k3,p1]^2*m - 16*sp[k1,p2]*sp[k3,
      p1]^2*m^2] + amp[10,12]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]^2*num[128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
      *m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1] + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,k2
      ]*sp[k1,p2]*sp[k2,p1]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 
      288*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 160*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 8*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1]*m^3] + amp[10,13]*color[ - Cf^2*Na*Tf + 
      Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*
      den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 128*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2] + 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3
      ,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m^2 + 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 480*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m + 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 
      8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2] - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2]*m^2 - 256*sp[k1,k3]^2*sp[k2,p1] + 128*sp[k1,k3]^2*
      sp[k2,p1]*m - 16*sp[k1,k3]^2*sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k1,
      p1]*sp[k2,k3] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p2]*m^2 - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]
      *sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 640*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 480*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 112*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 
      256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 416*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 64*sp[k1,k3
      ]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 
      64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,
      p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]^2*sp[
      k2,p2]*m^2 - 64*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*
      m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 896*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] + 608*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 - 
      64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 256*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2] - 128*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k3
      ,p1]*sp[k3,p2]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m - 256*sp[k1,p2]*sp[k3,p1]^2 + 128*sp[k1,p2]*sp[k3,p1]
      ^2*m - 16*sp[k1,p2]*sp[k3,p1]^2*m^2] + amp[10,14]*color[1/2*Ca*Cf
      *Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*
      den[sp[ - k2 + p1]]*den[sp[p1 + p2]]*num[192*sp[k1,k2]^2*sp[p1,p2
      ] - 112*sp[k1,k2]^2*sp[p1,p2]*m + 16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 
      32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m^2 - 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p1]*m - 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 144*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]
      *sp[k1,p2]*sp[k2,p1] - 80*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 192*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2] - 112*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 80*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*
      sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,p1]^2*m + 96*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 32*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1]*m - 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 80*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 64
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2] - 160*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]^2 - 48*sp[k1,k3
      ]*sp[k2,p1]^2*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,k3
      ]*sp[k2,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 64*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2
      ] - 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 224
      *sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,k3]*sp[k3,p1
      ]*sp[p1,p2] + 48*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]
      ^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3,
      p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p1]*m - 448*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 
      224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 112*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m
       + 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 80*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2]*m + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 + 320*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 176*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 24*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m^2 + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k3,p1]^2 + 80*sp[k1,p2
      ]*sp[k3,p1]^2*m - 16*sp[k1,p2]*sp[k3,p1]^2*m^2] + amp[10,15]*
      color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]^2*
      den[sp[ - k3 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 64*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1
      ]*m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 
      16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,
      k3]*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 128*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2
       + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2] + amp[10,16]*
      color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[
       - k2 + p1]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*num[32*sp[k1
      ,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 96*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 32
      *sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]
      *m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*
      sp[k3,p1]^2*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 128*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 192*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] + 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]^2 + 16
      *sp[k1,k3]*sp[k2,p1]^2*m - 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1]*m^2 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 32
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 320*sp[k1,k3
      ]*sp[k3,p1]*sp[p1,p2] - 208*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 32*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,p1]^2*sp[k2,k3] - 64
      *sp[k1,p1]^2*sp[k2,p1] + 32*sp[k1,p1]^2*sp[k2,p1]*m - 64*sp[k1,p1
      ]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3
      ,p2] + 128*sp[k1,p1]^2*sp[p1,p2] - 64*sp[k1,p1]^2*sp[p1,p2]*m + 
      16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,k3]^2 + 48*sp[k1,p1]*sp[k2,k3]
      ^2*m - 8*sp[k1,p1]*sp[k2,k3]^2*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 160*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 192*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m
       + 64*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k3,p1]*sp[
      k3,p2]*m + 128*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 64*sp[k1,p1]*sp[k3
      ,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 64*
      sp[k1,p2]*sp[k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]^2*m] + amp[11,1]*
      color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[
      sp[ - k3 + p1]]*num[64*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k3]*sp[k1,
      p1]*m - 160*sp[k1,k3]*sp[p1,p2] + 112*sp[k1,k3]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]^2 + 32*sp[k1,p1]^2*m + 96*
      sp[k1,p1]*sp[k3,p2] - 80*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[
      k3,p2]*m^2 + 64*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,p1]*sp[p1,p2]*m + 
      96*sp[k1,p2]*sp[k3,p1] - 80*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*
      sp[k3,p1]*m^2] + amp[11,2]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]
      *den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]^2*num[128*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
      *m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 + 128*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2] - 160*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3
       - 128*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 128*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1] + 288*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1]*m^3] + amp[11,3]*color[1/2*Ca*Cf*Na*Tf
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k3
       + p1]]*den[sp[ - k3 + p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,
      p1] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       - 160*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 192*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 112
      *sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2]*m^2 + 192*sp[k1,k2]*sp[p1,p2]^2 - 112*sp[k1,k2]*sp[p1,p2]^2*m
       + 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 96*sp[k1,k3]^2*sp[k2,p1] + 80*
      sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^2*sp[k2,p1]*m^2 + 96*sp[k1
      ,k3]^2*sp[p1,p2] - 32*sp[k1,k3]^2*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3] - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 
      16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 96*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 160*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ] + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 224*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 80
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m - 
      32*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,
      p1]^2*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]
      *m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 48*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 96*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 448*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] - 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 144
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,p2]^2*sp[k3,p1] + 48*sp[k1,p2]^2*sp[k3,p1]*m
       + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 256*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 320*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 176*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
      *m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[11,4]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[64
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 96*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2
      ]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]
      *sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 32*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[p1,p2]^2 - 128*sp[k1,k2]*sp[p1,
      p2]^2*m + 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1]*m^2 + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
       - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2]*m^2 - 640*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 480*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2
       + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^3 + 64*sp[k1,p1]^2*sp[k2,k3]
       - 64*sp[k1,p1]^2*sp[k2,k3]*m + 16*sp[k1,p1]^2*sp[k2,k3]*m^2 - 64
      *sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1
      ]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1
      ] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 256*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p2] - 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 96*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ]*m^2 + 896*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 608*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 8*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p2]*m^3 - 256*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
       + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2]*m^2 - 256*sp[k1,p2]^2*sp[k3,p1] + 128*sp[k1,p2]^2*sp[k3
      ,p1]*m - 16*sp[k1,p2]^2*sp[k3,p1]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 416*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^3 - 
      64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 640*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2] + 480*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 112*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m^3 - 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]
      *sp[p1,p2]*m^2 - 256*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 128*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2]
       + amp[11,5]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - 
      k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 96*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 640*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] - 480*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 112
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2]*m^3 + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 96*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 256*sp[
      k1,k3]^2*sp[k2,p1] + 128*sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^2
      *sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 128*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 
      64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 256*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 64
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
      *m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m + 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 480*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m + 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 8
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 256*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2
       - 640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 416*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^3 + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 16
      *sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 64*sp[k1,p1]^2*sp[k2,k3] - 
      32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,
      p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]^2*sp[k2,p2]*m^2 - 64*sp[k1,p1]^2
      *sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k1,p2]
      *sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1]*m - 896*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 608*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 8
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 - 64*sp[k1,p1]*sp[k2,k3]*sp[p1
      ,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ]*m^2 + 256*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 128*sp[k1,p1]*sp[k3,
      p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 + 256*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 256*sp[k1,p2]*
      sp[k3,p1]^2 + 128*sp[k1,p2]*sp[k3,p1]^2*m - 16*sp[k1,p2]*sp[k3,p1
      ]^2*m^2] + amp[11,6]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + 
      p1]]*num[ - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1]*m + 320*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 208*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*
      m^2 - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]^2 - 64*sp[k1,k2]*sp[k1,p1]^
      2*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 48*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] + 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 32*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,k3]^2*sp[k2,p1] + 16*
      sp[k1,k3]^2*sp[k2,p1]*m + 128*sp[k1,k3]^2*sp[p1,p2] - 32*sp[k1,k3
      ]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1
      ] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1] - 256*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 128*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ]*m^2 - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]
      *sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2
      ] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 48*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m^2 - 32*sp[k1,k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 64*
      sp[k1,p1]^2*sp[k1,p2] + 32*sp[k1,p1]^2*sp[k1,p2]*m - 32*sp[k1,p1]
      ^2*sp[k2,k3] - 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2
      ]*m + 64*sp[k1,p1]^2*sp[k3,p2] - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 128*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m
       + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 32*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m - 64*sp[k1,p1]*sp[k3,p2]^2 + 48*sp[k1,p1]*sp[k3,p2]^2*m - 8*
      sp[k1,p1]*sp[k3,p2]^2*m^2 + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16
      *sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,p2]^2*sp[k3,p1] - 16*
      sp[k1,p2]^2*sp[k3,p1]*m + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 48*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 + 32
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]
      *m] + amp[11,7]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*
      Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]*den[
      sp[p1 + p2]]*num[ - 128*sp[k1,k3]^2*sp[p1,p2] + 96*sp[k1,k3]^2*
      sp[p1,p2]*m - 16*sp[k1,k3]^2*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,
      p1]^2 + 64*sp[k1,k3]*sp[k1,p1]^2*m - 128*sp[k1,k3]*sp[k1,p1]*sp[
      k1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 256*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1] - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
       - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k3]
      *sp[k1,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 128*sp[k1,k3]*sp[k1,p2]*sp[p1
      ,p2] + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k1,p2
      ]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 96*sp[k1,k3
      ]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 
      1024*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 704*sp[k1,k3]*sp[k3,p2]*sp[
      p1,p2]*m + 144*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 8*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2]*m^3 - 128*sp[k1,k3]*sp[p1,p2]^2 + 96*sp[k1,k3
      ]*sp[p1,p2]^2*m - 16*sp[k1,k3]*sp[p1,p2]^2*m^2 + 128*sp[k1,p1]^3
       - 64*sp[k1,p1]^3*m + 128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*
      sp[k1,p2]*m + 128*sp[k1,p1]^2*sp[k3,p1] - 64*sp[k1,p1]^2*sp[k3,p1
      ]*m + 256*sp[k1,p1]^2*sp[k3,p2] - 64*sp[k1,p1]^2*sp[k3,p2]*m - 
      128*sp[k1,p1]^2*sp[p1,p2] + 64*sp[k1,p1]^2*sp[p1,p2]*m - 128*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 
      96*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k3
      ,p2]*m^2 + 256*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 192*sp[k1,p1]*sp[
      k1,p2]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*
      m - 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k3,p1
      ]*sp[p1,p2] + 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 1024*sp[k1,p1]
      *sp[k3,p2]^2 + 704*sp[k1,p1]*sp[k3,p2]^2*m - 144*sp[k1,p1]*sp[k3,
      p2]^2*m^2 + 8*sp[k1,p1]*sp[k3,p2]^2*m^3 + 128*sp[k1,p1]*sp[k3,p2]
      *sp[p1,p2] - 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*
      sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p2]^2*sp[k3,p1] - 96*sp[k1,p2
      ]^2*sp[k3,p1]*m + 16*sp[k1,p2]^2*sp[k3,p1]*m^2 + 128*sp[k1,p2]*
      sp[k3,p1]^2 - 96*sp[k1,p2]*sp[k3,p1]^2*m + 16*sp[k1,p2]*sp[k3,p1]
      ^2*m^2 + 1024*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 704*sp[k1,p2]*sp[k3
      ,p1]*sp[k3,p2]*m + 144*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 8*sp[
      k1,p2]*sp[k3,p1]*sp[k3,p2]*m^3 + 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2
      ] - 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2]*m^2] + amp[11,8]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[ - k3 + p1]]*
      num[64*sp[k1,k2]^2*sp[k3,p1] - 24*sp[k1,k2]^2*sp[k3,p1]*m - 64*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*
      m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 8*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 8*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 144*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
       - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,k2
      ]*sp[k2,p2]*sp[k3,p1]*m - 144*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 48*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[
      p1,p2]^2 + 8*sp[k1,k2]*sp[p1,p2]^2*m - 32*sp[k1,k3]^2*sp[k2,p1]
       + 8*sp[k1,k3]^2*sp[k2,p1]*m + 8*sp[k1,k3]^2*sp[p1,p2]*m - 4*sp[
      k1,k3]^2*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 24*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p1
      ] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 8*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 16*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1] - 24*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 24*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 144*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 40*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 24*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 32*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[p1,p2]^
      2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 80*sp[k1,p1]^2*sp[k2,k3] + 16*
      sp[k1,p1]^2*sp[k2,k3]*m + 64*sp[k1,p1]^2*sp[k2,p1] - 32*sp[k1,p1]
      ^2*sp[k2,p1]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3
      ,p1] - 16*sp[k1,p1]^2*sp[k3,p1]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m + 
      16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 
      80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*
      sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*
      m - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 24*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 32*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 
      64*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k3,p1]*sp[k3,
      p2]*m - 4*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k3,
      p1]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,p1]
      *sp[k3,p2]^2 - 24*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]
      ^2*m^2 + 64*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k3,p2
      ]*sp[p1,p2]*m - 80*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m
       + 80*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m + 176*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 72*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] - 40*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 4*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k3,p1]^2 + 8*
      sp[k1,p2]*sp[k3,p1]^2*m - 4*sp[k1,p2]*sp[k3,p1]^2*m^2 - 8*sp[k1,
      p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2
       + 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p1]*sp[
      p1,p2]*m] + amp[11,9]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*
      den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*num[80*
      sp[k1,k2]^2*sp[k3,p1] - 32*sp[k1,k2]^2*sp[k3,p1]*m + 64*sp[k1,k2]
      *sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
       + 40*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 128*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]^2 + 32*sp[k1,k2]*
      sp[k1,p1]^2*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m^2 - 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 176*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       + 72*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m^2 + 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 24
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2] - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 
      32*sp[k1,k2]*sp[p1,p2]^2 - 8*sp[k1,k2]*sp[p1,p2]^2*m + 32*sp[k1,
      k3]^2*sp[k2,p1] - 8*sp[k1,k3]^2*sp[k2,p1]*m - 64*sp[k1,k3]^2*sp[
      p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[
      k1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 32*sp[k1,k3]*sp[k1,
      p1]*sp[k2,k3] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 8*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 
      4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 16*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 24*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m^2 + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2
       + 8*sp[k1,k3]*sp[p1,p2]^2*m - 4*sp[k1,k3]*sp[p1,p2]^2*m^2 + 32*
      sp[k1,p1]^2*sp[k1,p2] - 16*sp[k1,p1]^2*sp[k1,p2]*m + 8*sp[k1,p1]^
      2*sp[k2,k3]*m + 80*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,
      p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m + 192*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 144*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 24*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*
      m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2] - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 4*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,p1]*sp[k2
      ,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 16*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 32*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 24*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*
      m + 32*sp[k1,p1]*sp[k3,p2]^2 - 24*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[
      k1,p1]*sp[k3,p2]^2*m^2 - 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 4*
      sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 + 32*sp[k1,p2]^2*sp[k3,p1] + 8*
      sp[k1,p2]^2*sp[k3,p1]*m - 4*sp[k1,p2]^2*sp[k3,p1]*m^2 - 64*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1] + 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 64
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
      *m + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 112*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2] + 40*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p2]*
      sp[k2,p1]^2 - 24*sp[k1,p2]*sp[k2,p1]^2*m + 48*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1] - 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1]*m^2 + 144*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 48*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1] - 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 4*sp[k1,p2]*sp[k3,p1
      ]*sp[k3,p2]*m^2 + 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,p2]
      *sp[k3,p1]*sp[p1,p2]*m + 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + 
      amp[11,11]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p2]]^2*den[sp[
       - k2 - k3]]*den[sp[ - k3 + p1]]*num[ - 64*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 64*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,p2]*sp[k2,p1]
      *sp[p1,p2]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 128*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 
      32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[k3,p1]*sp[
      k3,p2] + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2]*m^2 + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 64*sp[k1,
      p2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2]
       + amp[11,12]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - 
      p2]]^2*den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*num[256*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 288*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m^3 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p2]*m^3 - 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 160*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 8
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^3 - 128*sp[k1,p2]*sp[k3,p1]*sp[
      p1,p2] + 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k3
      ,p1]*sp[p1,p2]*m^2] + amp[11,13]*color[ - Cf^2*Na*Tf]*den[sp[k1
       - p2]]^2*den[sp[ - k3 + p1]]^2*num[128*sp[k1,p2]*sp[k3,p1]*sp[k3
      ,p2] - 192*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2]*m^2 - 16*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^3] + amp[
      11,14]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]
      ]*den[sp[ - k2 - k3]]*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[
       - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 32*sp[k1,
      k2]*sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 48*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m - 64*sp[k1,k2]*sp[p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2*m
       + 32*sp[k1,k3]^2*sp[p1,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m
       + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,
      p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 32*sp[
      k1,k3]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m
       - 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k3]*sp[k3,p2]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*
      sp[p1,p2]^2 + 32*sp[k1,k3]*sp[p1,p2]^2*m - 64*sp[k1,p1]^2*sp[k2,
      k3] + 32*sp[k1,p1]^2*sp[k2,k3]*m + 128*sp[k1,p1]^2*sp[k2,p1] - 64
      *sp[k1,p1]^2*sp[k2,p1]*m - 32*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1
      ]^2*sp[k3,p1] - 32*sp[k1,p1]^2*sp[k3,p1]*m - 64*sp[k1,p1]^2*sp[k3
      ,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m + 160*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 160*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,p1]*
      sp[k2,p1]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 192*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 64
      *sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]
      *m + 64*sp[k1,p1]*sp[k3,p2]^2 - 48*sp[k1,p1]*sp[k3,p2]^2*m + 8*
      sp[k1,p1]*sp[k3,p2]^2*m^2 + 128*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 
      32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1]*m - 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 
      112*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 320*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 208*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 
      256*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1]*m + 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,p2]*sp[
      k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]^2*m - 64*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2] + 48*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m^2 + 256*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 128*
      sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2
      ]*m^2] + amp[11,15]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*den[sp[ - k3
       + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 80*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 + 64
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 320*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2] - 176*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m^2 + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 
      80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2]*m^2 + 96*sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2]*sp[p1,p2]^2*m
       + 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 192*sp[k1,k3]^2*sp[k2,p1] + 112
      *sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^2*sp[k2,p1]*m^2 + 256*sp[
      k1,k3]*sp[k1,p1]*sp[k2,k3] - 144*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m
       + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 192*sp[k1
      ,k3]*sp[k1,p1]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 
      32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 192*sp[k1,k3]*sp[k2
      ,k3]*sp[p1,p2] - 80*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 
      112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 96*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2
       - 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p2]*sp[
      p1,p2]*m + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[p1,p2]^2 - 32*sp[k1,k3]*sp[p1,
      p2]^2*m + 32*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m
       + 32*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[
      k1,p1]^2*sp[k3,p2] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 80*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2
       + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1]*m - 448*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 224*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2
       - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 
      192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]
       - 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2] + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 128*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 224*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1]*m^2 - 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 160*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,p2]*sp[k2,p1]
      *sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k3,p1]^2 + 
      48*sp[k1,p2]*sp[k3,p1]^2*m - 160*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 
      64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[11,16]*color[1/2*Ca*Cf*
      Na*Tf]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]^2
      *num[128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 128*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,
      p1] + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]
      *sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 
      128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,
      p2]*sp[k3,p1]*sp[k3,p2]*m^2] + amp[12,1]*color[ - 1/2*Ca^2*Na*Tf]
      *den[sp[ - k1 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 
      48*sp[k1,k2]*sp[k3,p1] + 24*sp[k1,k2]*sp[k3,p1]*m + 48*sp[k1,p1]*
      sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m - 48*sp[k1,p1]*sp[k2,p1] + 
      24*sp[k1,p1]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k3,p2] + 24*sp[k1,p1]*
      sp[k3,p2]*m + 48*sp[k1,p1]*sp[p1,p2] - 24*sp[k1,p1]*sp[p1,p2]*m
       + 48*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p2]*sp[k3,p1]*m] + amp[12,1]
      *color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k2 - p2]]*
      den[sp[ - k3 + p1]]*num[ - 48*sp[k1,k2]*sp[k3,p1] + 24*sp[k1,k2]*
      sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,p1]*sp[k2,k3]*m
       - 48*sp[k1,p1]*sp[k2,p1] + 24*sp[k1,p1]*sp[k2,p1]*m - 48*sp[k1,
      p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,p1]*sp[p1,p2]
       - 24*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,
      p2]*sp[k3,p1]*m] + amp[12,2]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1
       + k2]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]^2*num[ - 64*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,
      p1] + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]
      *sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 
      128*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k3]*sp[k1,p2]*sp[k3
      ,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 
      64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1]*m^2] + amp[12,3]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[k2 - p2]]*den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[16*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 
      176*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 112*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] + 48*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2
       + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 56*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[p1,p2]^2 + 56*sp[k1,k2]*sp[p1
      ,p2]^2*m - 48*sp[k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m
       - 48*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m + 48*sp[
      k1,k3]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m
       + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 8*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m + 112*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 48*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2
      ] + 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 144*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1] + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m^2 - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[
      k1,k3]*sp[k2,p1]^2*m + 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 40*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*
      m^2 + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]^2*sp[k2,k3]
       - 16*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p2] + 40*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 160*sp[k1,p1]*
      sp[k1,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 144*
      sp[k1,p1]*sp[k2,k3]^2 - 96*sp[k1,p1]*sp[k2,k3]^2*m + 16*sp[k1,p1]
      *sp[k2,k3]^2*m^2 - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 
      16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 224*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2] + 72*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2] - 40*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p2
      ]^2*sp[k3,p1] - 56*sp[k1,p2]^2*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 192*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 56*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m + 48*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m - 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 56*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[12,4]*color[ - 1/2*Ca*Cf*Na*Tf
       + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k2 - p2]]*den[sp[ - k3
       + p1]]*den[sp[p1 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 48*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2
       - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[
      p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1
      ,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2
       - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 224*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] + 160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m^2 + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]
      *sp[p1,p2]*m - 128*sp[k1,k2]*sp[p1,p2]^2 + 48*sp[k1,k2]*sp[p1,p2]
      ^2*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64
      *sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 80*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]
      *m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1
      ]^2 + 80*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2
       - 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 80*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 320
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 176*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 32*sp[k1,p1]^2*sp[k2
      ,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] + 32
      *sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m + 32*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p2] + 144*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1
      ] - 80*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1]*m^2 + 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 112*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 
      32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,p1]*sp[k2,
      p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 448*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 224*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p1
      ]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 192*
      sp[k1,p2]^2*sp[k3,p1] - 112*sp[k1,p2]^2*sp[k3,p1]*m + 16*sp[k1,p2
      ]^2*sp[k3,p1]*m^2 - 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m - 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 
      96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m^2 + 96*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m
       - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m + 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,p2]*sp[k2
      ,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1
      ,p2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 
      192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[12,5]*color[
      1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2
       + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[32*sp[k1,k2]^2*
      sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 96*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 64
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]
      *m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1
      ,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2
      ]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 48*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
      *m^2 + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 128*sp[k1,k2]*sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,p1]^
      2*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m
       + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 192*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]^2 + 16*sp[k1,k3]
      *sp[k2,p1]^2*m - 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 
      256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 320*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2] - 208*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,p1]^2*sp[k2,k3] - 64*sp[k1,p1]
      ^2*sp[k2,p1] + 32*sp[k1,p1]^2*sp[k2,p1]*m - 64*sp[k1,p1]^2*sp[k2,
      p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3,p2] + 128
      *sp[k1,p1]^2*sp[p1,p2] - 64*sp[k1,p1]^2*sp[p1,p2]*m + 16*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1
      ] - 64*sp[k1,p1]*sp[k2,k3]^2 + 48*sp[k1,p1]*sp[k2,k3]^2*m - 8*sp[
      k1,p1]*sp[k2,k3]^2*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m^2 - 160*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 48*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]
       + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 192*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 
      128*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] - 64*sp[k1,p1]*sp[k3,p1]*sp[p1,
      p2]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p2]*
      sp[k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]^2*m] + amp[12,6]*color[ - Ca
      *Cf*Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*
      den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 96*sp[k1,k2]^2*sp[k3,
      p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 192*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 80*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
      *m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 48*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 352*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 96*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k3]
      *sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 80*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*
      sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m + 96*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 704*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 368*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 80*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 96*
      sp[k1,k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m - 352*sp[k1,p1
      ]^2*sp[k2,p2] + 96*sp[k1,p1]^2*sp[k2,p2]*m - 48*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 96*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 96*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*
      m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,k3]^2 - 80*sp[k1,p1]*sp[k2,k3]^
      2*m + 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 192*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2 + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 352*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 192*sp[k1,p1]*
      sp[k3,p2]^2 - 80*sp[k1,p1]*sp[k3,p2]^2*m + 8*sp[k1,p1]*sp[k3,p2]^
      2*m^2 - 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]
      *sp[p1,p2]*m - 96*sp[k1,p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1
      ]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 192*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 80*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*
      m - 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[12,7]*
      color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[
      sp[k2 - p2]]*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[128*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 32
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
      *m - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[
      k3,p1]^2*m - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1
      ,k3]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 
      64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2]*m + 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1
      ]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       + 160*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 320*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 208*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 
      192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 128*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 
      16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2] + 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 48*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]
      *m^2 + 32*sp[k1,k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m + 32
      *sp[k1,p1]^2*sp[k2,k3] + 128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]
      ^2*sp[k2,p1]*m + 64*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k2,
      p2]*m - 64*sp[k1,p1]^2*sp[k3,p2] - 64*sp[k1,p1]^2*sp[p1,p2] + 32*
      sp[k1,p1]^2*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k1,
      p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 64*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 160*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*
      m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m - 128*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k3
      ,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,p1
      ]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k3,p2]^2 - 48*sp[k1,p1]
      *sp[k3,p2]^2*m + 8*sp[k1,p1]*sp[k3,p2]^2*m^2 - 32*sp[k1,p1]*sp[k3
      ,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,p2
      ]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 96*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      128*sp[k1,p2]*sp[k3,p1]^2 - 32*sp[k1,p2]*sp[k3,p1]^2*m - 64*sp[k1
      ,p2]*sp[k3,p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 8
      *sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k3,p1]*sp[p1
      ,p2] + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[12,8]*color[ - 1/
      4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[ - k2 - k3]]*den[sp[k2
       - p2]]*den[sp[ - k3 + p1]]*num[ - 72*sp[k1,k2]^2*sp[k3,p1] + 28*
      sp[k1,k2]^2*sp[k3,p1]*m + 72*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 28*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 56*sp[k1,k2]*sp[k1,k3]*sp[k3,p1
      ] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[
      k1,p1]*sp[k2,k3] - 12*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 112*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 
      56*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 12*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 20*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1]*m + 112*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1] - 44*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 80*sp[k1,
      k2]*sp[k2,p1]^2 + 32*sp[k1,k2]*sp[k2,p1]^2*m + 24*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p1] + 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 48*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*
      m - 40*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m - 32*sp[k1,k2]*sp[k3,p1]^2 + 8*sp[k1,k2]*sp[k3,p1]^2*m
       + 12*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[p1,p2]^2 - 56*sp[k1,k3]^2*sp[
      k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m - 56*sp[k1,k3]^2*sp[p1,p2] + 
      16*sp[k1,k3]^2*sp[p1,p2]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 8
      *sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p1] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 40*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 88*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 72*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 56
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 24*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m + 56*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 36*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,
      k3]*sp[k2,k3]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 36
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 120*sp[k1,k3]*sp[k2,p1]^2 + 44
      *sp[k1,k3]*sp[k2,p1]^2*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 4*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 112*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 36*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 40
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m - 64*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k3,p1]*
      sp[k3,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[
      k3,p1]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 12*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m + 40*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,
      p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[
      k2,p2]*m - 104*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m
       - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 24*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p1]*m + 88*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1]*m - 160*sp[k1,p1]*sp[k2,k3]^2 + 68*sp[k1,p1
      ]*sp[k2,k3]^2*m + 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 36*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 4*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1
      ] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 136*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] - 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 80*sp[k1,
      p1]*sp[k2,p1]^2 - 40*sp[k1,p1]*sp[k2,p1]^2*m - 32*sp[k1,p1]*sp[k2
      ,p1]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m - 136*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*
      m - 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[
      p1,p2]*m + 40*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 20*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m - 88*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[k3,p1]*sp[k3,p2
      ] - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 80*sp[k1,p1]*sp[k3,p1]*
      sp[p1,p2] + 40*sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m + 72*sp[k1,p1]*sp[
      k3,p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2*m - 32*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1] - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 48
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m - 16*sp[k1,p2]*sp[k2,p1]^2 + 32*sp[k1,p2]*sp[k2,p1]^2*m + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m + 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m - 104*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2
      ,p1]*sp[p1,p2]*m - 120*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 44*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1]*m - 80*sp[k1,p2]*sp[k3,p1]^2 + 32*sp[k1,
      p2]*sp[k3,p1]^2*m - 56*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 20*sp[k1,
      p2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 16
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[12,9]*color[ - 1/2*Ca^2*
      Na*Tf]*den[sp[ - k1 + p1]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*
      den[sp[ - k3 + p1]]*num[96*sp[k1,k2]^2*sp[k3,p1] - 40*sp[k1,k2]^2
      *sp[k3,p1]*m + 4*sp[k1,k2]^2*sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k1,
      k3]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 4*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1]*m^2 + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m^2 - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,k2]*sp[k1,p1]
      *sp[k2,k3]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1]*m + 12*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 4*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]
       + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2]*m - 104*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 
      48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 12*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 48*sp[k1,k2]*sp[k3
      ,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[p1,p2]^2 - 16*
      sp[k1,k2]*sp[p1,p2]^2*m - 176*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m^2 - 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,k3]*sp[
      k1,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 + 96*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1] - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m
       + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 48*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2
      ,k3]*sp[p1,p2]*m^2 - 24*sp[k1,k3]*sp[k2,p1]^2*m + 4*sp[k1,k3]*sp[
      k2,p1]^2*m^2 - 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 4*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 24*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m^2 + 176*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m + 96*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 40*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 24*sp[
      k1,k3]*sp[p1,p2]^2*m + 4*sp[k1,k3]*sp[p1,p2]^2*m^2 + 176*sp[k1,p1
      ]^2*sp[k2,p2] - 48*sp[k1,p1]^2*sp[k2,p2]*m + 12*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 48*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 24
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 4*sp[k1,p1]*sp[k1,p2]*sp[k3,p2
      ]*m^2 + 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k1,p2]
      *sp[p1,p2]*m - 96*sp[k1,p1]*sp[k2,k3]^2 + 40*sp[k1,p1]*sp[k2,k3]^
      2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p1]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m^2 + 104*sp[k1,p1]*sp[k2
      ,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 96*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
      *m - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 104*sp[k1,p1]*sp[k2,p1
      ]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 12*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 128
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m - 104*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 104*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k3,p2]^2 + 40*sp[k1,p1]*
      sp[k3,p2]^2*m - 4*sp[k1,p1]*sp[k3,p2]^2*m^2 + 24*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 + 96*sp[k1,
      p2]^2*sp[k3,p1] - 40*sp[k1,p2]^2*sp[k3,p1]*m + 4*sp[k1,p2]^2*sp[
      k3,p1]*m^2 + 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1]*m - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,p2]*sp[k2,p1]^2
       + 16*sp[k1,p2]*sp[k2,p1]^2*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 24*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2]*m + 104*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m
       - 4*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] + 40*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[
      k3,p1]*sp[p1,p2]*m^2] + amp[12,10]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*den[sp[ - k3
       + p2]]*num[ - 56*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 24*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 88*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 104*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 48*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] - 20*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 56*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 20*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m - 56*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p1]*m - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 104*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 120*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1] - 44*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 80*sp[k1,k2]*
      sp[k3,p1]^2 - 32*sp[k1,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2] - 12*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m
       + 16*sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,k2]*sp[p1,p2]^2*m + 56*sp[
      k1,k3]^2*sp[k2,p1] - 16*sp[k1,k3]^2*sp[k2,p1]*m + 56*sp[k1,k3]^2*
      sp[p1,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m - 88*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 72*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 40*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 40
      *sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*
      m + 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k1,p1]*sp[
      p1,p2]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1]*m - 56*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k3]*
      sp[k1,p2]*sp[k3,p1]*m + 72*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 28*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
       + 12*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k3,p1] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 112*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] + 36*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 40*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] + 12*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 36*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k3,p1]*sp[
      k3,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2] - 36*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 120*
      sp[k1,k3]*sp[p1,p2]^2 + 44*sp[k1,k3]*sp[p1,p2]^2*m + 104*sp[k1,p1
      ]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2
      ,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m - 40*sp[k1,p1]^2*sp[k3,p2] + 16
      *sp[k1,p1]^2*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 12*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 56*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 40*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] - 12*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 112*sp[k1
      ,p1]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 
      72*sp[k1,p1]*sp[k2,k3]^2 - 28*sp[k1,p1]*sp[k2,k3]^2*m - 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 48
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 20*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
      *m - 80*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m - 136*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 20*sp[k1
      ,p1]*sp[k2,k3]*sp[p1,p2]*m + 88*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 
      32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 80*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p1] - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p1]*m + 136*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2] - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]
      *sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 40*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 8*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]
      *sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k3,p1]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k3,p1]*sp[p1,p2]*m - 160*sp[k1,p1]*sp[k3,p2]^2 + 68*
      sp[k1,p1]*sp[k3,p2]^2*m + 104*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 36*
      sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p1]*sp[p1,p2]^2 - 40*
      sp[k1,p1]*sp[p1,p2]^2*m - 72*sp[k1,p2]^2*sp[k3,p1] + 28*sp[k1,p2]
      ^2*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 12*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,p2]*sp[k2,p1]^2 - 160*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m + 48*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,
      p1]*sp[p1,p2]*m + 40*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 12*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k3,p1]^2 - 8*sp[k1,p2]*
      sp[k3,p1]^2*m + 112*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 44*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2]*m + 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 4*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 80*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]
       + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[p1,p2]^2
       - 32*sp[k1,p2]*sp[p1,p2]^2*m] + amp[12,11]*color[1/4*Ca^2*Na*Tf]
      *den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[k2 - p2]]*den[sp[ - 
      k3 + p1]]*num[128*sp[k1,k2]^2*sp[k3,p1] - 56*sp[k1,k2]^2*sp[k3,p1
      ]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 24*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1]*m - 112*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 48*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 40*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*
      m + 160*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 8*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64
      *sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
      *m - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m + 192*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 56*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 24*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
       + 56*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 48*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 48
      *sp[k1,k2]*sp[p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2*m + 48*sp[k1,k3
      ]^2*sp[k2,p1] - 16*sp[k1,k3]^2*sp[k2,p1]*m + 48*sp[k1,k3]^2*sp[p1
      ,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,
      k3] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ] + 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 40*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] + 40*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m^2 - 144*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 96*
      sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2
      ]*m^2 + 48*sp[k1,k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m + 
      16*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1
      ]^2*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 224*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 72*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 16*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 
      40*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] - 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 48*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*
      m + 144*sp[k1,p1]*sp[k3,p2]^2 - 96*sp[k1,p1]*sp[k3,p2]^2*m + 16*
      sp[k1,p1]*sp[k3,p2]^2*m^2 - 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 16
      *sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1] + 56*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1]*m^2 - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,p1]^2 - 56*sp[
      k1,p2]*sp[k2,p1]^2*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 40*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
       + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 112*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1]*m^2 - 176*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 
      112*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k3,p1]*sp[
      k3,p2]*m^2 - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]] + amp[12,12]*
      color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]]*den[sp[
       - k2 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 192*sp[
      k1,k2]^2*sp[k3,p1] + 112*sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]^2
      *sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 80*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 + 64
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 144*sp[k1,k2]*sp[k1,p1]*
      sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 192*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*
      m - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 192*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2] + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      112*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,
      k2]*sp[p1,p2]^2*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]
      *m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 320*sp[k1,k3]
      *sp[k2,p1]*sp[k2,p2] - 176*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 24*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] + 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[p1,p2]^2 - 80*sp[k1,k3
      ]*sp[p1,p2]^2*m + 16*sp[k1,k3]*sp[p1,p2]^2*m^2 + 32*sp[k1,p1]^2*
      sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[k2,p2]
       + 32*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 96*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3] + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m
       - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 96*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 448*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2] + 224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 
      24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2
      ,p1]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 192*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2
      ] + 80*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k3,p2]*
      sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 48*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m + 224*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 112*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m^2 - 128*sp[k1,p2]*sp[k2,p1]^2 + 48*sp[k1,p2]*sp[k2,p1]^2*m - 
      96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 160*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 64*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 256*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1] + 160*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,p2]
      *sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + 
      amp[12,13]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p2]]*den[sp[k2 - p2
      ]]*den[sp[ - k3 + p1]]^2*num[128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 
      128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 64*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*
      m - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1] + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 128
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^2 + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[k3,
      p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2] + amp[12,
      16]*color[ - Ca*Cf*Na*Tf]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*
      den[sp[ - k3 + p1]]^2*num[ - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 
      128*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m^2 + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 352*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 272*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
      *m - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 128
      *sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k3,p1]*sp[k3,
      p2]*m^2] + amp[13,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]
      *den[sp[k1 + k2]]*den[sp[ - k3 + p1]]*num[96*sp[k1,k2]*sp[k3,p1]
       - 80*sp[k1,k2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k3,p1]*m^2 - 64*sp[
      k1,k3]*sp[k1,p1] + 32*sp[k1,k3]*sp[k1,p1]*m - 160*sp[k1,k3]*sp[k2
      ,p1] + 112*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*m^2 + 
      64*sp[k1,p1]^2 - 32*sp[k1,p1]^2*m + 96*sp[k1,p1]*sp[k2,k3] - 80*
      sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k2,k3]*m^2 + 64*sp[k1,p1]
      *sp[k2,p1] - 32*sp[k1,p1]*sp[k2,p1]*m] + amp[13,2]*color[ - Cf^2*
      Na*Tf]*den[sp[k1 + k2]]^2*den[sp[ - k3 + p1]]^2*num[128*sp[k1,k2]
      *sp[k2,k3]*sp[k3,p1] - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 96*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,
      p1]*m^3] + amp[13,3]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*
      den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k2,k3
      ]*sp[k3,p1] - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[p1
      ,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1
      ,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2
      ] + amp[13,4]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + 
      k2]]^2*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[128*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*
      m^3 - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p1]*m - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 256*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 288*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 
      96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m^3 + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 
      128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1]*m + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1]*m^3] + amp[13,5]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*
      Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[
       - k2 + p1]]*den[sp[ - k3 + p1]]*num[128*sp[k1,k2]^2*sp[k3,p1] - 
      96*sp[k1,k2]^2*sp[k3,p1]*m + 16*sp[k1,k2]^2*sp[k3,p1]*m^2 + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*
      m - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 96*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 128*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,p1] + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p1]^2 + 
      64*sp[k1,k2]*sp[k1,p1]^2*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 
      96*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,k3]*m^2 + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 192*sp[k1,k2]*sp[
      k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m^2 + 128*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 1024*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ] - 704*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 144*sp[k1,k2]*sp[k2,k3]
      *sp[k3,p1]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 16
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k3,p1]^2 + 
      96*sp[k1,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1]^2*m^2 + 128*
      sp[k1,k3]^2*sp[k2,p1] - 96*sp[k1,k3]^2*sp[k2,p1]*m + 16*sp[k1,k3]
      ^2*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k1,p1]^2 + 64*sp[k1,k3]*sp[k1
      ,p1]^2*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 96*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 128*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1] + 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 
      192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p1]*m^2 + 1024*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 704*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m + 144*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 8
      *sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^3 - 128*sp[k1,k3]*sp[k2,p1]^2 + 
      96*sp[k1,k3]*sp[k2,p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2 + 128*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,p1]^3 - 64*
      sp[k1,p1]^3*m - 256*sp[k1,p1]^2*sp[k2,k3] + 64*sp[k1,p1]^2*sp[k2,
      k3]*m + 128*sp[k1,p1]^2*sp[k2,p1] - 64*sp[k1,p1]^2*sp[k2,p1]*m + 
      128*sp[k1,p1]^2*sp[k3,p1] - 64*sp[k1,p1]^2*sp[k3,p1]*m - 1024*sp[
      k1,p1]*sp[k2,k3]^2 + 704*sp[k1,p1]*sp[k2,k3]^2*m - 144*sp[k1,p1]*
      sp[k2,k3]^2*m^2 + 8*sp[k1,p1]*sp[k2,k3]^2*m^3 + 128*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p1] - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
       - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p1]*m] + amp[13,6]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]
      ]*den[sp[ - k3 + p1]]*num[ - 32*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,
      k2]^2*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,
      k2]*sp[k1,k3]*sp[k1,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16
      *sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k3,
      p1] + 128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,k2]
      *sp[k1,p1]^2 + 32*sp[k1,k2]*sp[k1,p1]^2*m + 32*sp[k1,k2]*sp[k1,p1
      ]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 64*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 128*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*
      m + 192*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
       + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[
      k3,p1]*m^2 - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1]*m - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 160*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 128*sp[k1,k3]^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1
      ]*m - 64*sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m - 128
      *sp[k1,k3]*sp[k1,p1]*sp[k1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]
      *m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,
      k3]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 32
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 320*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1] - 208*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*
      sp[k1,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 48*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2
      *m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ]*m^2 + 128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*sp[k1,p2]*m + 
      64*sp[k1,p1]^2*sp[k2,k3] + 64*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1
      ]^2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] - 160*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 160*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*
      m + 64*sp[k1,p1]*sp[k2,k3]^2 - 48*sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[
      k1,p1]*sp[k2,k3]^2*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m] + amp[13,7]*color[ - Cf^2*Na*Tf + Ca*Cf*Na
      *Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[
       - k3 + p1]]*den[sp[p1 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 128*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 
      256*sp[k1,k2]*sp[k3,p1]^2 - 128*sp[k1,k2]*sp[k3,p1]^2*m + 16*sp[
      k1,k2]*sp[k3,p1]^2*m^2 + 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 128*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2
      ]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p1]
      *sp[p1,p2]*m + 256*sp[k1,k3]^2*sp[p1,p2] - 128*sp[k1,k3]^2*sp[p1,
      p2]*m + 16*sp[k1,k3]^2*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2]*m^2 - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64
      *sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 256*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p2] + 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 96*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ]*m^2 - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,
      p2]*sp[k3,p1]*m^2 + 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1
      ,k3]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2
       - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 640*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 480*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m + 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 - 64*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2] + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m^2 - 640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 416*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2
       + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 64*sp[k1,p1]^2*sp[k2,k3]
       - 32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 64*sp[
      k1,p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]^2*sp[k2,p2]*m^2 - 64*sp[k1,p1
      ]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,
      p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p1] + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 608
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 
      32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 480*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2
       - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1]*m^2] + amp[13,9]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 + p1]]*den[sp[k1 + k2]]*den[sp[ - k2 + p2]]*den[sp[ - k3
       + p1]]*num[ - 32*sp[k1,k2]^2*sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,p1]
      *m + 4*sp[k1,k2]^2*sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,
      p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 + 96*sp[k1,k2]
      *sp[k1,k3]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 48*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m + 32*sp[k1,k2]*sp[k1,p1]^2 - 16*sp[k1,k2]*sp[k1,p1]^2*m + 64*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*
      m + 4*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 192*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 144*sp[k1
      ,k2]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 
      176*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 72*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m + 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k2]*sp[k2,
      k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 144*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 
      32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p1]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 112*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p2] + 40*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,k2
      ]*sp[k2,p1]*sp[p1,p2] + 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m^2 - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m
       + 64*sp[k1,k2]*sp[p1,p2]^2 - 24*sp[k1,k2]*sp[p1,p2]^2*m - 64*sp[
      k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m + 32*sp[k1,k3]^2*
      sp[p1,p2] - 8*sp[k1,k3]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 64*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p1]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 96*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*
      m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[
      k2,p1] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,
      k3]*sp[k2,p1]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]^2*m + 4*sp[k1,k3]
      *sp[k2,p1]^2*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 24*sp[k1,k3
      ]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 4*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 64*
      sp[k1,p1]^2*sp[k1,p2] + 32*sp[k1,p1]^2*sp[k1,p2]*m - 16*sp[k1,p1]
      ^2*sp[k2,k3]*m - 80*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,
      p2]*m + 8*sp[k1,p1]^2*sp[k3,p2]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 24*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 4*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m^2 + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 24*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 80*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]
       - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*
      sp[p1,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[
      k2,k3]^2 + 24*sp[k1,p1]*sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*
      m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 24*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 - 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p1
      ]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 8*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 80*sp[k1,p2]^2*
      sp[k3,p1] + 32*sp[k1,p2]^2*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 80*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 32
      *sp[k1,p2]*sp[k2,p1]^2 - 8*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 144*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m - 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 24*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m - 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1]*m] + amp[13,10]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 + p1]]*den[sp[k1 + k2]]*den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]
      ]*num[32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 24*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2 - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 8
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2] - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
       + 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 64
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
      *m - 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k3,p1]
      ^2 + 8*sp[k1,k2]*sp[k3,p1]^2*m - 4*sp[k1,k2]*sp[k3,p1]^2*m^2 - 16
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 176*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] + 72*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m^2 - 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,k2]*
      sp[p1,p2]^2*m + 8*sp[k1,k3]^2*sp[k2,p1]*m - 4*sp[k1,k3]^2*sp[k2,
      p1]*m^2 - 32*sp[k1,k3]^2*sp[p1,p2] + 8*sp[k1,k3]^2*sp[p1,p2]*m - 
      8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,
      k3]*m^2 + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k3,p2] + 24*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 80*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*
      m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m^2 + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 8*sp[k1,k3]*sp[k1
      ,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 24*sp[k1,k3
      ]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 24*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2
      *m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 4*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 24*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2] - 40*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m^2 - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 144*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]^2*sp[k2,k3]*m + 8*
      sp[k1,p1]^2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p1] + 16*sp[k1,p1]
      ^2*sp[k3,p1]*m - 80*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,
      p2]*m + 64*sp[k1,p1]^2*sp[p1,p2] - 32*sp[k1,p1]^2*sp[p1,p2]*m + 4
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1]*m + 144*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2
      ]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[
      k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,k3]^2 + 24*sp[
      k1,p1]*sp[k2,k3]^2*m - 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 64*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 32*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m - 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1] + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p1]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 24*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 4*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2
      ,p1]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p1]*m - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2
      ] - 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 80*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 64
      *sp[k1,p2]^2*sp[k3,p1] + 24*sp[k1,p2]^2*sp[k3,p1]*m + 32*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 144*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 24*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]^2 + 8*sp[k1,p2]*sp[k2,p1]^2*m
       - 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 24*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1] + 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[
      13,11]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]
      ]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[ - k3 + p1]]*num[
      128*sp[k1,k2]^2*sp[k3,p1] - 48*sp[k1,k2]^2*sp[k3,p1]*m - 64*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 
      160*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,
      p1]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 48*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,k3]*m + 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 64*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1
      ] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m^2 - 320*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 176*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 
      256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k2,
      p1]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 48
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 96*
      sp[k1,k3]^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m - 96*sp[k1,k3]
      ^2*sp[p1,p2] + 80*sp[k1,k3]^2*sp[p1,p2]*m - 16*sp[k1,k3]^2*sp[p1,
      p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,
      p1]*sp[k2,k3]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 96*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*
      m + 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k3]*sp[k1,p1]
      *sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[
      k1,k3]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m
       - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 80*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 80*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*
      m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m + 224*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 112*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m^2 + 32*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,p2] - 16*
      sp[k1,p1]^2*sp[k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]
      ^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 48*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 448*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 24*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m^2 + 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 112
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 256*sp[k1,p1]*sp[k2,
      p1]*sp[k2,p2] + 144*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1
      ]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] + 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 112*sp[k1,p2]
      *sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 
      256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 160*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 192*sp[k1,p2]*sp[
      k2,p1]^2 - 112*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]^2
      *m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m^2] + amp[13,12]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 
      1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k2 + 
      p1]]*den[sp[ - k3 + p1]]*num[ - 256*sp[k1,k2]^2*sp[k3,p1] + 128*
      sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]^2*sp[k3,p1]*m^2 + 64*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2
       - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 96*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 16*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 256*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 640*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] - 480*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 112*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m^3 - 640*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 416*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m^3 + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m
       - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ]*m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 64*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*
      m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 640*sp[k1,k3
      ]*sp[k2,p1]*sp[k2,p2] - 480*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 112
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m^3 + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1
      ,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,k3]*m - 64*sp[k1,p1]^2*
      sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]^2*sp[k3,p2]
       + 64*sp[k1,p1]^2*sp[k3,p2]*m - 16*sp[k1,p1]^2*sp[k3,p2]*m^2 - 
      128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m^2 - 896*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p2] + 608*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2]*m^2 + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^3 - 64*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       + 256*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 128*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 128*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2
       - 256*sp[k1,p2]*sp[k2,p1]^2 + 128*sp[k1,p2]*sp[k2,p1]^2*m - 16*
      sp[k1,p2]*sp[k2,p1]^2*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[13,13]*color[ - Cf^2*Na*
      Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[
       - k3 + p1]]^2*num[128*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 128*sp[k1,
      k2]*sp[k1,k3]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m^2
       + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 160*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^3 - 128*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 128
      *sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,p2]*sp[k3,
      p1]*m^2 - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 288*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 8*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 160*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3] + amp[13,14]
      *color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[ - k2 - k3]]*den[sp[ - k3 + p1]]*den[sp[p1 + p2]]*num[32*sp[k1
      ,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 96*sp[k1,
      k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64
      *sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
      *m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 64*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 224*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] - 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
      *m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k3,p1
      ]^2 + 48*sp[k1,k2]*sp[k3,p1]^2*m - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k3,p1]
      *sp[p1,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m^2 - 192*sp[k1,k3]^2*sp[p1,p2] + 112*sp[k1,k3]^
      2*sp[p1,p2]*m - 16*sp[k1,k3]^2*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 64*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 256*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p2] - 144*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ] + 80*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 112*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 
      96*sp[k1,k3]*sp[k2,p1]^2 + 32*sp[k1,k3]*sp[k2,p1]^2*m - 96*sp[k1,
      k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 64
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]
      *m - 192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 80*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 256*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,p1]^2*sp[k2,k3
      ] - 32*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*
      sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]
       + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 192*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p1] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 448*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 24*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,
      p2] + 80*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m^2 - 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 80*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 320*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] + 176*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 24*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k2,p1]^2 - 80
      *sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]^2*m^2 - 16*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2] + amp[13,15]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 + k2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*den[sp[ - k3 + 
      p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2
      ] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 128*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m
       + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 112*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 128
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p1]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 320*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2] - 208*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m
       + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]
      *sp[k3,p1]^2*m - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]^2*sp[k2,p1] - 16*sp[k1,k3]^2
      *sp[k2,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,k3]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 
      32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[p1
      ,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1] - 48*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 8*sp[
      k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p1]^2 - 32*
      sp[k1,k3]*sp[k2,p1]^2*m - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p1] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p1]
      *sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,p1]^2*
      sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k3,p1]
       + 32*sp[k1,p1]^2*sp[k3,p1]*m - 64*sp[k1,p1]^2*sp[k3,p2] + 32*sp[
      k1,p1]^2*sp[k3,p2]*m + 128*sp[k1,p1]^2*sp[p1,p2] - 64*sp[k1,p1]^2
      *sp[p1,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,k3]^2 + 48*sp[
      k1,p1]*sp[k2,k3]^2*m - 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 128*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 64*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 160*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m
       - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p1]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,p1
      ]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ] - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p2]*sp[k2,p1]^2
       + 16*sp[k1,p2]*sp[k2,p1]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]]
       + amp[13,16]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]*den[sp[
       - k2 + p2]]*den[sp[ - k3 + p1]]^2*num[ - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1] + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 64*sp[
      k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*
      m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 128*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 
      32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 64*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2]
       + amp[14,1]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[
      k1 - p2]]*den[sp[k2 + k3]]*num[48*sp[k1,k2]*sp[k1,p1] - 24*sp[k1,
      k2]*sp[k1,p1]*m + 48*sp[k1,k3]*sp[k1,p1] - 24*sp[k1,k3]*sp[k1,p1]
      *m - 48*sp[k1,p1]*sp[k2,p2] + 24*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1
      ,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,p2]*sp[k2,p1
      ] - 24*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,p2]*sp[k3,p1] - 24*sp[k1,
      p2]*sp[k3,p1]*m] + amp[14,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 + p1]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*num[32*sp[k1,k2]*sp[
      k1,p1] - 16*sp[k1,k2]*sp[k1,p1]*m - 24*sp[k1,k2]*sp[p1,p2] + 20*
      sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 + 16*sp[k1,k3]*
      sp[k1,p1] - 8*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k3]*sp[p1,p2] - 20
      *sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[p1,p2]*m^2 - 8*sp[k1,p1]*
      sp[k2,p2] - 4*sp[k1,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*m^2
       - 40*sp[k1,p1]*sp[k3,p2] + 28*sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,p1
      ]*sp[k3,p2]*m^2 + 40*sp[k1,p2]*sp[k2,p1] - 28*sp[k1,p2]*sp[k2,p1]
      *m + 4*sp[k1,p2]*sp[k2,p1]*m^2 + 8*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,
      p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]*m^2] + amp[14,1]*color[1/
      4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[k2 + k3
      ]]*num[ - 16*sp[k1,k2]*sp[k1,p1] + 8*sp[k1,k2]*sp[k1,p1]*m - 24*
      sp[k1,k2]*sp[p1,p2] + 20*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[
      p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1] + 16*sp[k1,k3]*sp[k1,p1]*m + 
      24*sp[k1,k3]*sp[p1,p2] - 20*sp[k1,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*
      sp[p1,p2]*m^2 + 40*sp[k1,p1]*sp[k2,p2] - 28*sp[k1,p1]*sp[k2,p2]*m
       + 4*sp[k1,p1]*sp[k2,p2]*m^2 + 8*sp[k1,p1]*sp[k3,p2] + 4*sp[k1,p1
      ]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k3,p2]*m^2 - 8*sp[k1,p2]*sp[k2,p1]
       - 4*sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2 - 40*sp[k1
      ,p2]*sp[k3,p1] + 28*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,p2]*sp[k3,p1]
      *m^2] + amp[14,2]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 + k2]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*
      num[ - 128*sp[k1,k2]^2*sp[k3,p1] + 48*sp[k1,k2]^2*sp[k3,p1]*m + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 48*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 320*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 176*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2
      ]*sp[k2,p1]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] - 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 48*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m^2 - 96*sp[k1,k3]^2*sp[k2,p1] + 32*sp[k1,k3]^2*sp[k2,p1]*m + 96
      *sp[k1,k3]^2*sp[p1,p2] - 80*sp[k1,k3]^2*sp[p1,p2]*m + 16*sp[k1,k3
      ]^2*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 32*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
      *m - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 80*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 32*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m^2 + 96*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] - 80*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ] - 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 224*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,
      p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3,p2] - 16*
      sp[k1,p1]^2*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 96*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 448*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 24*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 256*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2] - 144*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 
      16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1] - 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 112
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[
      k1,p2]*sp[k2,p1]^2 + 112*sp[k1,p2]*sp[k2,p1]^2*m - 16*sp[k1,p2]*
      sp[k2,p1]^2*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[14,4]*color[1/2*Ca*Cf*Na*Tf - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*
      den[sp[p1 + p2]]*num[ - 32*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2
      *sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]^2 - 32*sp[k1,k2]*
      sp[k1,p1]^2*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
       - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 128*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 192*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 128*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 256*sp[k1,k2]*sp[k1
      ,p2]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,p2]*sp[p1
      ,p2] - 48*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p2]
      *sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2]*m - 256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 160*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ]*m^2 + 128*sp[k1,k3]*sp[k1,p1]^2 - 64*sp[k1,k3]*sp[k1,p1]^2*m + 
      128*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,
      p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 64*
      sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 320*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2] - 208*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 32*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2] - 112*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p2
      ]*sp[p1,p2]*m^2 + 64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2
      ,k3]*m + 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k3,p2] + 64
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
      *m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 128*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 32*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 16*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2
      ] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]^2 + 48*sp[k1,p1]*sp[k2,p2]^2*m
       - 8*sp[k1,p1]*sp[k2,p2]^2*m^2 - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 128*sp[k1,p2]
      ^2*sp[k2,p1] + 32*sp[k1,p2]^2*sp[k2,p1]*m - 64*sp[k1,p2]^2*sp[k3,
      p1] + 16*sp[k1,p2]^2*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1
      ]^2*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m^2 - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m] + amp[14,5]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*
      Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[
      k2 + k3]]*num[96*sp[k1,k2]^2*sp[k3,p1] - 32*sp[k1,k2]^2*sp[k3,p1]
      *m - 96*sp[k1,k2]^2*sp[p1,p2] + 80*sp[k1,k2]^2*sp[p1,p2]*m - 16*
      sp[k1,k2]^2*sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 96*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,
      k2]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 48
      *sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1]*m^2 + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 
      224*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 192*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2] + 80*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 128*sp[k1,k3]^2*sp[k2,
      p1] - 48*sp[k1,k3]^2*sp[k2,p1]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,
      k3] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1
      ] - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 320*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       + 176*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 128
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
       - 80*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2]*m^2 + 32*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,p1]^2*sp[k2,
      p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,p1]^2*sp[k3,p2] - 16*
      sp[k1,p1]^2*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 192*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] - 112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 448*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 24*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2] + 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 8*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k3,p1
      ]*sp[k3,p2] + 144*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k3,p1]*sp[k3,p2]*m^2 - 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 160
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 112*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 32*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2 + 192*sp[k1,p2]*sp[k3,p1]^2 - 112*sp[k1,p2]*sp[k3,p1]^2*m + 
      16*sp[k1,p2]*sp[k3,p1]^2*m^2] + amp[14,7]*color[ - 1/2*Ca*Cf*Na*
      Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[k2
       + k3]]*den[sp[p1 + p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k1,p1]^2
       + 64*sp[k1,k2]*sp[k1,p1]^2*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]
       + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 160*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 160*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m - 320*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 208*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 96*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m - 192*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 112*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k3]
      ^2*sp[p1,p2] - 16*sp[k1,k3]^2*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p1
      ]^2 + 32*sp[k1,k3]*sp[k1,p1]^2*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,
      p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 128*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 192*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m
       - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p2]*m + 128*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1
      ,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 256*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 128*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]
      *m - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 256*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2] - 160*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 24*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k3]*sp[k3,p1]*sp[p1,
      p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p2]
      *sp[p1,p2] + 48*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2]*m^2 - 64*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*
      sp[k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*sp[k3,p2]
       - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 64*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1] - 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 32*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 
      16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k3,p2]^2 - 
      48*sp[k1,p1]*sp[k3,p2]^2*m + 8*sp[k1,p1]*sp[k3,p2]^2*m^2 + 64*sp[
      k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m + 128*sp[k1,p2]^2
      *sp[k3,p1] - 32*sp[k1,p2]^2*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,p2]*
      sp[k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]^2*m - 64*sp[k1,p2]*sp[k3,p1]
      *sp[k3,p2] + 48*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m^2] + amp[14,8]*color[ - 1/2*Ca^2*Na*Tf]*den[
      sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[k2 + 
      k3]]*num[ - 24*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m
       - 24*sp[k1,k2]^2*sp[p1,p2]*m + 4*sp[k1,k2]^2*sp[p1,p2]*m^2 + 24*
      sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*
      m + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m^2 - 104*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 48*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 
      16*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[k2
      ,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 48*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 12*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2]*m + 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 
      96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 48*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 40*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 40*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*
      m^2 - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 48*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 4*sp[k1
      ,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 24*sp[k1,k3]^2*sp[k2,p1] + 16*sp[
      k1,k3]^2*sp[k2,p1]*m - 24*sp[k1,k3]^2*sp[p1,p2]*m + 4*sp[k1,k3]^2
      *sp[p1,p2]*m^2 - 104*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 48*sp[k1,k3]
      *sp[k1,p1]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 12*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ]*m + 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 24*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p2]*m - 4*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m^2 - 48*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 96*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[
      k1,p2]*sp[k3,p1]*m^2 + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
       - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 4*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2
       - 96*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,k3]*sp[k3,p1]*sp[
      p1,p2]*m - 4*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2] - 40*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,
      k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 176*sp[k1,p1]^2*sp[k2,k3] + 48*sp[
      k1,p1]^2*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 64*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 104*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 176*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 24*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 4*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m^2 - 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 4*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k2,p2]^2 + 40*sp[k1,p1]*sp[k2,p2]
      ^2*m - 4*sp[k1,p1]*sp[k2,p2]^2*m^2 - 12*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1]*m - 4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 24*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 4*
      sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k3,p2]^2 + 40
      *sp[k1,p1]*sp[k3,p2]^2*m - 4*sp[k1,p1]*sp[k3,p2]^2*m^2 - 104*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       - 104*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 176*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p1]^2 - 40*sp[k1,p2]*sp[k2,
      p1]^2*m + 4*sp[k1,p2]*sp[k2,p1]^2*m^2 + 24*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 96*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 12*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m + 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*
      sp[k3,p1]^2 - 40*sp[k1,p2]*sp[k3,p1]^2*m + 4*sp[k1,p2]*sp[k3,p1]^
      2*m^2 + 24*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1
      ]*sp[k3,p2]*m^2] + amp[14,9]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*
      num[80*sp[k1,k2]^2*sp[k1,p1] - 40*sp[k1,k2]^2*sp[k1,p1]*m + 80*
      sp[k1,k2]^2*sp[k2,p1] - 32*sp[k1,k2]^2*sp[k2,p1]*m - 16*sp[k1,k2]
      ^2*sp[k3,p1] + 32*sp[k1,k2]^2*sp[k3,p1]*m - 120*sp[k1,k2]^2*sp[p1
      ,p2] + 44*sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,
      p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 48*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 104*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 48*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 
      64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k1,
      p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 8*sp[k1,k2]*sp[k1,p1]*
      sp[k2,k3]*m - 112*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 40*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1]*m + 104*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 36*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 104*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1] + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 136*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 20*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 24*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] + 4*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 
      48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 20*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 8*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 4*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,
      k2]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 72*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] - 28*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 56*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m
       + 56*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m + 112*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k3
      ,p2]*sp[p1,p2]*m + 56*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,
      p2]^2*m - 24*sp[k1,k3]^2*sp[k2,p1] - 80*sp[k1,k3]*sp[k1,p1]*sp[k1
      ,p2] + 40*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 88*sp[k1,k3]*sp[k1,p1
      ]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 24*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 136*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p2]*m + 72*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,
      p1]*sp[p1,p2]*m + 160*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 16*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 12*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] + 36*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 40*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2] + 12*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 56*sp[k1,
      k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m + 40*sp[k1,p1]^2*sp[
      k2,k3] - 16*sp[k1,p1]^2*sp[k2,k3]*m - 40*sp[k1,p1]^2*sp[k2,p2] + 
      16*sp[k1,p1]^2*sp[k2,p2]*m - 104*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1
      ,p1]^2*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m + 56*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 24
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 88*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1] - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 80*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 
      48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m - 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2]*m + 40*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 12*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 12*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k2,p2]^2 + 68*sp[
      k1,p1]*sp[k2,p2]^2*m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 24*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 40*sp[k1,p1]*sp[k2,p2]*sp[
      p1,p2] + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[k1,p1]*sp[k3,
      p2]^2 - 28*sp[k1,p1]*sp[k3,p2]^2*m + 88*sp[k1,p1]*sp[k3,p2]*sp[p1
      ,p2] - 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,p2]^2*sp[k2,
      p1] - 8*sp[k1,p2]^2*sp[k2,p1]*m - 80*sp[k1,p2]^2*sp[k3,p1] + 32*
      sp[k1,p2]^2*sp[k3,p1]*m - 40*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 12*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 120*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 44*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 72*sp[k1,p2]*
      sp[k2,p1]^2 + 28*sp[k1,p2]*sp[k2,p1]^2*m + 112*sp[k1,p2]*sp[k2,p1
      ]*sp[k2,p2] - 44*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 12*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 56*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] + 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[
      k2,p2]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m - 56*sp[k1,
      p2]*sp[k3,p1]*sp[k3,p2] + 20*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 56
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]
      *m - 64*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] + 32*sp[k1,p2]*sp[k3,p2]*
      sp[p1,p2]*m] + amp[14,10]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1
      ]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[24*
      sp[k1,k2]^2*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 48*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2] - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 80*sp[k1,
      k2]*sp[k1,p1]*sp[k1,p2] - 40*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 88
      *sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]
      *m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m - 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1]*m + 136*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 40*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p2]*m - 72*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k2
      ,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 160*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k2]
      *sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 40*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*
      m + 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k2,
      p2]*sp[p1,p2] - 12*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 
      96*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 36*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2]*m + 56*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 
      80*sp[k1,k3]^2*sp[k1,p1] + 40*sp[k1,k3]^2*sp[k1,p1]*m + 16*sp[k1,
      k3]^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m - 80*sp[k1,k3]^2*sp[
      k3,p1] + 32*sp[k1,k3]^2*sp[k3,p1]*m + 120*sp[k1,k3]^2*sp[p1,p2]
       - 44*sp[k1,k3]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]
       - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m + 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 104*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 136*sp[k1
      ,k3]*sp[k1,p1]*sp[k2,p2] + 20*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 
      112*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 40*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p1]*m - 104*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 36*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 8*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 20*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 4*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[
      p1,p2] + 8*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       - 56*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 112*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 36*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 32*
      sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m - 72*sp[k1,k3]*sp[k3,p1]*sp[p1,p2
      ] + 28*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2] + 36*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 56*sp[k1,k3]*sp[
      p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 40*sp[k1,p1]^2*sp[k2,k3]
       + 16*sp[k1,p1]^2*sp[k2,k3]*m + 104*sp[k1,p1]^2*sp[k2,p2] - 32*
      sp[k1,p1]^2*sp[k2,p2]*m + 40*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]
      ^2*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 88*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 24*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 56*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] + 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 48*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 40*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m - 72*sp[k1,p1]*sp[k2,p2]^2 + 28*sp[k1,p1]*sp[k2,
      p2]^2*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 12*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m - 88*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 40*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]
       + 12*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 160*sp[k1,p1]*sp[k3,p2]^2
       - 68*sp[k1,p1]*sp[k3,p2]^2*m + 40*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]
       - 8*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,p2]^2*sp[k2,p1]
       - 32*sp[k1,p2]^2*sp[k2,p1]*m - 32*sp[k1,p2]^2*sp[k3,p1] + 8*sp[
      k1,p2]^2*sp[k3,p1]*m - 120*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 44*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 40*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 12*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2] - 20*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 48*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] - 20*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m - 56*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2]*m + 12*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p2]*
      sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[
      k1,p2]*sp[k3,p1]^2 - 28*sp[k1,p2]*sp[k3,p1]^2*m - 112*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2] + 44*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 56*sp[
      k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m
       + 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p2]*sp[
      p1,p2]*m] + amp[14,11]*color[Ca*Cf*Na*Tf]*den[sp[k1 - p2]]^2*den[
      sp[ - k2 - k3]]*den[sp[k2 + k3]]*num[ - 352*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 272*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 128
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2]*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 192*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2] - 128*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2]*m^2] + amp[14,12]*color[ - 1/2*Ca*Cf*Na*Tf]*
      den[sp[k1 - p2]]^2*den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*num[ - 64
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1
      ]*sp[k2,p2] + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 128
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,p2]*sp[k2,
      p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] - 128*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,p2]*
      sp[k3,p1]*sp[p1,p2]*m^2] + amp[14,13]*color[1/2*Ca*Cf*Na*Tf]*den[
      sp[k1 - p2]]^2*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[64*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 16
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2
       - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 128*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,p2]*sp[k3,p1]*sp[p1,
      p2] + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k3,p1]
      *sp[p1,p2]*m^2] + amp[14,14]*color[Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[k1 - p2]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[sp[p1
       + p2]]*num[ - 96*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2
      ]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m + 192*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p1]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 96
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m + 192*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 48*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 96*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 
      8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]^2*sp[p1,p2] + 
      16*sp[k1,k3]^2*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 
      32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 192*sp[k1,k3]*sp[k1,
      p1]*sp[k3,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 96*sp[k1,k3]
      *sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 48*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 96*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[
      k3,p1]*m - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 8*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 96*
      sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*
      m + 192*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 80*sp[k1,k3]*sp[k3,p2]*
      sp[p1,p2]*m + 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 - 352*sp[k1,p1]
      ^2*sp[k2,k3] + 96*sp[k1,p1]^2*sp[k2,k3]*m - 352*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 352*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 96*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m - 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m - 192*sp[k1,p1]*sp[k2,p2]^2 + 80*sp[k1,p1]*sp[k2,p2]^2*m
       - 8*sp[k1,p1]*sp[k2,p2]^2*m^2 - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 16*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k3,p2]^2 + 80*sp[
      k1,p1]*sp[k3,p2]^2*m - 8*sp[k1,p1]*sp[k3,p2]^2*m^2 - 704*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2] + 368*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 48*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,p2]*sp[k2,p1]^2 - 16
      *sp[k1,p2]*sp[k2,p1]^2*m + 192*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 80
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 8*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 
      8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k3,p1]^2 - 
      16*sp[k1,p2]*sp[k3,p1]^2*m + 192*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 
      80*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,
      p2]*m^2] + amp[14,15]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - p2]]*den[
      sp[ - k2 + p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[48*sp[k1
      ,k2]^2*sp[k3,p1] - 16*sp[k1,k2]^2*sp[k3,p1]*m + 48*sp[k1,k2]^2*
      sp[p1,p2] - 16*sp[k1,k2]^2*sp[p1,p2]*m - 112*sp[k1,k2]*sp[k1,k3]*
      sp[k2,p1] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 64*sp[k1,k2]*sp[
      k1,k3]*sp[k3,p1] + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 8*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2
      ]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 48*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 40*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*
      m + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 80*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 144*sp[k1
      ,k2]*sp[k2,p2]*sp[p1,p2] + 96*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 
      16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 40*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2
       + 48*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m + 128*
      sp[k1,k3]^2*sp[k2,p1] - 56*sp[k1,k3]^2*sp[k2,p1]*m - 96*sp[k1,k3]
      *sp[k1,p1]*sp[k2,k3] + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 48*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*
      m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 8*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m + 160*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 128*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 56*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3
      ]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 56*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2] + 24*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[
      p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m + 16*sp[k1,p1]^2*sp[k2,k3]
       + 16*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 
      48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p1]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m^2 + 224*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 72*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m + 144*sp[k1,p1]*sp[k2,p2]^2 - 96*sp[k1,p1]*sp[k2,p2]^2*m
       + 16*sp[k1,p1]*sp[k2,p2]^2*m^2 + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ] - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 48*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 96*sp[
      k1,p1]*sp[k3,p1]*sp[k3,p2] + 40*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m
       + 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k3,p2]*sp[
      p1,p2]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 8*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 128*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1] + 56*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 
      80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m - 176*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 112*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 64*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1] - 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 16*sp[k1,p2]*sp[k2,p1
      ]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k3,p1]^2 - 56*sp[k1,p2]*sp[
      k3,p1]^2*m + 112*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 48*sp[k1,p2]*sp[
      k3,p1]*sp[p1,p2]*m] + amp[14,16]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]
      ]*num[ - 128*sp[k1,k2]^2*sp[k3,p1] + 56*sp[k1,k2]^2*sp[k3,p1]*m
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 24*sp[k1,k2]*sp[k1,k3]*sp[
      k2,p1]*m + 112*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 96*sp[k1,
      k2]*sp[k1,p1]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 
      160*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p1]*m - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 
      128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2]*m - 192*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 56*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 56*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2
      ] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 48*sp[k1,
      k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2*m - 48*sp[k1,k3]^2*sp[
      k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m - 48*sp[k1,k3]^2*sp[p1,p2] + 
      16*sp[k1,k3]^2*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 
      16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 48*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 40*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 48*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] - 40*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m^2 + 144*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 96*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m^2 - 48*sp[k1,k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 16*
      sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2
      *sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 224*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p2] + 72*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 40*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 48*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 
      144*sp[k1,p1]*sp[k3,p2]^2 + 96*sp[k1,p1]*sp[k3,p2]^2*m - 16*sp[k1
      ,p1]*sp[k3,p2]^2*m^2 + 48*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16*sp[
      k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
       - 56*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m^2 + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,p1]^2 + 56*sp[k1,
      p2]*sp[k2,p1]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 112*sp[k1,p2]*sp[k2,p1]*sp[p1,
      p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1] + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 176*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 112*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[k3,p2
      ]*m^2 + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]] + amp[15,1]*color[1/4*
      Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[k2 - p2]]
      *num[ - 48*sp[k1,k2]*sp[k1,p1] + 24*sp[k1,k2]*sp[k1,p1]*m + 48*
      sp[k1,k3]*sp[k2,p1] - 24*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,k3]*sp[
      p1,p2] + 24*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[k1,p2] - 24*
      sp[k1,p1]*sp[k1,p2]*m - 48*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,p1]*sp[
      k2,k3]*m + 48*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,p1]*sp[k3,p2]*m] + 
      amp[15,1]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + 
      k3]]*den[sp[k2 - p2]]*num[ - 48*sp[k1,k2]*sp[k1,p1] + 24*sp[k1,k2
      ]*sp[k1,p1]*m + 48*sp[k1,k3]*sp[k2,p1] - 24*sp[k1,k3]*sp[k2,p1]*m
       - 48*sp[k1,k3]*sp[p1,p2] + 24*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,
      p1]*sp[k1,p2] - 24*sp[k1,p1]*sp[k1,p2]*m - 48*sp[k1,p1]*sp[k2,k3]
       + 24*sp[k1,p1]*sp[k2,k3]*m + 48*sp[k1,p1]*sp[k3,p2] - 24*sp[k1,
      p1]*sp[k3,p2]*m] + amp[15,2]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[k2 - p2]]*den[sp[
       - k3 + p1]]*num[ - 32*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[
      k3,p1]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k1,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] - 16*sp[k1,k2]
      *sp[k1,k3]*sp[k2,p1]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1
      ]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]
      ^2 + 32*sp[k1,k2]*sp[k1,p1]^2*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,k3
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 128*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 192*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*
      m - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,
      k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2
       - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p1]*m - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 160*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 24*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 128*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 128*sp[k1,k3]^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m - 64*
      sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m - 128*sp[k1,k3
      ]*sp[k1,p1]*sp[k1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 128*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*
      m - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,
      p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 32*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 320*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 208*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m + 32*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m + 32*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 
      128*sp[k1,p1]^2*sp[k1,p2] - 64*sp[k1,p1]^2*sp[k1,p2]*m + 64*sp[k1
      ,p1]^2*sp[k2,k3] + 64*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[
      k2,p2]*m - 32*sp[k1,p1]^2*sp[k3,p2] - 160*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 160*sp[k1,p1
      ]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*
      sp[k1,p1]*sp[k2,k3]^2 - 48*sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[k1,p1]*
      sp[k2,k3]^2*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m + 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 112*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m] + amp[15,4]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*
      Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[k2 - p2]]*den[sp[p1
       + p2]]*num[ - 128*sp[k1,k2]^2*sp[p1,p2] + 48*sp[k1,k2]^2*sp[p1,
      p2]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k2
      ]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 128*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 32*sp[k1,
      k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64
      *sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
      *m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m^2 - 160*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 48*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1
      ] + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 320
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 176*sp[k1,k2]*sp[k2,p2]*sp[k3,p1
      ]*m - 24*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 48*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
      *m^2 + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p1]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m - 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[p1,
      p2] - 48*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k1,p2]
      *sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]^2 + 112*sp[k1,k3]*sp[k2,
      p1]^2*m - 16*sp[k1,k3]*sp[k2,p1]^2*m^2 - 192*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2] - 160*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[
      k2,k3]*m - 32*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k3,p2] + 
      16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 
      16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 80*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m^2
       + 256*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 144*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m^2 + 448*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 24*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2] + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 192*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
      *m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 96*sp[k1,p2]^2*sp[k2,
      p1] - 32*sp[k1,p2]^2*sp[k2,p1]*m + 96*sp[k1,p2]^2*sp[k3,p1] - 80*
      sp[k1,p2]^2*sp[k3,p1]*m + 16*sp[k1,p2]^2*sp[k3,p1]*m^2 - 192*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] + 80*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 224*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
       - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1] - 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m^2] + amp[15,5]*color[1/2*Ca*Cf*Na*Tf]*den[sp[
      k1 + k3]]^2*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*num[64*sp[k1,k3]
      *sp[k2,k3]*sp[k2,p1] - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 16*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
       - 128*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k3,p1]*
      sp[p1,p2]*m^2] + amp[15,6]*color[ - Ca*Cf*Na*Tf]*den[sp[k1 + k3]]
      ^2*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*num[ - 192*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1] + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      352*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 272*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[
      k3,p2]*sp[p1,p2] + 128*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1
      ,k3]*sp[k3,p2]*sp[p1,p2]*m^2] + amp[15,7]*color[ - 1/2*Ca*Cf*Na*
      Tf]*den[sp[k1 + k3]]^2*den[sp[k2 - p2]]*den[sp[p1 + p2]]*num[ - 
      128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p1] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 64
      *sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]
      *m - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k3,p2
      ]*sp[p1,p2] + 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2]*m^2] + amp[15,8]*color[1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*den[sp[k2 - 
      p2]]*num[ - 80*sp[k1,k2]^2*sp[k1,p1] + 40*sp[k1,k2]^2*sp[k1,p1]*m
       - 80*sp[k1,k2]^2*sp[k2,p1] + 32*sp[k1,k2]^2*sp[k2,p1]*m - 120*
      sp[k1,k2]^2*sp[k3,p1] + 44*sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]
      ^2*sp[p1,p2] + 32*sp[k1,k2]^2*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1] + 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 
      48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 20*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]
      *sp[k1,p2]*m + 104*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 36*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m + 112*sp[k1,k2]*sp[k1,p1]*sp[k2,p1] - 40*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2
      ] - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] - 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 136*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] + 20*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 104*sp[k1
      ,k2]*sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 
      48*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,
      p1]*m + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 104*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 32*sp[
      k1,k2]*sp[k2,k3]*sp[k2,p1]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
       + 36*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] - 28*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 24*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 4*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m - 56*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2*m + 112*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 36*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m - 56*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 24*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m - 56*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2]*m - 32*sp[k1,k3]^2*sp[k2,p1] + 8*sp[k1,k3]^2*sp[k2,
      p1]*m - 80*sp[k1,k3]^2*sp[p1,p2] + 32*sp[k1,k3]^2*sp[p1,p2]*m + 
      80*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 40*sp[k1,k3]*sp[k1,p1]*sp[k1,
      p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,p1]
      *sp[k2,k3]*m + 56*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m + 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 80*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
       - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 88*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 24*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 160*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[
      k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m
       - 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]*sp[
      p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 44*sp[k1,k3]*sp[k2
      ,k3]*sp[k2,p1]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,k3
      ]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 12*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 72*sp[k1,k3]*sp[k2,p1]^2 + 28*
      sp[k1,k3]*sp[k2,p1]^2*m + 40*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 12*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 56*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 20*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m + 120*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 
      44*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k3,p1]*sp[k3
      ,p2] - 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2]*m + 56*sp[k1,k3]*sp[k3,p1
      ]*sp[p1,p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m + 56*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2] - 20*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 40*sp[
      k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m + 40*sp[k1,p1]^2*
      sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m + 104*sp[k1,p1]^2*sp[k3,p2
      ] - 32*sp[k1,p1]^2*sp[k3,p2]*m + 136*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] - 40*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 24*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 88*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 72*sp[k1,
      p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 32
      *sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]
      *m + 160*sp[k1,p1]*sp[k2,k3]^2 - 68*sp[k1,p1]*sp[k2,k3]^2*m + 40*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p1] - 12*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*
      m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 4*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 8*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 8*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 24*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       - 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 88*sp[k1,
      p1]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m - 72
      *sp[k1,p1]*sp[k3,p2]^2 + 28*sp[k1,p1]*sp[k3,p2]^2*m + 24*sp[k1,p2
      ]^2*sp[k2,p1] - 24*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 36*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1] - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2] - 40*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m - 56*sp[k1,p2]*sp[k3,p1]^2 + 16*sp[k1,p2]*
      sp[k3,p1]^2*m + 40*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 12*sp[k1,p2]*
      sp[k3,p1]*sp[k3,p2]*m] + amp[15,9]*color[1/2*Ca^2*Na*Tf]*den[sp[
       - k1 + p1]]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]
      ]*num[ - 24*sp[k1,k2]^2*sp[k3,p1]*m + 4*sp[k1,k2]^2*sp[k3,p1]*m^2
       - 24*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m - 96*sp[
      k1,k2]*sp[k1,k3]*sp[k2,p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m
       - 4*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 + 48*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] + 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2]*m^2 + 24*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1
      ,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]
       + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m - 104*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 12*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 4*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 48*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m
       + 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1]*m + 24*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1
      ,p2]*sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 40
      *sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ]*m^2 - 24*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]
      *sp[p1,p2]*m - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 40*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 + 24*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m + 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m - 4*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 48*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] + 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 
      64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2
      ,p1] + 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 4*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1]*m^2 - 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2]*m - 4*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m^2 - 24*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 + 12*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m^2 + 96*sp[k1,k3]*sp[k2,p1]^2 - 40*sp[k1,k3]*sp[k2,p1
      ]^2*m + 4*sp[k1,k3]*sp[k2,p1]^2*m^2 + 104*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 12*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 176*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1] + 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 104*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 24*sp[k1,k3]
      *sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 96
      *sp[k1,k3]*sp[p1,p2]^2 - 40*sp[k1,k3]*sp[p1,p2]^2*m + 4*sp[k1,k3]
      *sp[p1,p2]^2*m^2 - 176*sp[k1,p1]^2*sp[k2,p2] + 48*sp[k1,p1]^2*sp[
      k2,p2]*m - 12*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3]*m^2 + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 
      48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 24*sp[k1,p1]*sp[k1,p2]*sp[k3
      ,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k1
      ,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,p1
      ]*sp[k2,k3]^2 - 40*sp[k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3
      ]^2*m^2 - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 4*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1]*m^2 - 104*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 48*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2]*m - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m^2 + 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2]*m^2 + 12*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 4*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2]*m^2 - 176*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 48
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 104*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k3,p2]
      ^2 - 40*sp[k1,p1]*sp[k3,p2]^2*m + 4*sp[k1,p1]*sp[k3,p2]^2*m^2 - 
      24*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k3,p2]*sp[p1,
      p2]*m^2 + 24*sp[k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m
       - 24*sp[k1,p2]^2*sp[k3,p1]*m + 4*sp[k1,p2]^2*sp[k3,p1]*m^2 + 48*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       - 4*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 24*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p1]*m^2 + 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[k3,p1]*sp[k3,
      p2] + 40*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,p2]*
      sp[k3,p1]*sp[p1,p2]*m - 4*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m^2] + 
      amp[15,10]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + 
      k3]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[ - 24*sp[k1,k2]^2*
      sp[p1,p2] - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 40*sp[k1,k2]*sp[k1
      ,k3]*sp[k1,p1]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 160*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2] + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]
      *sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 88*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m
       + 72*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p1]*m + 136*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 40*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2]*m + 104*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 32*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 48*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 40*sp[k1,k2]*sp[
      k2,k3]*sp[k3,p1] - 12*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 24*sp[k1,
      k2]*sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 40*sp[k1,k2]*sp[k2,p2]*sp[k3,p1
      ] - 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 56*sp[k1,k2]*sp[k3,p1]^2
       - 16*sp[k1,k2]*sp[k3,p1]^2*m - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       + 36*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2] - 4*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 80*sp[k1,k3]
      ^2*sp[k2,p1] - 32*sp[k1,k3]^2*sp[k2,p1]*m + 32*sp[k1,k3]^2*sp[p1,
      p2] - 8*sp[k1,k3]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2
      ] - 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 80*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 88*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] - 24*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 40*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16
      *sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]
      *m - 56*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 24*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 20*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 8*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 4*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[k2,p1
      ] - 20*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*
      sp[k3,p1] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m - 12*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m - 120*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 44*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2]*m - 56*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 
      16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2] + 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k2,p1
      ]*sp[p1,p2] - 20*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 40*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2] + 12*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m
       + 32*sp[k1,k3]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k3,p1]*sp[
      k3,p2]*m - 56*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k3,
      p1]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 44*sp[k1,k3
      ]*sp[k3,p2]*sp[p1,p2]*m - 72*sp[k1,k3]*sp[p1,p2]^2 + 28*sp[k1,k3]
      *sp[p1,p2]^2*m - 104*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^2*sp[k2
      ,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,p2]*m + 
      40*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 80*sp[k1,
      p1]*sp[k1,p2]^2 + 40*sp[k1,p1]*sp[k1,p2]^2*m - 136*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3] + 20*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 104*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 
      32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ]*m - 24*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 8*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 36*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m + 112*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 40*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 72*sp[k1,p1]*sp[k2,k3]^2 + 28*
      sp[k1,p1]*sp[k2,k3]^2*m + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 20*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 88*sp[k1,p1]*sp[k2,k3]*sp[k3,p1
      ] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] - 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,
      p1]*sp[k2,p1]*sp[k3,p2] + 24*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 40
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 4*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m - 40*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,p1]*sp[k3,
      p1]*sp[k3,p2]*m + 160*sp[k1,p1]*sp[k3,p2]^2 - 68*sp[k1,p1]*sp[k3,
      p2]^2*m + 40*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 12*sp[k1,p1]*sp[k3,
      p2]*sp[p1,p2]*m + 16*sp[k1,p2]^2*sp[k2,p1] - 32*sp[k1,p2]^2*sp[k2
      ,p1]*m - 120*sp[k1,p2]^2*sp[k3,p1] + 44*sp[k1,p2]^2*sp[k3,p1]*m
       + 80*sp[k1,p2]^2*sp[p1,p2] - 32*sp[k1,p2]^2*sp[p1,p2]*m + 56*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m
       + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 36*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m - 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 24*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] + 4*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 56*sp[k1,p2]*sp[k3,p1]^2
       - 16*sp[k1,p2]*sp[k3,p1]^2*m - 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]
       + 36*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m + 72*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] - 28*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 80*sp[k1,p2]*sp[
      k3,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k3,p2]*sp[p1,p2]*m] + amp[15,
      12]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[
      sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*num[ - 96*sp[k1
      ,k2]^2*sp[k3,p1] + 80*sp[k1,k2]^2*sp[k3,p1]*m - 16*sp[k1,k2]^2*
      sp[k3,p1]*m^2 + 96*sp[k1,k2]^2*sp[p1,p2] - 32*sp[k1,k2]^2*sp[p1,
      p2]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,p1] + 48*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 - 32*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*
      m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m^2 - 96*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 32*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m
       - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 160*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1] + 64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 64*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 96
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m - 224*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1] - 80*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 192*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2] + 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 48*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 96*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       - 160*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 24*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 112
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2]*m^2 + 192*sp[k1,k3]*sp[p1,p2]^2 - 112*sp[k1,k3]*sp[p1,p2]^2*m
       + 16*sp[k1,k3]*sp[p1,p2]^2*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*
      sp[k1,p1]^2*sp[k2,k3]*m + 32*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]
      ^2*sp[k3,p2] + 16*sp[k1,p1]^2*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,
      p2] - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 32*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*
      sp[k1,p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 192*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
      *m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2] - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       + 448*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 224*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p1
      ]*sp[k3,p2]*sp[p1,p2] + 144*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m - 16*
      sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p2]^2*sp[k2,p1] + 
      48*sp[k1,p2]^2*sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 
      48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 320*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1] + 176*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 24*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 80
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,
      p2]*m^2] + amp[15,13]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[k2 - p2]]*den[sp[ - k3
       + p1]]*num[ - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k1,p1]*m + 320*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 208*
      sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1
      ]*m^2 - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]^2 - 64*sp[k1,k2]*sp[k1,p1]
      ^2*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p1]*m + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 48*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[
      k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] + 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 32*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[k1,k3]^2*sp[k2,p1] + 16*
      sp[k1,k3]^2*sp[k2,p1]*m + 128*sp[k1,k3]^2*sp[p1,p2] - 32*sp[k1,k3
      ]^2*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]
      *sp[k1,p1]*sp[k1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1
      ] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1] - 256*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 128*
      sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ]*m^2 - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]
      *sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2
      ] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] - 48*sp[
      k1,k3]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*
      m^2 - 32*sp[k1,k3]*sp[p1,p2]^2 + 16*sp[k1,k3]*sp[p1,p2]^2*m - 64*
      sp[k1,p1]^2*sp[k1,p2] + 32*sp[k1,p1]^2*sp[k1,p2]*m - 32*sp[k1,p1]
      ^2*sp[k2,k3] - 64*sp[k1,p1]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2
      ]*m + 64*sp[k1,p1]^2*sp[k3,p2] - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 128*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m
       + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 32*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m - 64*sp[k1,p1]*sp[k3,p2]^2 + 48*sp[k1,p1]*sp[k3,p2]^2*m - 8*
      sp[k1,p1]*sp[k3,p2]^2*m^2 + 32*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] - 16
      *sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,p2]^2*sp[k3,p1] - 16*
      sp[k1,p2]^2*sp[k3,p1]*m + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k3,p1]*sp[k3,p2] - 48*sp[k1,p2]
      *sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 + 32
      *sp[k1,p2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]
      *m] + amp[15,14]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[
       - k2 - k3]]*den[sp[k2 - p2]]*den[sp[p1 + p2]]*num[ - 128*sp[k1,
      k2]^2*sp[p1,p2] + 56*sp[k1,k2]^2*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k1
      ,k3]*sp[p1,p2] + 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 160*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*m + 96
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 40*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]
      *m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 64*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 24*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] + 48*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2] + 56*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1] - 24*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 192*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 56*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m - 48*sp[k1,k2]*sp[k3,p1]^2 + 16*sp[k1,k2]*sp[k3,p1]^2
      *m - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 32
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1,k3]*sp[k1,p1]
      *sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[
      k1,k3]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 128*sp[k1,k3]*sp[k2,p1]^2 + 56*sp[k1,k3]*sp[k2,p1]^2*m - 
      128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 56*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m + 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 40*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2
      ,p2]*sp[p1,p2]*m^2 + 16*sp[k1,k3]*sp[k3,p1]*sp[p1,p2] - 176*sp[k1
      ,k3]*sp[k3,p2]*sp[p1,p2] + 112*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m - 
      16*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 16*sp[k1,p1]^2*sp[k2,k3]
       - 16*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*
      m - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[
      k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p1] - 40*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 224*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p2] - 72*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 48*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*
      m + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 8*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       - 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m^2 + 48*sp[k1,p1]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2]*m + 144*sp[k1,p1]*sp[k3,p2]^2 - 96*sp[k1,p1]*sp[
      k3,p2]^2*m + 16*sp[k1,p1]*sp[k3,p2]^2*m^2 + 48*sp[k1,p2]^2*sp[k2,
      p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m - 48*sp[k1,p2]^2*sp[k3,p1] + 16*
      sp[k1,p2]^2*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] - 40*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m - 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 40*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1]*m - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2 - 48*sp[k1,p2]*sp[
      k3,p1]^2 + 16*sp[k1,p2]*sp[k3,p1]^2*m - 144*sp[k1,p2]*sp[k3,p1]*
      sp[k3,p2] + 96*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[
      k3,p1]*sp[k3,p2]*m^2] + amp[15,15]*color[1/4*Ca^2*Na*Tf]*den[sp[
      k1 + k3]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]
      ]*num[ - 48*sp[k1,k2]^2*sp[k3,p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m - 
      48*sp[k1,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,k3
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2] + 112*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 48*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
      *m - 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p2]*
      sp[p1,p2]*m - 144*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 96*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 - 48
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m + 48*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 40*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 48*sp[
      k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]^2*m + 48*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] - 40*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m - 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32
      *sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1] + 40*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 176*sp[k1,k3]*sp[k2,k3
      ]*sp[k2,p1] + 112*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*
      sp[k2,k3]*sp[k2,p1]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ] + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m^2 - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 40
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2
      ]*sp[p1,p2] - 56*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 112*sp[k1,k3]*
      sp[k3,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k3,p1]*sp[p1,p2]*m - 128*
      sp[k1,k3]*sp[p1,p2]^2 + 56*sp[k1,k3]*sp[p1,p2]^2*m - 16*sp[k1,p1]
      ^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2
      ] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 8*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 40*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 160*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*
      m + 144*sp[k1,p1]*sp[k2,k3]^2 - 96*sp[k1,p1]*sp[k2,k3]^2*m + 16*
      sp[k1,p1]*sp[k2,k3]^2*m^2 + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 
      8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 48*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*
      m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 224*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 72*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[
      k3,p1]*sp[k3,p2] + 16*sp[k1,p1]*sp[k3,p1]*sp[k3,p2]*m + 96*sp[k1,
      p1]*sp[k3,p2]*sp[p1,p2] - 40*sp[k1,p1]*sp[k3,p2]*sp[p1,p2]*m + 
      128*sp[k1,p2]^2*sp[k2,p1] - 56*sp[k1,p2]^2*sp[k2,p1]*m + 32*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 
      48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m - 192*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 56*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 56*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,p2]*sp[k3,p1]
      ^2 - 16*sp[k1,p2]*sp[k3,p1]^2*m + 64*sp[k1,p2]*sp[k3,p1]*sp[p1,p2
      ] - 24*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[15,16]*color[ - Ca*
      Cf*Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*
      den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 96*sp[k1,k2]^2*sp[k3,
      p1] + 16*sp[k1,k2]^2*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 48*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 192*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p1]*
      m - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 80*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
      *m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p1]*m + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 48*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m
       + 352*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 96*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k3]
      *sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] + 80*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]
      *m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k3]*
      sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m + 96*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 704*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 368*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 48*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k3,p2]*sp[p1,p2] + 80*sp[k1,k3]*
      sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k3,p2]*sp[p1,p2]*m^2 + 96*
      sp[k1,k3]*sp[p1,p2]^2 - 16*sp[k1,k3]*sp[p1,p2]^2*m - 352*sp[k1,p1
      ]^2*sp[k2,p2] + 96*sp[k1,p1]^2*sp[k2,p2]*m - 48*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 96*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 96*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*
      m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,k3]^2 - 80*sp[k1,p1]*sp[k2,k3]^
      2*m + 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 192*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2 + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 352*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 192*sp[k1,p1]*
      sp[k3,p2]^2 - 80*sp[k1,p1]*sp[k3,p2]^2*m + 8*sp[k1,p1]*sp[k3,p2]^
      2*m^2 - 96*sp[k1,p1]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,p1]*sp[k3,p2]
      *sp[p1,p2]*m - 96*sp[k1,p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,p1
      ]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 8*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 192*
      sp[k1,p2]*sp[k3,p1]*sp[k3,p2] + 80*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*
      m - 8*sp[k1,p2]*sp[k3,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k3,p1]*
      sp[p1,p2] + 16*sp[k1,p2]*sp[k3,p1]*sp[p1,p2]*m] + amp[16,1]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]*
      den[sp[k3 - p2]]*num[ - 40*sp[k1,k2]*sp[k3,p1] + 28*sp[k1,k2]*sp[
      k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]*m^2 + 8*sp[k1,k2]*sp[p1,p2] + 4*
      sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[p1,p2]*m^2 + 32*sp[k1,k3]*
      sp[k1,p1] - 16*sp[k1,k3]*sp[k1,p1]*m + 24*sp[k1,k3]*sp[k2,p1] - 
      20*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,k3]*sp[k2,p1]*m^2 - 16*sp[k1,
      p1]*sp[k1,p2] + 8*sp[k1,p1]*sp[k1,p2]*m + 8*sp[k1,p1]*sp[k2,k3]
       + 4*sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k2,k3]*m^2 - 40*sp[k1
      ,p1]*sp[k2,p2] + 28*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k2,p2]
      *m^2 + 24*sp[k1,p2]*sp[k2,p1] - 20*sp[k1,p2]*sp[k2,p1]*m + 4*sp[
      k1,p2]*sp[k2,p1]*m^2] + amp[16,1]*color[1/4*Ca^2*Na*Tf]*den[sp[
       - k1 + p1]]*den[sp[k1 + k2]]*den[sp[k3 - p2]]*num[8*sp[k1,k2]*
      sp[k3,p1] + 4*sp[k1,k2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k3,p1]*m^2
       - 40*sp[k1,k2]*sp[p1,p2] + 28*sp[k1,k2]*sp[p1,p2]*m - 4*sp[k1,k2
      ]*sp[p1,p2]*m^2 - 16*sp[k1,k3]*sp[k1,p1] + 8*sp[k1,k3]*sp[k1,p1]*
      m + 24*sp[k1,k3]*sp[k2,p1] - 20*sp[k1,k3]*sp[k2,p1]*m + 4*sp[k1,
      k3]*sp[k2,p1]*m^2 + 32*sp[k1,p1]*sp[k1,p2] - 16*sp[k1,p1]*sp[k1,
      p2]*m - 40*sp[k1,p1]*sp[k2,k3] + 28*sp[k1,p1]*sp[k2,k3]*m - 4*sp[
      k1,p1]*sp[k2,k3]*m^2 + 8*sp[k1,p1]*sp[k2,p2] + 4*sp[k1,p1]*sp[k2,
      p2]*m - 4*sp[k1,p1]*sp[k2,p2]*m^2 + 24*sp[k1,p2]*sp[k2,p1] - 20*
      sp[k1,p2]*sp[k2,p1]*m + 4*sp[k1,p2]*sp[k2,p1]*m^2] + amp[16,1]*
      color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]*den[
      sp[k3 - p2]]*num[48*sp[k1,k2]*sp[k3,p1] - 24*sp[k1,k2]*sp[k3,p1]*
      m - 48*sp[k1,k2]*sp[p1,p2] + 24*sp[k1,k2]*sp[p1,p2]*m - 48*sp[k1,
      k3]*sp[k1,p1] + 24*sp[k1,k3]*sp[k1,p1]*m + 48*sp[k1,p1]*sp[k1,p2]
       - 24*sp[k1,p1]*sp[k1,p2]*m - 48*sp[k1,p1]*sp[k2,k3] + 24*sp[k1,
      p1]*sp[k2,k3]*m + 48*sp[k1,p1]*sp[k2,p2] - 24*sp[k1,p1]*sp[k2,p2]
      *m] + amp[16,2]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*den[sp[
       - k3 + p1]]*den[sp[k3 - p2]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ] - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]
      *m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 128
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2]*m^2 + 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[16
      ,3]*color[ - Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*den[sp[ - k3 + p2]]*
      den[sp[k3 - p2]]*num[ - 192*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 128*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,p1
      ]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]
      *sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 352*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 272*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 
      48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1] - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,
      p2]*sp[k3,p1]*m^2 - 192*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1
      ,k2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2
      ] + amp[16,4]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k2]]^2*den[
      sp[k3 - p2]]*den[sp[p1 + p2]]*num[ - 128*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2] + 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] - 128*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*
      m^2 + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1] - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2] + 
      amp[16,5]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]*den[sp[k3 - p2]]*num[
      128*sp[k1,k2]^2*sp[k3,p1] - 32*sp[k1,k2]^2*sp[k3,p1]*m - 64*sp[k1
      ,k2]^2*sp[p1,p2] + 16*sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 256*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,p1] + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m^2 + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 64*sp[k1,k2]*
      sp[k1,p1]*sp[k1,p2]*m - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 32*
      sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p2
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 320*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 208*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 
      32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 96*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k2,
      k3]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2
      ]*sp[k3,p1]^2*m + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^
      2*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p1]^2 + 32*sp[k1,k3]*sp[k1,p1]
      ^2*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3]*m - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 32*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p1]*m + 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1
      ] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 128*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,
      k3]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 256*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2] + 160*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 24*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p1]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 
      48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 128*sp[k1,p1]^2*sp[k1,p2] - 
      64*sp[k1,p1]^2*sp[k1,p2]*m + 64*sp[k1,p1]^2*sp[k2,k3] - 32*sp[k1,
      p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[k3,p2] - 32*sp[k1,p1]^2*sp[k3
      ,p2]*m - 160*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 48*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m + 160*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*
      sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]^2 - 48*
      sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[k1,p1]*sp[k2,k3]^2*m^2 + 64*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,k3]
      *sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 192*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 112*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
      *m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 96*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[16,7]*
      color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[k1 + k3]]*den[sp[k3 - p2]]*den[sp[p1 + p2]]*num[ - 96*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p1] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p2]*sp[
      p1,p2]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 192*sp[k1,k2]*
      sp[k3,p1]^2 + 112*sp[k1,k2]*sp[k3,p1]^2*m - 16*sp[k1,k2]*sp[k3,p1
      ]^2*m^2 - 192*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 112*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 32*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m^2 + 256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p2]
      *sp[p1,p2]*m + 24*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 128*sp[k1,
      k3]^2*sp[p1,p2] + 48*sp[k1,k3]^2*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 192*sp[k1,k3]*sp[k1,p1]*sp[k3
      ,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k1,
      p1]*sp[k3,p2] - 48*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k3]
      *sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 16*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m - 160*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k3]*
      sp[k1,p2]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 48*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p1
      ] + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p1]*m^2 - 320*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 176*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 
      64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*
      sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m - 32
      *sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m - 32*sp[k1,p1
      ]^2*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
       + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 96*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 256*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1] - 144*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
      *m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 + 448*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2] - 224*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 24*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 80
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 96*sp[k1,p2]^2*sp[k2,p1] - 80
      *sp[k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 96*sp[
      k1,p2]^2*sp[k3,p1] - 32*sp[k1,p2]^2*sp[k3,p1]*m - 192*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 224*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ] + 112*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 80*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m^2 + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m] + amp[16,8]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[k1 + k2]]*den[sp[ - k2 - k3]]*den[sp[k3 - p2]]*num[32
      *sp[k1,k2]^2*sp[k3,p1] - 8*sp[k1,k2]^2*sp[k3,p1]*m + 80*sp[k1,k2]
      ^2*sp[p1,p2] - 32*sp[k1,k2]^2*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,p1] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*sp[k1,k2]*
      sp[k1,k3]*sp[k2,p1] - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 24*sp[
      k1,k2]*sp[k1,k3]*sp[k3,p1] - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 
      48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 20*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 40*sp[k1,k2]*sp[k1,p1]
      *sp[k1,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 56*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]
       + 24*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 40*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 88*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] - 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 
      160*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p2]
      *sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,k2]*
      sp[k2,k3]*sp[k2,p1]*m + 112*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 44*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ] - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*
      sp[k2,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 56*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 56
      *sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m + 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 56*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2] + 20*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 72*sp[k1,k2]*sp[
      k3,p1]^2 - 28*sp[k1,k2]*sp[k3,p1]^2*m - 40*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] + 12*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2] + 20*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 120*sp[k1
      ,k2]*sp[k3,p2]*sp[p1,p2] + 44*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 
      80*sp[k1,k3]^2*sp[k1,p1] - 40*sp[k1,k3]^2*sp[k1,p1]*m + 120*sp[k1
      ,k3]^2*sp[k2,p1] - 44*sp[k1,k3]^2*sp[k2,p1]*m + 80*sp[k1,k3]^2*
      sp[k3,p1] - 32*sp[k1,k3]^2*sp[k3,p1]*m + 16*sp[k1,k3]^2*sp[p1,p2]
       - 32*sp[k1,k3]^2*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]
       + 32*sp[k1,k3]*sp[k1,p1]*sp[k1,p2]*m - 104*sp[k1,k3]*sp[k1,p1]*
      sp[k2,k3] + 36*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 136*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2] - 20*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 
      112*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 40*sp[k1,k3]*sp[k1,p1]*sp[k3,
      p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 8*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p2]*m + 104*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 48*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2]*m - 48*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 4*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]
       - 32*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 104*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k2,k3]*sp[k2,p1] - 36*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m + 80*sp[k1,
      k3]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,p1]*m + 16
      *sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m + 56*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m - 112*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 36*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*
      m - 72*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 28*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p1]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 4*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 56*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,k3]
      *sp[k2,p1]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 56*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 40*sp[k1,p1]^2*sp[k2,k3]
       - 16*sp[k1,p1]^2*sp[k2,k3]*m - 104*sp[k1,p1]^2*sp[k2,p2] + 32*
      sp[k1,p1]^2*sp[k2,p2]*m - 40*sp[k1,p1]^2*sp[k3,p2] + 16*sp[k1,p1]
      ^2*sp[k3,p2]*m - 136*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 40*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m + 72*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 24*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1] + 16*sp[k1,p1]*sp[k1,p2]*sp[k3,p1]*m + 88*sp[k1,p1]*sp[
      k1,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m - 160*sp[k1
      ,p1]*sp[k2,k3]^2 + 68*sp[k1,p1]*sp[k2,k3]^2*m - 40*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p1] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 40*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p1] + 12*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*
      m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 4*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2]*m + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 24*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m - 88*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]
      *sp[k2,p1]*sp[k2,p2]*m - 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 72*sp[k1,p1]*sp[k2,p2]^2 - 28*
      sp[k1,p1]*sp[k2,p2]^2*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 12*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] - 20*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 24*sp[k1,p2]^2*sp[k3,p1]
       + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 36*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]
      *sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*
      sp[k2,p1]^2*m - 40*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 12*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1]*m + 40*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 
      12*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p2]*sp[k3
      ,p1]] + amp[16,9]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[
      sp[k1 + k2]]*den[sp[ - k2 + p2]]*den[sp[k3 - p2]]*num[80*sp[k1,k2
      ]^2*sp[k3,p1] - 32*sp[k1,k2]^2*sp[k3,p1]*m + 32*sp[k1,k2]^2*sp[p1
      ,p2] - 8*sp[k1,k2]^2*sp[p1,p2]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,
      p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k2,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m - 64*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 160*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*
      m + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k1,p2]*m - 80*sp[k1,k2]*sp[k1,p1]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,
      p1]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k2]
      *sp[k1,p1]*sp[k2,p2]*m + 88*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 24*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 40*sp[k1,k2]*sp[k1,p1]*sp[k3,p2
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 56*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] + 24*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[
      k1,p2]*sp[k2,p1] - 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 48*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] + 20*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 24
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*
      m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,k2]*sp[k2,k3]*sp[
      k2,p1]*m + 56*sp[k1,k2]*sp[k2,k3]*sp[k3,p1] - 20*sp[k1,k2]*sp[k2,
      k3]*sp[k3,p1]*m - 12*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,
      k2]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m - 56
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p1]
      *m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 56*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 12*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1]*m - 112*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 
      44*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 120*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 44*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 48*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2] - 20*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 40*sp[k1,k2]
      *sp[k3,p2]*sp[p1,p2] + 12*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 72*
      sp[k1,k2]*sp[p1,p2]^2 + 28*sp[k1,k2]*sp[p1,p2]^2*m - 24*sp[k1,k3]
      ^2*sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k1,p2] - 32*sp[k1,k3]*
      sp[k1,p1]*sp[k1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,k3] + 16*sp[
      k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 72*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]
       - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 136*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 40*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 88*sp[k1,k3]*sp[
      k1,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 24*sp[k1,
      k3]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 48
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 4*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m + 104*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1]*m + 48*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[
      k1,p2]*sp[p1,p2]*m + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1] - 12*sp[k1,
      k3]*sp[k2,k3]*sp[k2,p1]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 56
      *sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m - 96*sp[k1,k3
      ]*sp[k2,p1]*sp[k2,p2] + 36*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 40*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 12*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*
      m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 4*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2]*m + 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2
      ]*sp[k3,p1]*m + 24*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m - 104*sp[k1,p1]^2*sp[k2,k3] + 32*sp[k1,p1]^
      2*sp[k2,k3]*m + 40*sp[k1,p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k2,
      p2]*m + 40*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]^2*sp[k3,p2]*m - 
      80*sp[k1,p1]*sp[k1,p2]^2 + 40*sp[k1,p1]*sp[k1,p2]^2*m - 136*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] + 20*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 
      24*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 36*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m - 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 8*sp[
      k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 112*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]
       - 40*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 72*sp[k1,p1]*sp[k2,k3]^2
       + 28*sp[k1,p1]*sp[k2,k3]^2*m - 88*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]
       + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 32*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 48*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2] - 20*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] - 12*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 40
      *sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m + 40*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m + 160*sp[k1,p1]*sp[k2,p2]^2 - 68*sp[k1,p1]*sp[k2,p2]^2*m
       - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 24*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 4*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m + 40*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 12*sp[k1,p1]
      *sp[k2,p2]*sp[p1,p2]*m - 120*sp[k1,p2]^2*sp[k2,p1] + 44*sp[k1,p2]
      ^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k3,p1] - 32*sp[k1,p2]^2*sp[k3,
      p1]*m + 80*sp[k1,p2]^2*sp[p1,p2] - 32*sp[k1,p2]^2*sp[p1,p2]*m + 
      112*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 36*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m + 56*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m + 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m + 56*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*
      sp[k2,p1]^2*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 36*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m - 56*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 24*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
       + 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 72*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2] - 28*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 80*sp[k1,p2]
      *sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m] + amp[
      16,10]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k2]]
      *den[sp[ - k3 + p2]]*den[sp[k3 - p2]]*num[ - 96*sp[k1,k2]*sp[k1,
      k3]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 4*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1]*m^2 + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 4*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2]*m + 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 4*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1]*m - 4*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 96*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2] + 40*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m
       - 4*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 24*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 12*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 176
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m + 12*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 4*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 24*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 4*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]^2 - 40*sp[k1,k2]
      *sp[k3,p1]^2*m + 4*sp[k1,k2]*sp[k3,p1]^2*m^2 + 104*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] - 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 104*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2] + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[p1,p2
      ]^2 - 40*sp[k1,k2]*sp[p1,p2]^2*m + 4*sp[k1,k2]*sp[p1,p2]^2*m^2 - 
      24*sp[k1,k3]^2*sp[k2,p1]*m + 4*sp[k1,k3]^2*sp[k2,p1]*m^2 - 24*sp[
      k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m + 24*sp[k1,k3]*
      sp[k1,p1]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m^2 - 12*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 4*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
      *m^2 - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k1,p1]*
      sp[k3,p1]*m - 104*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] + 48*sp[k1,k3]*
      sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 16*sp[
      k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 24*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 24*sp[k1,k3]*sp[k1,p2]*
      sp[k3,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m - 24*sp[k1,k3]*sp[
      k1,p2]*sp[p1,p2] + 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 96*sp[k1,
      k3]*sp[k2,k3]*sp[k2,p1] + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 4*
      sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m^2 - 24*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2] + 4*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 40*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p1]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m^2 + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 4*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m - 4*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 24*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 176*
      sp[k1,p1]^2*sp[k3,p2] + 48*sp[k1,p1]^2*sp[k3,p2]*m - 12*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 24
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 4*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ]*m^2 + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,p1]*sp[k1,p2]
      *sp[k3,p1]*m + 104*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 48*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 16*sp[
      k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,k3]^2 - 40*sp[
      k1,p1]*sp[k2,k3]^2*m + 4*sp[k1,p1]*sp[k2,k3]^2*m^2 - 96*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]
      *m + 4*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m^2 - 104*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 12*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 176
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m + 96*sp[k1,p1]*sp[k2,p2]^2 - 40*sp[k1,p1]*sp[k2,p2]^2*m + 4*
      sp[k1,p1]*sp[k2,p2]^2*m^2 + 12*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 
      4*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 104*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 24*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2]*m + 4*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 24*sp[k1,
      p2]^2*sp[k2,p1]*m + 4*sp[k1,p2]^2*sp[k2,p1]*m^2 + 24*sp[k1,p2]^2*
      sp[k3,p1] - 16*sp[k1,p2]^2*sp[k3,p1]*m + 48*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] + 4*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 4*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m^2 - 24*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 40
      *sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 4*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m - 4*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 96*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] + 40*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 4*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 24*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
       - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[16,12]*color[1/2*Ca*
      Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[
      sp[ - k2 + p1]]*den[sp[k3 - p2]]*num[ - 64*sp[k1,k2]^2*sp[k3,p1]
       + 16*sp[k1,k2]^2*sp[k3,p1]*m + 128*sp[k1,k2]^2*sp[p1,p2] - 32*
      sp[k1,k2]^2*sp[p1,p2]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,p1] + 64*
      sp[k1,k2]*sp[k1,k3]*sp[k1,p1]*m + 320*sp[k1,k2]*sp[k1,k3]*sp[k2,
      p1] - 208*sp[k1,k2]*sp[k1,k3]*sp[k2,p1]*m + 32*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,p1]*m^2 - 96*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k2,k3
      ] - 16*sp[k1,k2]*sp[k1,p1]*sp[k2,k3]*m - 128*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 256*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
      *m - 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 64*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       + 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 48*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*
      m^2 - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m - 32*sp[k1,k2]*sp[p1,p2]^2 + 16*sp[k1,k2]*sp[p1,p2]^2
      *m + 128*sp[k1,k3]*sp[k1,p1]^2 - 64*sp[k1,k3]*sp[k1,p1]^2*m + 160
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]
      *m + 160*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[
      k1,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m - 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 
      112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2]*m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m - 64*sp[k1,p1]^2*sp[k1,p2] + 32*sp[k1,p1]^2*
      sp[k1,p2]*m - 32*sp[k1,p1]^2*sp[k2,k3] + 64*sp[k1,p1]^2*sp[k2,p2]
       - 64*sp[k1,p1]^2*sp[k3,p2] + 32*sp[k1,p1]^2*sp[k3,p2]*m - 192*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1
      ,p1]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] - 
      32*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[
      k1,p1]*sp[k2,p2]^2 + 48*sp[k1,p1]*sp[k2,p2]^2*m - 8*sp[k1,p1]*sp[
      k2,p2]^2*m^2 - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[
      k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]^2*sp[k2,p1]*m + 256*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] - 160*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 24*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*
      sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 48*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 16*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m] + amp[16,13]*color[1/2*Ca*Cf*Na*Tf
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - p2]]*den[sp[ - k3
       + p1]]*den[sp[k3 - p2]]*num[ - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]
       + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k1,k3]*
      sp[k3,p1]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] + 48*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*
      sp[p1,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[
      k1,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       - 160*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 24*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 192*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 112
      *sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2]*m^2 + 192*sp[k1,k2]*sp[p1,p2]^2 - 112*sp[k1,k2]*sp[p1,p2]^2*m
       + 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 96*sp[k1,k3]^2*sp[k2,p1] + 80*
      sp[k1,k3]^2*sp[k2,p1]*m - 16*sp[k1,k3]^2*sp[k2,p1]*m^2 + 96*sp[k1
      ,k3]^2*sp[p1,p2] - 32*sp[k1,k3]^2*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k1,p1]*sp[k2,k3] - 80*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*sp[k1,
      k3]*sp[k1,p1]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p1] - 
      16*sp[k1,k3]*sp[k1,p1]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 96*sp[k1,k3]*sp[k1,p1
      ]*sp[k3,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k3]*
      sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 160*sp[k1,k3]*sp[k1,p2]*sp[k3,p1
      ] + 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k1,p2]*
      sp[p1,p2] - 16*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 224*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 80
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m^2 - 32*sp[k1,p1]^2*sp[k2,k3] + 16*sp[k1,p1]^2*sp[k2,k3]*m - 
      32*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]^2*sp[k2,p2]*m + 32*sp[k1,
      p1]^2*sp[k3,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]
      *m + 32*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k1,p2]*
      sp[k3,p1]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 48*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 64*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 96*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 80*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 448*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] - 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 24*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 144
      *sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,p2]^2*sp[k3,p1] + 48*sp[k1,p2]^2*sp[k3,p1]*m
       + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 256*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 - 320*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 176*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m - 24*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
      *m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[16,14]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 - k3]]*
      den[sp[k3 - p2]]*den[sp[p1 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2] - 40*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 48*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m - 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 48*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*
      m - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2] - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 112*sp[k1,k2]*sp[k2,p1]*sp[k3,p1] + 48*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p1]*m - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2
      ] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k2]*sp[k2
      ,p2]*sp[k3,p1]*m + 176*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 112*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2
       + 128*sp[k1,k2]*sp[k3,p1]^2 - 56*sp[k1,k2]*sp[k3,p1]^2*m + 128*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 56*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 40*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 8*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1
      ,k3]^2*sp[p1,p2] - 56*sp[k1,k3]^2*sp[p1,p2]*m + 16*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 8*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2]*m - 160*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 64*
      sp[k1,k3]*sp[k1,p1]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k1,p1]*sp[k3,p2
      ] + 40*sp[k1,k3]*sp[k1,p1]*sp[k3,p2]*m + 48*sp[k1,k3]*sp[k1,p1]*
      sp[p1,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] + 24*sp[k1,
      k3]*sp[k1,p2]*sp[k3,p1]*m + 112*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] - 
      48*sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2] - 56*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k2,
      p1]^2 - 16*sp[k1,k3]*sp[k2,p1]^2*m + 48*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p1] + 24*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       - 192*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 56*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m - 16*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,p1]^2*sp[k2
      ,p2] + 16*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k3,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k3,p2]*m - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p1]*m - 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m
       + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p1] + 40*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m - 224*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] + 72*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 48*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 144*sp[k1,p1]*sp[k2
      ,p2]^2 + 96*sp[k1,p1]*sp[k2,p2]^2*m - 16*sp[k1,p1]*sp[k2,p2]^2*
      m^2 - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m + 24*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 + 48*sp[k1,p2]^2*sp[k2,p1] - 16*sp[k1,p2]
      ^2*sp[k2,p1]*m - 48*sp[k1,p2]^2*sp[k3,p1] + 16*sp[k1,p2]^2*sp[k3,
      p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 40*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 128*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 80*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m + 48*sp[k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m + 144*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*
      m + 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 8*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 48*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m]
       + amp[16,15]*color[ - Ca*Cf*Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*den[sp[k3 - p2]]*
      num[96*sp[k1,k2]*sp[k1,k3]*sp[k3,p1] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k3,p1]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2]*m + 352*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 96*sp[k1,k2
      ]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 16*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 96*sp[k1,k2]*sp[k1,p2]*sp[p1,p2
      ] - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 192*sp[k1,k2]*sp[k2,k3]*
      sp[k3,p1] + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[
      k2,k3]*sp[k3,p1]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 8*sp[k1
      ,k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2
       - 704*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 368*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 96*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k2]*sp[k2,p2]*sp[p1,p2
      ] + 80*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k3,p1]^2 - 16*sp[k1,k2]*sp[k3,p1]
      ^2*m - 96*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 96*sp[k1,k2]*sp[p1,p2]^2 - 16*sp[k1,k2]*sp[p1,p2]^2
      *m - 96*sp[k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m + 96*
      sp[k1,k3]*sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*
      m - 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m - 192*sp[k1,k3]*sp[k1,p1]*sp[k3,p1] + 32*sp[k1,k3]*sp[k1
      ,p1]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k3
      ]*sp[k1,p1]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 192*sp[k1,k3]*sp[k2,k3]*sp[k2,
      p1] + 80*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k2,k3]*
      sp[k2,p1]*m^2 + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 8*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p1]*
      m + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 352*sp[k1,p1]^2*sp[k3,p2] + 96*sp[k1,p1]^2*sp[k3,p2]*m
       - 48*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 16*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k3,p1]*m - 192*sp[k1,p1]*sp[k1,p2]*sp[p1,p2] + 32*
      sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,k3]^2 - 80*
      sp[k1,p1]*sp[k2,k3]^2*m + 8*sp[k1,p1]*sp[k2,k3]^2*m^2 - 192*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 
      16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p1] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p1]*m + 48*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 352*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2] + 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 192*
      sp[k1,p1]*sp[k2,p2]^2 - 80*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*
      sp[k2,p2]^2*m^2 + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 16*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,p2]^2*sp[k2,p1] + 16*
      sp[k1,p2]^2*sp[k2,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 8*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
      *m^2 - 192*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 80*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 48*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 96*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*
      m] + amp[16,16]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - 
      k2 + p2]]*den[sp[ - k3 + p1]]*den[sp[k3 - p2]]*num[16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1
      ,k2]*sp[k1,k3]*sp[p1,p2]*m + 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p1] - 
      16*sp[k1,k2]*sp[k1,p1]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3
      ,p2] - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 48*sp[k1,k2]*sp[k1,p1
      ]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] + 40*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 176*
      sp[k1,k2]*sp[k2,k3]*sp[k3,p1] + 112*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]
      *m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 
      48*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 40*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*
      m + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 56*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m - 128*sp[k1,k2]*sp[p1,p2]^2 + 56*sp[k1,k2]*sp[p1,p2]^
      2*m - 48*sp[k1,k3]^2*sp[k2,p1] + 16*sp[k1,k3]^2*sp[k2,p1]*m - 48*
      sp[k1,k3]^2*sp[p1,p2] + 16*sp[k1,k3]^2*sp[p1,p2]*m + 48*sp[k1,k3]
      *sp[k1,p1]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,k3]*m + 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
       + 48*sp[k1,k3]*sp[k1,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k1,p1]*sp[
      k3,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[p1,p2] - 8*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m + 112*sp[k1,k3]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k3
      ]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[p1,p2] + 24*
      sp[k1,k3]*sp[k1,p2]*sp[p1,p2]*m - 144*sp[k1,k3]*sp[k2,k3]*sp[k2,
      p1] + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,k3]
      *sp[k2,p1]*m^2 - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m + 48*sp[k1,k3]*sp[k2,p1]^2 - 16*sp[k1,k3]*
      sp[k2,p1]^2*m + 48*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 40*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 48*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 40*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*
      m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1
      ,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]^2*sp[k2,k3] - 16*sp[k1,
      p1]^2*sp[k2,p2] - 16*sp[k1,p1]^2*sp[k3,p2] - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3] + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] - 48*sp[k1,p1]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1
      ,p1]*sp[k1,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k3,p2] + 
      40*sp[k1,p1]*sp[k1,p2]*sp[k3,p2]*m + 160*sp[k1,p1]*sp[k1,p2]*sp[
      p1,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[p1,p2]*m + 144*sp[k1,p1]*sp[k2
      ,k3]^2 - 96*sp[k1,p1]*sp[k2,k3]^2*m + 16*sp[k1,p1]*sp[k2,k3]^2*
      m^2 - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p1]*m + 24*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m^2 + 24*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2] - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 48*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p1]*m - 224*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 72*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2
      ] - 40*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p2]^2*sp[k3,p1
      ] - 56*sp[k1,p2]^2*sp[k3,p1]*m - 48*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
       + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 192*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] + 56*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 48*sp[
      k1,p2]*sp[k2,p1]^2 - 16*sp[k1,p2]*sp[k2,p1]^2*m - 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 128*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m + 64*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 24*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 56*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1]*m])
