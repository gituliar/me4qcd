(amp[1,1]*color[ - 2/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*
      den[sp[k3 + k4]]*den[sp[k3 - q]]*num[256*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 128*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 
      32*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 128
      *sp[k1,k3]^2*sp[k2,k4] - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 64*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k4] + 128
      *sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]
      *sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m] + amp[1,2]*color[ - 2/9*Na*Tf^2]*den[
      sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*den[sp[ - k4 + q
      ]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3
      ]*sp[k4,q]*m - 256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 
      32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k4] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q
      ]*m + 128*sp[k1,k4]^2*sp[k2,k3] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ] + 32*sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 
      64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4
      ] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[
      1,3]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]^2*den[sp[ - k3 - k4]]*
      den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]*sp[k3,k4] + 96*sp[k1,k2]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]
       - 32*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,
      k4]*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 64*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 192*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2] + amp[1,4]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]*den[sp[ - k2
       + q]]*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[ - 256*sp[k1,k2]^
      2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 256*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 256
      *sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1
      ,k2]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 64*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1
      ,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,k3
      ]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*
      sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,
      q]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 512*sp[k1,q]*sp[k2,q]*sp[k3,k4]
       - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4]*m^2] + amp[2,1]*color[ - 2/9*Na*Tf^2]*den[sp[ - k1 - k2]]*
      den[sp[ - k2 + q]]*den[sp[k3 + k4]]*den[sp[k3 - q]]*num[ - 256*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*
      m + 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 32*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 64*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,
      k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 
      32*sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3]^2 - 128*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[
      k1,k4]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4]
       - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,
      q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[2,2]*
      color[ - 2/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[ - k2 + q]]*den[
      sp[k3 + k4]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[k4,
      q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 256*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 128*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 
      32*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]
      *sp[k3,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 32*
      sp[k1,k3]*sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[
      k1,k4]*sp[k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 64*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4
      ]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]
      *sp[k2,q]*sp[k3,k4]*m] + amp[2,3]*color[4/9*Na*Tf^2]*den[sp[k1 - 
      q]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[
       - 256*sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] + 256*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 256*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4]*m - 448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k3,q]
      *sp[k4,q] - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,k3]
      *sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k4]*
      sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,q]*sp[
      k2,k3]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]
      *sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 512*sp[
      k1,q]*sp[k2,q]*sp[k3,k4] - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[2,4]*color[4/9*Na*Tf^2]*
      den[sp[ - k2 + q]]^2*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[ - 
      128*sp[k1,k2]*sp[k3,k4] + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]
      *sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*
      m - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q]*m + 64*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m - 128*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 
      256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[3,1]*color[1/9*Na*
      Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k3 - q]]^2*num[
       - 128*sp[k1,k2]*sp[k3,k4] + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,
      k2]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 192*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64
      *sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k4]*
      sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,k4]
      *sp[k3,q] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m] + amp[3,2]*color[1/
      9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k3 - q]]*
      den[sp[ - k4 + q]]*num[ - 448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]
      *sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*sp[k3,
      k4]^2 + 64*sp[k1,k2]*sp[k3,k4]^2*m + 256*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 512*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 256*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 32*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m^2 + 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 
      128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 128*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 128
      *sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       + 128*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m + 128*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*sp[k3
      ,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[
      3,3]*color[ - 2/9*Na*Tf^2]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[
      sp[ - k3 - k4]]*den[sp[k3 - q]]*num[256*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 128*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 
      32*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 128
      *sp[k1,k3]^2*sp[k2,k4] - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 64*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k4] + 128
      *sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]
      *sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3,4]*color[ - 2/9*Na*Tf^2]*den[
      sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 - q
      ]]*num[ - 256*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4] - 
      64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3]^2
       - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,
      q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m]
       + amp[4,1]*color[1/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 + k2
      ]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[ - 448*sp[k1,k2]*sp[k3,
      k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 - 
      256*sp[k1,k2]*sp[k3,k4]^2 + 64*sp[k1,k2]*sp[k3,k4]^2*m + 256*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ]*m + 512*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 256*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 128*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2
      ,k4]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4] - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[
      k2,k3]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
       - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,
      q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m] + amp[4,2]*color[1/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k2]]*den[sp[ - k4 + q]]^2*num[ - 128*sp[k1,k2]*sp[k3,k4]
       + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 256*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 192*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 
      32*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k3] - 32*sp[k1
      ,k4]*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m] + amp[4,3]*color[ - 2/9*Na*Tf^2]*den[sp[k1
       + k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[sp[ - k4 + q]]*
      num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m - 256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*sp[
      k1,k2]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 32*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]
       - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 
      64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       + 128*sp[k1,k4]^2*sp[k2,k3] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 32*sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 64
      *sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[
      4,4]*color[ - 2/9*Na*Tf^2]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*
      den[sp[ - k3 - k4]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 256*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 128*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128
      *sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 32*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 
      32*sp[k1,k3]*sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*
      sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 64*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 64*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2
      ,k4]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m])
