(amp[1,1]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*
      num[ - 16*sp[k1,k2] + 24*sp[k1,k2]*m - 8*sp[k1,k2]*m^2] + amp[1,1
      ]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*
      num[ - 16*sp[k1,k2] + 24*sp[k1,k2]*m - 8*sp[k1,k2]*m^2] + amp[1,1
      ]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*num[
      32*sp[k1,k2] - 48*sp[k1,k2]*m + 16*sp[k1,k2]*m^2] + amp[1,1]*
      color[Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*num[32*sp[
      k1,k2] - 48*sp[k1,k2]*m + 16*sp[k1,k2]*m^2] + amp[1,2]*color[ - 
      Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[ - k3 - 
      k4]]*num[24*sp[k1,k2]*sp[k1,k3] - 12*sp[k1,k2]*sp[k1,k3]*m + 24*
      sp[k1,k2]*sp[k1,k4] - 12*sp[k1,k2]*sp[k1,k4]*m + 24*sp[k1,k2]*sp[
      k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k2,k4] - 12*
      sp[k1,k2]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k3,k4] + 48*sp[k1,k2]*sp[
      k3,k4]*m - 12*sp[k1,k2]*sp[k3,q] + 12*sp[k1,k2]*sp[k3,q]*m - 12*
      sp[k1,k2]*sp[k4,q] + 12*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2
      ,k3] - 24*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k2,k4] - 24*sp[
      k1,k3]*sp[k2,k4]*m + 12*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q
      ]*m + 48*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m + 48*sp[
      k1,k4]*sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k4]*m + 12*sp[k1,k4]*sp[k2,
      q] - 12*sp[k1,k4]*sp[k2,q]*m + 12*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q
      ]*sp[k2,k3]*m + 12*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m]
       + amp[1,2]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[
      k1 + k2]]*den[sp[ - k3 - k4]]*num[ - 8*sp[k1,k2]*sp[k1,k3] + 12*
      sp[k1,k2]*sp[k1,k3]*m - 4*sp[k1,k2]*sp[k1,k3]*m^2 + 32*sp[k1,k2]*
      sp[k1,k4] - 24*sp[k1,k2]*sp[k1,k4]*m + 4*sp[k1,k2]*sp[k1,k4]*m^2
       - 8*sp[k1,k2]*sp[k2,k3] + 12*sp[k1,k2]*sp[k2,k3]*m - 4*sp[k1,k2]
      *sp[k2,k3]*m^2 + 32*sp[k1,k2]*sp[k2,k4] - 24*sp[k1,k2]*sp[k2,k4]*
      m + 4*sp[k1,k2]*sp[k2,k4]*m^2 - 48*sp[k1,k2]*sp[k3,k4] + 24*sp[k1
      ,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,q] + 28*sp[k1,k2]*sp[k3,q]*
      m - 4*sp[k1,k2]*sp[k3,q]*m^2 + 20*sp[k1,k2]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k4,q]*m^2 + 24*sp[k1,k3]*sp[k2,k3
      ] - 16*sp[k1,k3]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[k2,k4] - 12*sp[k1,
      k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m
       + 24*sp[k1,k4]*sp[k2,k3] - 12*sp[k1,k4]*sp[k2,k3]*m + 24*sp[k1,
      k4]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k4]*m - 4*sp[k1,k4]*sp[k2,q] + 
      16*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,q]*sp[
      k2,k4]] + amp[1,2]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k2]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]*sp[k1,k3] + 
      24*sp[k1,k2]*sp[k1,k3]*m - 4*sp[k1,k2]*sp[k1,k3]*m^2 + 8*sp[k1,k2
      ]*sp[k1,k4] - 12*sp[k1,k2]*sp[k1,k4]*m + 4*sp[k1,k2]*sp[k1,k4]*
      m^2 - 32*sp[k1,k2]*sp[k2,k3] + 24*sp[k1,k2]*sp[k2,k3]*m - 4*sp[k1
      ,k2]*sp[k2,k3]*m^2 + 8*sp[k1,k2]*sp[k2,k4] - 12*sp[k1,k2]*sp[k2,
      k4]*m + 4*sp[k1,k2]*sp[k2,k4]*m^2 + 48*sp[k1,k2]*sp[k3,k4] - 24*
      sp[k1,k2]*sp[k3,k4]*m - 20*sp[k1,k2]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k3,q]*m - 4*sp[k1,k2]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k4,q] - 28*
      sp[k1,k2]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*
      sp[k2,k3] + 8*sp[k1,k3]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[k2,k4] + 12
      *sp[k1,k3]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k4]*sp[
      k2,k3] + 12*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,k4]*sp[k2,k4] + 16*
      sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,q] + 12*sp[k1,k4]*sp[
      k2,q]*m + 4*sp[k1,q]*sp[k2,k3] - 16*sp[k1,q]*sp[k2,k4] + 12*sp[k1
      ,q]*sp[k2,k4]*m] + amp[1,3]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1
       - k2]]*den[sp[k1 + k2]]*den[sp[ - k3 + q]]*num[ - 20*sp[k1,k2]
       + 12*sp[k1,k2]*m + 32*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,k2]*sp[k1,
      k3]*m + 4*sp[k1,k2]*sp[k1,k3]*m^2 + 8*sp[k1,k2]*sp[k1,q] - 12*sp[
      k1,k2]*sp[k1,q]*m + 4*sp[k1,k2]*sp[k1,q]*m^2 + 32*sp[k1,k2]*sp[k2
      ,k3] - 24*sp[k1,k2]*sp[k2,k3]*m + 4*sp[k1,k2]*sp[k2,k3]*m^2 + 8*
      sp[k1,k2]*sp[k2,q] - 12*sp[k1,k2]*sp[k2,q]*m + 4*sp[k1,k2]*sp[k2,
      q]*m^2 - 20*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 4*
      sp[k1,k2]*sp[k3,k4]*m^2 + 48*sp[k1,k2]*sp[k3,q] - 24*sp[k1,k2]*
      sp[k3,q]*m - 32*sp[k1,k2]*sp[k4,q] + 28*sp[k1,k2]*sp[k4,q]*m - 4*
      sp[k1,k2]*sp[k4,q]*m^2 + 24*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,k3]*sp[
      k2,k3]*m + 4*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,q] + 12*sp[
      k1,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,q]
       - 12*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,q]*sp[k2,k3] + 12*sp[k1,q]*
      sp[k2,k3]*m + 16*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m + 
      24*sp[k1,q]*sp[k2,q] - 16*sp[k1,q]*sp[k2,q]*m] + amp[1,3]*color[1/
      2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[ - k3
       + q]]*num[28*sp[k1,k2] - 12*sp[k1,k2]*m + 8*sp[k1,k2]*sp[k1,k3]
       - 12*sp[k1,k2]*sp[k1,k3]*m + 4*sp[k1,k2]*sp[k1,k3]*m^2 + 32*sp[
      k1,k2]*sp[k1,q] - 24*sp[k1,k2]*sp[k1,q]*m + 4*sp[k1,k2]*sp[k1,q]*
      m^2 + 8*sp[k1,k2]*sp[k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m + 4*sp[k1,
      k2]*sp[k2,k3]*m^2 + 32*sp[k1,k2]*sp[k2,q] - 24*sp[k1,k2]*sp[k2,q]
      *m + 4*sp[k1,k2]*sp[k2,q]*m^2 - 32*sp[k1,k2]*sp[k3,k4] + 28*sp[k1
      ,k2]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k3,k4]*m^2 - 48*sp[k1,k2]*sp[k3
      ,q] + 24*sp[k1,k2]*sp[k3,q]*m - 20*sp[k1,k2]*sp[k4,q] + 16*sp[k1,
      k2]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,k3
      ] + 16*sp[k1,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k2,k4] - 12*sp[k1,
      k3]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m
       + 16*sp[k1,k4]*sp[k2,k3] - 12*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4
      ]*sp[k2,q] + 24*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q]*sp[k2,k3]*m + 4*
      sp[k1,q]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,q] + 8*sp[k1,q]*sp[k2,q]*m
      ] + amp[1,3]*color[Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2
      ]]*den[sp[ - k3 + q]]*num[48*sp[k1,k2] - 24*sp[k1,k2]*m - 24*sp[
      k1,k2]*sp[k1,k3] + 12*sp[k1,k2]*sp[k1,k3]*m + 24*sp[k1,k2]*sp[k1,
      q] - 12*sp[k1,k2]*sp[k1,q]*m - 24*sp[k1,k2]*sp[k2,k3] + 12*sp[k1,
      k2]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k2,q] - 12*sp[k1,k2]*sp[k2,q]*m
       - 12*sp[k1,k2]*sp[k3,k4] + 12*sp[k1,k2]*sp[k3,k4]*m - 96*sp[k1,
      k2]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,q]*m + 12*sp[k1,k2]*sp[k4,q] - 
      12*sp[k1,k2]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k3] + 24*sp[k1,k3]*
      sp[k2,k3]*m + 12*sp[k1,k3]*sp[k2,k4] - 12*sp[k1,k3]*sp[k2,k4]*m
       + 48*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k3]*sp[k2,q]*m + 12*sp[k1,k4]
      *sp[k2,k3] - 12*sp[k1,k4]*sp[k2,k3]*m - 12*sp[k1,k4]*sp[k2,q] + 
      12*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,q]*sp[k2,k3] - 24*sp[k1,q]*sp[
      k2,k3]*m - 12*sp[k1,q]*sp[k2,k4] + 12*sp[k1,q]*sp[k2,k4]*m - 48*
      sp[k1,q]*sp[k2,q] + 24*sp[k1,q]*sp[k2,q]*m] + amp[1,4]*color[1/2*
      Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[ - k4 + q
      ]]*num[48*sp[k1,k2] - 24*sp[k1,k2]*m - 24*sp[k1,k2]*sp[k1,k4] + 
      12*sp[k1,k2]*sp[k1,k4]*m + 24*sp[k1,k2]*sp[k1,q] - 12*sp[k1,k2]*
      sp[k1,q]*m - 24*sp[k1,k2]*sp[k2,k4] + 12*sp[k1,k2]*sp[k2,k4]*m + 
      24*sp[k1,k2]*sp[k2,q] - 12*sp[k1,k2]*sp[k2,q]*m - 12*sp[k1,k2]*
      sp[k3,k4] + 12*sp[k1,k2]*sp[k3,k4]*m + 12*sp[k1,k2]*sp[k3,q] - 12
      *sp[k1,k2]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k4,q] + 48*sp[k1,k2]*sp[
      k4,q]*m + 12*sp[k1,k3]*sp[k2,k4] - 12*sp[k1,k3]*sp[k2,k4]*m - 12*
      sp[k1,k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,q]*m + 12*sp[k1,k4]*sp[k2
      ,k3] - 12*sp[k1,k4]*sp[k2,k3]*m - 48*sp[k1,k4]*sp[k2,k4] + 24*sp[
      k1,k4]*sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[k2,q
      ]*m - 12*sp[k1,q]*sp[k2,k3] + 12*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,
      q]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,q] + 
      24*sp[k1,q]*sp[k2,q]*m] + amp[1,4]*color[Ca^2*Na*Tf]*den[sp[ - k1
       - k2]]*den[sp[k1 + k2]]*den[sp[ - k4 + q]]*num[48*sp[k1,k2] - 24
      *sp[k1,k2]*m - 24*sp[k1,k2]*sp[k1,k4] + 12*sp[k1,k2]*sp[k1,k4]*m
       + 24*sp[k1,k2]*sp[k1,q] - 12*sp[k1,k2]*sp[k1,q]*m - 24*sp[k1,k2]
      *sp[k2,k4] + 12*sp[k1,k2]*sp[k2,k4]*m + 24*sp[k1,k2]*sp[k2,q] - 
      12*sp[k1,k2]*sp[k2,q]*m - 12*sp[k1,k2]*sp[k3,k4] + 12*sp[k1,k2]*
      sp[k3,k4]*m + 12*sp[k1,k2]*sp[k3,q] - 12*sp[k1,k2]*sp[k3,q]*m - 
      96*sp[k1,k2]*sp[k4,q] + 48*sp[k1,k2]*sp[k4,q]*m + 12*sp[k1,k3]*
      sp[k2,k4] - 12*sp[k1,k3]*sp[k2,k4]*m - 12*sp[k1,k3]*sp[k2,q] + 12
      *sp[k1,k3]*sp[k2,q]*m + 12*sp[k1,k4]*sp[k2,k3] - 12*sp[k1,k4]*sp[
      k2,k3]*m - 48*sp[k1,k4]*sp[k2,k4] + 24*sp[k1,k4]*sp[k2,k4]*m + 48
      *sp[k1,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[k2,q]*m - 12*sp[k1,q]*sp[k2
      ,k3] + 12*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,q]*sp[k2,k4] - 24*sp[k1
      ,q]*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,q] + 24*sp[k1,q]*sp[k2,q]*m]
       + amp[1,5]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3
      ]]*den[sp[ - k2 - k4]]*num[64*sp[k1,k2]^2 - 32*sp[k1,k2]^2*m + 64
      *sp[k1,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*m + 64*sp[k1,k2]*
      sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k3,k4] + 
      80*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 - 96*sp[k1,
      k3]*sp[k2,k4] + 80*sp[k1,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]
      *m^2 + 160*sp[k1,k4]*sp[k2,k3] - 112*sp[k1,k4]*sp[k2,k3]*m + 16*
      sp[k1,k4]*sp[k2,k3]*m^2] + amp[1,6]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + q]]*num[ - 64*sp[k1,
      k2]^2 + 32*sp[k1,k2]^2*m + 64*sp[k1,k2]*sp[k1,q] - 32*sp[k1,k2]*
      sp[k1,q]*m - 64*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m - 
      96*sp[k1,k2]*sp[k3,q] + 80*sp[k1,k2]*sp[k3,q]*m - 16*sp[k1,k2]*
      sp[k3,q]*m^2 - 96*sp[k1,k3]*sp[k2,q] + 80*sp[k1,k3]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k2,q]*m^2 + 160*sp[k1,q]*sp[k2,k3] - 112*sp[k1,q]
      *sp[k2,k3]*m + 16*sp[k1,q]*sp[k2,k3]*m^2] + amp[1,7]*color[ - 1/2
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k4 + q]]
      *num[48*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*sp[k1,k4]*m - 48*sp[k1
      ,k2]*sp[k1,q] + 24*sp[k1,k2]*sp[k1,q]*m + 48*sp[k1,k2]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k3,q] + 24*sp[k1,k2
      ]*sp[k3,q]*m - 48*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m
       + 48*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k3]*sp[k2,q]*m] + amp[1,7]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[
      sp[ - k4 + q]]*num[48*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*sp[k1,k4
      ]*m - 48*sp[k1,k2]*sp[k1,q] + 24*sp[k1,k2]*sp[k1,q]*m + 48*sp[k1,
      k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k3,q]
       + 24*sp[k1,k2]*sp[k3,q]*m - 48*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3
      ]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k3]*sp[k2,q]*m]
       + amp[1,8]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4
      ]]*den[sp[ - k2 - k3]]*num[64*sp[k1,k2]^2 - 32*sp[k1,k2]^2*m + 64
      *sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m + 64*sp[k1,k2]*
      sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k3,k4] + 
      80*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 160*sp[k1
      ,k3]*sp[k2,k4] - 112*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,
      k4]*m^2 - 96*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k2,k3]*m^2] + amp[1,9]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*num[ - 32*sp[k1,
      k2]^2 + 16*sp[k1,k2]^2*m + 32*sp[k1,k2]*sp[k1,q] - 16*sp[k1,k2]*
      sp[k1,q]*m - 32*sp[k1,k2]*sp[k2,k4] + 16*sp[k1,k2]*sp[k2,k4]*m - 
      48*sp[k1,k2]*sp[k4,q] + 40*sp[k1,k2]*sp[k4,q]*m - 8*sp[k1,k2]*sp[
      k4,q]*m^2 - 48*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,q]*m - 8*
      sp[k1,k4]*sp[k2,q]*m^2 + 80*sp[k1,q]*sp[k2,k4] - 56*sp[k1,q]*sp[
      k2,k4]*m + 8*sp[k1,q]*sp[k2,k4]*m^2] + amp[1,9]*color[1/4*Ca^2*Na
      *Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*num[32*
      sp[k1,k2]^2 - 16*sp[k1,k2]^2*m - 32*sp[k1,k2]*sp[k1,q] + 16*sp[k1
      ,k2]*sp[k1,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*sp[k2,k4]
      *m + 48*sp[k1,k2]*sp[k4,q] - 40*sp[k1,k2]*sp[k4,q]*m + 8*sp[k1,k2
      ]*sp[k4,q]*m^2 + 48*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,q]*m
       + 8*sp[k1,k4]*sp[k2,q]*m^2 - 80*sp[k1,q]*sp[k2,k4] + 56*sp[k1,q]
      *sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k4]*m^2] + amp[1,10]*color[ - 1/2
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k3 + q]]
      *num[48*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,k2]*sp[k1,k3]*m - 48*sp[k1
      ,k2]*sp[k1,q] + 24*sp[k1,k2]*sp[k1,q]*m + 48*sp[k1,k2]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k4,q] + 24*sp[k1,k2
      ]*sp[k4,q]*m - 48*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m
       + 48*sp[k1,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[k2,q]*m] + amp[1,10]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[
      sp[ - k3 + q]]*num[16*sp[k1,k2]*sp[k1,k3] - 8*sp[k1,k2]*sp[k1,k3]
      *m - 32*sp[k1,k2]*sp[k1,q] + 16*sp[k1,k2]*sp[k1,q]*m + 40*sp[k1,
      k2]*sp[k3,k4] - 28*sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k3,k4]*
      m^2 - 8*sp[k1,k2]*sp[k4,q] - 4*sp[k1,k2]*sp[k4,q]*m + 4*sp[k1,k2]
      *sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4] + 20*sp[k1,k3]*sp[k2,k4]*m
       - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 8*sp[k1,k4]*sp[k2,k3] - 4*sp[k1,k4
      ]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k2,k3]*m^2 + 40*sp[k1,k4]*sp[k2,q]
       - 28*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 - 24*sp[k1,
      q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k4]*m^2
      ] + amp[1,10]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + 
      k4]]*den[sp[ - k3 + q]]*num[ - 32*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,
      k2]*sp[k1,k3]*m + 16*sp[k1,k2]*sp[k1,q] - 8*sp[k1,k2]*sp[k1,q]*m
       - 8*sp[k1,k2]*sp[k3,k4] - 4*sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,k2]*
      sp[k3,k4]*m^2 + 40*sp[k1,k2]*sp[k4,q] - 28*sp[k1,k2]*sp[k4,q]*m
       + 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4] + 20*sp[k1,
      k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 + 40*sp[k1,k4]*sp[k2,
      k3] - 28*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k2,k3]*m^2 - 8*
      sp[k1,k4]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q
      ]*m^2 - 24*sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1
      ,q]*sp[k2,k4]*m^2] + amp[1,11]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*num[ - 64*sp[k1,k2]^2
       + 32*sp[k1,k2]^2*m - 64*sp[k1,k2]*sp[k1,k3] + 32*sp[k1,k2]*sp[k1
      ,k3]*m + 64*sp[k1,k2]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,q]*m - 96*sp[
      k1,k2]*sp[k3,q] + 80*sp[k1,k2]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,q]
      *m^2 + 160*sp[k1,k3]*sp[k2,q] - 112*sp[k1,k3]*sp[k2,q]*m + 16*sp[
      k1,k3]*sp[k2,q]*m^2 - 96*sp[k1,q]*sp[k2,k3] + 80*sp[k1,q]*sp[k2,
      k3]*m - 16*sp[k1,q]*sp[k2,k3]*m^2] + amp[1,12]*color[ - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*num[
       - 32*sp[k1,k2]^2 + 16*sp[k1,k2]^2*m - 32*sp[k1,k2]*sp[k1,k4] + 
      16*sp[k1,k2]*sp[k1,k4]*m + 32*sp[k1,k2]*sp[k2,q] - 16*sp[k1,k2]*
      sp[k2,q]*m - 48*sp[k1,k2]*sp[k4,q] + 40*sp[k1,k2]*sp[k4,q]*m - 8*
      sp[k1,k2]*sp[k4,q]*m^2 + 80*sp[k1,k4]*sp[k2,q] - 56*sp[k1,k4]*sp[
      k2,q]*m + 8*sp[k1,k4]*sp[k2,q]*m^2 - 48*sp[k1,q]*sp[k2,k4] + 40*
      sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k4]*m^2] + amp[1,12]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - 
      k2 - k4]]*num[32*sp[k1,k2]^2 - 16*sp[k1,k2]^2*m + 32*sp[k1,k2]*
      sp[k1,k4] - 16*sp[k1,k2]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k2,q] + 16
      *sp[k1,k2]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k4,q] - 40*sp[k1,k2]*sp[
      k4,q]*m + 8*sp[k1,k2]*sp[k4,q]*m^2 - 80*sp[k1,k4]*sp[k2,q] + 56*
      sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,q]*m^2 + 48*sp[k1,q]*sp[
      k2,k4] - 40*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k4]*m^2] + 
      amp[1,13]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q
      ]]*den[sp[ - k3 - k4]]*num[32*sp[k1,k2]*sp[k1,k3] - 16*sp[k1,k2]*
      sp[k1,k3]*m + 16*sp[k1,k2]*sp[k1,k4] - 8*sp[k1,k2]*sp[k1,k4]*m - 
      8*sp[k1,k2]*sp[k3,q] - 4*sp[k1,k2]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k3
      ,q]*m^2 - 40*sp[k1,k2]*sp[k4,q] + 28*sp[k1,k2]*sp[k4,q]*m - 4*sp[
      k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,q] + 20*sp[k1,k3]*sp[k2,
      q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,q] - 20*sp[
      k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 + 40*sp[k1,q]*sp[k2,
      k3] - 28*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*m^2 + 8*sp[
      k1,q]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k4]*
      m^2] + amp[1,13]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1
       - q]]*den[sp[ - k3 - k4]]*num[ - 16*sp[k1,k2]*sp[k1,k3] + 8*sp[
      k1,k2]*sp[k1,k3]*m - 32*sp[k1,k2]*sp[k1,k4] + 16*sp[k1,k2]*sp[k1,
      k4]*m + 40*sp[k1,k2]*sp[k3,q] - 28*sp[k1,k2]*sp[k3,q]*m + 4*sp[k1
      ,k2]*sp[k3,q]*m^2 + 8*sp[k1,k2]*sp[k4,q] + 4*sp[k1,k2]*sp[k4,q]*m
       - 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,q] + 20*sp[k1,k3
      ]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,q]
       - 20*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 - 8*sp[k1,q
      ]*sp[k2,k3] - 4*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*m^2
       - 40*sp[k1,q]*sp[k2,k4] + 28*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q]*
      sp[k2,k4]*m^2] + amp[1,13]*color[1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]
      *den[sp[k1 - q]]*den[sp[ - k3 - k4]]*num[ - 48*sp[k1,k2]*sp[k1,k3
      ] + 24*sp[k1,k2]*sp[k1,k3]*m - 48*sp[k1,k2]*sp[k1,k4] + 24*sp[k1,
      k2]*sp[k1,k4]*m + 48*sp[k1,k2]*sp[k3,q] - 24*sp[k1,k2]*sp[k3,q]*m
       + 48*sp[k1,k2]*sp[k4,q] - 24*sp[k1,k2]*sp[k4,q]*m - 48*sp[k1,q]*
      sp[k2,k3] + 24*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,q]*sp[k2,k4] + 24*
      sp[k1,q]*sp[k2,k4]*m] + amp[1,14]*color[1/4*Ca^2*Na*Tf]*den[sp[k1
       + k2]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*num[ - 48*sp[k1,k2
      ]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k2,q] - 
      24*sp[k1,k2]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*
      sp[k3,k4]*m + 48*sp[k1,k2]*sp[k3,q] - 24*sp[k1,k2]*sp[k3,q]*m + 
      48*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m - 48*sp[k1,q]*
      sp[k2,k3] + 24*sp[k1,q]*sp[k2,k3]*m] + amp[1,14]*color[1/2*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*
      num[ - 48*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m + 48*sp[
      k1,k2]*sp[k2,q] - 24*sp[k1,k2]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k3,k4
      ] + 24*sp[k1,k2]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k3,q] - 24*sp[k1,
      k2]*sp[k3,q]*m + 48*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*
      m - 48*sp[k1,q]*sp[k2,k3] + 24*sp[k1,q]*sp[k2,k3]*m] + amp[1,15]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 - k4]]*
      den[sp[ - k3 + q]]*num[32*sp[k1,k2]*sp[k2,k3] - 16*sp[k1,k2]*sp[
      k2,k3]*m - 16*sp[k1,k2]*sp[k2,q] + 8*sp[k1,k2]*sp[k2,q]*m + 8*sp[
      k1,k2]*sp[k3,k4] + 4*sp[k1,k2]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k3,k4
      ]*m^2 - 40*sp[k1,k2]*sp[k4,q] + 28*sp[k1,k2]*sp[k4,q]*m - 4*sp[k1
      ,k2]*sp[k4,q]*m^2 - 40*sp[k1,k3]*sp[k2,k4] + 28*sp[k1,k3]*sp[k2,
      k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 + 24*sp[k1,k4]*sp[k2,k3] - 20*
      sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k2,k3]*m^2 + 24*sp[k1,k4]*
      sp[k2,q] - 20*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 + 8
      *sp[k1,q]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,
      k4]*m^2] + amp[1,15]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[ - 16*sp[k1,k2]*sp[k2,k3]
       + 8*sp[k1,k2]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k2,q] - 16*sp[k1,k2]
      *sp[k2,q]*m - 40*sp[k1,k2]*sp[k3,k4] + 28*sp[k1,k2]*sp[k3,k4]*m
       - 4*sp[k1,k2]*sp[k3,k4]*m^2 + 8*sp[k1,k2]*sp[k4,q] + 4*sp[k1,k2]
      *sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k4] + 
      4*sp[k1,k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 + 24*sp[k1,k4
      ]*sp[k2,k3] - 20*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k2,k3]*
      m^2 + 24*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,
      k4]*sp[k2,q]*m^2 - 40*sp[k1,q]*sp[k2,k4] + 28*sp[k1,q]*sp[k2,k4]*
      m - 4*sp[k1,q]*sp[k2,k4]*m^2] + amp[1,15]*color[1/2*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[ - 48
      *sp[k1,k2]*sp[k2,k3] + 24*sp[k1,k2]*sp[k2,k3]*m + 48*sp[k1,k2]*
      sp[k2,q] - 24*sp[k1,k2]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k3,k4] + 24*
      sp[k1,k2]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k4,q] - 24*sp[k1,k2]*sp[
      k4,q]*m + 48*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m - 48*
      sp[k1,q]*sp[k2,k4] + 24*sp[k1,q]*sp[k2,k4]*m] + amp[1,16]*color[
       - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - 
      k3 - k4]]*num[48*sp[k1,k2]*sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*m
       + 48*sp[k1,k2]*sp[k2,k4] - 24*sp[k1,k2]*sp[k2,k4]*m - 48*sp[k1,
      k2]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k4,q] + 
      24*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k3]*
      sp[k2,q]*m + 48*sp[k1,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[k2,q]*m] + 
      amp[1,16]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2
       + q]]*den[sp[ - k3 - k4]]*num[16*sp[k1,k2]*sp[k2,k3] - 8*sp[k1,
      k2]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*sp[k2,k4]
      *m - 40*sp[k1,k2]*sp[k3,q] + 28*sp[k1,k2]*sp[k3,q]*m - 4*sp[k1,k2
      ]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k4,q] - 4*sp[k1,k2]*sp[k4,q]*m + 
      4*sp[k1,k2]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q] + 4*sp[k1,k3]*sp[
      k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 40*sp[k1,k4]*sp[k2,q] - 28*
      sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 + 24*sp[k1,q]*sp[
      k2,k3] - 20*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*m^2 - 24*
      sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,
      k4]*m^2] + amp[1,16]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[
      sp[ - k2 + q]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]*sp[k2,k3]
       + 16*sp[k1,k2]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k2,k4] + 8*sp[k1,k2
      ]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k3,q] + 4*sp[k1,k2]*sp[k3,q]*m - 4
      *sp[k1,k2]*sp[k3,q]*m^2 + 40*sp[k1,k2]*sp[k4,q] - 28*sp[k1,k2]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k4,q]*m^2 - 40*sp[k1,k3]*sp[k2,q] + 
      28*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 - 8*sp[k1,k4]*
      sp[k2,q] - 4*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 + 24
      *sp[k1,q]*sp[k2,k3] - 20*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,
      k3]*m^2 - 24*sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m - 4*sp[
      k1,q]*sp[k2,k4]*m^2] + amp[2,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*num[ - 32*sp[k1,
      k2]^2 + 16*sp[k1,k2]^2*m - 32*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,k2]*
      sp[k1,k3]*m + 32*sp[k1,k2]*sp[k2,q] - 16*sp[k1,k2]*sp[k2,q]*m - 
      48*sp[k1,k2]*sp[k3,q] + 40*sp[k1,k2]*sp[k3,q]*m - 8*sp[k1,k2]*sp[
      k3,q]*m^2 + 80*sp[k1,k3]*sp[k2,q] - 56*sp[k1,k3]*sp[k2,q]*m + 8*
      sp[k1,k3]*sp[k2,q]*m^2 - 48*sp[k1,q]*sp[k2,k3] + 40*sp[k1,q]*sp[
      k2,k3]*m - 8*sp[k1,q]*sp[k2,k3]*m^2] + amp[2,1]*color[1/4*Ca^2*Na
      *Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*num[
      32*sp[k1,k2]^2 - 16*sp[k1,k2]^2*m + 32*sp[k1,k2]*sp[k1,k3] - 16*
      sp[k1,k2]*sp[k1,k3]*m - 32*sp[k1,k2]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k2,q]*m + 48*sp[k1,k2]*sp[k3,q] - 40*sp[k1,k2]*sp[k3,q]*m + 8*sp[
      k1,k2]*sp[k3,q]*m^2 - 80*sp[k1,k3]*sp[k2,q] + 56*sp[k1,k3]*sp[k2,
      q]*m - 8*sp[k1,k3]*sp[k2,q]*m^2 + 48*sp[k1,q]*sp[k2,k3] - 40*sp[
      k1,q]*sp[k2,k3]*m + 8*sp[k1,q]*sp[k2,k3]*m^2] + amp[2,2]*color[
       - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[ - 
      k2 - k3]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]^2*sp[k2,k3] + 
      16*sp[k1,k2]^2*sp[k2,k3]*m - 64*sp[k1,k2]^2*sp[k2,k4] + 32*sp[k1,
      k2]^2*sp[k2,k4]*m - 80*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[
      k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,q]*m - 8*sp[k1,k2]^2*sp[k4,q]*m
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 80*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 24*sp[k1,k2]*
      sp[k1,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       + 144*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]
      *sp[k1,k4]*sp[k3,k4] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
       - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3] + 16*sp[k1,k2]*sp[k2,k3]*m
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k2
      ,q]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 192*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 80*sp[k1
      ,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k2,k4
      ]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 48*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m^2 - 80*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 32*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k2,q]*sp[
      k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*
      sp[k4,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,
      k4] + 12*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
       + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k3,q]
      ^2 + 24*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 + 32*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 
      4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k3]^2*sp[k2,k4] - 8*
      sp[k1,k3]^2*sp[k2,k4]*m - 8*sp[k1,k3]^2*sp[k2,q]*m + 4*sp[k1,k3]^
      2*sp[k2,q]*m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 24*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 32*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3] + 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,q]
      *sp[k2,k3]*m^2 - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 4*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       + 40*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4] + 
      20*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 40*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*
      m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m - 144*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^
      2*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m + 32*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,q]
      *sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 16*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 64*sp[
      k1,k4]^2*sp[k2,k3] + 24*sp[k1,k4]^2*sp[k2,k3]*m + 48*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3]*m^2 + 56*sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k4
      ]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 144*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 
      24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,
      q] + 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 32*sp[k1,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m - 96
      *sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]
      *m + 32*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 4*sp[k1
      ,q]*sp[k2,k3]^2*m^2 + 176*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 72*sp[k1
      ,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 
      96*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m
       - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q
      ]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q]*m^2 + 80*sp[k1,q]*sp[k2,k4]^2 - 32*sp[k1,q]*sp[k2,k4]^
      2*m + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k4]*sp[
      k2,q]*m + 80*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q]*m + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m] + amp[2,4]*color[1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 - k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*
      num[16*sp[k1,k2]^2*m + 64*sp[k1,k2]^2*sp[k1,k4] - 32*sp[k1,k2]^2*
      sp[k1,k4]*m - 32*sp[k1,k2]^2*sp[k1,q] + 16*sp[k1,k2]^2*sp[k1,q]*m
       - 8*sp[k1,k2]^2*sp[k3,k4]*m + 16*sp[k1,k2]^2*sp[k3,q]*m - 80*sp[
      k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]*sp[
      k1,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k1,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 
      8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,
      q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 80*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 80*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 - 32*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3] + 144*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 48*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 
      192*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 24*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 + 16*sp[k1,k2]*sp[k2,
      k3] - 8*sp[k1,k2]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 24
      *sp[k1,k2]*sp[k2,k4]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 32*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k2,q] + 8*sp[k1,k2]*sp[k2,q]*m + 8*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,
      k2]*sp[k2,q]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 24*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[
      k1,k2]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 24*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 
      64*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
      *m - 16*sp[k1,k2]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,q]*m + 32*sp[k1,k2
      ]*sp[k3,q]^2 - 24*sp[k1,k2]*sp[k3,q]^2*m + 4*sp[k1,k2]*sp[k3,q]^2
      *m^2 - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m + 32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^2*sp[k2,k4]*m
       - 64*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m - 96*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k3] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 
      16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,
      q] - 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m^2 + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k3]*sp[
      k1,q]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 4*sp[
      k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,
      k3]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[
      k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 24*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]^2*m + 4*sp[k1,k3
      ]*sp[k2,q]^2*m^2 + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,k3
      ]*sp[k2,q]*sp[k3,k4]*m^2 - 32*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 24*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2
       + 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k4,q
      ]*m + 80*sp[k1,k4]^2*sp[k2,k3] - 32*sp[k1,k4]^2*sp[k2,k3]*m - 176
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 72*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 16*sp[k1,k4]*sp[k2,k3] + 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
      *m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q]*m - 80*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 24*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*
      sp[k2,q]^2*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,q]^2*sp[k2,k3] + 8*sp[k1,q]^2*
      sp[k2,k3]*m - 4*sp[k1,q]^2*sp[k2,k3]*m^2 + 16*sp[k1,q]*sp[k2,k3]
       - 8*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 40*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,q]*sp[k2,k3]*sp[
      k2,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 4*sp[
      k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 
      64*sp[k1,q]*sp[k2,k4]^2 + 24*sp[k1,q]*sp[k2,k4]^2*m + 32*sp[k1,q]
      *sp[k2,k4]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 64*sp[k1,
      q]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 144*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 
      112*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m] + amp[2,5]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - 
      k2 - k4]]*num[ - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,
      k4]*m + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*
      sp[k1,k2]^2*sp[k4,q] - 64*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]^2
      *sp[k4,q]*m^2 + 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 256*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,k4] - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 64*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
      *m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 
      16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4] + 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,q
      ]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 128*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 + 64
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2
      ]*sp[k2,q]*sp[k3,k4]*m - 896*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 608*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
      *m^2 + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^3 - 256*sp[k1,k3]^2*sp[k2
      ,k4] + 128*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]^2*sp[k2,k4]*m^2
       + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 96*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q]*m^2 - 640*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 416*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 
      64*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,
      q]*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 640*sp[k1,
      k3]*sp[k2,q]*sp[k3,k4] - 480*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 112
      *sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4
      ]*m^3 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 128*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q] + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 640*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       - 480*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^3 + 256*sp[k1,q]*
      sp[k2,k3]^2 - 128*sp[k1,q]*sp[k2,k3]^2*m + 16*sp[k1,q]*sp[k2,k3]^
      2*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2] + amp[2
      ,6]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q
      ]]*num[256*sp[k1,k2]^2 - 160*sp[k1,k2]^2*m + 16*sp[k1,k2]^2*m^2
       + 128*sp[k1,k2]^3 - 64*sp[k1,k2]^3*m + 128*sp[k1,k2]^2*sp[k1,k3]
       - 64*sp[k1,k2]^2*sp[k1,k3]*m - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[
      k1,k2]^2*sp[k1,q]*m + 128*sp[k1,k2]^2*sp[k2,k3] - 64*sp[k1,k2]^2*
      sp[k2,k3]*m - 128*sp[k1,k2]^2*sp[k2,q] + 64*sp[k1,k2]^2*sp[k2,q]*
      m - 256*sp[k1,k2]^2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k3,q]*m + 256*
      sp[k1,k2]*sp[k1,k3] - 160*sp[k1,k2]*sp[k1,k3]*m + 16*sp[k1,k2]*
      sp[k1,k3]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k1,q]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 192*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3
      ]*m^2 + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 128*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,q] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 256*sp[
      k1,k2]*sp[k1,q]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32
      *sp[k1,k2]*sp[k1,q]*sp[k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k3,q
      ] + 96*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m^2 + 256*sp[k1,k2]*sp[k2,k3] - 160*sp[k1,k2]*sp[k2,k3]*m
       + 16*sp[k1,k2]*sp[k2,k3]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k2,q]
       + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 96*sp[k1,k2
      ]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 1024
      *sp[k1,k2]*sp[k3,q]^2 + 704*sp[k1,k2]*sp[k3,q]^2*m - 144*sp[k1,k2
      ]*sp[k3,q]^2*m^2 + 8*sp[k1,k2]*sp[k3,q]^2*m^3 - 128*sp[k1,k3]^2*
      sp[k2,q] + 96*sp[k1,k3]^2*sp[k2,q]*m - 16*sp[k1,k3]^2*sp[k2,q]*
      m^2 + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 128*sp[k1,k3]
      *sp[k1,q]*sp[k2,q] + 96*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,
      k3]*sp[k1,q]*sp[k2,q]*m^2 - 1024*sp[k1,k3]*sp[k2,k3] + 704*sp[k1,
      k3]*sp[k2,k3]*m - 144*sp[k1,k3]*sp[k2,k3]*m^2 + 8*sp[k1,k3]*sp[k2
      ,k3]*m^3 + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 96*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 128*sp[k1,
      k3]*sp[k2,q]^2 - 96*sp[k1,k3]*sp[k2,q]^2*m + 16*sp[k1,k3]*sp[k2,q
      ]^2*m^2 + 1024*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 704*sp[k1,k3]*sp[k2,
      q]*sp[k3,q]*m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k3]
      *sp[k2,q]*sp[k3,q]*m^3 + 128*sp[k1,q]^2*sp[k2,k3] - 96*sp[k1,q]^2
      *sp[k2,k3]*m + 16*sp[k1,q]^2*sp[k2,k3]*m^2 - 128*sp[k1,q]*sp[k2,
      k3]^2 + 96*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]^2*m^2
       - 128*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 96*sp[k1,q]*sp[k2,k3]*sp[k2,
      q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 1024*sp[k1,q]*sp[k2,
      k3]*sp[k3,q] - 704*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 144*sp[k1,q]*
      sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^3] + 
      amp[2,7]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]
      *den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*num[64*
      sp[k1,k2]^2 - 32*sp[k1,k2]^2*m - 128*sp[k1,k2]^2*sp[k1,k4] + 64*
      sp[k1,k2]^2*sp[k1,k4]*m + 64*sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^
      2*sp[k1,q]*m + 32*sp[k1,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^2*sp[k3,q]
       + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[k1
      ,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m - 128*sp[k1,k2]*sp[k1,
      k3]*sp[k1,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]
      *sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 64
      *sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]
      *m - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 128*sp[k1,k2]*sp[k1,
      q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 192*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 
      64*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*m + 64*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 
      64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
      *m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k3,q]^2
       + 48*sp[k1,k2]*sp[k3,q]^2*m - 8*sp[k1,k2]*sp[k3,q]^2*m^2 - 64*
      sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m + 128*sp[k1,k3
      ]^2*sp[k2,q] - 32*sp[k1,k3]^2*sp[k2,q]*m + 320*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,k3] - 208*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 256*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
       + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k3]*sp[k1
      ,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 128*sp[k1,k3]*
      sp[k2,k3] + 96*sp[k1,k3]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k2,k3]*m^2
       - 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 32*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 32*sp[
      k1,k3]*sp[k2,q]^2 - 16*sp[k1,k3]*sp[k2,q]^2*m - 32*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[k1
      ,k3]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 8*sp[
      k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 
      16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,
      q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] + 112*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m^2 + 32*sp[k1,q]^2*sp[k2,k3] - 16*sp[k1,q]^2*sp[
      k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 48*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*
      sp[k2,k3]*sp[k2,q]*m + 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 160*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2
       + 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,q
      ]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[2,8]*color[ - Cf^2
      *Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[
      sp[ - k2 - k3]]^2*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 128*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m^2 - 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 256*sp[k1,k3]
      *sp[k2,k3]*sp[k4,q] + 288*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*
      m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 160*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^3] + amp[2,9]*color[ - 
      Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[
      sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*num[ - 64*sp[
      k1,k2]^2 - 64*sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m
       - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 64*sp[k1,k2]^2*sp[k3,q] - 32*
      sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2
      *sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k4]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 
      64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,k3]*m^2 - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 96*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 - 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m
       - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m + 256*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,q]*
      sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1
      ,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 256*sp[k1
      ,k2]*sp[k1,q]*sp[k3,q] - 128*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 16*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q
      ] + 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k2,k4] + 64*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 128*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*
      m^2 - 608*sp[k1,k2]*sp[k3,k4] + 368*sp[k1,k2]*sp[k3,k4]*m - 72*
      sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 896*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] - 608*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 128*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 544*sp[k1,k3]*sp[k2,k4] - 
      368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,
      k3]*sp[k2,k4]*m^3 - 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 96*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 
      640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[k2,q]*sp[k4,q]
      *m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m^3 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m + 352*sp[k1,k4]*sp[k2,k3] - 240*sp[k1,k4]*sp[k2
      ,k3]*m + 56*sp[k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,k3]*m^3
       + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m - 256*sp[k1,k4]*sp[k2,q]^2 + 128*sp[k1,k4]*sp[k2,q]^2*m - 
      16*sp[k1,k4]*sp[k2,q]^2*m^2 - 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 
      128*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m^2 - 256*sp[k1,q]^2*sp[k2,k3] + 128*sp[k1,q]^2*sp[k2,k3]*m - 
      16*sp[k1,q]^2*sp[k2,k3]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 
      64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m^2 - 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 - 640*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m^3 + 640*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 416*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m^3] + amp[2,10]*color[1/2*Ca*Cf*Na*Tf - 1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*
      den[sp[ - k3 + q]]*num[ - 32*sp[k1,k2]^2 + 32*sp[k1,k2]^2*sp[k3,
      k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q] + 32*
      sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*
      sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 96*sp[k1,k2]
      *sp[k1,k3]*sp[k3,k4] - 80*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,
      q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 
      32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
      *m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[
      k2,k4]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,q
      ]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 128*sp[
      k1,k2]*sp[k1,q]*sp[k3,q] - 48*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 96*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 80*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k2]*sp[k2,k4] - 
      32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 256*sp[k1,k2]*sp[k2,q]*sp[
      k4,q] - 144*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,q]
      *sp[k4,q]*m^2 - 272*sp[k1,k2]*sp[k3,k4] + 104*sp[k1,k2]*sp[k3,k4]
      *m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
       + 112*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m^2 + 448*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 224*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 96*sp[
      k1,k3]^2*sp[k2,k4] + 80*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]^2*
      sp[k2,k4]*m^2 + 96*sp[k1,k3]^2*sp[k2,q] - 32*sp[k1,k3]^2*sp[k2,q]
      *m - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 32*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 160*sp[
      k1,k3]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m - 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 112*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 240*sp[
      k1,k3]*sp[k2,k4] - 104*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,
      k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4
      ]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 80*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 
      192*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 80*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 96*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]
      *sp[k2,k3]*m^2 + 144*sp[k1,k4]*sp[k2,k3] - 72*sp[k1,k4]*sp[k2,k3]
      *m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*
      m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 256*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] - 160*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 24*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m^2 - 192*sp[k1,k4]*sp[k2,q]^2 + 112*sp[k1,k4]*
      sp[k2,q]^2*m - 16*sp[k1,k4]*sp[k2,q]^2*m^2 - 192*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]^2*sp[k2,k3] + 48*sp[k1,q]^2*
      sp[k2,k3]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 8*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[
      k2,q] + 80*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m^2 - 320*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 176*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 256*sp[
      k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 8*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[2,11]*color[ - Cf^2*Na*Tf]
      *den[sp[k1 - q]]^2*den[sp[ - k2 - k3]]^2*num[ - 64*sp[k1,k3]*sp[
      k2,k3] + 96*sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k2,k3]*m^2 + 
      8*sp[k1,k3]*sp[k2,k3]*m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 192
      *sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k3,q]*
      m^2 - 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^3] + amp[2,12]*color[ - 
      Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - q]]^2*den[sp[ - k2 - k3
      ]]*den[sp[ - k2 - k4]]*num[ - 64*sp[k1,k2]*sp[k2,k3] + 64*sp[k1,
      k2]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k2
      ,k4] + 64*sp[k1,k2]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*m^2 - 
      128*sp[k1,k2]*sp[k3,k4] + 144*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2
      ]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 64*sp[k1,k3]*sp[k2,
      k4] - 80*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k4]*m^2 - 4*
      sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k4]*sp[k2,k3] - 80*sp[k1,k4]*
      sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,k3]*
      m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,q]*sp[k2,k3]*
      sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 128*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] + 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 
      128*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,q]*sp[k2,k4]*sp[k2,q]
      *m + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 - 128*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] + 160*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] - 288*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 96*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^3] + amp[2,13]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 - q]]^2*den[sp[
       - k2 - k3]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]*sp[k2,k3] + 
      32*sp[k1,k2]*sp[k2,k3]*m - 8*sp[k1,k2]*sp[k2,k3]*m^2 - 64*sp[k1,
      k2]*sp[k2,k4] + 64*sp[k1,k2]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k2,k4]
      *m^2 - 32*sp[k1,k2]*sp[k3,k4] + 32*sp[k1,k2]*sp[k3,k4]*m - 8*sp[
      k1,k2]*sp[k3,k4]*m^2 - 32*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k3]*sp[
      k2,k3]*m - 8*sp[k1,k3]*sp[k2,k3]*m^2 - 32*sp[k1,k3]*sp[k2,k4] + 
      32*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 + 64*sp[k1,
      k4]*sp[k2,k3] - 64*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]
      *m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,q]*sp[k2,k3]*sp[
      k2,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 64*sp[k1,q]*sp[k2,
      k3]*sp[k3,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,q]*sp[
      k2,k3]*sp[k3,q]*m^2 - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 128*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 
      128*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,q]*sp[k2,k4]*sp[k2,q]
      *m + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 64*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[
      2,14]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]^
      2*den[sp[ - k4 + q]]*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 128*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3
      ]*m^2 - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*
      sp[k2,k3] + 64*sp[k1,k3]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k2,k3]*m^2
       - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[2,15]*color[1/
      2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3
      ]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[ - 32*sp[k1,k2]^2*
      sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q]
       - 32*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m + 192*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m
       + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 256*sp[k1,k2]*sp[k1,
      k3]*sp[k3,k4] - 144*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,k4]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1
      ,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 48*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 80*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*
      m^2 - 96*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m - 128*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 
      32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
      *m - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,k4]
       - 16*sp[k1,k2]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 
      32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k2,q]*
      sp[k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,
      q]*sp[k4,q] - 80*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[
      k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3
      ,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q] + 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 112*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 192*
      sp[k1,k3]^2*sp[k2,k4] + 112*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3
      ]^2*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2
       + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q]*m - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 96*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2
       + 160*sp[k1,k3]*sp[k2,k4] - 80*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,
      k3]*sp[k2,k4]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 112*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m^2 - 96*sp[k1,k3]*sp[k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m + 192*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 80*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m
       + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 96*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2,
      k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,
      q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 320*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q] - 176*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 24*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m^2 - 96*sp[k1,k4]*sp[k2,q]^2 + 80*sp[k1,k4]*
      sp[k2,q]^2*m - 16*sp[k1,k4]*sp[k2,q]^2*m^2 - 96*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q] + 80*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,k3]^2 - 48*sp[k1,q]*sp[k2
      ,k3]^2*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,q]*sp[k2,k3
      ]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 160*sp[k1,q]
      *sp[k2,k3]*sp[k2,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 128*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 
      64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,k4]*sp[
      k2,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m^2 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 224*sp[
      k1,q]*sp[k2,q]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 8*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[2,16]*color[1/2*Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[
       - k2 + q]]*den[sp[ - k3 - k4]]*num[ - 64*sp[k1,k2]^2*sp[k2,k3]
       + 32*sp[k1,k2]^2*sp[k2,k3]*m - 128*sp[k1,k2]^2*sp[k2,k4] + 64*
      sp[k1,k2]^2*sp[k2,k4]*m - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]
      ^2*sp[k3,k4]*m - 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k4,q
      ] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k3]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 160*sp[k1,k2]*sp[k1,
      q]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 192*sp[
      k1,k2]*sp[k2,k3] + 80*sp[k1,k2]*sp[k2,k3]*m - 8*sp[k1,k2]*sp[k2,
      k3]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k3
      ]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q]*m - 192*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m - 288*sp[k1,k2]*sp[k2,k4] + 160*sp[k1,k2
      ]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*m^2 + 128*sp[k1,k2]*sp[k2,
      k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 160*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 128
      *sp[k1,k2]*sp[k2,q]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m
       + 64*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q
      ]*m - 112*sp[k1,k2]*sp[k3,k4] + 72*sp[k1,k2]*sp[k3,k4]*m - 8*sp[
      k1,k2]*sp[k3,k4]*m^2 - 64*sp[k1,k2]*sp[k3,q]^2 + 48*sp[k1,k2]*sp[
      k3,q]^2*m - 8*sp[k1,k2]*sp[k3,q]^2*m^2 + 64*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q]*m^2 - 32*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q
      ]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k3]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k3] + 48*sp[k1,k3]*sp[
      k2,k3]*m - 8*sp[k1,k3]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 176*sp[k1,k3]*sp[k2,
      k4] + 88*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 - 96*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       - 128*sp[k1,k3]*sp[k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m + 64*sp[
      k1,k3]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 8*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 240*sp[k1,k4]*sp[
      k2,k3] - 136*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]*m^2
       + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,q]^2 + 16
      *sp[k1,k4]*sp[k2,q]^2*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m - 32*sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,q
      ]*sp[k2,k3]^2*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 256*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 128*sp[
      k1,q]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2
       + 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,q
      ]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 256*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] + 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m^2 + 320*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 208*sp[k1,q]
      *sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 192*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m^2] + amp[3,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2
      ]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*num[64*sp[k1,k2]^2 - 32*
      sp[k1,k2]^2*m + 64*sp[k1,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*m
       - 64*sp[k1,k2]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,q]*m + 96*sp[k1,k2]
      *sp[k4,q] - 80*sp[k1,k2]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k4,q]*m^2
       - 160*sp[k1,k4]*sp[k2,q] + 112*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,
      k4]*sp[k2,q]*m^2 + 96*sp[k1,q]*sp[k2,k4] - 80*sp[k1,q]*sp[k2,k4]*
      m + 16*sp[k1,q]*sp[k2,k4]*m^2] + amp[3,2]*color[1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[sp[
       - k3 - k4]]*num[64*sp[k1,k2]^2*sp[k2,k3] - 32*sp[k1,k2]^2*sp[k2,
      k3]*m + 32*sp[k1,k2]^2*sp[k2,k4] - 16*sp[k1,k2]^2*sp[k2,k4]*m + 
      80*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m + 8*sp[k1,
      k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 144*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 8*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q]*m^2 - 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 24*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*
      m - 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,
      q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 80*sp[k1,
      k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k2,k3]
      *sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 48*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4] - 16*sp[k1
      ,k2]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k2]
      *sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 
      24*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q
      ]*m^2 - 80*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,
      q]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k2]*sp[
      k2,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,k4] - 12*sp[k1,k2]*sp[k3,k4
      ]*m - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 24*sp[k1,k2]
      *sp[k3,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[
      k1,k2]*sp[k4,q]^2 - 24*sp[k1,k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4
      ,q]^2*m^2 + 64*sp[k1,k3]^2*sp[k2,k4] - 24*sp[k1,k3]^2*sp[k2,k4]*m
       - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k3]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m^2 - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 40*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 80*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4]
       + 20*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 
      16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 144*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2
      ,q]^2 - 8*sp[k1,k3]*sp[k2,q]^2*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4
      ] - 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]^2*sp[k2,k3
      ] + 8*sp[k1,k4]^2*sp[k2,k3]*m + 8*sp[k1,k4]^2*sp[k2,q]*m - 4*sp[
      k1,k4]^2*sp[k2,q]*m^2 + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4
      ]*m^2 + 56*sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k4]*sp[k2,k3]*m + 128*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 144*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] - 48*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 32*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q] - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 112*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 64*sp[k1,k4]*sp[k2,q]^2 - 16*sp[k1,k4]*sp[k2,q]^2*m - 96*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2
       - 32*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k4]*sp[k2,q]*sp[k4,q
      ]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 80*sp[k1,q]*sp[k2,k3]^2
       + 32*sp[k1,q]*sp[k2,k3]^2*m - 176*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       + 72*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4]*m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,q]*sp[k2,k3]
      *sp[k2,q]*m - 80*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,q]*sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2
      ,k4]^2*m + 4*sp[k1,q]*sp[k2,k4]^2*m^2 - 96*sp[k1,q]*sp[k2,k4]*sp[
      k2,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 8*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3
      ,3]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[16*sp[k1,k2]^2*m + 64*
      sp[k1,k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2*sp[k1,k3]*m - 32*sp[k1,k2]
      ^2*sp[k1,q] + 16*sp[k1,k2]^2*sp[k1,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]
      *m - 80*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[
      k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k1,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,k4] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 80*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 48*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 4*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k1,k4]*m - 32*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m
       + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,k4]*m - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 16*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q]*m + 144*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 48
      *sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k1,q]*
      sp[k4,q] + 24*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,q
      ]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*
      m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k2,
      k4] - 8*sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q] + 8*
      sp[k1,k2]*sp[k2,q]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[
      k1,k2]*sp[k2,q]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 8*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k4,
      q] + 8*sp[k1,k2]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k4,q]^2 - 24*sp[k1,
      k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 80*sp[k1,k3]^2*
      sp[k2,k4] - 32*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3] - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1
      ,k4]*sp[k2,k4]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 176
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 72*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 80*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*
      sp[k2,k4] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m - 80*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 24*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,q]^2 + 8*sp[k1,k3]
      *sp[k2,q]^2*m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m + 32*sp[k1,k4]^2*sp[k2,k3] - 8*sp[k1,k4]^
      2*sp[k2,k3]*m - 64*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]
      *m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3]*m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k4]*m - 24*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[
      k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 8*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]
      *sp[k2,k4]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,
      q]^2*m^2 + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,
      q]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 24*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 32*
      sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m - 4*sp[k1,q]^2*
      sp[k2,k4]*m^2 - 64*sp[k1,q]*sp[k2,k3]^2 + 24*sp[k1,q]*sp[k2,k3]^2
      *m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 40*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 144*sp[k1,
      q]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[
      k1,q]*sp[k2,k4] - 8*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k4]*
      sp[k2,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,q]*sp[k2,k4
      ]*sp[k2,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 16*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 4
      *sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3,5]*color[ - Cf^2*Na
      *Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[
       - k2 - k4]]^2*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 128*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2
       + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 8*sp[k1,k3]*sp[k2
      ,k4]*sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,
      k4]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 - 
      256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q]*m - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4
      ]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 160*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 8*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^3] + amp[3,6]*color[ - Cf^2*Na*Tf
       + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]
      *den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[ - 64*sp[k1,k2]^2 - 
      64*sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,
      k2]^2*sp[k3,k4]*m^2 + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*
      sp[k3,q]*m + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 128*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k1,k4] + 64
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
      *m + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 
      256*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*
      m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[
      k1,q]*sp[k4,q] - 128*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]
      *sp[k1,q]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k2,k3] + 64*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 128*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 128*sp[k1,k2]*
      sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 608*
      sp[k1,k2]*sp[k3,k4] + 368*sp[k1,k2]*sp[k3,k4]*m - 72*sp[k1,k2]*
      sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 896*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q] - 608*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 64*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 352*sp[k1,k3]*sp[
      k2,k4] - 240*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k4]*m^2
       - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 
      32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 256*sp[k1,k3]*sp[k2,q]^2 + 
      128*sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*sp[k2,q]^2*m^2 - 256*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q]*m^2 + 544*sp[k1,k4]*sp[k2,k3] - 368*sp[k1,
      k4]*sp[k2,k3]*m + 72*sp[k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,
      k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 96*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 640*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 480*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 112*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^3 - 256*sp[k1,q]^2*sp[k2,k4] + 128*sp[k1,q]^2*sp[k2,k4]*m - 16*
      sp[k1,q]^2*sp[k2,k4]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,q]*m^2 - 640*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 480*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m - 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^3 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m^2 + 640*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 416*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m^3] + amp[3,7]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[
      sp[ - k4 + q]]*num[ - 32*sp[k1,k2]^2 + 32*sp[k1,k2]^2*sp[k3,k4]
       - 16*sp[k1,k2]^2*sp[k3,k4]*m + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[
      k1,k2]^2*sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 96*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 96*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 64*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       - 32*sp[k1,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q
      ] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 80*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 96*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m
       - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,q]*
      sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1
      ,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 128*sp[k1,
      k2]*sp[k1,q]*sp[k4,q] - 48*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 32*sp[
      k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q] + 80*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 256*sp[k1,k2]*sp[k2,q]*sp[k3,
      q] - 144*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m^2 - 272*sp[k1,k2]*sp[k3,k4] + 104*sp[k1,k2]*sp[k3,k4]*
      m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 112*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q]*m^2 + 448*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 224*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 32*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m
       - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 32*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m^2 + 144*sp[k1,k3]*sp[k2,k4] - 72*sp[k1,k3]*
      sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 24*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 192*sp[k1,k3]*sp[k2,q]^2 + 112*
      sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*sp[k2,q]^2*m^2 - 192*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] + 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,k4]^2*sp[k2,k3] + 80*
      sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]*m^2 + 96*sp[k1
      ,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q]*m - 16*sp[k1,k4]*sp[k1,
      q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 160*sp[k1,
      k4]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 64*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 
      240*sp[k1,k4]*sp[k2,k3] - 104*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]
      *sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 80*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2
       - 224*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 192*sp[k1,k4]
      *sp[k2,q]*sp[k3,q] + 80*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]^2*sp[k2,k4] + 48*sp[k1,q
      ]^2*sp[k2,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] + 80*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 
      16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 320*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q] + 176*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 128*sp[
      k1,q]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 256
      *sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m
       + 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[3,8]*color[ - Cf^2*Na
      *Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - 
      q]]*den[sp[ - k2 - k3]]*den[sp[ - k2 - k4]]*num[ - 64*sp[k1,k2]^2
      *sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[k1,k2]^2*sp[k3,q]
       - 64*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*sp[k3,q]*m^2 + 64*
      sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 64*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 256*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 128*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*
      m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k4]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 128*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q]*m^2 - 256*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 128*sp[k1,k2]*
      sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 + 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 896*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 608*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 8*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 128*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 640*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q] - 480*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 112*sp[k1,k3]*sp[k2,k4]
      *sp[k4,q]*m^2 - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^3 - 256*sp[k1,k4
      ]^2*sp[k2,k3] + 128*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[
      k2,k3]*m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 256*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*
      sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 640*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] + 416*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 96*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*
      m^3 + 640*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 480*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m + 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m^3 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 256*sp[k1,q]*sp[k2,k4]^2 - 128*sp[
      k1,q]*sp[k2,k4]^2*m + 16*sp[k1,q]*sp[k2,k4]^2*m^2 + 256*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[3,9]*color[ - Cf^2*Na*Tf + 3/
      2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[256*sp[k1,k2]^2 - 160*
      sp[k1,k2]^2*m + 16*sp[k1,k2]^2*m^2 + 128*sp[k1,k2]^3 - 64*sp[k1,
      k2]^3*m + 128*sp[k1,k2]^2*sp[k1,k4] - 64*sp[k1,k2]^2*sp[k1,k4]*m
       - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,k2]^2*sp[k1,q]*m + 128*sp[
      k1,k2]^2*sp[k2,k4] - 64*sp[k1,k2]^2*sp[k2,k4]*m - 128*sp[k1,k2]^2
      *sp[k2,q] + 64*sp[k1,k2]^2*sp[k2,q]*m - 256*sp[k1,k2]^2*sp[k4,q]
       + 64*sp[k1,k2]^2*sp[k4,q]*m + 256*sp[k1,k2]*sp[k1,k4] - 160*sp[
      k1,k2]*sp[k1,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*m^2 - 128*sp[k1,k2]*
      sp[k1,k4]*sp[k1,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 256*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4] + 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m^2 + 128*sp[k1,k2]*sp[k1,k4]
      *sp[k2,q] + 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 96*sp[k1,k2]*sp[k1
      ,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 128*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] - 256*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 192*
      sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*
      m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,q]*sp[
      k4,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 + 256*sp[k1,k2]*sp[
      k2,k4] - 160*sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*m^2
       - 128*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k2,k4]*sp[
      k2,q]*m + 128*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 96*sp[k1,k2]*sp[k2,
      k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 - 128*sp[k1,
      k2]*sp[k2,q]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 16*sp[
      k1,k2]*sp[k2,q]*sp[k4,q]*m^2 - 1024*sp[k1,k2]*sp[k4,q]^2 + 704*
      sp[k1,k2]*sp[k4,q]^2*m - 144*sp[k1,k2]*sp[k4,q]^2*m^2 + 8*sp[k1,
      k2]*sp[k4,q]^2*m^3 - 128*sp[k1,k4]^2*sp[k2,q] + 96*sp[k1,k4]^2*
      sp[k2,q]*m - 16*sp[k1,k4]^2*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k1,q]
      *sp[k2,k4] - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 96*sp[k1,
      k4]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 
      1024*sp[k1,k4]*sp[k2,k4] + 704*sp[k1,k4]*sp[k2,k4]*m - 144*sp[k1,
      k4]*sp[k2,k4]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*m^3 + 128*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,q]^2 - 96*sp[k1,k4
      ]*sp[k2,q]^2*m + 16*sp[k1,k4]*sp[k2,q]^2*m^2 + 1024*sp[k1,k4]*sp[
      k2,q]*sp[k4,q] - 704*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 144*sp[k1,k4
      ]*sp[k2,q]*sp[k4,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^3 + 128
      *sp[k1,q]^2*sp[k2,k4] - 96*sp[k1,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2
      *sp[k2,k4]*m^2 - 128*sp[k1,q]*sp[k2,k4]^2 + 96*sp[k1,q]*sp[k2,k4]
      ^2*m - 16*sp[k1,q]*sp[k2,k4]^2*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q] + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m^2 + 1024*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 704*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m + 144*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 8*
      sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^3] + amp[3,10]*color[1/2*Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - 
      k2 - k4]]*den[sp[ - k3 + q]]*num[64*sp[k1,k2]^2 - 32*sp[k1,k2]^2*
      m - 128*sp[k1,k2]^2*sp[k1,k3] + 64*sp[k1,k2]^2*sp[k1,k3]*m + 64*
      sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^2*sp[k1,q]*m + 32*sp[k1,k2]^2
      *sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m
       - 64*sp[k1,k2]^2*sp[k4,q] - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m - 160*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 160*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1
      ,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 32*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k2]
      *sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 64*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       - 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 32*sp[k1,
      k2]*sp[k1,q]*sp[k2,q]*m - 192*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m + 64*sp[k1,k2]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m + 64*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k4,
      q] + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k4,q]^2 + 48*sp[k1,k2]*sp[k4,q
      ]^2*m - 8*sp[k1,k2]*sp[k4,q]^2*m^2 + 320*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4] - 208*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1
      ,k4]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 112*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k4,q]*m^2 - 64*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*
      sp[k2,k3]*m + 128*sp[k1,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q]*
      m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 256*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k1,
      q]*sp[k2,k4]*m^2 - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k4]*sp[k2,k4] + 96*sp[
      k1,k4]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 32*sp[k1,k4]*sp[k2,q]^2 - 16*sp[k1,
      k4]*sp[k2,q]^2*m - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 48*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2
       + 32*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m - 128*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 
      32*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       + 256*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 160*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[k1,q]*sp[
      k2,k4]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m^2] + amp[3,11]*color[ - Cf^2*Na*Tf + 1/2*Ca*
      Cf*Na*Tf]*den[sp[k1 - q]]^2*den[sp[ - k2 - k3]]*den[sp[ - k2 - k4
      ]]*num[ - 64*sp[k1,k2]*sp[k2,k3] + 64*sp[k1,k2]*sp[k2,k3]*m - 16*
      sp[k1,k2]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k2,k4] + 64*sp[k1,k2]*
      sp[k2,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*m^2 - 128*sp[k1,k2]*sp[k3,k4
      ] + 144*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k3,k4]*m^2 + 4*
      sp[k1,k2]*sp[k3,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4] - 80*sp[k1,k3]*
      sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*
      m^3 + 64*sp[k1,k4]*sp[k2,k3] - 80*sp[k1,k4]*sp[k2,k3]*m + 32*sp[
      k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] - 128*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1
      ,q]*sp[k2,k3]*sp[k2,q]*m^2 - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 
      160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m^2 + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 128*sp[k1,q]*sp[k2,k4
      ]*sp[k2,q] - 128*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,q]*sp[
      k2,k4]*sp[k2,q]*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 160*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8
      *sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] - 288*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[3,12]*
      color[ - Cf^2*Na*Tf]*den[sp[k1 - q]]^2*den[sp[ - k2 - k4]]^2*num[
       - 64*sp[k1,k4]*sp[k2,k4] + 96*sp[k1,k4]*sp[k2,k4]*m - 48*sp[k1,
      k4]*sp[k2,k4]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*m^3 + 128*sp[k1,q]*sp[
      k2,k4]*sp[k4,q] - 192*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 96*sp[k1,q]
      *sp[k2,k4]*sp[k4,q]*m^2 - 16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^3] + 
      amp[3,13]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - q]]^2*den[sp[ - 
      k2 - k4]]*den[sp[ - k3 - k4]]*num[64*sp[k1,k2]*sp[k2,k3] - 64*sp[
      k1,k2]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k2,k3]*m^2 + 32*sp[k1,k2]*
      sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k2,k4]*m^2
       + 32*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2
      ]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k3]*sp[k2,k4]
      *m - 16*sp[k1,k3]*sp[k2,k4]*m^2 + 32*sp[k1,k4]*sp[k2,k3] - 32*sp[
      k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*sp[
      k2,k4] - 32*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k4]*m^2 - 
      128*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,q]*sp[k2,k3]*sp[k2,q]
      *m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 128*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[
      k4,q] + 64*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k4]*
      sp[k4,q]*m^2 - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[3,14]
      *color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[
       - k2 - k3]]*den[sp[ - k2 - k4]]*den[sp[ - k4 + q]]*num[ - 32*sp[
      k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*
      sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 192*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 32
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]
       - 144*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m^2 - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       + 80*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m^2 + 32*sp[k1,k2]*sp[k2,k3] - 16*sp[k1,k2]*sp[k2,k3]*m - 64
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 96*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m - 32*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*sp[k4,
      q] + 48*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] - 80*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k2]*
      sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 32*sp[k1
      ,k2]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]
      *sp[k3,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q] + 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 24*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m^2 + 192*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 112*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 80*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k4] - 32*
      sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 320*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 176*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m
       + 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k2,q]^2
       + 80*sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*sp[k2,q]^2*m^2 - 96*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 80*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 192*sp[k1,k4]^2*sp[k2,k3] + 
      112*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]*m^2 - 32*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*
      m^2 + 160*sp[k1,k4]*sp[k2,k3] - 80*sp[k1,k4]*sp[k2,k3]*m + 8*sp[
      k1,k4]*sp[k2,k3]*m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 
      112*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4
      ]*sp[k2,q]*m - 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 96*
      sp[k1,k4]*sp[k2,q]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m + 192*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] - 80*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4]*m^2 - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 48*sp[k1,q]*sp[k2,k3]
      *sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 256*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] + 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,k4]^2 - 48*sp[k1,
      q]*sp[k2,k4]^2*m + 160*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 48*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 48
      *sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 + 224*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m + 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[3,15]*color[1/
      2*Ca*Cf*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]^2*den[sp[ - k3
       + q]]*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 128*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 64*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k4] + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k4]*sp[k2
      ,k4]*m - 16*sp[k1,k4]*sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q] + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4
      ]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*
      sp[k1,q]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 
      16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2] + amp[3,16]*color[ - 1/2*Ca*
      Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*
      den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*num[128*sp[k1,k2]^2*sp[k2,
      k3] - 64*sp[k1,k2]^2*sp[k2,k3]*m + 64*sp[k1,k2]^2*sp[k2,k4] - 32*
      sp[k1,k2]^2*sp[k2,k4]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]
      ^2*sp[k3,k4]*m + 32*sp[k1,k2]^2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k4,q
      ] - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q
      ] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 128*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 288
      *sp[k1,k2]*sp[k2,k3] - 160*sp[k1,k2]*sp[k2,k3]*m + 16*sp[k1,k2]*
      sp[k2,k3]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 64*sp[k1,k2]*
      sp[k2,k3]*sp[k2,q]*m - 160*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 48*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k2,k4] - 80*sp[k1,
      k2]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k2,k4]*m^2 - 64*sp[k1,k2]*sp[k2,
      k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1
      ,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 64*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q
      ]*m - 128*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,q]*sp[
      k4,q]*m + 112*sp[k1,k2]*sp[k3,k4] - 72*sp[k1,k2]*sp[k3,k4]*m + 8*
      sp[k1,k2]*sp[k3,k4]*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 
      64*sp[k1,k2]*sp[k4,q]^2 - 48*sp[k1,k2]*sp[k4,q]^2*m + 8*sp[k1,k2]
      *sp[k4,q]^2*m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 48*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m - 240*sp[k1,k3]*sp[k2,k4] + 136*sp[k1
      ,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k2,q]^2 - 16*sp[k1,k3]*sp[k2,q]
      ^2*m + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m + 32*sp[k1,k4]^2*sp[k2,q] - 16*sp[k1,k4]^2*sp[k2,q]*m - 
      96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
      *m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4]*m + 176*sp[k1,k4]*sp[k2,k3] - 88*sp[k1,k4]*sp[k2,k3]*m + 8
      *sp[k1,k4]*sp[k2,k3]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k4] - 48*sp[
      k1,k4]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k4]*m^2 - 32*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 128*sp[k1,
      k4]*sp[k2,q]^2 - 32*sp[k1,k4]*sp[k2,q]^2*m - 32*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 64*sp[k1,k4]*
      sp[k2,q]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 8*sp[k1,k4
      ]*sp[k2,q]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 16*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 320*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       + 208*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,q]*sp[k2,k3]*sp[
      k2,q]*m^2 - 192*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 112*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 32*sp[k1,q]
      *sp[k2,k4]^2 - 16*sp[k1,q]*sp[k2,k4]^2*m - 256*sp[k1,q]*sp[k2,k4]
      *sp[k2,q] + 128*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2
      ,k4]*sp[k2,q]*m^2 + 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,q
      ]*sp[k2,k4]*sp[k3,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 64*
      sp[k1,q]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 
      8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 128*sp[k1,q]*sp[k2,q]*sp[k3,
      k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^2] + amp[4,1]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2
      ]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*num[48*sp[k1,k2]*sp[k1,k3] - 
      24*sp[k1,k2]*sp[k1,k3]*m + 48*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*
      sp[k1,k4]*m - 48*sp[k1,k2]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,q]*m - 
      48*sp[k1,k2]*sp[k4,q] + 24*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,q]*sp[
      k2,k3] - 24*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,q]*sp[k2,k4] - 24*sp[
      k1,q]*sp[k2,k4]*m] + amp[4,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 - k2]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*num[32*sp[k1,k2]*sp[k1
      ,k3] - 16*sp[k1,k2]*sp[k1,k3]*m + 16*sp[k1,k2]*sp[k1,k4] - 8*sp[
      k1,k2]*sp[k1,k4]*m - 8*sp[k1,k2]*sp[k3,q] - 4*sp[k1,k2]*sp[k3,q]*
      m + 4*sp[k1,k2]*sp[k3,q]*m^2 - 40*sp[k1,k2]*sp[k4,q] + 28*sp[k1,
      k2]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,q]
       + 20*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 24*sp[k1,
      k4]*sp[k2,q] - 20*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2
       + 40*sp[k1,q]*sp[k2,k3] - 28*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*
      sp[k2,k3]*m^2 + 8*sp[k1,q]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k4]*m - 4
      *sp[k1,q]*sp[k2,k4]*m^2] + amp[4,1]*color[1/4*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*num[ - 16*sp[k1,k2]
      *sp[k1,k3] + 8*sp[k1,k2]*sp[k1,k3]*m - 32*sp[k1,k2]*sp[k1,k4] + 
      16*sp[k1,k2]*sp[k1,k4]*m + 40*sp[k1,k2]*sp[k3,q] - 28*sp[k1,k2]*
      sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,q]*m^2 + 8*sp[k1,k2]*sp[k4,q] + 4*
      sp[k1,k2]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*
      sp[k2,q] + 20*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 
      24*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[
      k2,q]*m^2 - 8*sp[k1,q]*sp[k2,k3] - 4*sp[k1,q]*sp[k2,k3]*m + 4*sp[
      k1,q]*sp[k2,k3]*m^2 - 40*sp[k1,q]*sp[k2,k4] + 28*sp[k1,q]*sp[k2,
      k4]*m - 4*sp[k1,q]*sp[k2,k4]*m^2] + amp[4,2]*color[ - 1/2*Ca^2*Na
      *Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[
      sp[k3 + k4]]*num[176*sp[k1,k2]^2*sp[k3,k4] - 48*sp[k1,k2]^2*sp[k3
      ,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 48*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
      *m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 + 12*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 48*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m
       - 104*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 48*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m^2 + 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 4*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*
      m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 + 12*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 12*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 24*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*
      m^2 - 176*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m + 152*sp[k1,k2]*sp[k3,k4] - 56*sp[k1,k2]*sp[k3,k4]*m
       + 104*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m + 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,q]^
      2*m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 - 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ]*m^2 - 96*sp[k1,k2]*sp[k4,q]^2 + 40*sp[k1,k2]*sp[k4,q]^2*m - 4*
      sp[k1,k2]*sp[k4,q]^2*m^2 - 24*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3
      ]^2*sp[k2,k4]*m - 24*sp[k1,k3]^2*sp[k2,q]*m + 4*sp[k1,k3]^2*sp[k2
      ,q]*m^2 + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3
      ] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3]*m^2 - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 96*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 4*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 40*sp[k1,k3]
      *sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 48*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] + 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 4*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 24*sp[k1,k4]^2*sp[k2,k3] + 16*
      sp[k1,k4]^2*sp[k2,k3]*m - 24*sp[k1,k4]^2*sp[k2,q]*m + 4*sp[k1,k4]
      ^2*sp[k2,q]*m^2 - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k4]
      *sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 40*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2
       - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m + 48*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 4*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,k4]*sp[k2,
      q]*sp[k4,q] - 40*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[
      k2,q]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k3]^2 + 40*sp[k1,q]*sp[k2,
      k3]^2*m - 4*sp[k1,q]*sp[k2,k3]^2*m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4] - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m^2 - 104*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 48*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 4*sp[
      k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 12*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       + 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k4]^2 + 
      40*sp[k1,q]*sp[k2,k4]^2*m - 4*sp[k1,q]*sp[k2,k4]^2*m^2 - 104*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4] + 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 
      12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[
      k4,q]*m^2 - 176*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[4,3]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1
       - k2]]*den[sp[k1 - q]]*den[sp[ - k3 + q]]*den[sp[k3 + k4]]*num[
       - 40*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m + 40*sp[
      k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m + 104*sp[k1,k2]^2*
      sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 12*sp[k1,k2]*sp[k1,k3]*m
       + 80*sp[k1,k2]*sp[k1,k3]^2 - 40*sp[k1,k2]*sp[k1,k3]^2*m + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1
      ,q]*m + 112*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k3]*m + 104*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 8*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 8*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 104*sp[k1,k2]*sp[k1,k3]*sp[k3,q
      ] - 36*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 136*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 20*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1
      ,k4]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 24*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 72*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      88*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4]*m - 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 40*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k4,q]*m - 56*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3]*m - 88*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 24*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4]*m - 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 
      16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q
      ] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k1,q]*sp[
      k4,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k2,k3]
       + 12*sp[k1,k2]*sp[k2,k3]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 
      12*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,
      q] - 12*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k2,k4]
       - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,
      q]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k2]*sp[
      k2,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4] + 8*sp[k1,k2]*sp[k3,k4]
      *m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 4*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 20*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q]*m + 36*sp[k1,k2]*sp[k3,q] - 20*sp[k1,k2]*sp[k3,q]*m - 
      160*sp[k1,k2]*sp[k3,q]^2 + 68*sp[k1,k2]*sp[k3,q]^2*m - 32*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 24*sp[
      k1,k2]*sp[k4,q] - 16*sp[k1,k2]*sp[k4,q]*m + 72*sp[k1,k2]*sp[k4,q]
      ^2 - 28*sp[k1,k2]*sp[k4,q]^2*m + 80*sp[k1,k3]^2*sp[k2,k3] - 32*
      sp[k1,k3]^2*sp[k2,k3]*m - 16*sp[k1,k3]^2*sp[k2,k4] + 32*sp[k1,k3]
      ^2*sp[k2,k4]*m - 120*sp[k1,k3]^2*sp[k2,q] + 44*sp[k1,k3]^2*sp[k2,
      q]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m + 104*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,q]*m + 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       - 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,q] - 8*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k3]
       - 8*sp[k1,k3]*sp[k2,k3]*m - 72*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 28
      *sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 80*sp[k1,k3]*sp[k2,k3]*sp[k3,q]
       + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 24*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4
      ] + 16*sp[k1,k3]*sp[k2,k4]*m - 56*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 
      24*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 56*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 20*sp[k1,k3]*sp[k2
      ,q] + 12*sp[k1,k3]*sp[k2,q]*m - 56*sp[k1,k3]*sp[k2,q]^2 + 16*sp[
      k1,k3]*sp[k2,q]^2*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 4*sp[k1,
      k3]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 36*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       - 36*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k4]^2*sp[k2,k3] + 
      160*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]
      *sp[k2,q]*m + 40*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 24*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 24*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k4]*
      m - 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m + 32*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m + 56*
      sp[k1,k4]*sp[k2,q]^2 - 16*sp[k1,k4]*sp[k2,q]^2*m - 40*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 96*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q] + 36*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 40*
      sp[k1,k4]*sp[k2,q]*sp[k4,q] + 12*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 
      32*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]^2*sp[k2,k3]*m - 80*sp[k1,q]^
      2*sp[k2,k4] + 32*sp[k1,q]^2*sp[k2,k4]*m + 12*sp[k1,q]*sp[k2,k3]
       - 4*sp[k1,q]*sp[k2,k3]*m + 72*sp[k1,q]*sp[k2,k3]^2 - 28*sp[k1,q]
      *sp[k2,k3]^2*m + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 20*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1
      ,q]*sp[k2,k3]*sp[k2,q]*m - 40*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 12*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,k3]*sp[k3,q]
       - 44*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 12*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m + 4*sp[k1,q]*sp[k2,k4]*m - 56*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       + 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 120*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] - 44*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] + 12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 56*sp[k1,q]*sp[k2
      ,k4]*sp[k4,q] + 20*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,
      q]*sp[k2,q]*sp[k3,q] + 16*sp[k1,q]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1
      ,q]*sp[k2,q]*sp[k4,q] + 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + amp[4,
      4]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[
      sp[k3 + k4]]*den[sp[ - k4 + q]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16
      *sp[k1,k2]^2*sp[k3,k4]*m - 104*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2
      ]^2*sp[k3,q]*m - 40*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q
      ]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k1,k4]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 40*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 136*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q] - 40*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 12*sp[k1,k2
      ]*sp[k1,k4]*m - 80*sp[k1,k2]*sp[k1,k4]^2 + 40*sp[k1,k2]*sp[k1,k4]
      ^2*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k1,q]*m - 104*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3]*m - 112*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,k4]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 8*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]
       + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 136*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q] + 20*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 104*sp[k1,k2]*sp[
      k1,k4]*sp[k4,q] + 36*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 88*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 56*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 
      40*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m - 80*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k3
      ,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,q]*
      sp[k4,q]*m - 24*sp[k1,k2]*sp[k2,k3] + 48*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q] - 24*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k4
      ] - 12*sp[k1,k2]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 
      12*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,k2]*sp[k2,k4]*sp[k4,
      q] - 12*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 40*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 40*sp[k1,k2]*
      sp[k2,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2
      ]*sp[k3,k4] - 8*sp[k1,k2]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q] - 20*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q] - 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 24*sp[k1,k2]*
      sp[k3,q] + 16*sp[k1,k2]*sp[k3,q]*m - 72*sp[k1,k2]*sp[k3,q]^2 + 28
      *sp[k1,k2]*sp[k3,q]^2*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 8*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m - 36*sp[k1,k2]*sp[k4,q] + 20*sp[k1,k2]
      *sp[k4,q]*m + 160*sp[k1,k2]*sp[k4,q]^2 - 68*sp[k1,k2]*sp[k4,q]^2*
      m + 24*sp[k1,k3]^2*sp[k2,k4] - 104*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
       + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]
      *sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 160*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m
       - 48*sp[k1,k3]*sp[k2,k3] + 8*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 40*sp[
      k1,k3]*sp[k2,k4] - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 24*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 32*
      sp[k1,k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,q]*m - 56*sp[k1,k3]*sp[k2
      ,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m + 40*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] - 12*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 40*sp[k1,k3]*sp[k2,q]*
      sp[k3,q] - 12*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] - 36*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k4]^2*
      sp[k2,k3] - 32*sp[k1,k4]^2*sp[k2,k3]*m - 80*sp[k1,k4]^2*sp[k2,k4]
       + 32*sp[k1,k4]^2*sp[k2,k4]*m + 120*sp[k1,k4]^2*sp[k2,q] - 44*sp[
      k1,k4]^2*sp[k2,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 20*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3]*m - 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 4*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]
       + 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 56*sp[k1,k4]*sp[k2,k3] - 16*
      sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 24*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m + 56*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,
      q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k4] + 
      8*sp[k1,k4]*sp[k2,k4]*m + 72*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 28*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 80*sp[k1,k4]*sp[k2,k4]*sp[
      k4,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m + 20*sp[k1,k4]*sp[k2,q]
       - 12*sp[k1,k4]*sp[k2,q]*m + 56*sp[k1,k4]*sp[k2,q]^2 - 16*sp[k1,
      k4]*sp[k2,q]^2*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 4*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 112*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 36*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q]*m - 96*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 36*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 80*sp[k1,q]^2*sp[k2,k3] - 32*sp[
      k1,q]^2*sp[k2,k3]*m - 32*sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[
      k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4] + 20*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,q]*sp[k2,k3]*
      sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 120*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4] + 44*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 56*sp[k1,q]*
      sp[k2,k3]*sp[k3,q] - 20*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,
      q]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 12*sp[
      k1,q]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k4]*m - 72*sp[k1,q]*sp[k2,k4]^
      2 + 28*sp[k1,q]*sp[k2,k4]^2*m - 56*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 
      16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 40*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ] - 12*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 12*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m - 112*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 44*sp[k1,q]*sp[k2,k4]
      *sp[k4,q]*m - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[
      k2,q]*sp[k3,q]*m + 32*sp[k1,q]*sp[k2,q]*sp[k4,q] - 16*sp[k1,q]*
      sp[k2,q]*sp[k4,q]*m] + amp[4,5]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[
      sp[k3 + k4]]*num[32*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,
      q] - 16*sp[k1,k2]^2*sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 16*sp[
      k1,k2]^2*sp[k4,q]*m + 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 128*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 32*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 8*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[
      k1,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 80*
      sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*
      m^2 - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m - 256*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 144*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4
      ,q]*m - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 80*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 32*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 448*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 224*sp[k1
      ,k2]*sp[k3,k4]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2
       - 192*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 112*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 128*sp[k1,k3]^2*
      sp[k2,k4] + 48*sp[k1,k3]^2*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 160*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2
       + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] - 80*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 96*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*
      m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 128*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 8*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 320*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] - 176*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2 - 96*sp[k1,k4]^2*sp[k2,k3] + 32*sp[k1,k4]^2*sp[k2,
      k3]*m + 96*sp[k1,k4]^2*sp[k2,q] - 80*sp[k1,k4]^2*sp[k2,q]*m + 16*
      sp[k1,k4]^2*sp[k2,q]*m^2 - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]
       - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 80*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 96*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 224*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4] - 80*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m^2 + 192*sp[k1,q]*sp[k2,k3]^2 - 112*sp[k1,q]*
      sp[k2,k3]^2*m + 16*sp[k1,q]*sp[k2,k3]^2*m^2 - 32*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 192*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 256*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4] - 160*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m^2] + amp[4,6]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 + q]]*den[sp[k3 + 
      k4]]*num[ - 64*sp[k1,k2]^2*sp[k1,k3] + 32*sp[k1,k2]^2*sp[k1,k3]*m
       - 128*sp[k1,k2]^2*sp[k1,k4] + 64*sp[k1,k2]^2*sp[k1,k4]*m - 64*
      sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m - 64*sp[k1,k2]
      ^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k4,q] - 192*sp[k1,k2]*sp[k1,k3]
       + 80*sp[k1,k2]*sp[k1,k3]*m - 8*sp[k1,k2]*sp[k1,k3]*m^2 + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 
      64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k3]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k4]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,q]*m - 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 64
      *sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 288*sp[k1,k2]*sp[k1,k4] + 160*
      sp[k1,k2]*sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*m^2 + 128*sp[k1,k2
      ]*sp[k1,k4]*sp[k1,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m
       + 160*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 
      16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q
      ] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 112*sp[k1,k2]
      *sp[k3,k4] + 72*sp[k1,k2]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2
       - 64*sp[k1,k2]*sp[k3,q]^2 + 48*sp[k1,k2]*sp[k3,q]^2*m - 8*sp[k1,
      k2]*sp[k3,q]^2*m^2 + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 32*
      sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m + 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 64*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 256*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 
      128*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ]*m^2 - 64*sp[k1,k3]*sp[k2,k3] + 48*sp[k1,k3]*sp[k2,k3]*m - 8*sp[
      k1,k3]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,q]*m + 240*sp[k1,k3]*sp[k2,k4] - 136*sp[k1,
      k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k3
      ]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 8*sp[k1,
      k3]*sp[k2,q]*sp[k3,q]*m^2 - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 160
      *sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3]*m + 320*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 208*sp[k1,k4]*sp[k1,
      q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 176*sp[k1,k4
      ]*sp[k2,k3] + 88*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*
      m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 112*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1
      ,q]^2*sp[k2,k3] + 32*sp[k1,q]^2*sp[k2,k3]*m - 64*sp[k1,q]^2*sp[k2
      ,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k3]^2 + 16*
      sp[k1,q]*sp[k2,k3]^2*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 48
      *sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*
      m^2 + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[4,8
      ]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*
      den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[k3 + k4]]*num[ - 32*
      sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*
      sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 96*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 96*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] - 80*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 16*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 128*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 96*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 96*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q] - 144*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k2,k4]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 
      192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 112*sp[k1,k2]*sp[k3,k4]*sp[k3,
      q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 448*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 24*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m^2 + 96*sp[k1,k3]^2*sp[k2,k4] - 32*sp[k1,k3]^
      2*sp[k2,k4]*m - 96*sp[k1,k3]^2*sp[k2,q] + 80*sp[k1,k3]^2*sp[k2,q]
      *m - 16*sp[k1,k3]^2*sp[k2,q]*m^2 - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k3] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m
       - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 224*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q] - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       + 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 192*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 80*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 80*sp[k1,k3]
      *sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 128
      *sp[k1,k4]^2*sp[k2,k3] - 48*sp[k1,k4]^2*sp[k2,k3]*m - 96*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 128*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 64*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 80*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q]*m^2 - 320*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 176*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 
      32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ]*m^2 - 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 160*sp[k1,q]*sp[k2,k3]
      *sp[k3,k4]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 192*sp[k1,q]
      *sp[k2,k4]^2 + 112*sp[k1,q]*sp[k2,k4]^2*m - 16*sp[k1,q]*sp[k2,k4]
      ^2*m^2 - 192*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 112*sp[k1,q]*sp[k2,k4
      ]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[4,9]*
      color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[
      sp[k1 - q]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[128*sp[k1,k2]
      ^2*sp[k1,k3] - 64*sp[k1,k2]^2*sp[k1,k3]*m + 64*sp[k1,k2]^2*sp[k1,
      k4] - 32*sp[k1,k2]^2*sp[k1,k4]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*
      sp[k1,k2]^2*sp[k3,k4]*m + 32*sp[k1,k2]^2*sp[k3,q] + 64*sp[k1,k2]^
      2*sp[k4,q] + 288*sp[k1,k2]*sp[k1,k3] - 160*sp[k1,k2]*sp[k1,k3]*m
       + 16*sp[k1,k2]*sp[k1,k3]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q]
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 160*sp[k1,k2]
      *sp[k1,k3]*sp[k4,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 192*sp[
      k1,k2]*sp[k1,k4] - 80*sp[k1,k2]*sp[k1,k4]*m + 8*sp[k1,k2]*sp[k1,
      k4]*m^2 - 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 32*sp[k1,k2]*sp[k1,k4
      ]*sp[k1,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 192*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1
      ,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 
      128*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*
      m - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,
      k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m + 112*sp[k1,k2]*sp[k3,k4] - 72*sp[k1,k2]*sp[
      k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[
      k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k4,q]^2 - 48*sp[k1,k2]*sp[k4,q]^2*
      m + 8*sp[k1,k2]*sp[k4,q]^2*m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 320*sp[k1,k3]*sp[k1,
      q]*sp[k2,q] + 208*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k3]*
      sp[k1,q]*sp[k2,q]*m^2 + 176*sp[k1,k3]*sp[k2,k4] - 88*sp[k1,k3]*
      sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]
      *sp[k2,q]*sp[k4,q]*m^2 + 32*sp[k1,k4]^2*sp[k2,q] - 16*sp[k1,k4]^2
      *sp[k2,q]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 256*sp[k1,
      k4]*sp[k1,q]*sp[k2,q] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 240*sp[k1,k4]*sp[k2,k3] + 136*
      sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 + 128*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[
      k1,k4]*sp[k2,k4] - 48*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,
      k4]*m^2 - 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4
      ]*sp[k2,q]*m + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 64*sp[
      k1,k4]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 8*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 64*sp[k1,q]^2*sp[k2,k3] - 16*
      sp[k1,q]^2*sp[k2,k3]*m + 128*sp[k1,q]^2*sp[k2,k4] - 32*sp[k1,q]^2
      *sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]*sp[
      k2,k4]^2*m - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 128*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 
      16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[4,11]*color[ - 1/2*Ca*
      Cf*Na*Tf]*den[sp[k1 - q]]^2*den[sp[ - k2 - k3]]*den[sp[k3 + k4]]*
      num[32*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*m + 8*sp[k1,
      k2]*sp[k2,k3]*m^2 + 64*sp[k1,k2]*sp[k2,k4] - 64*sp[k1,k2]*sp[k2,
      k4]*m + 16*sp[k1,k2]*sp[k2,k4]*m^2 + 32*sp[k1,k2]*sp[k3,k4] - 32*
      sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 32*sp[k1,k3]*
      sp[k2,k3] - 32*sp[k1,k3]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k2,k3]*m^2
       + 32*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3
      ]*sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k4]*sp[k2,k3]
      *m - 16*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       + 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2
      ,q]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 64*sp[k1,q]*sp[k2,k3]*
      sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 128*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 
      128*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k2,q
      ]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[
      k2,q]*sp[k3,k4] + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m^2] + amp[4,12]*color[1/2*Ca*Cf*Na*Tf]*den[
      sp[k1 - q]]^2*den[sp[ - k2 - k4]]*den[sp[k3 + k4]]*num[ - 64*sp[
      k1,k2]*sp[k2,k3] + 64*sp[k1,k2]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k2,
      k3]*m^2 - 32*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m - 8*
      sp[k1,k2]*sp[k2,k4]*m^2 - 32*sp[k1,k2]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k3,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]
       - 64*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*m^2 - 32*sp[
      k1,k4]*sp[k2,k3] + 32*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,
      k3]*m^2 - 32*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k4]*sp[k2,k4]*m - 8*
      sp[k1,k4]*sp[k2,k4]*m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 128*
      sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*
      m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,
      k4]*sp[k2,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,q]*sp[
      k2,k4]*sp[k2,q]*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 128*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 
      64*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m
       + 16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m^2] + amp[4,13]*color[Ca*Cf*Na*Tf]*den[sp[k1 - q]]^2*
      den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[176*sp[k1,k2]*sp[k3,k4]
       - 136*sp[k1,k2]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k3,k4]*m^2 - 96*
      sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[
      k2,k3]*m^2 - 48*sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[k2,k4]*m + 8
      *sp[k1,k3]*sp[k2,k4]*m^2 - 48*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*
      sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k2,k4]
       + 64*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[k2,k4]*m^2 + 192*sp[
      k1,q]*sp[k2,k3]*sp[k3,q] - 128*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 16
      *sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m^2 + 96*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,q]*
      sp[k2,k4]*sp[k4,q] - 128*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1
      ,q]*sp[k2,k4]*sp[k4,q]*m^2 - 352*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 
      272*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m^2] + amp[4,14]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[
       - k2 - k3]]*den[sp[k3 + k4]]*den[sp[ - k4 + q]]*num[ - 16*sp[k1,
      k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,
      q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 48*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 
      160*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 96*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4] + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 48*sp[k1,k2]
      *sp[k1,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 48*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 
      16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m + 16*sp[k1,k2]*sp[k2,k3] - 16*sp[k1,k2]*sp[k2,k3]*m + 16*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 80*
      sp[k1,k2]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k2]
      *sp[k2,k4]*sp[k4,q] - 40*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 16*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 
      16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,k4] - 24*
      sp[k1,k2]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       - 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 144*sp[k1,k2]*sp[k3,q]^2
       - 96*sp[k1,k2]*sp[k3,q]^2*m + 16*sp[k1,k2]*sp[k3,q]^2*m^2 - 24*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2
       + 48*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^2*sp[k2,k4]*m + 48*sp[
      k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 112*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4] + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
       + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m + 80*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k3]*sp[k2,k3]*m + 80*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       + 16*sp[k1,k3]*sp[k2,k4] - 8*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 
      32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,q]^2 + 16*
      sp[k1,k3]*sp[k2,q]^2*m + 48*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 40*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2
       - 144*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 96*sp[k1,k3]*sp[k2,q]*sp[k3,
      q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 48*sp[k1,k3]*sp[k2,q]
      *sp[k4,q] + 40*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,
      q]*sp[k4,q]*m^2 + 128*sp[k1,k4]^2*sp[k2,k3] - 56*sp[k1,k4]^2*sp[
      k2,k3]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k3]*m - 48*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,k3]*m
       + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 56*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 56*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 48*sp[k1,k4]*sp[k2,q]^2 - 16*sp[
      k1,k4]*sp[k2,q]^2*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 32*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4]*m + 48*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       + 40*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 176*sp[k1,q]*
      sp[k2,k3]*sp[k3,q] + 112*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1
      ,q]*sp[k2,k3]*sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 8*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2
       - 128*sp[k1,q]*sp[k2,k4]^2 + 56*sp[k1,q]*sp[k2,k4]^2*m - 112*sp[
      k1,q]*sp[k2,k4]*sp[k2,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 128
      *sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 56*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4]*m] + amp[4,15]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[
      sp[ - k2 - k4]]*den[sp[ - k3 + q]]*den[sp[k3 + k4]]*num[16*sp[k1,
      k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,
      q] + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 96*sp[k1,
      k2]*sp[k1,k3]*sp[k3,k4] - 40*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16
      *sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]
      *sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[
      k1,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 48*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 48*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 
      16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m - 80*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m - 96*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,q] + 40*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k2,k4] + 16*sp[k1,k2]*sp[k2,k4]*m - 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,k4] + 24
      *sp[k1,k2]*sp[k3,k4]*m - 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 72*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*
      m + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 24*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 144*sp[k1,k2]*
      sp[k4,q]^2 + 96*sp[k1,k2]*sp[k4,q]^2*m - 16*sp[k1,k2]*sp[k4,q]^2*
      m^2 - 128*sp[k1,k3]^2*sp[k2,k4] + 56*sp[k1,k3]^2*sp[k2,k4]*m + 64
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
      *m + 112*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 48*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4] - 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 192*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 56*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       + 48*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 128*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 56*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m - 48*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m + 128
      *sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m
       - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q
      ]*m - 48*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m - 48*
      sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m - 32*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*
      sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 48*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 80*
      sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k4]*sp[k2,k4]*m - 80*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 48*sp[k1,k4
      ]*sp[k2,q]^2 - 16*sp[k1,k4]*sp[k2,q]^2*m - 48*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] + 40*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4]*m^2 + 48*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 40*sp[k1,k4]
      *sp[k2,q]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 144*
      sp[k1,k4]*sp[k2,q]*sp[k4,q] - 96*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 
      16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,k3]^2 - 
      56*sp[k1,q]*sp[k2,k3]^2*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 40*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 112*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       - 48*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 56*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2
      ,k4]*sp[k2,q] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 64*sp[
      k1,q]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 8*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 176*sp[k1,q]*sp[k2,k4]*sp[k4,q]
       - 112*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k4]*sp[
      k4,q]*m^2 + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]
      *sp[k3,k4]*m] + amp[4,16]*color[Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[k1 - q]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3
       + k4]]*num[352*sp[k1,k2]^2*sp[k3,k4] - 96*sp[k1,k2]^2*sp[k3,k4]*
      m - 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 96*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 352*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m
       + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m + 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*
      sp[k2,k4]*sp[k4,q]*m - 352*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 96*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4]*m + 656*sp[k1,k2]*sp[k3,k4] - 296*sp[k1
      ,k2]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[
      k3,q]^2 + 80*sp[k1,k2]*sp[k3,q]^2*m - 8*sp[k1,k2]*sp[k3,q]^2*m^2
       - 192*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,q]*sp[k4,
      q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 192*sp[k1,k2]*sp[k4,q
      ]^2 + 80*sp[k1,k2]*sp[k4,q]^2*m - 8*sp[k1,k2]*sp[k4,q]^2*m^2 - 96
      *sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m - 96*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 48*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       - 192*sp[k1,k3]*sp[k2,k3] + 80*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,
      k3]*sp[k2,k3]*m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,k4] - 8*sp[k1,k3]*sp[
      k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q] - 80*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2
      ,q]*sp[k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[
      k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 48*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 96*sp[
      k1,k4]*sp[k2,k3] - 8*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3
      ]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,k4] + 80*sp[k1,k4]*sp[k2,k4]*m
       - 8*sp[k1,k4]*sp[k2,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 
      16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,
      q]*m^2 + 192*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 80*sp[k1,k4]*sp[k2,q]*
      sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[
      k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m - 96*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,
      k3]*sp[k3,q] - 80*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,q]*sp[
      k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 96*
      sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m + 96*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,q]
      *sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 80*
      sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2
       - 704*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 368*sp[k1,q]*sp[k2,q]*sp[k3,
      k4]*m - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[5,1]*color[ - 1/
      4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k3]]*den[sp[ - k2
       + q]]*num[ - 32*sp[k1,k2]^2 + 16*sp[k1,k2]^2*m + 32*sp[k1,k2]*
      sp[k1,q] - 16*sp[k1,k2]*sp[k1,q]*m - 32*sp[k1,k2]*sp[k2,k3] + 16*
      sp[k1,k2]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k3,q] + 40*sp[k1,k2]*sp[
      k3,q]*m - 8*sp[k1,k2]*sp[k3,q]*m^2 - 48*sp[k1,k3]*sp[k2,q] + 40*
      sp[k1,k3]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,q]*m^2 + 80*sp[k1,q]*sp[
      k2,k3] - 56*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,q]*sp[k2,k3]*m^2] + 
      amp[5,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k3
      ]]*den[sp[ - k2 + q]]*num[32*sp[k1,k2]^2 - 16*sp[k1,k2]^2*m - 32*
      sp[k1,k2]*sp[k1,q] + 16*sp[k1,k2]*sp[k1,q]*m + 32*sp[k1,k2]*sp[k2
      ,k3] - 16*sp[k1,k2]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k3,q] - 40*sp[
      k1,k2]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,q]*m^2 + 48*sp[k1,k3]*sp[k2
      ,q] - 40*sp[k1,k3]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k2,q]*m^2 - 80*sp[
      k1,q]*sp[k2,k3] + 56*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,q]*sp[k2,k3]*
      m^2] + amp[5,2]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k3]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*num[ - 32*sp[
      k1,k2]^2*sp[k1,k3] + 16*sp[k1,k2]^2*sp[k1,k3]*m - 64*sp[k1,k2]^2*
      sp[k1,k4] + 32*sp[k1,k2]^2*sp[k1,k4]*m - 80*sp[k1,k2]^2*sp[k3,k4]
       + 16*sp[k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,q]*m - 8*sp[
      k1,k2]^2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,k2]*sp[k1
      ,k3]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k1,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 144*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 24*
      sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*
      m^2 - 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k4]*m + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]
      *m + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 24*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 24*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*
      m^2 - 80*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[
      k3,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 24*sp[k1,k2]*sp[k3,k4] + 12*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 64*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       - 32*sp[k1,k2]*sp[k3,q]^2 + 24*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,
      k2]*sp[k3,q]^2*m^2 + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 24*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*
      sp[k1,k3]^2*sp[k2,q] + 8*sp[k1,k3]^2*sp[k2,q]*m - 4*sp[k1,k3]^2*
      sp[k2,q]*m^2 + 176*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 72*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 24*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*
      m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,q]
      *sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 
      112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ]*m + 56*sp[k1,k3]*sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4]*m - 64*sp[
      k1,k3]*sp[k2,k4]^2 + 24*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 144*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 
      48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 80*sp[
      k1,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q]*m - 128*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3]*m^2 - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 96*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 
      56*sp[k1,k4]*sp[k2,k3] + 20*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k4]*
      sp[k2,k3]^2 - 8*sp[k1,k4]*sp[k2,k3]^2*m + 64*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 144*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 
      80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m + 80*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m - 64*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*m
       - 32*sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m - 8*sp[k1,q
      ]*sp[k2,k3]^2*m + 4*sp[k1,q]*sp[k2,k3]^2*m^2 + 8*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q
      ]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 32*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 
      4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 32*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,q]*sp[
      k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[5,4]*
      color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k3]]*den[
      sp[ - k2 + q]]*den[sp[ - k4 + q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1
      ,k2]^2*sp[k2,k4] - 32*sp[k1,k2]^2*sp[k2,k4]*m - 32*sp[k1,k2]^2*
      sp[k2,q] + 16*sp[k1,k2]^2*sp[k2,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m
       + 16*sp[k1,k2]^2*sp[k3,q]*m - 80*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1
      ,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k3] - 8*sp[k1,k2]*sp[k1,k3
      ]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 32*sp[k1,k2]
      *sp[k1,k4] - 24*sp[k1,k2]*sp[k1,k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k4]*m + 144*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 48*sp[k1,k2]
      *sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k1,q] + 8*sp[k1,k2]*sp[k1,q]*m - 16*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 8*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m
       - 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k1,q]*sp[
      k4,q] + 24*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]
      *m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k2,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 80*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k2,
      k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       + 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k3,
      q]*m^2 + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[k1,k2]*sp[k3,k4]*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 4*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3
      ,q] + 8*sp[k1,k2]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k3,q]^2 - 24*sp[k1
      ,k2]*sp[k3,q]^2*m + 4*sp[k1,k2]*sp[k3,q]^2*m^2 - 128*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 48*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k1,q]*sp[
      k2,q] + 24*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,k3]*sp[k2,k3]*m
       - 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 40*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4] + 80*sp[k1,k3]*sp[
      k2,k4]^2 - 32*sp[k1,k3]*sp[k2,k4]^2*m - 176*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] + 72*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k3]
      *sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 32*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,q] - 8*sp[k1,k3]
      *sp[k2,q]*m + 32*sp[k1,k3]*sp[k2,q]^2 + 8*sp[k1,k3]*sp[k2,q]^2*m
       - 4*sp[k1,k3]*sp[k2,q]^2*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3
      ,k4]*m^2 - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,q]
      *sp[k3,q]*m^2 - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 64*sp[k1,k4]^2*
      sp[k2,q] + 24*sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2
      ,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k1,
      q]*sp[k2,k4] - 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k4]*
      sp[k1,q]*sp[k2,q] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 96*sp[k1,k4
      ]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]^2
       - 8*sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 24*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4]*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,q]^2*sp[k2,k3]*m + 4*sp[
      k1,q]^2*sp[k2,k3]*m^2 - 32*sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*
      sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m
       + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 24*sp[k1,q]*sp[k2,
      k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 16*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 32*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 
      4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ] - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 144*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 32*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[5,5]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[
       - k2 - k4]]*den[sp[ - k2 + q]]*num[128*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,k4] - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,
      k3]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 
      256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 288*sp[k1,k3]*sp[k2,k3]*sp[k4,
      q]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q]*m^3 + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]
      *sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 8*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] - 160*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2 - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^3] + amp[5,6]*
      color[ - Cf^2*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 + q]]^2*num[
       - 64*sp[k1,k3]*sp[k2,k3] + 96*sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,
      k3]*sp[k2,k3]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*m^3 + 128*sp[k1,k3]*sp[
      k2,q]*sp[k3,q] - 192*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k3]
      *sp[k2,q]*sp[k3,q]*m^2 - 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^3] + 
      amp[5,7]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - 
      k2 + q]]*den[sp[ - k4 + q]]*num[64*sp[k1,k3]*sp[k2,k3] - 64*sp[k1
      ,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 
      64*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,
      q]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,k3]
      *sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 
      128*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 64*sp[k1,k3]*sp[k2,q]*
      sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2] + amp[5,8]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*num[
       - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[
      k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^2*
      sp[k4,q] - 64*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]^2*sp[k4,q]*
      m^2 + 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 128
      *sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
      *m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 
      16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m^2
       + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4]*m + 256*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 64*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m^2 - 896*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 608*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*
      m^2 + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^3 + 256*sp[k1,k3]^2*sp[k2,
      q] - 128*sp[k1,k3]^2*sp[k2,q]*m + 16*sp[k1,k3]^2*sp[k2,q]*m^2 + 
      64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
      *m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 96*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4
      ]*m^2 - 640*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 416*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 64*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2
       + 640*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 480*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m + 112*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 128*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2
       + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,
      k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 256*sp[k1,k4]*sp[k2
      ,k3]^2 + 128*sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2,k3]^2*
      m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 128*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 128*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 
      16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 640*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 480*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^3] + amp[5,9
      ]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[
      k1 + k4]]*den[sp[ - k2 + q]]^2*num[ - 64*sp[k1,k2]*sp[k1,k3] + 64
      *sp[k1,k2]*sp[k1,k3]*m - 16*sp[k1,k2]*sp[k1,k3]*m^2 - 64*sp[k1,k2
      ]*sp[k1,k4] + 64*sp[k1,k2]*sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*
      m^2 - 128*sp[k1,k2]*sp[k3,k4] + 144*sp[k1,k2]*sp[k3,k4]*m - 48*
      sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,
      k3]*sp[k1,q]*sp[k2,q] - 128*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 80*sp[
      k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[
      k2,k4]*m^3 - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 160*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m^3 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 128
      *sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*
      m^2 + 64*sp[k1,k4]*sp[k2,k3] - 80*sp[k1,k4]*sp[k2,k3]*m + 32*sp[
      k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] + 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 
      256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 288*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^3] + amp[5,10]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf
      ]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[ - 
      k3 + q]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*
      m + 32*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,
      k2]^2*sp[k4,q]*m + 96*sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3
      ]*m - 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 48*
      sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q]*m^2 - 32*sp[k1,k2]*sp[k1,k4] + 16*sp[k1,k2]*sp[k1,k4]*m - 
      96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1
      ,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 
      96*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 80*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 256*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4] + 144*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*
      sp[k2,k3]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 80*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k3,
      k4] - 64*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 448*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 192*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q]*m^2 - 128*sp[k1,k3]^2*sp[k2,q] + 48*sp[k1,k3]^2*sp[
      k2,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 
      160*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q]*
      m + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 80*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,
      k3]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k3
      ]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4
      ]*sp[k2,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m^2 - 320*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 176*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2
       - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k3]*sp[k2,q]*sp[k3
      ,k4]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 32*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4
      ]*sp[k1,q]*sp[k2,q] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q]*m^2 - 160*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,
      k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 192*sp[k1,k4]*sp[k2
      ,k3]^2 - 112*sp[k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]*sp[k2,k3]^2*
      m^2 + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m^2 - 192*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 112*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 256*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,q]^2*sp[k2,k3]
       - 32*sp[k1,q]^2*sp[k2,k3]*m + 96*sp[k1,q]^2*sp[k2,k4] - 80*sp[k1
      ,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2*sp[k2,k4]*m^2 - 64*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 192*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 8*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k3
      ,q] - 80*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 - 224*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[5,11
      ]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[
      k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*
      num[256*sp[k1,k2]^2 - 160*sp[k1,k2]^2*m + 16*sp[k1,k2]^2*m^2 + 
      128*sp[k1,k2]^3 - 64*sp[k1,k2]^3*m + 128*sp[k1,k2]^2*sp[k1,k3] - 
      64*sp[k1,k2]^2*sp[k1,k3]*m - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,
      k2]^2*sp[k1,q]*m + 128*sp[k1,k2]^2*sp[k2,k3] - 64*sp[k1,k2]^2*sp[
      k2,k3]*m - 128*sp[k1,k2]^2*sp[k2,q] + 64*sp[k1,k2]^2*sp[k2,q]*m
       - 256*sp[k1,k2]^2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k3,q]*m + 256*sp[
      k1,k2]*sp[k1,k3] - 160*sp[k1,k2]*sp[k1,k3]*m + 16*sp[k1,k2]*sp[k1
      ,k3]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 64*sp[k1,k2]*sp[k1,
      k3]*sp[k1,q]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 192*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m^2 + 
      128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 128*sp[k1,k2]*sp[k1,k3]*sp[k3,
      q] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 256*sp[k1,k2]*
      sp[k1,q]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,
      k2]*sp[k1,q]*sp[k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 96*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*
      m^2 + 256*sp[k1,k2]*sp[k2,k3] - 160*sp[k1,k2]*sp[k2,k3]*m + 16*
      sp[k1,k2]*sp[k2,k3]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 64*
      sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,q]
       - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[
      k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 96*sp[k1,k2]*sp[k2,
      q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 1024*sp[k1,
      k2]*sp[k3,q]^2 + 704*sp[k1,k2]*sp[k3,q]^2*m - 144*sp[k1,k2]*sp[k3
      ,q]^2*m^2 + 8*sp[k1,k2]*sp[k3,q]^2*m^3 - 128*sp[k1,k3]^2*sp[k2,q]
       + 96*sp[k1,k3]^2*sp[k2,q]*m - 16*sp[k1,k3]^2*sp[k2,q]*m^2 + 128*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m
       + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k1,q]*
      sp[k2,q] + 96*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,
      q]*sp[k2,q]*m^2 - 1024*sp[k1,k3]*sp[k2,k3] + 704*sp[k1,k3]*sp[k2,
      k3]*m - 144*sp[k1,k3]*sp[k2,k3]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*m^3
       + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 128*sp[k1,k3]*sp[
      k2,q]^2 - 96*sp[k1,k3]*sp[k2,q]^2*m + 16*sp[k1,k3]*sp[k2,q]^2*m^2
       + 1024*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 704*sp[k1,k3]*sp[k2,q]*sp[
      k3,q]*m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k3]*sp[k2
      ,q]*sp[k3,q]*m^3 + 128*sp[k1,q]^2*sp[k2,k3] - 96*sp[k1,q]^2*sp[k2
      ,k3]*m + 16*sp[k1,q]^2*sp[k2,k3]*m^2 - 128*sp[k1,q]*sp[k2,k3]^2
       + 96*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]^2*m^2 - 128*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] + 96*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 
      16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 1024*sp[k1,q]*sp[k2,k3]*sp[
      k3,q] - 704*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 144*sp[k1,q]*sp[k2,k3
      ]*sp[k3,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^3] + amp[5,12]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[
       - 64*sp[k1,k2]^2 - 64*sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[
      k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 64*sp[k1,k2]^2*sp[k3,q]
       - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1
      ,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,k3]
      *sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 64*sp[k1,k2]*
      sp[k1,k4] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
      *m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k4]*m + 256*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 
      256*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 128*sp[k1,k2]*sp[k1,q]*sp[k4,q]
      *m + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k2,k3]
       + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4
      ,q]*m - 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k2]*sp[k2,k4]
      *sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 
      128*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q
      ]*m^2 - 608*sp[k1,k2]*sp[k3,k4] + 368*sp[k1,k2]*sp[k3,k4]*m - 72*
      sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 896*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] - 608*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 352*sp[
      k1,k3]*sp[k2,k4] - 240*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2
      ,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 256*sp[k1,k3]*sp[k2,q
      ]^2 + 128*sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*sp[k2,q]^2*m^2 - 
      256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]
      *m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q]*m^2 + 544*sp[k1,k4]*sp[k2,k3] - 368*sp[k1,
      k4]*sp[k2,k3]*m + 72*sp[k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,
      k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 96*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 640*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 480*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 112*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^3 - 256*sp[k1,q]^2*sp[k2,k4] + 128*sp[k1,q]^2*sp[k2,k4]*m - 16*
      sp[k1,q]^2*sp[k2,k4]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,q]*m^2 - 640*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 480*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m - 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^3 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m^2 + 640*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 416*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m^3] + amp[5,13]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 + q]]*
      den[sp[ - k3 - k4]]*num[64*sp[k1,k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2
      *sp[k1,k3]*m + 128*sp[k1,k2]^2*sp[k1,k4] - 64*sp[k1,k2]^2*sp[k1,
      k4]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*sp[k3,k4]*m + 
      64*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k4,q] + 192*sp[k1,k2]
      *sp[k1,k3] - 80*sp[k1,k2]*sp[k1,k3]*m + 8*sp[k1,k2]*sp[k1,k3]*m^2
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1
      ,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]
      *sp[k2,k3]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 192*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 288*sp[k1,k2]*sp[k1,k4]
       - 160*sp[k1,k2]*sp[k1,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*m^2 - 128*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m
       + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m - 160*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q]*m - 160*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 48*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 112*sp[
      k1,k2]*sp[k3,k4] - 72*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,
      k4]*m^2 + 64*sp[k1,k2]*sp[k3,q]^2 - 48*sp[k1,k2]*sp[k3,q]^2*m + 8
      *sp[k1,k2]*sp[k3,q]^2*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2
       + 32*sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 32*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m
       - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 256*sp[k1,k3]*sp[k1,q]*sp[k2
      ,q] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k3] - 48*sp[k1,k3]*sp[k2,k3]*m
       + 8*sp[k1,k3]*sp[k2,k3]*m^2 - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 
      16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 240*sp[k1,k3]*sp[k2,k4] + 136
      *sp[k1,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*m^2 + 128*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 64*
      sp[k1,k3]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 
      8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 256*sp[k1,k3]*sp[k2,q]*sp[k4,
      q] - 160*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m^2 + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 320*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 208*sp[k1,
      k4]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 
      176*sp[k1,k4]*sp[k2,k3] - 88*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*
      sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 112*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2
       + 128*sp[k1,q]^2*sp[k2,k3] - 32*sp[k1,q]^2*sp[k2,k3]*m + 64*sp[
      k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2
      ,k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2*m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]*
      sp[k3,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k3
      ]*sp[k3,q]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2] + amp[5,14]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*den[sp[ - k4
       + q]]*num[ - 64*sp[k1,k2]^2 + 32*sp[k1,k2]^2*m + 128*sp[k1,k2]^2
      *sp[k2,k4] - 64*sp[k1,k2]^2*sp[k2,k4]*m - 64*sp[k1,k2]^2*sp[k2,q]
       + 32*sp[k1,k2]^2*sp[k2,q]*m - 32*sp[k1,k2]^2*sp[k3,k4] + 64*sp[
      k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[
      k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 32*sp[k1,k2]*sp[k1,k3]*m + 160
      *sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
      *m - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 
      64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
      *m + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2
      ,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,
      k3] + 32*sp[k1,k2]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k2,k4
      ] - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*
      sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,
      k2]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 64*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 160*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q
      ]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 64*
      sp[k1,k2]*sp[k3,q]^2 - 48*sp[k1,k2]*sp[k3,q]^2*m + 8*sp[k1,k2]*
      sp[k3,q]^2*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 48*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 128*sp[k1,k3]*sp[k2,k3] - 96*sp[
      k1,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k2,k3]*m^2 - 320*sp[k1,k3]*
      sp[k2,k3]*sp[k2,k4] + 208*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,q] - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]
      *sp[k2,q]*m^2 + 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 32*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       + 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 32*sp[k1,k3]*sp[
      k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m - 256*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] + 160*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k3]*
      sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 32*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 
      64*sp[k1,k4]*sp[k2,k3]^2 - 16*sp[k1,k4]*sp[k2,k3]^2*m - 64*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 16*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,
      q]^2*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,q]*sp[k2,
      k3]^2*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]
      *sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,q]*sp[k2
      ,k3]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 48*sp[
      k1,q]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2]
       + amp[5,15]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*den[sp[ - k3 + q]]
      *num[32*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*
      sp[k3,k4]*m + 32*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k4,q]
       + 16*sp[k1,k2]^2*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 96*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q] - 80*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
       + 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m - 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,q]*
      sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1
      ,q]*sp[k3,k4]*m - 256*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 144*sp[k1,k2]
      *sp[k1,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 + 32*
      sp[k1,k2]*sp[k2,k3] - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2
       + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 128*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 
      272*sp[k1,k2]*sp[k3,k4] - 104*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]
      *sp[k3,k4]*m^2 + 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 112*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 448
      *sp[k1,k2]*sp[k3,q]*sp[k4,q] + 224*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 48*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4
      ]*m^2 + 160*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k3]
      *sp[k2,q]*m + 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 144*
      sp[k1,k3]*sp[k2,k4] + 72*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[
      k2,k4]*m^2 - 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 256*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k3]*sp[k2,q]^2 - 48*
      sp[k1,k3]*sp[k2,q]^2*m - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 48*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2
       + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,
      q]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 80*sp[k1,k4]*sp[k1
      ,q]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 240*sp[k1,
      k4]*sp[k2,k3] + 104*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]
      *m^2 + 96*sp[k1,k4]*sp[k2,k3]^2 - 80*sp[k1,k4]*sp[k2,k3]^2*m + 16
      *sp[k1,k4]*sp[k2,k3]^2*m^2 + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 
      8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] + 80*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m^2 + 320*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 176*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 192*
      sp[k1,q]^2*sp[k2,k4] - 112*sp[k1,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2
      *sp[k2,k4]*m^2 - 96*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,q]*sp[k2,k3]^
      2*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k3]
      *sp[k2,q]*m - 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4]*m + 192*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 192*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 256*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m^2] + amp[5,16]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[ - k2 + q]]^2*den[sp[ - k3 - k4]]*num[32*sp[k1,k2]*
      sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m + 8*sp[k1,k2]*sp[k1,k3]*m^2
       + 64*sp[k1,k2]*sp[k1,k4] - 64*sp[k1,k2]*sp[k1,k4]*m + 16*sp[k1,
      k2]*sp[k1,k4]*m^2 + 32*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,
      k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ] + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k3]*sp[k2,k3]*m + 8
      *sp[k1,k3]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k3]*
      sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,q]*
      sp[k3,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,
      q]*sp[k3,q]*m^2 + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 128*sp[k1,k3]
      *sp[k2,q]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m
       - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 32*sp[k1,k4]*sp[k2,k3] - 
      32*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 
      64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m^2] + amp[6,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k4]]*den[sp[ - k2 + q]]*num[64*sp[k1,k2]^2 - 32*sp[k1,k2]
      ^2*m - 64*sp[k1,k2]*sp[k1,q] + 32*sp[k1,k2]*sp[k1,q]*m + 64*sp[k1
      ,k2]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k4,q]
       - 80*sp[k1,k2]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k4,q]*m^2 + 96*sp[k1
      ,k4]*sp[k2,q] - 80*sp[k1,k4]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,q]*
      m^2 - 160*sp[k1,q]*sp[k2,k4] + 112*sp[k1,q]*sp[k2,k4]*m - 16*sp[
      k1,q]*sp[k2,k4]*m^2] + amp[6,2]*color[1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]
      *num[64*sp[k1,k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2*sp[k1,k3]*m + 32*
      sp[k1,k2]^2*sp[k1,k4] - 16*sp[k1,k2]^2*sp[k1,k4]*m + 80*sp[k1,k2]
      ^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m + 8*sp[k1,k2]^2*sp[k3,q
      ]*m + 16*sp[k1,k2]^2*sp[k4,q]*m + 80*sp[k1,k2]*sp[k1,k3] - 32*sp[
      k1,k2]*sp[k1,k3]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 32*sp[k1,
      k2]*sp[k1,k3]*sp[k1,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k4
      ] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 48*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 4*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k1,k4] - 16*sp[k1,k2
      ]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k1,q]*m - 144*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k4,q] - 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[
      k1,k4]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       + 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k4,
      q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q]*m^2 - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,
      k2]*sp[k2,k4]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*
      m^2 + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m + 24*sp[k1,k2]*sp[k3,k4] - 12*sp[k1,k2]*sp[k3,k4]*m - 64
      *sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m - 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[
      k4,q]^2 - 24*sp[k1,k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2
       - 80*sp[k1,k3]^2*sp[k2,q] + 32*sp[k1,k3]^2*sp[k2,q]*m - 176*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] + 72*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 16*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 40*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*
      sp[k1,q]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 64*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 80
      *sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       + 56*sp[k1,k3]*sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1,
      k3]*sp[k2,k4]^2 + 8*sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 144*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 80*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m
       - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,q]*sp[k4,q
      ]*m - 32*sp[k1,k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m + 4*sp[
      k1,k4]^2*sp[k2,q]*m^2 - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[
      k2,q] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 56*sp[k1,k4]*sp[k2,k3]
       + 20*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k2,k3]^2 - 24*sp[k1
      ,k4]*sp[k2,k3]^2*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*
      m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m - 144*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 112
      *sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,
      q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,q
      ]*sp[k4,q]*m^2 + 32*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]^2*sp[k2,k3]
      *m + 64*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m - 8*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2
       + 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 8*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m + 8*sp[k1,q]*sp[k2,k4]^2*m - 4*sp[k1,q]*sp[k2,k4]^2*m^2
       - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 - 32*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2
      ,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,q]
      *sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[6,3
      ]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[
      sp[ - k2 + q]]*den[sp[ - k3 + q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1
      ,k2]^2*sp[k2,k3] - 32*sp[k1,k2]^2*sp[k2,k3]*m - 32*sp[k1,k2]^2*
      sp[k2,q] + 16*sp[k1,k2]^2*sp[k2,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m
       - 80*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[k1
      ,k2]^2*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,k2]*sp[k1,
      k3]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]
      *sp[k2,k3]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 144*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k1,k4] - 8*sp[
      k1,k2]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       - 16*sp[k1,k2]*sp[k1,q] + 8*sp[k1,k2]*sp[k1,q]*m + 80*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 8*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       + 24*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k4,
      q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k3]
      *sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*
      sp[k2,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k2,k4]*m - 32
      *sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m
       - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,k4]*m - 80*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]
      *sp[k3,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 24*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k4,
      q] + 8*sp[k1,k2]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k4,q]^2 - 24*sp[k1,
      k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 - 64*sp[k1,k3]^2*
      sp[k2,q] + 24*sp[k1,k3]^2*sp[k2,q]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,k4]
      *sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 24*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 8*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]
       - 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m - 96*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m + 32*
      sp[k1,k3]*sp[k2,k4]^2 - 8*sp[k1,k3]*sp[k2,k4]^2*m - 48*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 32*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m
       - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m + 144*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 16*sp[
      k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[k2,k3]^2 - 32*sp[k1,k4]*sp[k2,
      k3]^2*m - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 40*sp[k1,k4]*sp[k2,
      k3]*sp[k2,k4]*m - 176*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 72*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 80*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q]*m + 32*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k4]*m + 96*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m + 16*sp[k1,k4]*sp[k2,q] - 8*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1
      ,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m - 4*sp[k1,k4]*sp[k2,q]
      ^2*m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]
      *sp[k2,q]*sp[k4,q]*m^2 - 32*sp[k1,q]^2*sp[k2,k3] + 8*sp[k1,q]^2*
      sp[k2,k3]*m - 8*sp[k1,q]^2*sp[k2,k4]*m + 4*sp[k1,q]^2*sp[k2,k4]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 144*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*
      sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m - 24*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2
       + 96*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k4]*sp[
      k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 112*sp[k1,q]*sp[k2,
      q]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[6,5]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[
       - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[
      k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*
      sp[k3,q]*m^2 + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*
      m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m^2 - 128*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 256*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 - 256*sp[k1,k2]*sp[k1,k4]*sp[k4,
      q] + 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 
      64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m + 256*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4] + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,q
      ]*sp[k3,k4]*m^2 - 896*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 608*sp[k1,k2
      ]*sp[k3,k4]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 8
      *sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,
      q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m^2 - 256*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*
      sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 256*sp[k1,k3]
      *sp[k2,k4]*sp[k4,q] - 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 256*sp[k1,k4]^2*sp[k2,q] - 128*
      sp[k1,k4]^2*sp[k2,q]*m + 16*sp[k1,k4]^2*sp[k2,q]*m^2 - 128*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3] + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4
      ]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 640*sp[k1,k4]*sp[k2,k3]*sp[k4,
      q] - 480*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 112*sp[k1,k4]*sp[k2,k3]
      *sp[k4,q]*m^2 - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^3 - 640*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q] + 416*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 96*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m^3 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 128*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 640*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
       - 480*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^3] + amp[6,6]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1
       + k4]]*den[sp[ - k2 + q]]^2*num[ - 64*sp[k1,k2]*sp[k1,k3] + 64*
      sp[k1,k2]*sp[k1,k3]*m - 16*sp[k1,k2]*sp[k1,k3]*m^2 - 64*sp[k1,k2]
      *sp[k1,k4] + 64*sp[k1,k2]*sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*
      m^2 - 128*sp[k1,k2]*sp[k3,k4] + 144*sp[k1,k2]*sp[k3,k4]*m - 48*
      sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,
      k3]*sp[k1,q]*sp[k2,q] - 128*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 80*sp[
      k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[
      k2,k4]*m^3 - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 160*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m^3 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 128
      *sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*
      m^2 + 64*sp[k1,k4]*sp[k2,k3] - 80*sp[k1,k4]*sp[k2,k3]*m + 32*sp[
      k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] + 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 
      256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 288*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^3] + amp[6,7]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[ - 
      k4 + q]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*
      m + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m + 32*sp[
      k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,k2]*sp[k1,
      k3]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 48*sp[k1,k2]*sp[k1,k3]
      *sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 48*sp[k1,k2]*sp[
      k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k1,k4] - 32*sp[k1,k2]*
      sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k1
      ,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] + 80*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 
      16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 96*sp[k1,k2]*sp[k1,q]*sp[k4,
      q] + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q] - 256*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 144*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 32*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 80*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k3,
      k4] - 64*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 448*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 192*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 48*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 - 160*sp[k1,k3]*sp[k2,k4
      ] + 80*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 + 192*
      sp[k1,k3]*sp[k2,k4]^2 - 112*sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3
      ]*sp[k2,k4]^2*m^2 + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 - 192*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 
      112*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 + 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 160*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]
      ^2*sp[k2,q] + 48*sp[k1,k4]^2*sp[k2,q]*m + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 160*sp[
      k1,k4]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 32*
      sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[
      k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 80*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 64*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 320*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q] + 176*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 96*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 
      128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4
      ]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,q]^2*sp[k2
      ,k3] - 80*sp[k1,q]^2*sp[k2,k3]*m + 16*sp[k1,q]^2*sp[k2,k3]*m^2 + 
      96*sp[k1,q]^2*sp[k2,k4] - 32*sp[k1,q]^2*sp[k2,k4]*m - 64*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 96*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 192*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ] + 80*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m - 224*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[6
      ,8]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]^2*
      den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*num[128*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,k4] - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 160*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*
      m^2 - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k2,k4
      ]*sp[k2,q] + 128*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q]*m^2 - 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 288*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*
      m^2 + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[k1,k4]*sp[k2,q]
      *sp[k3,k4] - 160*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^3] + 
      amp[6,9]*color[ - Cf^2*Na*Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2 + q
      ]]^2*num[ - 64*sp[k1,k4]*sp[k2,k4] + 96*sp[k1,k4]*sp[k2,k4]*m - 
      48*sp[k1,k4]*sp[k2,k4]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*m^3 + 128*sp[
      k1,k4]*sp[k2,q]*sp[k4,q] - 192*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 96
      *sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]
      *m^3] + amp[6,10]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]^2*
      den[sp[ - k2 + q]]*den[sp[ - k3 + q]]*num[ - 128*sp[k1,k4]*sp[k2,
      k3]*sp[k2,k4] + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 64*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*
      m^2 + 64*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k4]*sp[k2,k4]*m + 16*sp[
      k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 64*sp[k1
      ,k4]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2
       + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4] + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]
      *sp[k2,q]*sp[k3,k4]*m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 64*sp[
      k1,k4]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2]
       + amp[6,11]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k2
       + q]]*num[ - 64*sp[k1,k2]^2 - 64*sp[k1,k2]^2*sp[k3,k4] + 64*sp[
      k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 64*sp[k1,k2
      ]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^2*sp[k4,q
      ] - 32*sp[k1,k2]^2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 64*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k4,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 
      32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4]*m + 256*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64
      *sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m^2 + 256*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 128*sp[k1,k2]*sp[k1,q]*
      sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 128*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k2,k4] + 64*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,q]*
      sp[k4,q] - 128*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2
      ,q]*sp[k4,q]*m^2 - 608*sp[k1,k2]*sp[k3,k4] + 368*sp[k1,k2]*sp[k3,
      k4]*m - 72*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 
      896*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 608*sp[k1,k2]*sp[k3,q]*sp[k4,q]
      *m + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 128*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2
      ,q]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 544*sp[k1,k3]*sp[k2,
      k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*
      sp[k1,k3]*sp[k2,k4]*m^3 - 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 96*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*
      m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m^3 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 352*sp[k1,k4]*sp[k2,k3] - 240*sp[k1
      ,k4]*sp[k2,k3]*m + 56*sp[k1,k4]*sp[k2,k3]*m^2 - 4*sp[k1,k4]*sp[k2
      ,k3]*m^3 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m - 256*sp[k1,k4]*sp[k2,q]^2 + 128*sp[k1,k4]*sp[k2,q
      ]^2*m - 16*sp[k1,k4]*sp[k2,q]^2*m^2 - 256*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m^2 - 256*sp[k1,q]^2*sp[k2,k3] + 128*sp[k1,q]^2*sp[k2,
      k3]*m - 16*sp[k1,q]^2*sp[k2,k3]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m^2 - 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 64*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*
      m^2 - 640*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m^3 + 640*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 416*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[6,12]*color[ - Cf^2*Na*Tf
       + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1
       - q]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[256*sp[k1,k2]^2
       - 160*sp[k1,k2]^2*m + 16*sp[k1,k2]^2*m^2 + 128*sp[k1,k2]^3 - 64*
      sp[k1,k2]^3*m + 128*sp[k1,k2]^2*sp[k1,k4] - 64*sp[k1,k2]^2*sp[k1,
      k4]*m - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,k2]^2*sp[k1,q]*m + 
      128*sp[k1,k2]^2*sp[k2,k4] - 64*sp[k1,k2]^2*sp[k2,k4]*m - 128*sp[
      k1,k2]^2*sp[k2,q] + 64*sp[k1,k2]^2*sp[k2,q]*m - 256*sp[k1,k2]^2*
      sp[k4,q] + 64*sp[k1,k2]^2*sp[k4,q]*m + 256*sp[k1,k2]*sp[k1,k4] - 
      160*sp[k1,k2]*sp[k1,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*m^2 - 128*sp[
      k1,k2]*sp[k1,k4]*sp[k1,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 
      256*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 192*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m^2 + 128*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q] + 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 96*sp[k1,k2]
      *sp[k1,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 128
      *sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 256*sp[k1,k2]*sp[k1,q]*sp[k2,q]
       + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,
      q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 + 256*sp[k1,k2
      ]*sp[k2,k4] - 160*sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*
      m^2 - 128*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k2,k4]*
      sp[k2,q]*m + 128*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 96*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 - 128*sp[
      k1,k2]*sp[k2,q]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2 - 1024*sp[k1,k2]*sp[k4,q]^2 + 704
      *sp[k1,k2]*sp[k4,q]^2*m - 144*sp[k1,k2]*sp[k4,q]^2*m^2 + 8*sp[k1,
      k2]*sp[k4,q]^2*m^3 - 128*sp[k1,k4]^2*sp[k2,q] + 96*sp[k1,k4]^2*
      sp[k2,q]*m - 16*sp[k1,k4]^2*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k1,q]
      *sp[k2,k4] - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 96*sp[k1,
      k4]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 
      1024*sp[k1,k4]*sp[k2,k4] + 704*sp[k1,k4]*sp[k2,k4]*m - 144*sp[k1,
      k4]*sp[k2,k4]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*m^3 + 128*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,q]^2 - 96*sp[k1,k4
      ]*sp[k2,q]^2*m + 16*sp[k1,k4]*sp[k2,q]^2*m^2 + 1024*sp[k1,k4]*sp[
      k2,q]*sp[k4,q] - 704*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 144*sp[k1,k4
      ]*sp[k2,q]*sp[k4,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^3 + 128
      *sp[k1,q]^2*sp[k2,k4] - 96*sp[k1,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2
      *sp[k2,k4]*m^2 - 128*sp[k1,q]*sp[k2,k4]^2 + 96*sp[k1,q]*sp[k2,k4]
      ^2*m - 16*sp[k1,q]*sp[k2,k4]^2*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q] + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m^2 + 1024*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 704*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m + 144*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 8*
      sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^3] + amp[6,13]*color[1/2*Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - 
      k2 + q]]*den[sp[ - k3 - k4]]*num[ - 128*sp[k1,k2]^2*sp[k1,k3] + 
      64*sp[k1,k2]^2*sp[k1,k3]*m - 64*sp[k1,k2]^2*sp[k1,k4] + 32*sp[k1,
      k2]^2*sp[k1,k4]*m - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[
      k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]^2*sp[k4,q] - 
      288*sp[k1,k2]*sp[k1,k3] + 160*sp[k1,k2]*sp[k1,k3]*m - 16*sp[k1,k2
      ]*sp[k1,k3]*m^2 + 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 64*sp[k1,k2]
      *sp[k1,k3]*sp[k1,q]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,q]
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 160*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 192*sp[k1,k2]*sp[
      k1,k4] + 80*sp[k1,k2]*sp[k1,k4]*m - 8*sp[k1,k2]*sp[k1,k4]*m^2 + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]
      *m + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k4]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m - 192*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 64*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[
      k1,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 128*sp[k1,k2]
      *sp[k1,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m
       + 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m - 112*sp[k1,k2]*sp[k3,k4] + 72*sp[k1,k2]*sp[k3,k4]*m - 8*
      sp[k1,k2]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 
      64*sp[k1,k2]*sp[k4,q]^2 + 48*sp[k1,k2]*sp[k4,q]^2*m - 8*sp[k1,k2]
      *sp[k4,q]^2*m^2 + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m + 320*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 208
      *sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q]*
      m^2 - 176*sp[k1,k3]*sp[k2,k4] + 88*sp[k1,k3]*sp[k2,k4]*m - 8*sp[
      k1,k3]*sp[k2,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 32*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 112
      *sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 - 32*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 64*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 256*sp[k1,k4]*sp[k1,q]*sp[k2,
      q] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,q]*m^2 + 240*sp[k1,k4]*sp[k2,k3] - 136*sp[k1,k4]*sp[k2,k3]*
      m + 16*sp[k1,k4]*sp[k2,k3]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k4]*sp[k2,k4] + 
      48*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[k2,k4]*m^2 + 32*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 256*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] + 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       - 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[
      k4,q] - 48*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*
      sp[k4,q]*m^2 - 64*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*
      m - 128*sp[k1,q]^2*sp[k2,k4] + 32*sp[k1,q]^2*sp[k2,k4]*m + 32*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 
      64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       - 32*sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m + 32*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 64
      *sp[k1,q]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m
       + 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m^2] + amp[6,14]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na
      *Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*den[
      sp[ - k4 + q]]*num[32*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k3,k4] + 16
      *sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]
      ^2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 96*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      96*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
      *m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 96*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4] - 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m - 256*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 144*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*
      m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 96*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4] + 80*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,
      k4]*sp[k3,k4]*m^2 - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2
      ]*sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4
      ]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,q]*
      sp[k4,q]*m + 272*sp[k1,k2]*sp[k3,k4] - 104*sp[k1,k2]*sp[k3,k4]*m
       + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 192*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       - 112*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q]*m^2 - 448*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 224*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 64*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,q] - 80*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,
      q]*sp[k2,q]*m^2 - 240*sp[k1,k3]*sp[k2,k4] + 104*sp[k1,k3]*sp[k2,
      k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]^2 - 80
      *sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2
       - 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 80*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 320*sp[k1,k3]*sp[k2
      ,q]*sp[k4,q] - 176*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m^2 + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 144*sp[k1,k4]*sp[k2,k3] + 72*sp[
      k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 
      64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q
      ]*m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 160*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q]*m - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 160*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 224*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k4]*sp[k2,q]^2
       - 48*sp[k1,k4]*sp[k2,q]^2*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 
      48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4
      ]*m^2 + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m + 192*sp[k1,q]^2*sp[k2,k3] - 112*sp[k1,q]^2*sp[k2,k3]*
      m + 16*sp[k1,q]^2*sp[k2,k3]*m^2 + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] - 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]
      *sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k4]^2 + 32*sp[k1,q]*sp[k2,k4]^2
      *m - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m + 192*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 80*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 256*sp[k1,q
      ]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[6,15]*color[ - 1/2*Ca*Cf*Na*Tf
       + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[sp[
       - k2 + q]]*den[sp[ - k3 + q]]*num[ - 64*sp[k1,k2]^2 + 32*sp[k1,
      k2]^2*m + 128*sp[k1,k2]^2*sp[k2,k3] - 64*sp[k1,k2]^2*sp[k2,k3]*m
       - 64*sp[k1,k2]^2*sp[k2,q] + 32*sp[k1,k2]^2*sp[k2,q]*m - 32*sp[k1
      ,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k3
      ,q]*m + 64*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4
      ] + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,
      k4] + 32*sp[k1,k2]*sp[k1,k4]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k3
      ] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k1
      ,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[
      k1,k2]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32
      *sp[k1,k2]*sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m
       + 128*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k2,k3]*sp[
      k2,k4]*m - 160*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*
      m - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[
      k2,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,
      k4]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4,q
      ] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,k4]
      *sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k4,q]^2 - 48*sp[k1,k2]*sp[k4,q]^2
      *m + 8*sp[k1,k2]*sp[k4,q]^2*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q
      ] - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k2,
      k4]^2 - 16*sp[k1,k3]*sp[k2,k4]^2*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m - 320*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 208*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[
      k1,k4]*sp[k2,k4] - 96*sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,
      k4]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,
      k4]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 128*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 32*sp[k1,k4]*sp[k2,q]^2 + 16*
      sp[k1,k4]*sp[k2,q]^2*m - 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 160*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*
      m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,q]*sp[
      k4,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 32*sp[k1,q]^2*sp[k2
      ,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,q]*sp[k2,k4]^2
       + 32*sp[k1,q]*sp[k2,k4]^2*m + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 
      16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 64*sp[k1,q]*sp[k2,k4]*
      sp[k4,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k4
      ]*sp[k4,q]*m^2] + amp[6,16]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4
      ]]*den[sp[ - k2 + q]]^2*den[sp[ - k3 - k4]]*num[ - 64*sp[k1,k2]*
      sp[k1,k3] + 64*sp[k1,k2]*sp[k1,k3]*m - 16*sp[k1,k2]*sp[k1,k3]*m^2
       - 32*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k4]*m - 8*sp[k1,k2
      ]*sp[k1,k4]*m^2 - 32*sp[k1,k2]*sp[k3,k4] + 32*sp[k1,k2]*sp[k3,k4]
      *m - 8*sp[k1,k2]*sp[k3,k4]*m^2 + 128*sp[k1,k3]*sp[k1,q]*sp[k2,q]
       - 128*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[
      k2,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k3]*sp[k2,k4]*m - 8
      *sp[k1,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k4]*sp[k1,q]*sp[
      k2,q]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 64*sp[k1,k4]*sp[k2
      ,k3] - 64*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]*m^2 - 32
      *sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[
      k2,k4]*m^2 - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 64*sp[k1,
      k4]*sp[k2,q]*sp[k4,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 16*sp[
      k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 
      64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m^2] + amp[7,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[16*sp[k1,k2]*sp[k2,k3] - 
      8*sp[k1,k2]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*
      sp[k2,k4]*m - 40*sp[k1,k2]*sp[k3,q] + 28*sp[k1,k2]*sp[k3,q]*m - 4
      *sp[k1,k2]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k4,q] - 4*sp[k1,k2]*sp[
      k4,q]*m + 4*sp[k1,k2]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q] + 4*sp[
      k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 40*sp[k1,k4]*sp[k2
      ,q] - 28*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*m^2 + 24*sp[
      k1,q]*sp[k2,k3] - 20*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*
      m^2 - 24*sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,q
      ]*sp[k2,k4]*m^2] + amp[7,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - 
      k2]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[ - 32*sp[k1,k2]*sp[
      k2,k3] + 16*sp[k1,k2]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k2,k4] + 8*
      sp[k1,k2]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k3,q] + 4*sp[k1,k2]*sp[k3,
      q]*m - 4*sp[k1,k2]*sp[k3,q]*m^2 + 40*sp[k1,k2]*sp[k4,q] - 28*sp[
      k1,k2]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k4,q]*m^2 - 40*sp[k1,k3]*sp[k2
      ,q] + 28*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,q]*
      m^2 + 24*sp[k1,q]*sp[k2,k3] - 20*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q
      ]*sp[k2,k3]*m^2 - 24*sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m
       - 4*sp[k1,q]*sp[k2,k4]*m^2] + amp[7,1]*color[1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[ - 48
      *sp[k1,k2]*sp[k2,k3] + 24*sp[k1,k2]*sp[k2,k3]*m - 48*sp[k1,k2]*
      sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k3,q] - 24
      *sp[k1,k2]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k4,q] - 24*sp[k1,k2]*sp[
      k4,q]*m - 48*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k3]*sp[k2,q]*m - 48*
      sp[k1,k4]*sp[k2,q] + 24*sp[k1,k4]*sp[k2,q]*m] + amp[7,2]*color[1/
      2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 + q]]*den[sp[ - k3
       - k4]]*den[sp[k3 + k4]]*num[ - 176*sp[k1,k2]^2*sp[k3,k4] + 48*
      sp[k1,k2]^2*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4
      ] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 12*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 48*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k4]*m - 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m^2 - 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 4*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q]*m^2 + 176*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 48*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 104*sp[k1,k2]*sp[k2,k3]*sp[k3,k4
      ] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 24*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 12*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 104*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*
      m - 12*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 - 24*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2
      ,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4]*m - 152*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]
      *sp[k3,k4]*m - 104*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q]*m - 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 48*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k3,q]^2 - 40*sp[k1,
      k2]*sp[k3,q]^2*m + 4*sp[k1,k2]*sp[k3,q]^2*m^2 + 96*sp[k1,k2]*sp[
      k3,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m^2 + 96*sp[k1,k2]*sp[k4,q]^2 - 40*sp[k1,k2]*
      sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 96*sp[k1,k3]^2*sp[k2,
      q] - 40*sp[k1,k3]^2*sp[k2,q]*m + 4*sp[k1,k3]^2*sp[k2,q]*m^2 + 96*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,q]
      *sp[k2,k3]*m^2 - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 24*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*
      m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k3]*
      sp[k2,k4]^2 - 16*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]*sp[k2,k4]
      *sp[k2,q] + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k3]
      *sp[k2,k4]*sp[k4,q]*m + 104*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 48*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 
      4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 12*sp[k1,k3]*sp[k2,q]*sp[k4,q
      ]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 96*sp[k1,k4]^2*sp[k2,q]
       - 40*sp[k1,k4]^2*sp[k2,q]*m + 4*sp[k1,k4]^2*sp[k2,q]*m^2 - 48*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k4]*sp[k1,q]
      *sp[k2,k4]*m^2 + 24*sp[k1,k4]*sp[k2,k3]^2 - 16*sp[k1,k4]*sp[k2,k3
      ]^2*m - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 24*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 96*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 104*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] - 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 12*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 24*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2
       + 24*sp[k1,q]*sp[k2,k3]^2*m - 4*sp[k1,q]*sp[k2,k3]^2*m^2 + 24*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 40*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 48*sp[k1,q]*sp[k2,
      k3]*sp[k4,q] - 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q]*m^2 + 24*sp[k1,q]*sp[k2,k4]^2*m - 4*sp[k1,q]*sp[k2,
      k4]^2*m^2 - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 4*sp[k1,q]*sp[k2,k4]
      *sp[k3,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,q]*sp[
      k2,k4]*sp[k4,q] + 40*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m^2 + 176*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 48*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[7,3]*color[1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 - k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 + q]]*den[sp[k3
       + k4]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m
       - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m - 104*sp[
      k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m + 48*sp[k1,k2]*sp[
      k1,k3] - 12*sp[k1,k2]*sp[k1,k3]*m - 112*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,k3] + 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 40*sp[k1
      ,k2]*sp[k1,k3]*sp[k3,q] - 12*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 12*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       - 24*sp[k1,k2]*sp[k1,k4] - 104*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 
      48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,q] - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q] - 24*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 24*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3] - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 72*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 40*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 40*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 
      88*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m
       - 12*sp[k1,k2]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[k2,k3]^2 + 40*sp[k1
      ,k2]*sp[k2,k3]^2*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,
      k2]*sp[k2,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 32*
      sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]
       + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 104*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] + 36*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 136*sp[k1,k2]*sp[
      k2,k3]*sp[k4,q] + 20*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,k2
      ]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m - 88*sp[
      k1,k2]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m
       + 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 40*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4
      ]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]
      *sp[k2,q]*sp[k3,q]*m - 80*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 32*sp[k1,
      k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4] - 8*sp[k1,k2]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 4*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 20*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m - 36*sp[k1,k2]*sp[k3,q] + 20*sp[k1,k2]*sp[k3
      ,q]*m + 160*sp[k1,k2]*sp[k3,q]^2 - 68*sp[k1,k2]*sp[k3,q]^2*m + 32
      *sp[k1,k2]*sp[k3,q]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 
      24*sp[k1,k2]*sp[k4,q] + 16*sp[k1,k2]*sp[k4,q]*m - 72*sp[k1,k2]*
      sp[k4,q]^2 + 28*sp[k1,k2]*sp[k4,q]^2*m - 72*sp[k1,k3]^2*sp[k2,q]
       + 28*sp[k1,k3]^2*sp[k2,q]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 
      20*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 72*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3] - 28*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 56*sp[k1,k3]*sp[k1
      ,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 8*sp[k1,k3]*sp[
      k2,k3] + 8*sp[k1,k3]*sp[k2,k3]*m - 80*sp[k1,k3]*sp[k2,k3]^2 + 32*
      sp[k1,k3]*sp[k2,k3]^2*m + 48*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]
       - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[
      k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 24*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 40*sp[k1,k3]*sp[
      k2,k4] + 24*sp[k1,k3]*sp[k2,k4]^2 - 160*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,k3]*sp[k2
      ,k4]*sp[k4,q] - 12*sp[k1,k3]*sp[k2,q] + 4*sp[k1,k3]*sp[k2,q]*m - 
      32*sp[k1,k3]*sp[k2,q]^2 + 8*sp[k1,k3]*sp[k2,q]^2*m + 40*sp[k1,k3]
      *sp[k2,q]*sp[k3,k4] - 12*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 112*sp[
      k1,k3]*sp[k2,q]*sp[k3,q] + 44*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 12*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 56*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       - 24*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 56*sp[k1,k4]*sp[k1,q]*sp[
      k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 56*sp[k1,k4]*sp[k2,k3]
       - 16*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]^2 - 32*sp[k1
      ,k4]*sp[k2,k3]^2*m - 104*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 20
      *sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 56*sp[k1,k4]*sp[k2,k3]*sp[
      k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k4]*sp[k2,k4
      ] + 8*sp[k1,k4]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 
      16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 48*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,q]*m
       + 80*sp[k1,k4]*sp[k2,q]^2 - 32*sp[k1,k4]*sp[k2,q]^2*m - 120*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4] + 44*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 
      16*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 12*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       + 56*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 20*sp[k1,k4]*sp[k2,q]*sp[k4,q
      ]*m + 56*sp[k1,q]^2*sp[k2,k3] - 16*sp[k1,q]^2*sp[k2,k3]*m - 56*
      sp[k1,q]^2*sp[k2,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m + 20*sp[k1,q]*
      sp[k2,k3] - 12*sp[k1,q]*sp[k2,k3]*m + 120*sp[k1,q]*sp[k2,k3]^2 - 
      44*sp[k1,q]*sp[k2,k3]^2*m + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       + 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 96*sp[k1,q]*sp[k2,k3]*
      sp[k3,q] + 36*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 112*sp[k1,q]*sp[k2,
      k3]*sp[k4,q] + 36*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,q]*sp[
      k2,k4] + 12*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       + 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 40*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 12*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 36*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,
      k4]*sp[k4,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,q]*sp[
      k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*
      sp[k2,q]*sp[k3,q] - 16*sp[k1,q]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]
      *sp[k2,q]*sp[k4,q] - 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + amp[7,4]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 + q]]*
      den[sp[k3 + k4]]*den[sp[ - k4 + q]]*num[ - 40*sp[k1,k2]^2*sp[k3,
      k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[k3,q] - 32*
      sp[k1,k2]^2*sp[k3,q]*m + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2
      *sp[k4,q]*m + 24*sp[k1,k2]*sp[k1,k3] + 104*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 88*sp[k1,k2]*sp[
      k1,k3]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 48*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 48*sp[
      k1,k2]*sp[k1,k4] + 12*sp[k1,k2]*sp[k1,k4]*m - 24*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 112*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k4] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 56*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 12*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 12*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m - 72*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 8*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4]*m + 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m - 88*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 40*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 
      8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4
      ] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k2,k3]*
      sp[k2,q] + 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 88*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 136*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 12*sp[k1,k2]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k2,k4]^2 - 40*sp[k1
      ,k2]*sp[k2,k4]^2*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,
      k2]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 8*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] - 20*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 104*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q] - 36*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 40*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 80*sp[k1,k2]*
      sp[k2,q]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,
      k2]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 16*sp[
      k1,k2]*sp[k3,k4] + 8*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q] + 20*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 24*sp[k1,
      k2]*sp[k3,q] - 16*sp[k1,k2]*sp[k3,q]*m + 72*sp[k1,k2]*sp[k3,q]^2
       - 28*sp[k1,k2]*sp[k3,q]^2*m - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 8
      *sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 36*sp[k1,k2]*sp[k4,q] - 20*sp[k1
      ,k2]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k4,q]^2 + 68*sp[k1,k2]*sp[k4,q
      ]^2*m + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m - 56*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k4]*m - 56*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,k3]*sp[k2,
      k3]*m + 104*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k3
      ]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k3]
      *sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]^2 + 32*sp[k1,k3]*sp[k2,k4]^
      2*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m - 56*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k3]*sp[k2,q]*m - 80*sp[k1,k3]*sp[
      k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m + 120*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 44*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 56*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q] + 20*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 12*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 72*sp[k1,k4]^
      2*sp[k2,q] - 28*sp[k1,k4]^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 72*sp[k1,k4]*sp[k1,q]
      *sp[k2,k4] + 28*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 56*sp[k1,k4]*sp[
      k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 40*sp[k1,k4]*
      sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]^2 - 48*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4] + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 160*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 24*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] + 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k4]*
      sp[k2,k4]*m + 80*sp[k1,k4]*sp[k2,k4]^2 - 32*sp[k1,k4]*sp[k2,k4]^2
      *m + 24*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k4]*sp[
      k2,q]*m + 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4
      ]*sp[k3,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[
      k2,k4]*sp[k4,q]*m + 12*sp[k1,k4]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,q]*
      m + 32*sp[k1,k4]*sp[k2,q]^2 - 8*sp[k1,k4]*sp[k2,q]^2*m - 40*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 12*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,q]*sp[k4,q]
       - 44*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 56*sp[k1,q]^2*sp[k2,k3] - 
      16*sp[k1,q]^2*sp[k2,k3]*m - 56*sp[k1,q]^2*sp[k2,k4] + 16*sp[k1,q]
      ^2*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q]*sp[k2,k3]*m
       - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,q]*m - 40*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 12*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4]*m - 40*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 12*sp[k1,q]*
      sp[k2,k3]*sp[k3,q]*m - 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 36*sp[k1,
      q]*sp[k2,k3]*sp[k4,q]*m - 20*sp[k1,q]*sp[k2,k4] + 12*sp[k1,q]*sp[
      k2,k4]*m - 120*sp[k1,q]*sp[k2,k4]^2 + 44*sp[k1,q]*sp[k2,k4]^2*m
       - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]
      *m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 4*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4]*m + 112*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 36*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 36*sp[k1,q]*sp[k2,
      k4]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,q]*sp[k3,q] + 32*sp[k1,q]*
      sp[k2,q]*sp[k3,q]*m - 32*sp[k1,q]*sp[k2,q]*sp[k4,q] + 16*sp[k1,q]
      *sp[k2,q]*sp[k4,q]*m] + amp[7,5]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2
      *Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*
      den[sp[k3 + k4]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*
      sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] - 
      16*sp[k1,k2]^2*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32
      *sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,q
      ] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 96*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] + 80*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m^2 - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 192*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 96
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m - 256*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 144*sp[k1,k2]*sp[k1,k4
      ]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 32*sp[k1,k2]
      *sp[k1,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 
      32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4
      ] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 48*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,
      q]*sp[k3,k4]*m - 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 112*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 448
      *sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*
      m - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m^2 + 160*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 
      64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,q] - 48*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q]*m^2 - 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 112*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 128*
      sp[k1,k3]*sp[k2,k4]^2 + 48*sp[k1,k3]*sp[k2,k4]^2*m + 96*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 8*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 
      48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ]*m^2 + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,k4]
      *sp[k4,q]*m + 256*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 160*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 192*
      sp[k1,k4]^2*sp[k2,q] - 112*sp[k1,k4]^2*sp[k2,q]*m + 16*sp[k1,k4]^
      2*sp[k2,q]*m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 80*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2
       - 96*sp[k1,k4]*sp[k2,k3]^2 + 32*sp[k1,k4]*sp[k2,k3]^2*m + 64*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m
       - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 192*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 256*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 8
      *sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4] - 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]^2 - 80*sp[k1,q]*sp[k2,k3]^2
      *m + 16*sp[k1,q]*sp[k2,k3]^2*m^2 - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4] - 80*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4]*m^2 + 320*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 176*sp[k1
      ,q]*sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2]
       + amp[7,6]*color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2
       + q]]^2*den[sp[k3 + k4]]*num[ - 32*sp[k1,k2]*sp[k1,k3] + 32*sp[
      k1,k2]*sp[k1,k3]*m - 8*sp[k1,k2]*sp[k1,k3]*m^2 - 64*sp[k1,k2]*sp[
      k1,k4] + 64*sp[k1,k2]*sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*m^2 - 
      32*sp[k1,k2]*sp[k3,k4] + 32*sp[k1,k2]*sp[k3,k4]*m - 8*sp[k1,k2]*
      sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 64*sp[k1,k3]*sp[
      k1,q]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 - 32*sp[k1,
      k3]*sp[k2,k3] + 32*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[k2,k3]*
      m^2 + 64*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k4]*m + 16*sp[
      k1,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 64*sp[k1,
      k3]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 
      128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]
      *m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k1,q]*
      sp[k2,q] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k1
      ,q]*sp[k2,q]*m^2 - 32*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k4]*sp[k2,k3
      ]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3
      ,q]*m^2 + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[7,7]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + q]]*den[sp[
      k3 + k4]]*den[sp[ - k4 + q]]*num[ - 16*sp[k1,k2]^2*sp[k3,k4] - 16
      *sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]*
      sp[k1,k3] - 16*sp[k1,k2]*sp[k1,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 80*sp[k1
      ,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*m + 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k3] - 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 8
      *sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 40*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] + 48*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,q
      ]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 40*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,
      k4]*m + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]
      *sp[k3,q]*m^2 + 224*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 72*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m + 144*sp[k1,k2]*sp[k3,q]^2 - 96*sp[k1,k2]*
      sp[k3,q]^2*m + 16*sp[k1,k2]*sp[k3,q]^2*m^2 - 24*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,q] + 80*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,
      k3]*sp[k2,k3]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 48*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 80*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       - 48*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k3]*sp[k2,k4]*m + 128*sp[k1,
      k3]*sp[k2,k4]^2 - 56*sp[k1,k3]*sp[k2,k4]^2*m - 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 128*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q] + 56*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 
      64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*
      m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 176*sp[k1,k3]*sp[k2,q]*
      sp[k3,q] + 112*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2
      ,q]*sp[k3,q]*m^2 + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 8*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[
      k1,k4]^2*sp[k2,q] + 56*sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k4]*
      sp[k1,q]*sp[k2,k4]*m - 112*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 48*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k4]*
      sp[k2,k3]*m + 48*sp[k1,k4]*sp[k2,k3]^2 - 16*sp[k1,k4]*sp[k2,k3]^2
      *m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 24*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 192*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       - 56*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] + 56*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 48*sp[k1,q]^2*sp[
      k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*m + 48*sp[k1,q]^2*sp[k2,k4] - 16
      *sp[k1,q]^2*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,k3]^2 - 16*sp[k1,q]*
      sp[k2,k3]^2*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 48*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] - 40*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1
      ,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 144*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 
      96*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]
      *m^2 - 48*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 48*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[7
      ,8]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*
      den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[ - 32
      *sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2
      *sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m
       - 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k3]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 96*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 256*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] - 144*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 8*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 16
      *sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4] - 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 96*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*
      m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 80*sp[k1,k2]*sp[k2,k4
      ]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 + 64*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 448*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 112*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m^2 - 192*sp[k1,k3]^2*sp[k2,q] + 112*sp[k1,k3]^2*sp[
      k2,q]*m - 16*sp[k1,k3]^2*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 64*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3] + 80*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 256*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m^2 + 96*sp[k1,k3]*sp[k2,k4]^2 - 32*sp[k1,k3]*sp[
      k2,k4]^2*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 80*sp[k1,k3]
      *sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 96*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m
       - 192*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 64*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3]*m^2 + 128*sp[k1,k4]*sp[k2,k3]^2 - 48*sp[k1,k4
      ]*sp[k2,k3]^2*m - 160*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,k4]*m - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*
      m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q] + 48*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 16*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 224*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q] - 112*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m^2 - 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 160*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 16*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 320*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 176*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 96*sp[k1,q]*
      sp[k2,k4]^2 + 80*sp[k1,q]*sp[k2,k4]^2*m - 16*sp[k1,q]*sp[k2,k4]^2
      *m^2 - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 80*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[7,9]*
      color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]^2*
      den[sp[k3 + k4]]*num[64*sp[k1,k2]*sp[k1,k3] - 64*sp[k1,k2]*sp[k1,
      k3]*m + 16*sp[k1,k2]*sp[k1,k3]*m^2 + 32*sp[k1,k2]*sp[k1,k4] - 32*
      sp[k1,k2]*sp[k1,k4]*m + 8*sp[k1,k2]*sp[k1,k4]*m^2 + 32*sp[k1,k2]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2
       - 128*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 128*sp[k1,k3]*sp[k1,q]*sp[k2
      ,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,
      k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 - 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k1,q]*sp[k2,
      q] + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k4]*sp[k2,k3]*m - 
      16*sp[k1,k4]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k4
      ]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k4]*m^2 + 128*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 64*sp[k1,k4
      ]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 64*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 
      16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[7,10]*color[ - 1/4*Ca^2
      *Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[ - k3 + q]]*
      den[sp[k3 + k4]]*num[16*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*
      sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,q] - 80*sp[k1,k2]*sp[k1,k3] + 32*
      sp[k1,k2]*sp[k1,k3]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4
      ] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 40*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4] + 16*sp[k1,k2]*sp[k1,
      k4]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 16*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 48*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 
      48*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m
       + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 40*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k3
      ]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 48*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
      *m - 64*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m - 224*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] + 72*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 
      24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ]*m^2 + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m^2 - 144*sp[k1,k2]*sp[k4,q]^2 + 96*sp[k1,k2]*sp[k4,q]^2
      *m - 16*sp[k1,k2]*sp[k4,q]^2*m^2 + 128*sp[k1,k3]^2*sp[k2,q] - 56*
      sp[k1,k3]^2*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 40*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 
      24*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ]*m + 112*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 48*sp[k1,k3]*sp[k1,q]*sp[
      k2,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,
      k3]*sp[k2,k4]*m - 192*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 56*sp[k1,k3]
      *sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[
      k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m
       - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k4]
      *sp[k3,q]*m + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 56*sp[k1,
      k3]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,q] + 48*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k4]*sp[k2,k3]*m - 128*
      sp[k1,k4]*sp[k2,k3]^2 + 56*sp[k1,k4]*sp[k2,k3]^2*m + 112*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 56*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q]*m - 80*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k4]*sp[k2,k4]*m
       + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 80*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] - 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,
      q]*sp[k3,k4]*m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 176*sp[
      k1,k4]*sp[k2,q]*sp[k4,q] - 112*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 16
      *sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 48*sp[k1,q]^2*sp[k2,k3] + 16*
      sp[k1,q]^2*sp[k2,k3]*m + 48*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*
      sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 128*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[k1,q
      ]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 48*sp[
      k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m - 48*sp[k1,q]*sp[k2
      ,k4]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m^2 + 48*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 40*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 
      144*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 96*sp[k1,q]*sp[k2,k4]*sp[k4,q]*
      m + 16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 + 80*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[7,11]*color[ - 1/
      2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3
      ]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[64*sp[k1,k2]^2*sp[k2,
      k3] - 32*sp[k1,k2]^2*sp[k2,k3]*m + 128*sp[k1,k2]^2*sp[k2,k4] - 64
      *sp[k1,k2]^2*sp[k2,k4]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2
      ]^2*sp[k3,k4]*m + 64*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k4,
      q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,
      k2]*sp[k1,k3]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 160*sp[k1,
      k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m
       + 192*sp[k1,k2]*sp[k2,k3] - 80*sp[k1,k2]*sp[k2,k3]*m + 8*sp[k1,
      k2]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2
      ]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 16*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q]*m + 192*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 
      64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 288*sp[k1,k2]*sp[k2,k4] - 160
      *sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*m^2 - 128*sp[k1,
      k2]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m - 160*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m - 128*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,
      q]*sp[k4,q]*m + 112*sp[k1,k2]*sp[k3,k4] - 72*sp[k1,k2]*sp[k3,k4]*
      m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[k3,q]^2 - 48*sp[
      k1,k2]*sp[k3,q]^2*m + 8*sp[k1,k2]*sp[k3,q]^2*m^2 - 64*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^
      2*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k3]*m - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k2,k3] - 48*sp[k1,
      k3]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k2,k3]*m^2 - 32*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 176*sp[k1,k3]*
      sp[k2,k4] - 88*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2
       + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q]*m + 128*sp[k1,k3]*sp[k2,q]^2 - 32*sp[k1,k3]*sp[k2,q]^2*m - 64
      *sp[k1,k3]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m
       - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 32*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 240*sp[k1,k4]
      *sp[k2,k3] + 136*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*
      m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 64*sp[k1,k4]*sp[k2,q]^2
       - 16*sp[k1,k4]*sp[k2,q]^2*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 
      16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,q]*sp[k2,k3]^2 - 16*
      sp[k1,q]*sp[k2,k3]^2*m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m - 256*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 
      128*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q
      ]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 48*sp[k1,q]*sp[k2,k3]*
      sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 256*sp[k1,q]*sp[
      k2,k3]*sp[k4,q] - 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 208*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*
      m^2 - 192*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 112*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[7,12]*color[1/2*Ca*Cf*Na*Tf - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + 
      q]]*den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]^2*sp[k2,k3] + 64*sp[k1,
      k2]^2*sp[k2,k3]*m - 64*sp[k1,k2]^2*sp[k2,k4] + 32*sp[k1,k2]^2*sp[
      k2,k4]*m - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m
       - 32*sp[k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]^2*sp[k4,q] + 128*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32
      *sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k1,k4]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 288*sp[k1,k2]*sp[k2,
      k3] + 160*sp[k1,k2]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k2,k3]*m^2 + 
      128*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q
      ]*m + 160*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 192*sp[k1,k2]*sp[k2,k4] + 80*sp[k1,k2]*sp[k2,k4]*m
       - 8*sp[k1,k2]*sp[k2,k4]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] - 
      32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*
      sp[k2,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,
      k2]*sp[k2,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 112*
      sp[k1,k2]*sp[k3,k4] + 72*sp[k1,k2]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[
      k3,k4]*m^2 + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,
      q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[k1,k2]*
      sp[k4,q]^2 + 48*sp[k1,k2]*sp[k4,q]^2*m - 8*sp[k1,k2]*sp[k4,q]^2*
      m^2 + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m - 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m + 240*sp[k1,k3]*sp[k2,k4] - 136*sp[k1,k3]*sp[k2
      ,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] - 64*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m - 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      32*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 96*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[
      k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 
      176*sp[k1,k4]*sp[k2,k3] + 88*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*
      sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k4]*sp[k2,k4] + 48*sp[k1,k4]*sp[
      k2,k4]*m - 8*sp[k1,k4]*sp[k2,k4]*m^2 + 32*sp[k1,k4]*sp[k2,k4]*sp[
      k2,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 128*sp[k1,k4]*sp[k2,q
      ]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[
      k4,q] - 48*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*
      sp[k4,q]*m^2 + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 320*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 208*sp[k1,
      q]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 
      192*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]
      *m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,k4]^2
       + 16*sp[k1,q]*sp[k2,k4]^2*m + 256*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 
      128*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k2,q
      ]*m^2 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,q]*sp[
      k2,k4]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,q]*
      sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2]
       + amp[7,13]*color[Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 - q]]*
      den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[352*
      sp[k1,k2]^2*sp[k3,k4] - 96*sp[k1,k2]^2*sp[k3,k4]*m - 192*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 96*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*
      m + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k3,q]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 352*sp[k1,k2]*sp[k1,q
      ]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 96*sp[k1,k2]*
      sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 48*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 48*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       + 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4
      ,q]*m - 352*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m + 656*sp[k1,k2]*sp[k3,k4] - 296*sp[k1,k2]*sp[k3,k4]*m
       + 24*sp[k1,k2]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k3,q]^2 + 80*sp[
      k1,k2]*sp[k3,q]^2*m - 8*sp[k1,k2]*sp[k3,q]^2*m^2 - 192*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m^2 - 192*sp[k1,k2]*sp[k4,q]^2 + 80*sp[k1,
      k2]*sp[k4,q]^2*m - 8*sp[k1,k2]*sp[k4,q]^2*m^2 - 96*sp[k1,k3]^2*
      sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k1,q]
      *sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 192*sp[k1,
      k3]*sp[k2,k3] + 80*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[k2,k3]*
      m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,k4] - 8*sp[k1,k3]*sp[k2,k4]*m + 8
      *sp[k1,k3]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,q]*sp[k3,q]
       - 80*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,
      q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,k4]^2*
      sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 96*sp[k1,k4]*
      sp[k2,k3] - 8*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2
       + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m - 192*sp[k1,k4]*sp[k2,k4] + 80*sp[k1,k4]*sp[k2,k4]*m - 8*
      sp[k1,k4]*sp[k2,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 16*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m^2 + 192*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 80*sp[k1,k4]*sp[k2,q]*
      sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[
      k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m - 96*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,
      k3]*sp[k3,q] - 80*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,q]*sp[
      k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 96*
      sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m + 96*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,q]
      *sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 80*
      sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2
       - 704*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 368*sp[k1,q]*sp[k2,q]*sp[k3,
      k4]*m - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[7,16]*color[Ca*
      Cf*Na*Tf]*den[sp[ - k2 + q]]^2*den[sp[ - k3 - k4]]*den[sp[k3 + k4
      ]]*num[176*sp[k1,k2]*sp[k3,k4] - 136*sp[k1,k2]*sp[k3,k4]*m + 24*
      sp[k1,k2]*sp[k3,k4]*m^2 - 96*sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k3]*
      sp[k2,k3]*m - 8*sp[k1,k3]*sp[k2,k3]*m^2 - 48*sp[k1,k3]*sp[k2,k4]
       + 8*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2 + 192*sp[
      k1,k3]*sp[k2,q]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 16
      *sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q]*m^2 - 48*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*sp[k2,k3]*m + 8*
      sp[k1,k4]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k4]*
      sp[k2,k4]*m - 8*sp[k1,k4]*sp[k2,k4]*m^2 + 96*sp[k1,k4]*sp[k2,q]*
      sp[k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,
      q]*sp[k3,q]*m^2 + 192*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 128*sp[k1,k4]
      *sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 352*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 272*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m
       - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[8,1]*color[ - Ca^2*
      Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k3 - q]]*num[
       - 48*sp[k1,k2] + 24*sp[k1,k2]*m + 24*sp[k1,k2]*sp[k1,k3] - 12*
      sp[k1,k2]*sp[k1,k3]*m - 24*sp[k1,k2]*sp[k1,q] + 12*sp[k1,k2]*sp[
      k1,q]*m + 24*sp[k1,k2]*sp[k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m - 24*
      sp[k1,k2]*sp[k2,q] + 12*sp[k1,k2]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k3
      ,k4] - 12*sp[k1,k2]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k3,q] - 48*sp[
      k1,k2]*sp[k3,q]*m - 12*sp[k1,k2]*sp[k4,q] + 12*sp[k1,k2]*sp[k4,q]
      *m + 48*sp[k1,k3]*sp[k2,k3] - 24*sp[k1,k3]*sp[k2,k3]*m - 12*sp[k1
      ,k3]*sp[k2,k4] + 12*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,q]
       + 24*sp[k1,k3]*sp[k2,q]*m - 12*sp[k1,k4]*sp[k2,k3] + 12*sp[k1,k4
      ]*sp[k2,k3]*m + 12*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m
       - 48*sp[k1,q]*sp[k2,k3] + 24*sp[k1,q]*sp[k2,k3]*m + 12*sp[k1,q]*
      sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,q] - 24*
      sp[k1,q]*sp[k2,q]*m] + amp[8,1]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k3 - q]]*num[ - 48*sp[k1,k2]
       + 24*sp[k1,k2]*m + 24*sp[k1,k2]*sp[k1,k3] - 12*sp[k1,k2]*sp[k1,
      k3]*m - 24*sp[k1,k2]*sp[k1,q] + 12*sp[k1,k2]*sp[k1,q]*m + 24*sp[
      k1,k2]*sp[k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[k2,
      q] + 12*sp[k1,k2]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k3,k4] - 12*sp[k1,
      k2]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,q]*m
       - 12*sp[k1,k2]*sp[k4,q] + 12*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,k3]
      *sp[k2,k3] - 24*sp[k1,k3]*sp[k2,k3]*m - 12*sp[k1,k3]*sp[k2,k4] + 
      12*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k3]*
      sp[k2,q]*m - 12*sp[k1,k4]*sp[k2,k3] + 12*sp[k1,k4]*sp[k2,k3]*m + 
      12*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m - 48*sp[k1,q]*sp[
      k2,k3] + 24*sp[k1,q]*sp[k2,k3]*m + 12*sp[k1,q]*sp[k2,k4] - 12*sp[
      k1,q]*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,q] - 24*sp[k1,q]*sp[k2,q]*m
      ] + amp[8,2]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[
      k1 + k2]]*den[sp[ - k3 - k4]]*den[sp[k3 - q]]*num[ - 104*sp[k1,k2
      ]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[
      k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 208*sp[k1,k2]^2*sp[k4,q] - 64
      *sp[k1,k2]^2*sp[k4,q]*m - 24*sp[k1,k2]*sp[k1,k3] + 12*sp[k1,k2]*
      sp[k1,k3]*m + 56*sp[k1,k2]*sp[k1,k3]^2 - 28*sp[k1,k2]*sp[k1,k3]^2
      *m + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 20*sp[k1,k2]*sp[k1,k3]*
      sp[k1,k4]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 20*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q]*m + 224*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 56*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 20
      *sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,q
      ] + 20*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4] + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,q] - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 48*sp[k1,k2
      ]*sp[k1,k4] + 24*sp[k1,k2]*sp[k1,k4]*m - 80*sp[k1,k2]*sp[k1,k4]*
      sp[k1,q] + 40*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 80*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] - 20*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 160*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 20*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 40*sp[k1,k2]
      *sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 8*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 
      16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k2,k3] + 12*
      sp[k1,k2]*sp[k2,k3]*m + 56*sp[k1,k2]*sp[k2,k3]^2 - 28*sp[k1,k2]*
      sp[k2,k3]^2*m + 40*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 20*sp[k1,k2]*
      sp[k2,k3]*sp[k2,k4]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 20*sp[
      k1,k2]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 4
      *sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,q]
       - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k2,k4
      ] + 24*sp[k1,k2]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 
      40*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4] - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2
      ,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1
      ,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 32*sp[
      k1,k2]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 40*
      sp[k1,k2]*sp[k3,k4] + 8*sp[k1,k2]*sp[k3,k4]*m - 52*sp[k1,k2]*sp[
      k3,k4]^2 + 28*sp[k1,k2]*sp[k3,k4]^2*m - 24*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 72*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,k2]*
      sp[k3,q] - 8*sp[k1,k2]*sp[k3,q]*m - 52*sp[k1,k2]*sp[k3,q]^2 + 28*
      sp[k1,k2]*sp[k3,q]^2*m + 72*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 24*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k4,q] - 16*sp[k1,k2]
      *sp[k4,q]*m + 88*sp[k1,k2]*sp[k4,q]^2 - 40*sp[k1,k2]*sp[k4,q]^2*m
       - 24*sp[k1,k3]^2*sp[k2,k4] + 12*sp[k1,k3]^2*sp[k2,k4]*m + 24*sp[
      k1,k3]^2*sp[k2,q] - 12*sp[k1,k3]^2*sp[k2,q]*m + 24*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3] - 12*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       - 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 12*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 4*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,k3] + 24*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] - 12*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 72*sp[k1,k3]*
      sp[k2,k3]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 72*sp[
      k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 
      200*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ]*m + 8*sp[k1,k3]*sp[k2,k4] - 8*sp[k1,k3]*sp[k2,k4]^2 + 4*sp[k1,
      k3]*sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 8*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q]*m + 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 24*sp[
      k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 8
      *sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       + 8*sp[k1,k3]*sp[k2,q] - 8*sp[k1,k3]*sp[k2,q]^2 + 4*sp[k1,k3]*
      sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k3]*sp[k2
      ,q]*sp[k3,k4]*m + 44*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k3]*
      sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 8*sp[k1,k4]
      ^2*sp[k2,k3] + 4*sp[k1,k4]^2*sp[k2,k3]*m + 16*sp[k1,k4]^2*sp[k2,q
      ] - 8*sp[k1,k4]^2*sp[k2,q]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 
      8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4
      ] + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,q] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 8*sp[k1,k4]*sp[k2,k3]
       - 24*sp[k1,k4]*sp[k2,k3]^2 + 12*sp[k1,k4]*sp[k2,k3]^2*m + 8*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 
      8*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[
      k3,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 8*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2
      ,k4] - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,k4]*
      sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k4]*sp[
      k2,k4]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*
      sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,q] - 16*sp[k1
      ,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m + 52*sp[k1,k4]*sp[k2,q
      ]*sp[k3,k4] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 52*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 72*sp[k1,
      k4]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 8*sp[
      k1,q]^2*sp[k2,k3] + 4*sp[k1,q]^2*sp[k2,k3]*m - 16*sp[k1,q]^2*sp[
      k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3] + 24*sp[
      k1,q]*sp[k2,k3]^2 - 12*sp[k1,q]*sp[k2,k3]^2*m + 8*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[
      k2,k3]*sp[k2,q] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 44*sp[k1
      ,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 4*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k4] + 16*sp[k1,q]*
      sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2,k4]^2*m + 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 52*sp[k1,q]*sp[k2,k4
      ]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 52*sp[k1,q]*sp[
      k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 72*sp[k1,q]*
      sp[k2,k4]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 64*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 32*sp[
      k1,q]*sp[k2,q]*sp[k3,q] + 16*sp[k1,q]*sp[k2,q]*sp[k3,q]*m - 64*
      sp[k1,q]*sp[k2,q]*sp[k4,q] + 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + 
      amp[8,3]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]
      ]*den[sp[ - k3 + q]]*den[sp[k3 - q]]*num[80*sp[k1,k2] - 40*sp[k1,
      k2]*m + 208*sp[k1,k2]^2 - 88*sp[k1,k2]^2*m - 304*sp[k1,k2]^2*sp[
      k3,q] + 112*sp[k1,k2]^2*sp[k3,q]*m - 104*sp[k1,k2]*sp[k1,k3] + 56
      *sp[k1,k2]*sp[k1,k3]*m - 48*sp[k1,k2]*sp[k1,k3]^2 + 32*sp[k1,k2]*
      sp[k1,k3]^2*m - 4*sp[k1,k2]*sp[k1,k3]^2*m^2 + 48*sp[k1,k2]*sp[k1,
      k3]*sp[k1,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 8*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q]*m^2 - 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 80*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*
      m^2 + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m^2 + 96*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 8*sp[k1,k2]
      *sp[k1,k3]*sp[k3,k4]*m^2 + 104*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 48*
      sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m^2 - 80*sp[k1,k2]*sp[k1,k4] + 40*sp[k1,k2]*sp[k1,k4]*m + 128
      *sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       + 80*sp[k1,k2]*sp[k1,q] - 40*sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]
      *sp[k1,q]^2 + 32*sp[k1,k2]*sp[k1,q]^2*m - 4*sp[k1,k2]*sp[k1,q]^2*
      m^2 + 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 8*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m^2 - 192*sp[k1,k2]*sp[
      k1,q]*sp[k2,q] + 80*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 8*sp[k1,k2]*
      sp[k1,q]*sp[k2,q]*m^2 - 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 8*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 
      104*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 48*sp[k1,k2]*sp[k1,q]*sp[k3,q]*
      m + 96*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,q]*sp[k4,
      q]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 104*sp[k1,k2]*sp[k2,k3
      ] + 56*sp[k1,k2]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k2,k3]^2 + 32*sp[
      k1,k2]*sp[k2,k3]^2*m - 4*sp[k1,k2]*sp[k2,k3]^2*m^2 + 48*sp[k1,k2]
      *sp[k2,k3]*sp[k2,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,
      k2]*sp[k2,k3]*sp[k2,q]*m^2 + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 
      64*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,
      k4]*m^2 + 104*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k2]*sp[k2,
      k3]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 80*
      sp[k1,k2]*sp[k2,k4] + 40*sp[k1,k2]*sp[k2,k4]*m + 128*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 80*sp[k1
      ,k2]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k2,q]^2
       + 32*sp[k1,k2]*sp[k2,q]^2*m - 4*sp[k1,k2]*sp[k2,q]^2*m^2 - 48*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 104*sp[k1,k2]*sp[k2,q]*
      sp[k3,q] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,
      q]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[
      k2,q]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]*sp[k3,
      k4]*m - 96*sp[k1,k2]*sp[k3,k4]^2 + 40*sp[k1,k2]*sp[k3,k4]^2*m - 4
      *sp[k1,k2]*sp[k3,k4]^2*m^2 + 40*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48
      *sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4
      ,q]*m^2 - 288*sp[k1,k2]*sp[k3,q] + 144*sp[k1,k2]*sp[k3,q]*m + 208
      *sp[k1,k2]*sp[k3,q]^2 - 96*sp[k1,k2]*sp[k3,q]^2*m - 40*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 40*sp[k1,
      k2]*sp[k4,q] - 40*sp[k1,k2]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k4,q]^2
       + 40*sp[k1,k2]*sp[k4,q]^2*m - 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 24*
      sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 24*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 128*
      sp[k1,k3]*sp[k2,k3] + 72*sp[k1,k3]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[
      k2,k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,
      k3]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 64*
      sp[k1,k3]*sp[k2,k4] - 56*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4] - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m
       + 80*sp[k1,k3]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,q]*m - 24*sp[k1,k3]
      *sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m - 80*sp[k1,k3]*sp[k2,q]*
      sp[k3,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,
      k3] - 56*sp[k1,k4]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
       - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 40*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q] - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k4]*sp[
      k2,k4] + 48*sp[k1,k4]*sp[k2,k4]*m + 176*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q] - 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k4]*sp[k2,q]
       + 40*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 40*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       - 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 48*sp[k1,k4]*sp[k2,q]*sp[k4
      ,q] - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,q]^2*sp[k2,k3]
       + 16*sp[k1,q]^2*sp[k2,k3]*m + 80*sp[k1,q]*sp[k2,k3] - 40*sp[k1,q
      ]*sp[k2,k3]*m + 24*sp[k1,q]*sp[k2,k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2
      *m + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k2
      ,q]*m - 80*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k3]*
      sp[k3,q]*m - 40*sp[k1,q]*sp[k2,k4] + 40*sp[k1,q]*sp[k2,k4]*m - 24
      *sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       + 40*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m + 48*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k4
      ,q]*m - 80*sp[k1,q]*sp[k2,q] + 40*sp[k1,q]*sp[k2,q]*m + 128*sp[k1
      ,q]*sp[k2,q]*sp[k3,q] - 64*sp[k1,q]*sp[k2,q]*sp[k3,q]*m] + amp[8,
      4]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*
      den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[52*sp[k1,k2] - 20*sp[k1,k2
      ]*m - 88*sp[k1,k2]^2 + 16*sp[k1,k2]^2*m - 208*sp[k1,k2]^2*sp[k3,
      k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[k3,q] - 32*
      sp[k1,k2]^2*sp[k3,q]*m + 104*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^
      2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 32*sp[k1,k2]*sp[k1,k3]*m
       + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 40*sp[k1,k2]*sp[k1,k3]*sp[
      k1,k4]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 20*sp[k1,k2]*sp[k1,
      k3]*sp[k1,q]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 40*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 20*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1
      ,k4] + 32*sp[k1,k2]*sp[k1,k4]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[k1,q]
       + 20*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 160*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q] + 20*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k4,
      q]*m + 64*sp[k1,k2]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,q]*m + 56*sp[k1
      ,k2]*sp[k1,q]^2 - 28*sp[k1,k2]*sp[k1,q]^2*m - 80*sp[k1,k2]*sp[k1,
      q]*sp[k2,k3] + 20*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 80*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] + 20*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 224*sp[
      k1,k2]*sp[k1,q]*sp[k2,q] - 56*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m
       - 8*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*
      m - 8*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 4*sp[k1,k2]*sp[k1,q]*sp[k4,q]
      *m - 64*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m + 80*sp[k1
      ,k2]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 
      40*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 20*sp[k1,k2]*sp[k2,k3]*sp[k2,q]
      *m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[
      k2,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 20*sp[k1,k2]*sp[k2,
      k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 8
      *sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,q] - 32*sp[
      k1,k2]*sp[k2,q]*m + 56*sp[k1,k2]*sp[k2,q]^2 - 28*sp[k1,k2]*sp[k2,
      q]^2*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 8*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 4*sp[k1,k2]*sp[k2,q
      ]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 4*sp[k1,k2]*sp[k2,
      q]*sp[k4,q]*m + 120*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*
      m + 88*sp[k1,k2]*sp[k3,k4]^2 - 40*sp[k1,k2]*sp[k3,k4]^2*m - 72*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       - 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k4
      ,q]*m - 80*sp[k1,k2]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,q]*m - 52*sp[
      k1,k2]*sp[k3,q]^2 + 28*sp[k1,k2]*sp[k3,q]^2*m + 24*sp[k1,k2]*sp[
      k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 80*sp[k1,k2]*
      sp[k4,q] + 32*sp[k1,k2]*sp[k4,q]*m - 52*sp[k1,k2]*sp[k4,q]^2 + 28
      *sp[k1,k2]*sp[k4,q]^2*m - 16*sp[k1,k3]^2*sp[k2,k4] + 8*sp[k1,k3]^
      2*sp[k2,k4]*m + 8*sp[k1,k3]^2*sp[k2,q] - 4*sp[k1,k3]^2*sp[k2,q]*m
       + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,k3]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 12*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k3] + 40*sp[k1
      ,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1,k3]
      *sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 4*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] - 32
      *sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q
      ] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 64*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 28*sp[k1,k3]*sp[k2
      ,k4] - 40*sp[k1,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]^2 + 8*
      sp[k1,k3]*sp[k2,k4]^2*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 4*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 
      32*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 52*sp[k1,k3]*sp[k2,k4]*sp[k3
      ,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 52*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,
      q] + 8*sp[k1,k3]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,q]^2 + 12*sp[k1,
      k3]*sp[k2,q]^2*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 44*sp[k1,k3]*
      sp[k2,q]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3
      ]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,
      k4]^2*sp[k2,k3] + 8*sp[k1,k4]^2*sp[k2,k3]*m + 8*sp[k1,k4]^2*sp[k2
      ,q] - 4*sp[k1,k4]^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,
      k4] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k4]*sp[k1,q]*
      sp[k2,q] - 12*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 28*sp[k1,k4]*sp[k2,
      k3] - 40*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]^2 + 8*sp[
      k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 4*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 72*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
       + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 52*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 52*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 72*sp[k1,k4]*
      sp[k2,k4] + 40*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[k2,k4]*sp[
      k2,q] + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k4]
      *sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 64*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1
      ,k4]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m - 4*
      sp[k1,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,k4]*sp[k2,
      q]^2 + 12*sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m + 44*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 24*sp[k1,k4]*sp[k2,q]*sp[k4,
      q]*m - 24*sp[k1,q]^2*sp[k2,k3] + 12*sp[k1,q]^2*sp[k2,k3]*m - 24*
      sp[k1,q]^2*sp[k2,k4] + 12*sp[k1,q]^2*sp[k2,k4]*m - 4*sp[k1,q]*sp[
      k2,k3] + 8*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,q]*sp[k2,k3]^2 - 4*sp[
      k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 8*sp[k1,q
      ]*sp[k2,k3]*sp[k2,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 12*sp[
      k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 44*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 
      4*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       - 4*sp[k1,q]*sp[k2,k4] + 8*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,q]*sp[
      k2,k4]^2 - 4*sp[k1,q]*sp[k2,k4]^2*m + 24*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m + 44*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 24*sp[k1,q]*sp[k2,k4]*
      sp[k4,q]*m - 40*sp[k1,q]*sp[k2,q] + 8*sp[k1,q]*sp[k2,q]*m - 200*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 
      72*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2,q]*sp[k3,q]*m
       + 72*sp[k1,q]*sp[k2,q]*sp[k4,q] - 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*
      m] + amp[8,5]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1
       + k3]]*den[sp[ - k2 - k4]]*den[sp[k3 - q]]*num[ - 16*sp[k1,k2]^2
       - 32*sp[k1,k2]^2*sp[k1,k3] + 16*sp[k1,k2]^2*sp[k1,k3]*m + 64*sp[
      k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^2*sp[k1,q]*m + 16*sp[k1,k2]^2*
      sp[k3,k4]*m + 80*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m
       - 8*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 144*sp[k1,k2]*sp[k1,k3]
      *sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 4*sp[k1,
      k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4] + 64*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,
      k2]*sp[k1,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[
      k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1
      ,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k1,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k3] - 8*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 32*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 8*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m^2 + 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m + 80*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m - 
      32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[k1,
      k2]*sp[k3,k4]^2*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1
      ,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 24*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*
      m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m - 32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^2*sp[k2,k4]*m + 
      4*sp[k1,k3]^2*sp[k2,k4]*m^2 + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m
       - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 96*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 176*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4] - 72*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 8*sp[k1,k3]*sp[
      k2,k3]*sp[k2,q]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,
      k3]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*
      sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]^2 + 24*sp[k1,k3]*sp[k2,q]^2*
      m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,q]
      *sp[k4,q]*m - 64*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]
      *m + 32*sp[k1,k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m - 128*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,
      k4] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,q] - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 8*
      sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[k1,k4]*sp[k2,k3]^2*m^2 + 8*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 
      32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 32*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 80*sp[k1,q]^2*sp[k2,k4] + 32*sp[k1,q]^2*sp[k2,k4]*m
       - 32*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,
      q]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 
      32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m + 144*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m] + amp[8,7]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 + k3]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[32*
      sp[k1,k2]^2 - 8*sp[k1,k2]^2*m + 104*sp[k1,k2]^2*sp[k3,k4] - 32*
      sp[k1,k2]^2*sp[k3,k4]*m - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^
      2*sp[k3,q]*m - 40*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*
      m - 16*sp[k1,k2]*sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]
       + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 88*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 80*sp[
      k1,k2]*sp[k1,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m
       + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q]*m + 40*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4] + 8*sp[k1,k2]*sp[k1,k4]*m + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]
      *m - 72*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 40
      *sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 104*sp[k1,k2]*sp[k1,q] + 
      48*sp[k1,k2]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1,q]^2 + 40*sp[k1,k2]*
      sp[k1,q]^2*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m + 104*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,
      k2]*sp[k1,q]*sp[k2,k4]*m - 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 40*
      sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       + 20*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 104*sp[k1,k2]*sp[k1,q]*sp[
      k3,q] - 36*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,q]*
      sp[k4,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,
      k3] - 8*sp[k1,k2]*sp[k2,k3]*m + 88*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 48*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 40*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] + 12*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 
      16*sp[k1,k2]*sp[k3,k4] + 4*sp[k1,k2]*sp[k3,k4]*m - 72*sp[k1,k2]*
      sp[k3,k4]^2 + 28*sp[k1,k2]*sp[k3,k4]^2*m - 32*sp[k1,k2]*sp[k3,k4]
      *sp[k3,q] + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q] - 20*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 60*sp[k1,k2]*
      sp[k3,q] + 28*sp[k1,k2]*sp[k3,q]*m + 160*sp[k1,k2]*sp[k3,q]^2 - 
      68*sp[k1,k2]*sp[k3,q]^2*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 4*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 80*sp[k1,k3]^2*sp[k2,k4] - 32*sp[
      k1,k3]^2*sp[k2,k4]*m + 32*sp[k1,k3]^2*sp[k2,q] - 8*sp[k1,k3]^2*
      sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3]*m - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4]*m - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 48
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
       - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k4] + 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k1,q]*
      sp[k2,q] + 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 104*sp[k1,k3]*sp[k2,
      k3] - 40*sp[k1,k3]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2
      ,k3]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,k3
      ]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 16*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8
      *sp[k1,k3]*sp[k2,k4] + 20*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] + 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 56*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,k4] - 20*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 
      16*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
      *m - 120*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 44*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m + 20*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m + 72
      *sp[k1,k3]*sp[k2,q]^2 - 28*sp[k1,k3]*sp[k2,q]^2*m - 12*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 44*sp[k1
      ,k3]*sp[k2,q]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 12*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k4]^2*sp[k2,q] + 48*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 
      104*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4
      ]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k4]*sp[k1,q]*sp[
      k2,q]*m - 16*sp[k1,k4]*sp[k2,k3] + 4*sp[k1,k4]*sp[k2,k3]*m - 56*
      sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m - 8*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 40*sp[k1,
      k4]*sp[k2,k3]*sp[k3,k4] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 96
      *sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 36*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       + 40*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q]*m + 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2
      ,q]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 120*sp[k1,q]^2*
      sp[k2,k3] + 44*sp[k1,q]^2*sp[k2,k3]*m + 16*sp[k1,q]^2*sp[k2,k4]
       - 32*sp[k1,q]^2*sp[k2,k4]*m + 80*sp[k1,q]^2*sp[k2,q] - 32*sp[k1,
      q]^2*sp[k2,q]*m - 44*sp[k1,q]*sp[k2,k3] + 20*sp[k1,q]*sp[k2,k3]*m
       - 56*sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m + 56*sp[k1
      ,q]*sp[k2,k3]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 72*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] + 28*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 
      112*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 36*sp[k1,q]*sp[k2,k3]*sp[k3,k4
      ]*m - 96*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 36*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 4*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m + 56*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[
      k1,q]*sp[k2,q]*sp[k3,q]*m] + amp[8,8]*color[ - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[k3
       - q]]*num[ - 16*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k2,k3] + 16*sp[
      k1,k2]^2*sp[k2,k3]*m + 64*sp[k1,k2]^2*sp[k2,q] - 32*sp[k1,k2]^2*
      sp[k2,q]*m + 16*sp[k1,k2]^2*sp[k3,k4]*m + 80*sp[k1,k2]^2*sp[k3,q]
       - 16*sp[k1,k2]^2*sp[k3,q]*m - 8*sp[k1,k2]^2*sp[k4,q]*m - 16*sp[
      k1,k2]*sp[k1,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*
      m + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 144*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m
       + 8*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k2
      ,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,q
      ]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k2]*
      sp[k2,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 24*sp[
      k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*
      m^2 - 192*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4] + 64*sp[k1,k2]*sp[k2,k4]*sp[
      k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 80*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1
      ,k2]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 48*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k2,q]*sp[
      k4,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1
      ,k2]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 128*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1
      ,k2]*sp[k3,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 4*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k3]^2*sp[k2,k4]*m
       - 4*sp[k1,k3]^2*sp[k2,k4]*m^2 - 32*sp[k1,k3]^2*sp[k2,q] + 8*sp[
      k1,k3]^2*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 24*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2
       - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 24*sp[k1,
      k3]*sp[k1,q]*sp[k2,q]*m + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 4*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 112*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k4]
       + 24*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1
      ,k3]*sp[k2,k4]^2*m - 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 
      32*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,
      k4]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 32*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m
       + 144*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,
      q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 40*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*
      sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]^2
       - 8*sp[k1,k4]*sp[k2,k3]^2*m + 4*sp[k1,k4]*sp[k2,k3]^2*m^2 + 96*
      sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*
      m + 176*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 72*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 8*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 16*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2
       - 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k2
      ,q]*m - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m - 80*sp[k1,k4]*sp[k2,q]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m
       - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m - 80*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,q]^2*sp[k2,k3] + 24*sp[k1,q]^2*sp[k2,k3]*m
       + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m + 144*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m + 32*sp[k1,q]*sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2,k4]^2
      *m + 16*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,9]*color[
      1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k2 + 
      q]]*den[sp[k3 - q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1,k2]^2*sp[k2,
      k3] - 32*sp[k1,k2]^2*sp[k2,k3]*m - 32*sp[k1,k2]^2*sp[k2,q] + 16*
      sp[k1,k2]^2*sp[k2,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m - 80*sp[k1,k2]
      ^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*sp[k4,q]
      *m + 32*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,k2]*sp[k1,k3]*m - 96*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 8
      *sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 144*sp[k1,k2]*sp[k1,k3]*sp[k2,
      q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k1,k4] - 8*sp[k1,k2]*sp[k1,k4]
      *m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]
      *sp[k1,q] + 8*sp[k1,k2]*sp[k1,q]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k2,
      k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 8*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 24*sp[k1,k2]*
      sp[k1,q]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 4*sp[k1,
      k2]*sp[k1,q]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 32
      *sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k2,k3]*sp[k3,
      k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2
      ,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 80*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 
      64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]
      *m + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m - 64*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,q]
      *sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2 + 128*sp[k1,k2]*
      sp[k3,k4] - 48*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k4,q] + 8*sp[k1,k2]*sp[
      k4,q]*m + 32*sp[k1,k2]*sp[k4,q]^2 - 24*sp[k1,k2]*sp[k4,q]^2*m + 4
      *sp[k1,k2]*sp[k4,q]^2*m^2 - 64*sp[k1,k3]^2*sp[k2,q] + 24*sp[k1,k3
      ]^2*sp[k2,q]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m
       - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 80*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3
      ]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k4]^2
       - 8*sp[k1,k3]*sp[k2,k4]^2*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 
      16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4] + 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 144*sp[k1,k3]*
      sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 32*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 
      4*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 16*sp[k1,k4]*sp[k2,k3] + 80*
      sp[k1,k4]*sp[k2,k3]^2 - 32*sp[k1,k4]*sp[k2,k3]^2*m - 96*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4] + 40*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 176*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 72*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 80*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k4]*
      sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k4]*m + 96*sp[k1,k4]*sp[k2,k4]*sp[
      k2,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,k4
      ]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k4]*sp[
      k2,q] - 8*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,q]^2 + 8*sp[
      k1,k4]*sp[k2,q]^2*m - 4*sp[k1,k4]*sp[k2,q]^2*m^2 - 64*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4]*m^2 - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 8*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2
       - 32*sp[k1,q]^2*sp[k2,k3] + 8*sp[k1,q]^2*sp[k2,k3]*m - 8*sp[k1,q
      ]^2*sp[k2,k4]*m + 4*sp[k1,q]^2*sp[k2,k4]*m^2 + 128*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4] - 40*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m^2 + 144*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 48*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]^2 + 16
      *sp[k1,q]*sp[k2,k4]^2*m - 24*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 4*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
      *m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,q]*sp[k2,
      k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m^2 - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 40*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,10]*color[1/2*Ca^2*Na*Tf]*den[
      sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k3 + q]]*den[sp[k3 - q]]*
      num[ - 128*sp[k1,k2]^2 + 48*sp[k1,k2]^2*m + 176*sp[k1,k2]^2*sp[k3
      ,q] - 48*sp[k1,k2]^2*sp[k3,q]*m + 104*sp[k1,k2]*sp[k1,k3] - 56*
      sp[k1,k2]*sp[k1,k3]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,
      k4]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 104*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 12*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 80*
      sp[k1,k2]*sp[k1,k4] - 40*sp[k1,k2]*sp[k1,k4]*m - 128*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 80*sp[k1
      ,k2]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[
      k1,q]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 12*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 104*
      sp[k1,k2]*sp[k1,q]*sp[k3,q] - 48*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 
      24*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k4,q]*
      m^2 + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m^2 - 12*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k2,k4] + 48*sp[k1,k2]*
      sp[k2,k4]*m + 176*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m - 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4]*m^2 + 24*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 4
      *sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2 + 104*sp[k1,k2]*sp[k3,k4] - 56*
      sp[k1,k2]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k3,k4]^2 - 40*sp[k1,k2]*
      sp[k3,k4]^2*m + 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 104*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 96*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q]*m^2 + 104*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48
      *sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k4,q] + 40*sp[k1
      ,k2]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k4,q]^2 - 40*sp[k1,k2]*sp[k4,q]
      ^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 - 24*sp[k1,k3]^2*sp[k2,k4]*m + 
      4*sp[k1,k3]^2*sp[k2,k4]*m^2 - 24*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,
      k3]^2*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 40*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 
      48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*
      m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 24*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 96*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*
      m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 24*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 40*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 4*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 24*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 48*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,q]
       + 40*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,
      q]*m^2 - 104*sp[k1,k4]*sp[k2,k3] + 56*sp[k1,k4]*sp[k2,k3]*m - 96*
      sp[k1,k4]*sp[k2,k3]^2 + 40*sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[k1,k4]*
      sp[k2,k3]^2*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 24*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
      *m^2 + 104*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k2,k4] - 48*sp[k1,k4]*sp[
      k2,k4]*m - 176*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q]*m + 80*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,q]*m
       - 96*sp[k1,k4]*sp[k2,q]^2 + 40*sp[k1,k4]*sp[k2,q]^2*m - 4*sp[k1,
      k4]*sp[k2,q]^2*m^2 + 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4]*m^2 - 104*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 48
      *sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m
       + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 24*sp[k1,q]^2*sp[k2,k3] - 
      16*sp[k1,q]^2*sp[k2,k3]*m - 24*sp[k1,q]^2*sp[k2,k4]*m + 4*sp[k1,q
      ]^2*sp[k2,k4]*m^2 - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 24*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 
      96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       + 4*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 48*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m^2 - 96*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 40*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 24*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8
      ,12]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[
      sp[ - k2 - k4]]*den[sp[k3 - q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1,
      k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2*sp[k1,k3]*m - 32*sp[k1,k2]^2*sp[
      k1,q] + 16*sp[k1,k2]^2*sp[k1,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m - 
      80*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2
      ]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k1,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 80*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 48*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 4*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k1,k4]*m - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k1,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 8
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q
      ]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 16*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q]*m + 144*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 48*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k1,q]*
      sp[k4,q] + 24*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,q
      ]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*
      m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 16*sp[k1,k2]*sp[k2,
      k4] - 8*sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q] + 8*
      sp[k1,k2]*sp[k2,q]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[
      k1,k2]*sp[k2,q]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 8*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k4,
      q] + 8*sp[k1,k2]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k4,q]^2 - 24*sp[k1,
      k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 80*sp[k1,k3]^2*
      sp[k2,k4] - 32*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3] - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1
      ,k4]*sp[k2,k4]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 176
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 72*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 80*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*
      sp[k2,k4] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m - 80*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 24*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,q]^2 + 8*sp[k1,k3]
      *sp[k2,q]^2*m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m + 32*sp[k1,k4]^2*sp[k2,k3] - 8*sp[k1,k4]^
      2*sp[k2,k3]*m - 64*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]
      *m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3]*m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k4]*m - 24*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[
      k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 8*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]
      *sp[k2,k4]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,
      q]^2*m^2 + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,
      q]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 24*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 32*
      sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m - 4*sp[k1,q]^2*
      sp[k2,k4]*m^2 - 64*sp[k1,q]*sp[k2,k3]^2 + 24*sp[k1,q]*sp[k2,k3]^2
      *m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 40*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 144*sp[k1,
      q]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[
      k1,q]*sp[k2,k4] - 8*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k4]*
      sp[k2,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,q]*sp[k2,k4
      ]*sp[k2,q]*m^2 - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 16*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 4
      *sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,13]*color[1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[
      sp[k3 - q]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,
      k4]*m - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m - 104
      *sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m - 12*sp[k1,k2]*
      sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,k3]^2 + 40*sp[k1,k2]*sp[k1,k3]^2
      *m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q]*m - 112*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 40*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k3]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 
      48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 104*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q] + 36*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 136*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q] + 20*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 80*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 40*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m
       + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m + 72*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4]*m + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 40*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 
      16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 56*sp[k1,k2]*sp[k1,q]*sp[k2,
      k3] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 88*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 40*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 80*sp[k1
      ,k2]*sp[k1,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 48*
      sp[k1,k2]*sp[k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m + 40*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q] - 12*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 24*sp[
      k1,k2]*sp[k2,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 8*
      sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 
      32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4] - 8*sp[
      k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 4*sp[k1,k2
      ]*sp[k3,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 20*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m - 36*sp[k1,k2]*sp[k3,q] + 20*sp[k1,k2
      ]*sp[k3,q]*m + 160*sp[k1,k2]*sp[k3,q]^2 - 68*sp[k1,k2]*sp[k3,q]^2
      *m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,q]*sp[k4,
      q]*m - 24*sp[k1,k2]*sp[k4,q] + 16*sp[k1,k2]*sp[k4,q]*m - 72*sp[k1
      ,k2]*sp[k4,q]^2 + 28*sp[k1,k2]*sp[k4,q]^2*m - 80*sp[k1,k3]^2*sp[
      k2,k3] + 32*sp[k1,k3]^2*sp[k2,k3]*m + 16*sp[k1,k3]^2*sp[k2,k4] - 
      32*sp[k1,k3]^2*sp[k2,k4]*m + 120*sp[k1,k3]^2*sp[k2,q] - 44*sp[k1,
      k3]^2*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k3]*m - 104*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 32*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k3] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] + 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[
      k1,q]*sp[k2,q] + 8*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 8*sp[k1,k3]*
      sp[k2,k3] + 8*sp[k1,k3]*sp[k2,k3]*m + 72*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q] - 28*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3
      ]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 24*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 56*sp[k1,k3
      ]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 56*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 20*sp[k1
      ,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m + 56*sp[k1,k3]*sp[k2,q]^2
       - 16*sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 
      4*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k3,q]
       + 36*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 36*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k4]^2*sp[k2,
      k3] - 160*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k4]
      *sp[k1,q]*sp[k2,q]*m - 40*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 24*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 24*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,k4]*sp[k2,k4] + 8*sp[k1,k4]*
      sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q] + 12*sp[k1,k4]*sp[k2,q]
      *m - 56*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m + 40*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4] - 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 
      96*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 36*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       + 40*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 12*sp[k1,k4]*sp[k2,q]*sp[k4,q
      ]*m - 32*sp[k1,q]^2*sp[k2,k3] + 8*sp[k1,q]^2*sp[k2,k3]*m + 80*sp[
      k1,q]^2*sp[k2,k4] - 32*sp[k1,q]^2*sp[k2,k4]*m - 12*sp[k1,q]*sp[k2
      ,k3] + 4*sp[k1,q]*sp[k2,k3]*m - 72*sp[k1,q]*sp[k2,k3]^2 + 28*sp[
      k1,q]*sp[k2,k3]^2*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 20*sp[k1,
      q]*sp[k2,k3]*sp[k2,k4]*m - 56*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*
      sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 40*sp[k1,q]*sp[k2,k3]*sp[k3,k4]
       - 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 112*sp[k1,q]*sp[k2,k3]*sp[
      k3,q] + 44*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 12*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*m + 56*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 120*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4] + 44*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 56*sp[k1,q]*
      sp[k2,k4]*sp[k4,q] - 20*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[
      k1,q]*sp[k2,q]*sp[k3,q] - 16*sp[k1,q]*sp[k2,q]*sp[k3,q]*m + 64*
      sp[k1,q]*sp[k2,q]*sp[k4,q] - 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + 
      amp[8,14]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2
       - k3]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[ - 32*sp[k1,k2]^2
       + 8*sp[k1,k2]^2*m - 104*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*
      sp[k3,k4]*m + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m
       + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1
      ,k2]*sp[k1,k3] + 8*sp[k1,k2]*sp[k1,k3]*m + 72*sp[k1,k2]*sp[k1,k3]
      *sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 88*sp[k1,
      k2]*sp[k1,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 40
      *sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m
       + 40*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k3]*m - 104*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 24*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,q]*m - 56*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 24*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 112*sp[k1,k2]*sp[k1,q]*sp[
      k2,q] - 40*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] - 12*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[
      k1,q]*sp[k3,q] - 12*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 16*sp[k1,k2]*
      sp[k2,k3]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[
      k2,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,
      k2]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 32*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4
      ] - 8*sp[k1,k2]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 
      32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 136*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 88*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 104*sp[k1,
      k2]*sp[k2,q] - 48*sp[k1,k2]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,q]^2
       - 40*sp[k1,k2]*sp[k2,q]^2*m + 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       - 20*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 104*sp[k1,k2]*sp[k2,q]*sp[
      k3,q] + 36*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,q]*
      sp[k4,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,
      k4] - 4*sp[k1,k2]*sp[k3,k4]*m + 72*sp[k1,k2]*sp[k3,k4]^2 - 28*sp[
      k1,k2]*sp[k3,k4]^2*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 8*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 20*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 60*sp[k1,k2]*sp[k3,q] - 28*sp[k1
      ,k2]*sp[k3,q]*m - 160*sp[k1,k2]*sp[k3,q]^2 + 68*sp[k1,k2]*sp[k3,q
      ]^2*m - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 4*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m + 56*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^2*sp[k2,k4]*m
       + 56*sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 56*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 
      56*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
      *m - 56*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m + 72*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 28*sp[k1,k3]*sp[k1
      ,q]*sp[k2,q]*m - 104*sp[k1,k3]*sp[k2,k3] + 40*sp[k1,k3]*sp[k2,k3]
      *m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,k3]*sp[k2
      ,k3]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,k3]
      *sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q] + 16*sp[
      k1,k3]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 
      16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4] - 4*
      sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 12
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ] - 36*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 44*sp[k1,k3]*sp[k2
      ,q] - 20*sp[k1,k3]*sp[k2,q]*m + 120*sp[k1,k3]*sp[k2,q]^2 - 44*sp[
      k1,k3]*sp[k2,q]^2*m - 112*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 36*sp[k1
      ,k3]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 36*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 
      4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       - 20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3] - 20
      *sp[k1,k4]*sp[k2,k3]*m - 80*sp[k1,k4]*sp[k2,k3]^2 + 32*sp[k1,k4]*
      sp[k2,k3]^2*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 20*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 56*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 
      20*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 120*sp[k1,k4]*sp[k2,k3]
      *sp[k4,q] - 44*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 104*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 48*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[
      k1,k4]*sp[k2,q]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m - 56*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 72*sp[k1
      ,q]^2*sp[k2,k3] + 28*sp[k1,q]^2*sp[k2,k3]*m - 20*sp[k1,q]*sp[k2,
      k3] + 12*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1
      ,q]*sp[k2,k3]^2*m + 160*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,q
      ]*sp[k2,k3]*sp[k2,k4]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 4*sp[
      k1,q]*sp[k2,k3]*sp[k2,q]*m + 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 
      112*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 44*sp[k1,q]*sp[k2,k3]*sp[k3,q]*
      m + 40*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,q]*sp[k2,k3]*sp[k4,
      q]*m + 24*sp[k1,q]*sp[k2,k4]^2 - 48*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m - 80*sp[k1,q]*sp[k2,q]^2 + 32*sp[k1,q]*sp[k2,q]^2*m - 24*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 
      80*sp[k1,q]*sp[k2,q]*sp[k3,q] + 32*sp[k1,q]*sp[k2,q]*sp[k3,q]*m]
       + amp[8,15]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - 
      k2 - k4]]*den[sp[ - k3 + q]]*den[sp[k3 - q]]*num[128*sp[k1,k2]^2
       - 48*sp[k1,k2]^2*m - 176*sp[k1,k2]^2*sp[k3,q] + 48*sp[k1,k2]^2*
      sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 4
      *sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 + 12*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k1,
      k4] - 48*sp[k1,k2]*sp[k1,k4]*m - 176*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,q
      ]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 12*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 24*sp[k1
      ,k2]*sp[k1,q]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 
      104*sp[k1,k2]*sp[k2,k3] + 56*sp[k1,k2]*sp[k2,k3]*m - 24*sp[k1,k2]
      *sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 
      104*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q
      ]*m + 12*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m^2 - 80*sp[k1,k2]*sp[k2,k4] + 40*sp[k1,k2]*sp[k2,k4]*m
       + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m + 80*sp[k1,k2]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,q]*m + 12*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*
      m^2 - 104*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,q]*sp[
      k3,q]*m - 24*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,q]
      *sp[k4,q]*m^2 - 104*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]*sp[k3,k4]*
      m - 96*sp[k1,k2]*sp[k3,k4]^2 + 40*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[
      k1,k2]*sp[k3,k4]^2*m^2 + 104*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4
      ,q]*m^2 - 104*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m + 80*sp[k1,k2]*sp[k4,q] - 40*sp[k1,k2]*sp[k4,q]*m - 
      96*sp[k1,k2]*sp[k4,q]^2 + 40*sp[k1,k2]*sp[k4,q]^2*m - 4*sp[k1,k2]
      *sp[k4,q]^2*m^2 + 96*sp[k1,k3]^2*sp[k2,k4] - 40*sp[k1,k3]^2*sp[k2
      ,k4]*m + 4*sp[k1,k3]^2*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k3] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m^2 + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 96*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4] - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4]*m^2 - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 16*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 104*sp[k1,k3]*sp[k2,k4] - 56*sp[
      k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 4*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 24*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m^2 - 104*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m - 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*sp[
      k2,k4]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[
      k2,q]^2*m - 24*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 4*sp[
      k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[
      k1,k4]*sp[k2,k3]^2*m^2 - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4] - 40*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4]*m^2 - 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 4*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[
      k1,k4]*sp[k2,k4] + 48*sp[k1,k4]*sp[k2,k4]*m + 176*sp[k1,k4]*sp[k2
      ,k4]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 24*sp[k1,k4]*
      sp[k2,q]^2*m - 4*sp[k1,k4]*sp[k2,q]^2*m^2 - 48*sp[k1,k4]*sp[k2,q]
      *sp[k3,k4] - 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 40*sp[k1,k4]
      *sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 96*sp[
      k1,q]^2*sp[k2,k4] - 40*sp[k1,q]^2*sp[k2,k4]*m + 4*sp[k1,q]^2*sp[
      k2,k4]*m^2 + 24*sp[k1,q]*sp[k2,k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2*m
       - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 24*sp[k1,q]*sp[k2,k3
      ]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 80*sp[k1,q]*
      sp[k2,k4] + 40*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k2
      ,q] - 40*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[
      k2,q]*m^2 - 12*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4]*m^2 + 104*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]
      *sp[k2,k4]*sp[k3,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 4*sp[
      k1,q]*sp[k2,k4]*sp[k4,q]*m^2 + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 
      16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,16]*color[ - 1/4*Ca^2*
      Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*
      den[sp[k3 - q]]*num[ - 40*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*
      sp[k3,k4]*m + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m
       + 104*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m - 48*sp[
      k1,k2]*sp[k1,k3] + 12*sp[k1,k2]*sp[k1,k3]*m + 112*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 24*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 56*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       - 40*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 12*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 12*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 24*sp[k1,k2]*sp[k1,k4] + 104*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 88*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 48*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 24*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k3] + 8*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 72*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m
       + 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4]*m + 40*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m - 88*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,q]*
      sp[k4,q]*m + 12*sp[k1,k2]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[k2,k3]^2
       - 40*sp[k1,k2]*sp[k2,k3]^2*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*
      sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 104*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,q] - 36*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 136*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 20*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 80*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k2
      ,q]*m + 88*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]
      *sp[k3,k4]*m - 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 40*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1
      ,k2]*sp[k2,k4]*sp[k4,q]*m - 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]
       + 8*sp[k1,k2]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 4*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 20*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 36*sp[k1,k2]*sp[k3,q] - 20
      *sp[k1,k2]*sp[k3,q]*m - 160*sp[k1,k2]*sp[k3,q]^2 + 68*sp[k1,k2]*
      sp[k3,q]^2*m - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k4,q] - 16*sp[k1,k2]*sp[k4,q]*m
       + 72*sp[k1,k2]*sp[k4,q]^2 - 28*sp[k1,k2]*sp[k4,q]^2*m + 72*sp[k1
      ,k3]^2*sp[k2,q] - 28*sp[k1,k3]^2*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 72*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3] + 28*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 56*
      sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 
      8*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,k3]*sp[k2,k3]*m + 80*sp[k1,k3]*
      sp[k2,k3]^2 - 32*sp[k1,k3]*sp[k2,k3]^2*m - 48*sp[k1,k3]*sp[k2,k3]
      *sp[k2,k4] + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 24*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q] + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 80*sp[k1,
      k3]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 24*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       + 40*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]^2 + 160*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 24*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       + 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 12*sp[k1,k3]*sp[k2,q] - 4*
      sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k2,q]^2 - 8*sp[k1,k3]*sp[
      k2,q]^2*m - 40*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4]*m + 112*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 44*sp[k1,k3]*
      sp[k2,q]*sp[k3,q]*m - 12*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 56*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 56*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 
      56*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*
      sp[k2,k3]^2 + 32*sp[k1,k4]*sp[k2,k3]^2*m + 104*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,k4] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q] - 20*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 56*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       + 48*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 48*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 4
      *sp[k1,k4]*sp[k2,q]*m - 80*sp[k1,k4]*sp[k2,q]^2 + 32*sp[k1,k4]*
      sp[k2,q]^2*m + 120*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 44*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 12*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m - 56*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 20*sp[
      k1,k4]*sp[k2,q]*sp[k4,q]*m - 56*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q
      ]^2*sp[k2,k3]*m + 56*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,
      k4]*m - 20*sp[k1,q]*sp[k2,k3] + 12*sp[k1,q]*sp[k2,k3]*m - 120*sp[
      k1,q]*sp[k2,k3]^2 + 44*sp[k1,q]*sp[k2,k3]^2*m - 48*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,q
      ]*sp[k2,k3]*sp[k3,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 96*sp[
      k1,q]*sp[k2,k3]*sp[k3,q] - 36*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 112
      *sp[k1,q]*sp[k2,k3]*sp[k4,q] - 36*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       + 32*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,q]*
      sp[k2,k4]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 40*sp[k1,
      q]*sp[k2,k4]*sp[k3,k4] + 12*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 96*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 36*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 
      40*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 12*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m
       + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m - 32*sp[k1,q]*sp[k2,q]*sp[k3,q] + 16*sp[k1,q]*sp[k2,q]*sp[k3,
      q]*m - 64*sp[k1,q]*sp[k2,q]*sp[k4,q] + 32*sp[k1,q]*sp[k2,q]*sp[k4
      ,q]*m] + amp[9,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k4]]*den[sp[k3 - q]]*num[ - 48*sp[k1,k2]*sp[k1,k3] + 24*
      sp[k1,k2]*sp[k1,k3]*m + 48*sp[k1,k2]*sp[k1,q] - 24*sp[k1,k2]*sp[
      k1,q]*m - 48*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m + 48*
      sp[k1,k2]*sp[k4,q] - 24*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,k4]*sp[k2
      ,k3] - 24*sp[k1,k4]*sp[k2,k3]*m - 48*sp[k1,k4]*sp[k2,q] + 24*sp[
      k1,k4]*sp[k2,q]*m] + amp[9,1]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1
       - k2]]*den[sp[k1 + k4]]*den[sp[k3 - q]]*num[ - 48*sp[k1,k2]*sp[
      k1,k3] + 24*sp[k1,k2]*sp[k1,k3]*m + 48*sp[k1,k2]*sp[k1,q] - 24*
      sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*sp[
      k3,k4]*m + 48*sp[k1,k2]*sp[k4,q] - 24*sp[k1,k2]*sp[k4,q]*m + 48*
      sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m - 48*sp[k1,k4]*sp[
      k2,q] + 24*sp[k1,k4]*sp[k2,q]*m] + amp[9,2]*color[1/4*Ca^2*Na*Tf]
      *den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k3 - k4]]*den[sp[
      k3 - q]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*
      m - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m - 104*sp[
      k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m + 128*sp[k1,k2]*sp[
      k1,k3] - 48*sp[k1,k2]*sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,k3]^2 + 40
      *sp[k1,k2]*sp[k1,k3]^2*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 112*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] + 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 104*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 104*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 36*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*
      m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q]*m - 136*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 20*sp[k1,k2]*sp[k1,k3]
      *sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*sp[k1,k4]*m
       + 80*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 40*sp[k1,k2]*sp[k1,k4]*sp[k1
      ,q]*m - 56*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k3]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 24*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 72*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 136*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 88*sp[k1
      ,k2]*sp[k1,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 32*
      sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 
      40*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 12*sp[k1,k2]*sp[k2,k3]*sp[k3,
      k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 60*sp[k1,k2]*sp[k3,k4] - 24*
      sp[k1,k2]*sp[k3,k4]*m + 160*sp[k1,k2]*sp[k3,k4]^2 - 68*sp[k1,k2]*
      sp[k3,k4]^2*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 4*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 8*sp[k1,k2]
      *sp[k3,k4]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 20*sp[k1
      ,k2]*sp[k3,q]*sp[k4,q]*m - 72*sp[k1,k2]*sp[k4,q]^2 + 28*sp[k1,k2]
      *sp[k4,q]^2*m - 80*sp[k1,k3]^2*sp[k2,k3] + 32*sp[k1,k3]^2*sp[k2,
      k3]*m - 120*sp[k1,k3]^2*sp[k2,k4] + 44*sp[k1,k3]^2*sp[k2,k4]*m - 
      16*sp[k1,k3]^2*sp[k2,q] + 32*sp[k1,k3]^2*sp[k2,q]*m + 24*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k3] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m
       + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 20*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,q]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k4]*m - 104*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 32*sp[k1,k3]*
      sp[k1,q]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 28*sp[k1
      ,k3]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] + 
      32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 68*sp[k1,k3]*sp[k2,k4]
       - 24*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k4]^2 - 16*sp[k1
      ,k3]*sp[k2,k4]^2*m + 56*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 36*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 112*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q] - 36*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]
      *sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 56*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]^
      2*sp[k2,k3] + 8*sp[k1,k4]^2*sp[k2,k3]*m - 80*sp[k1,k4]^2*sp[k2,q]
       + 32*sp[k1,k4]^2*sp[k2,q]*m - 160*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k4]*sp[k1,q
      ]*sp[k2,q] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 76*sp[k1,k4]*sp[
      k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 72*sp[k1,k4]*sp[k2,k3]^2 - 28
      *sp[k1,k4]*sp[k2,k3]^2*m - 56*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       + 20*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 112*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4] + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 40*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 12*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,k4] - 56*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m + 
      16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m + 64*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[
      k4,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k4]*sp[k2,q]
      *sp[k3,k4]*m + 120*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 44*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m + 56*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 20*sp[k1,k4]*
      sp[k2,q]*sp[k4,q]*m + 24*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 24*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] + 56*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]*
      sp[k2,k4]^2*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 36*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m - 40*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 12*sp[k1,q]
      *sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 12*sp[k1
      ,q]*sp[k2,k4]*sp[k4,q]*m - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[9,3]*color[1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k3 + q]]*den[sp[k3
       - q]]*num[ - 128*sp[k1,k2]^2 + 48*sp[k1,k2]^2*m + 176*sp[k1,k2]^
      2*sp[k3,q] - 48*sp[k1,k2]^2*sp[k3,q]*m + 104*sp[k1,k2]*sp[k1,k3]
       - 56*sp[k1,k2]*sp[k1,k3]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 24*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 104*sp[k1,k2]
      *sp[k1,k3]*sp[k3,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 12*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2
       + 80*sp[k1,k2]*sp[k1,k4] - 40*sp[k1,k2]*sp[k1,k4]*m - 128*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 80*
      sp[k1,k2]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k2]*
      sp[k1,q]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 12*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 
      104*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 48*sp[k1,k2]*sp[k1,q]*sp[k3,q]*
      m + 24*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q]*m^2 + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m^2 - 12*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k2,k4] + 48*sp[k1,
      k2]*sp[k2,k4]*m + 176*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m - 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 4*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 24*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m
       - 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2 + 104*sp[k1,k2]*sp[k3,k4] - 
      56*sp[k1,k2]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k3,k4]^2 - 40*sp[k1,k2
      ]*sp[k3,k4]^2*m + 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 104*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 96*sp[k1,k2
      ]*sp[k3,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1
      ,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 104*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 
      48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k4,q] + 40*sp[
      k1,k2]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k4,q]^2 - 40*sp[k1,k2]*sp[k4,
      q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 - 24*sp[k1,k3]^2*sp[k2,k4]*m
       + 4*sp[k1,k3]^2*sp[k2,k4]*m^2 - 24*sp[k1,k3]^2*sp[k2,q] + 16*sp[
      k1,k3]^2*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 40*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2
       + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,
      q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k1,q]
      *sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 24*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 96*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*
      m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 24*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 40*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 4*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 24*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 48*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,q]
       + 40*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,
      q]*m^2 - 104*sp[k1,k4]*sp[k2,k3] + 56*sp[k1,k4]*sp[k2,k3]*m - 96*
      sp[k1,k4]*sp[k2,k3]^2 + 40*sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[k1,k4]*
      sp[k2,k3]^2*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 24*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
      *m^2 + 104*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k2,k4] - 48*sp[k1,k4]*sp[
      k2,k4]*m - 176*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q]*m + 80*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,q]*m
       - 96*sp[k1,k4]*sp[k2,q]^2 + 40*sp[k1,k4]*sp[k2,q]^2*m - 4*sp[k1,
      k4]*sp[k2,q]^2*m^2 + 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4]*m^2 - 104*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 48
      *sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m
       + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 24*sp[k1,q]^2*sp[k2,k3] - 
      16*sp[k1,q]^2*sp[k2,k3]*m - 24*sp[k1,q]^2*sp[k2,k4]*m + 4*sp[k1,q
      ]^2*sp[k2,k4]*m^2 - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 24*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 
      96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       + 4*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 + 48*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m^2 - 96*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 40*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 24*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[9
      ,4]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*
      den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[32*sp[k1,k2]^2 - 8*sp[k1,
      k2]^2*m + 104*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*sp[k3,k4]*m
       - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m - 40*sp[k1
      ,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,
      k3] + 8*sp[k1,k2]*sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]
       + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 72*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[
      k1,k2]*sp[k1,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m
       + 88*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q]*m + 136*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 40*sp[k1,k2]*sp[k1,k3]
      *sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k4]*
      sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 88*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,q] - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 80*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m - 104*sp[k1,k2]*sp[k1,q] + 48*sp[k1,k2]*sp[k1,q]*m - 
      80*sp[k1,k2]*sp[k1,q]^2 + 40*sp[k1,k2]*sp[k1,q]^2*m + 104*sp[k1,
      k2]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 24*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m
       - 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k2]*sp[k1,q]*sp[k2,
      q]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 20*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,
      q]*sp[k3,q]*m + 104*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 36*sp[k1,k2]*
      sp[k1,q]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 8*sp[k1,k2]*
      sp[k2,k4]*m + 88*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       + 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,q]*sp[
      k4,q] + 12*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]
       + 4*sp[k1,k2]*sp[k3,k4]*m - 72*sp[k1,k2]*sp[k3,k4]^2 + 28*sp[k1,
      k2]*sp[k3,k4]^2*m + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 20*sp[k1,k2
      ]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 8*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 4*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 60*sp[k1,k2]*sp[k4,q] + 28*sp[k1,
      k2]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k4,q]^2 - 68*sp[k1,k2]*sp[k4,q]
      ^2*m - 24*sp[k1,k3]^2*sp[k2,q] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
       + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 160*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 104*sp[
      k1,k3]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 
      48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*
      m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,
      q]*m + 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4] + 4*sp[k1,k3]*sp[k2,k4]*m - 
      56*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m - 8*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 40*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 12*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*
      m + 40*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 12*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 36*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 80*sp[k1,k4]^
      2*sp[k2,k3] - 32*sp[k1,k4]^2*sp[k2,k3]*m + 32*sp[k1,k4]^2*sp[k2,q
      ] - 8*sp[k1,k4]^2*sp[k2,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 
      20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,
      k4] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k4]*sp[k1,q]*
      sp[k2,q] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3
      ] + 20*sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] + 20*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 56*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,k4] - 20*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 120*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q] + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       + 104*sp[k1,k4]*sp[k2,k4] - 40*sp[k1,k4]*sp[k2,k4]*m + 56*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 64*
      sp[k1,k4]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*
      m + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k4
      ]*sp[k4,q]*m + 20*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m + 
      72*sp[k1,k4]*sp[k2,q]^2 - 28*sp[k1,k4]*sp[k2,q]^2*m - 12*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m - 40*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 12*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m - 112*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 44
      *sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,q]^2*sp[k2,k3] - 32*sp[
      k1,q]^2*sp[k2,k3]*m - 120*sp[k1,q]^2*sp[k2,k4] + 44*sp[k1,q]^2*
      sp[k2,k4]*m + 80*sp[k1,q]^2*sp[k2,q] - 32*sp[k1,q]^2*sp[k2,q]*m
       + 56*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 44*sp[k1,q]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k4]*m
       - 56*sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[k2,k4]^2*m - 72*sp[k1
      ,q]*sp[k2,k4]*sp[k2,q] + 28*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 112*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 36*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]
      *m - 96*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 36*sp[k1,q]*sp[k2,k4]*sp[k4
      ,q]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k4,q] - 32*sp[k1,q]*sp[k2,q]*
      sp[k4,q]*m] + amp[9,5]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[sp[k3
       - q]]*num[64*sp[k1,k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2*sp[k1,k3]*m
       - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,k2]^2*sp[k1,q]*m - 64*sp[
      k1,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[
      k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,
      k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]
      *sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 128*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m + 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k1,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 
      32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 160*sp[k1,k2]
      *sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 160*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] + 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 
      32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,
      k4]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k3,k4]^2 - 48*sp[k1,k2]*sp[k3,
      k4]^2*m + 8*sp[k1,k2]*sp[k3,k4]^2*m^2 + 64*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m^2 - 32*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[
      k2,k4]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m - 256*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 128*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2
       - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 128*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 64*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,k4] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 8
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 256*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m^2 + 128*sp[k1,k4]^2*sp[k2,k3] - 32*sp[k1,k4]^2*sp[
      k2,k3]*m - 64*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 
      96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
      *m + 320*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 208*sp[k1,k4]*sp[k1,q]*
      sp[k2,k4]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 - 32*sp[k1,k4]*
      sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m - 32*sp[k1,k4]*sp[k2,k3]
      *sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k4]*sp[
      k2,k3]*sp[k3,k4] + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2
      ,k4]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m - 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 32*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 
      112*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m^2] + amp[9,6]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[k3 - 
      q]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m + 
      32*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^
      2*sp[k4,q]*m + 96*sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m
       - 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 48*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 
      32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q
      ]*m^2 - 32*sp[k1,k2]*sp[k1,k4] + 16*sp[k1,k2]*sp[k1,k4]*m - 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*sp[
      k1,k2]*sp[k1,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 96*
      sp[k1,k2]*sp[k1,q]*sp[k4,q] + 80*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 256*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4] + 144*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 96*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 80*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k3,k4]
       - 64*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 448*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 192*sp[k1,k2]*sp[k3,q]*sp[
      k4,q] + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m^2 - 128*sp[k1,k3]^2*sp[k2,q] + 48*sp[k1,k3]^2*sp[k2,q
      ]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 
      160*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q]*
      m + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 80*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,
      k3]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k3
      ]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4
      ]*sp[k2,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m^2 - 320*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 176*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2
       - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k3]*sp[k2,q]*sp[k3
      ,k4]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 32*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4
      ]*sp[k1,q]*sp[k2,q] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1
      ,k4]*sp[k1,q]*sp[k2,q]*m^2 - 160*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,
      k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 192*sp[k1,k4]*sp[k2
      ,k3]^2 - 112*sp[k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]*sp[k2,k3]^2*
      m^2 + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m^2 - 192*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 112*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 256*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,q]^2*sp[k2,k3]
       - 32*sp[k1,q]^2*sp[k2,k3]*m + 96*sp[k1,q]^2*sp[k2,k4] - 80*sp[k1
      ,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2*sp[k2,k4]*m^2 - 64*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 192*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 8*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k3
      ,q] - 80*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 - 224*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[9,8]
      *color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2 - k3]]*
      den[sp[k3 - q]]*num[64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2
       + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[
      k3,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 128*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 32*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k2,k4]*sp[k2,q]
       + 128*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k4]*
      sp[k2,q]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 
      16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2] + amp[9,9]*color[ - 1/2*Ca*
      Cf*Na*Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2 + q]]*den[sp[k3 - q]]*
      num[ - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,k4]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k4]*sp[k2,k4] - 64*
      sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k4]
      *sp[k2,k4]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 16*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m^2 - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 64*sp[
      k1,k4]*sp[k2,q]*sp[k4,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 16*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2] + amp[9,10]*color[ - Ca*Cf*Na*Tf
      ]*den[sp[k1 + k4]]^2*den[sp[ - k3 + q]]*den[sp[k3 - q]]*num[ - 
      192*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 128*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4] - 224*sp[k1,k4
      ]*sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,k4]*m^2 - 352*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q] + 272*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 16*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2
       - 192*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k4]*sp[k2,q]*sp[k4
      ,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2] + amp[9,11]*color[1/2
      *Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k3]]*den[sp[k3 - q]]*num[ - 32*sp[k1,k2]^2 + 32*
      sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]
      ^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m
       - 32*sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16
      *sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q
      ] + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 80*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 96*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32
      *sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*
      m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 48*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 80*sp[k1,k2]*sp[k2,k3
      ]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k2]*
      sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,
      q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 256*sp[k1,k2]*
      sp[k2,q]*sp[k4,q] - 144*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k2,q]*sp[k4,q]*m^2 - 272*sp[k1,k2]*sp[k3,k4] + 104*sp[k1,
      k2]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q] + 112*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m^2 + 448*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 224*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 - 96*sp[k1,k3]^2*sp[k2,k4] + 80*sp[k1,k3]^2*sp[k2,k4]*m - 16*
      sp[k1,k3]^2*sp[k2,k4]*m^2 + 96*sp[k1,k3]^2*sp[k2,q] - 32*sp[k1,k3
      ]^2*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 32
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       - 160*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k3]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]
      *sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,q]*m - 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 112*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2
       + 240*sp[k1,k3]*sp[k2,k4] - 104*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,
      k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 80*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2
       + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m - 192*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 80*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 96*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3]*m^2 + 144*sp[k1,k4]*sp[k2,k3] - 72*sp[k1,k4]*
      sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 32*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 256*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 24*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 192*sp[k1,k4]*sp[k2,q]^2 + 112*
      sp[k1,k4]*sp[k2,q]^2*m - 16*sp[k1,k4]*sp[k2,q]^2*m^2 - 192*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]^2*sp[k2,k3] + 48*
      sp[k1,q]^2*sp[k2,k3]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2
       + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,q]*sp[k2,
      k3]*sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[
      k2,k4]*sp[k2,q] + 80*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m^2 - 320*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 176*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m + 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[9,12]*color[1/
      2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k4]]*den[sp[k3 - q]]*num[64*sp[k1,k2]^2 - 32*sp[k1
      ,k2]^2*m - 128*sp[k1,k2]^2*sp[k1,k3] + 64*sp[k1,k2]^2*sp[k1,k3]*m
       + 64*sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^2*sp[k1,q]*m + 32*sp[k1
      ,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3
      ,q]*m - 64*sp[k1,k2]^2*sp[k4,q] - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,
      k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m - 160*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 160*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 
      64*sp[k1,k2]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k4]*m + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 32*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 64*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*
      m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,
      k4]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 32
      *sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 192*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[
      k4,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k4]*m
       + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m^2 - 64*sp[k1,k2]*sp[k4,q]^2 + 48*sp[k1,k2]*
      sp[k4,q]^2*m - 8*sp[k1,k2]*sp[k4,q]^2*m^2 + 320*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4] - 208*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q] + 112*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m^2 - 64*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^
      2*sp[k2,k3]*m + 128*sp[k1,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q
      ]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 256*sp[k1,k4]*sp[k1,q]*
      sp[k2,k4] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,
      k4]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q]
       - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k4]*sp[k2,k4] + 
      96*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 32*sp[k1,k4]*sp[k2,q]^2 - 16*
      sp[k1,k4]*sp[k2,q]^2*m - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[k4,q]
       - 48*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k4,
      q]*m^2 + 32*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m - 
      128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k4]*sp[
      k2,q]*m + 256*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 160*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[k1,
      q]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 8*sp[
      k1,q]*sp[k2,k4]*sp[k4,q]*m^2] + amp[9,14]*color[1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[k3 - q]]*den[sp[ - k4
       + q]]*num[16*sp[k1,k2]^2 + 16*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,
      k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k3,k4]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 48*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 48*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 160*sp[k1,k2]*sp[
      k1,q]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*sp[k1,
      k2]*sp[k1,q]*sp[k3,q] + 40*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 16*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 
      16*sp[k1,k2]*sp[k2,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       + 48*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k4
      ,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 96*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 40*sp[k1,k2]*sp[k2
      ,q]*sp[k4,q]*m + 184*sp[k1,k2]*sp[k3,k4] - 60*sp[k1,k2]*sp[k3,k4]
      *m + 4*sp[k1,k2]*sp[k3,k4]*m^2 + 144*sp[k1,k2]*sp[k3,k4]^2 - 96*
      sp[k1,k2]*sp[k3,k4]^2*m + 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 24*sp[k1
      ,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 
      24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ]*m^2 - 224*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 72*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m - 48*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*
      m - 48*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m + 16*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 112*sp[k1,k3]*sp[k1,q]*sp[k2,k3
      ] - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k3]*sp[k1,q]
      *sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 168*sp[k1,k3]*sp[k2,k4] + 60*sp[k1,k3]*sp[k2,
      k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 48*sp[k1,k3]*sp[k2,k4]^2 + 16
      *sp[k1,k3]*sp[k2,k4]^2*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 144
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 48*sp[k1,k3]*sp[k2,k4
      ]*sp[k3,q] - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 40*sp[k1,
      k3]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 
      48*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
      *m + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q]
      *sp[k2,k3]*m - 120*sp[k1,k4]*sp[k2,k3] + 60*sp[k1,k4]*sp[k2,k3]*m
       - 4*sp[k1,k4]*sp[k2,k3]*m^2 + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m - 176*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 112*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 64*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q
      ] + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[
      k4,q]*m^2 + 112*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k4]*sp[k2
      ,k4]*sp[k2,q]*m + 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,q]^2 - 56*sp[k1,k4]*
      sp[k2,q]^2*m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 56*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,q]^2*sp[k2,k3] - 56*sp[k1,q]^2*
      sp[k2,k3]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 56*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q
      ]*sp[k2,k4]^2*m - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 24*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1
      ,q]*sp[k2,k4]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 32*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4]
       + 56*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[9,15]*color[ - Ca*Cf*
      Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[
      sp[ - k3 + q]]*den[sp[k3 - q]]*num[ - 256*sp[k1,k2]^2 + 96*sp[k1,
      k2]^2*m + 352*sp[k1,k2]^2*sp[k3,q] - 96*sp[k1,k2]^2*sp[k3,q]*m + 
      192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k3]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q]*m - 256*sp[k1,k2]*sp[k1,k4] + 96*sp[k1,k2]
      *sp[k1,k4]*m + 352*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 96*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k3]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[
      k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k2,k3]
      *sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 256*sp[
      k1,k2]*sp[k2,k4] + 96*sp[k1,k2]*sp[k2,k4]*m + 352*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,q] - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1
      ,k2]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 192*
      sp[k1,k2]*sp[k3,k4]^2 - 80*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[k1,k2]*
      sp[k3,k4]^2*m^2 - 192*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 16*sp[k1,k2]
      *sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 192
      *sp[k1,k2]*sp[k4,q]^2 - 80*sp[k1,k2]*sp[k4,q]^2*m + 8*sp[k1,k2]*
      sp[k4,q]^2*m^2 - 96*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,
      k4]*m + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k3]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] + 80*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,
      k3]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 
      48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
      *m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2
      ,q]*m - 96*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m + 
      96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
      *m - 192*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q]*m^2 + 512*sp[k1,k4]*sp[k2,k4] - 320*sp[k1,
      k4]*sp[k2,k4]*m + 48*sp[k1,k4]*sp[k2,k4]*m^2 - 704*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q] + 368*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,
      k4]*sp[k2,q]^2*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 192*
      sp[k1,k4]*sp[k2,q]*sp[k4,q] + 80*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 
      8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,q]^2*sp[k2,k4] + 16*
      sp[k1,q]^2*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16
      *sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
       + 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m^2 - 192*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 80*sp[k1,q]*sp[k2,k4]
      *sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2] + amp[9,16]*
      color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[
       - k3 - k4]]*den[sp[k3 - q]]*num[ - 16*sp[k1,k2]^2*sp[k3,k4] + 16
      *sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k4,q] + 80*sp[k1,k2]*
      sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m - 160*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]
      *sp[k1,k3]*sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 40*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 8
      *sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4] - 16*sp[
      k1,k2]*sp[k1,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q
      ]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*sp[
      k1,q]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 40*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 8*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q] - 48*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]
      *m + 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 72*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m^2 - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m^2 + 144*sp[k1,k2]*sp[k4,q]^2 - 96*sp[k1,
      k2]*sp[k4,q]^2*m + 16*sp[k1,k2]*sp[k4,q]^2*m^2 - 128*sp[k1,k3]^2*
      sp[k2,q] + 56*sp[k1,k3]^2*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] + 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,q]
      *sp[k2,k3] - 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m - 112*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 48*sp[k1,k3
      ]*sp[k1,q]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 24*sp[
      k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       - 56*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4] - 8
      *sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]^2 - 16*sp[k1,k3]*
      sp[k2,k4]^2*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m - 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 32*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 
      16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 128*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] + 56*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,q]*
      sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 32*sp[k1,k4]*sp[k1,
      q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k4]*
      sp[k1,q]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,
      k3]*m + 128*sp[k1,k4]*sp[k2,k3]^2 - 56*sp[k1,k4]*sp[k2,k3]^2*m - 
      112*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 56*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k4]*
      sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 80*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2
       - 176*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 112*sp[k1,k4]*sp[k2,q]*sp[k4
      ,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 48*sp[k1,q]^2*sp[k2,
      k3] - 16*sp[k1,q]^2*sp[k2,k3]*m - 48*sp[k1,q]^2*sp[k2,k4] + 16*
      sp[k1,q]^2*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 128*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m
       + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m + 48*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]*sp[k2,k4]^2*m + 48*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 40*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       + 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 48*sp[k1,q]*sp[k2,k4]*sp[
      k3,q] + 40*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 - 144*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 96*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 80*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[
      10,1]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2
       - k4]]*den[sp[k3 - q]]*num[48*sp[k1,k2]*sp[k2,k3] - 24*sp[k1,k2]
      *sp[k2,k3]*m - 48*sp[k1,k2]*sp[k2,q] + 24*sp[k1,k2]*sp[k2,q]*m + 
      48*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*
      sp[k4,q] + 24*sp[k1,k2]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k4] + 24*
      sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,k4] - 24*sp[k1,q]*sp[k2
      ,k4]*m] + amp[10,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[ - k2 - k4]]*den[sp[k3 - q]]*num[48*sp[k1,k2]*sp[k2,k3] - 
      24*sp[k1,k2]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k2,q] + 24*sp[k1,k2]*
      sp[k2,q]*m + 48*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m - 
      48*sp[k1,k2]*sp[k4,q] + 24*sp[k1,k2]*sp[k4,q]*m - 48*sp[k1,k3]*
      sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,k4] - 24
      *sp[k1,q]*sp[k2,k4]*m] + amp[10,2]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 - k2]]*den[sp[ - k2 - k4]]*den[sp[ - k3 - k4]]*den[sp[k3
       - q]]*num[ - 40*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]
      *m + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m + 104*
      sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 112*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 56*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m
       + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q]*m + 40*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 12*sp[k1,k2]*sp[k1,k3]
      *sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 12*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3]*m - 72*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]
       - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,k4
      ]*sp[k4,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 104*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 88*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 48*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m
       - 128*sp[k1,k2]*sp[k2,k3] + 48*sp[k1,k2]*sp[k2,k3]*m + 80*sp[k1,
      k2]*sp[k2,k3]^2 - 40*sp[k1,k2]*sp[k2,k3]^2*m + 64*sp[k1,k2]*sp[k2
      ,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,k2
      ]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 104*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 36*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*
      m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m + 136*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 20*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m
       - 80*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k2
      ,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k4]
      *sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m - 80*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k2
      ]*sp[k2,k4]*sp[k4,q]*m - 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 40*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 60*sp[k1,k2]*sp[k3,k4]
       + 24*sp[k1,k2]*sp[k3,k4]*m - 160*sp[k1,k2]*sp[k3,k4]^2 + 68*sp[
      k1,k2]*sp[k3,k4]^2*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 4*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       - 20*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 72*sp[k1,k2]*sp[k4,q]^2 - 
      28*sp[k1,k2]*sp[k4,q]^2*m - 72*sp[k1,k3]^2*sp[k2,k4] + 28*sp[k1,
      k3]^2*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 28*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k4] - 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k3]
      ^2 - 32*sp[k1,k3]*sp[k2,k3]^2*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4
      ] - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2
      ,k3]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 76*sp[
      k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,
      k4]^2 - 8*sp[k1,k3]*sp[k2,k4]^2*m + 160*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 112*sp[k1,k3]*sp[k2,k4]
      *sp[k3,k4] - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 12*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,q]^2 + 24*sp[k1,k3
      ]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 56*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4
      ]^2*sp[k2,k3]*m - 56*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,
      q]*m - 56*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 56*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m - 68*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,
      k3]*m + 120*sp[k1,k4]*sp[k2,k3]^2 - 44*sp[k1,k4]*sp[k2,k3]^2*m - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,k4
      ]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 36*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 4*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 36*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 32*
      sp[k1,k4]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*
      m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4
      ]*sp[k4,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 36*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m + 40*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 12*sp[k1,k4]
      *sp[k2,q]*sp[k3,q]*m - 40*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 12*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]^2 - 32*sp[k1,q]*
      sp[k2,k3]^2*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 20*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 104*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,q
      ]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16
      *sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k4]^2 - 32*sp[
      k1,q]*sp[k2,k4]^2*m + 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q
      ]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 12*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m - 120*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      44*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 56*sp[k1,q]*sp[k2,k4]*sp[k4,q]
       + 20*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,q]*sp[k2,q]*sp[k3,
      k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[10,3]*color[ - 1/2*
      Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 - k4]]*den[sp[ - k3
       + q]]*den[sp[k3 - q]]*num[128*sp[k1,k2]^2 - 48*sp[k1,k2]^2*m - 
      176*sp[k1,k2]^2*sp[k3,q] + 48*sp[k1,k2]^2*sp[k3,q]*m - 96*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 48
      *sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m^2 + 12*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 4*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k1,k4] - 48*sp[k1,k2]*sp[
      k1,k4]*m - 176*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 16*sp[k1,
      k2]*sp[k1,q]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 4*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 24*sp[k1,k2]*sp[k1,q]*sp[k4,q]
      *m + 4*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 - 104*sp[k1,k2]*sp[k2,k3]
       + 56*sp[k1,k2]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m
       + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 104*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] - 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 12*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 80*sp[k1,
      k2]*sp[k2,k4] + 40*sp[k1,k2]*sp[k2,k4]*m + 128*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 80*sp[k1,k2]*sp[
      k2,q] - 40*sp[k1,k2]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
      *m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 104*sp[k1,k2]*sp[k2,q]*
      sp[k3,q] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k2,
      q]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m^2 - 104*sp[k1,k2]
      *sp[k3,k4] + 56*sp[k1,k2]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k3,k4]^2
       + 40*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 + 104
      *sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,
      q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 104*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[
      k4,q] - 40*sp[k1,k2]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k4,q]^2 + 40*
      sp[k1,k2]*sp[k4,q]^2*m - 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 96*sp[k1,k3
      ]^2*sp[k2,k4] - 40*sp[k1,k3]^2*sp[k2,k4]*m + 4*sp[k1,k3]^2*sp[k2,
      k4]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 40*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 48*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m^2 + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k3]*sp[k2,
      k3]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 24*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 24*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       + 104*sp[k1,k3]*sp[k2,k4] - 56*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*
      m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 104*sp[k1,k3]*sp[k2,k4]
      *sp[k3,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 12*sp[k1,k3]*sp[
      k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 24*sp[k1
      ,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m - 24*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 48*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 40*sp[
      k1,k4]*sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 + 
      24*sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[k1,k4]*sp[k2,k3]^2*m^2 - 24*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2
       + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 40*sp[k1,k4]*sp[k2,k3]*sp[
      k3,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 48*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k2,k4] + 48*sp[k1,k4]*
      sp[k2,k4]*m + 176*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,q]^2*m - 4*sp[k1,k4]*sp[k2
      ,q]^2*m^2 - 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 4*sp[k1,k4]*sp[k2,q
      ]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 96*sp[k1,k4]
      *sp[k2,q]*sp[k4,q] - 40*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m^2 + 96*sp[k1,q]^2*sp[k2,k4] - 40*sp[k1,q]
      ^2*sp[k2,k4]*m + 4*sp[k1,q]^2*sp[k2,k4]*m^2 + 24*sp[k1,q]*sp[k2,
      k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m^2 + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,q]*sp[k2,
      k3]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,k4] + 40*sp[k1,q]*sp[k2
      ,k4]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m^2 - 12*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 104*sp[
      k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 24*
      sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2
       + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m] + amp[10,4]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[ - k2 - k4]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[ - 32*
      sp[k1,k2]^2 + 8*sp[k1,k2]^2*m - 104*sp[k1,k2]^2*sp[k3,k4] + 32*
      sp[k1,k2]^2*sp[k3,k4]*m + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^
      2*sp[k3,q]*m + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*
      m + 88*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 24*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4] + 8*sp[k1,k2]*sp[k1
      ,k4]*m + 72*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2
      ,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 56*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 112*sp[k1,k2]*sp[
      k1,q]*sp[k2,q] - 40*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 12*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 40*sp[k1
      ,k2]*sp[k1,q]*sp[k4,q] - 12*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*
      sp[k1,k2]*sp[k2,k3] - 8*sp[k1,k2]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[
      k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,
      k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 32*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*
      m - 88*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[
      k3,q]*m - 136*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k4
      ]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 80*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m
       + 104*sp[k1,k2]*sp[k2,q] - 48*sp[k1,k2]*sp[k2,q]*m + 80*sp[k1,k2
      ]*sp[k2,q]^2 - 40*sp[k1,k2]*sp[k2,q]^2*m + 136*sp[k1,k2]*sp[k2,q]
      *sp[k3,k4] - 20*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 104*sp[k1,k2]*
      sp[k2,q]*sp[k4,q] + 36*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k3,k4] - 4*sp[k1,k2]*sp[k3,k4]*m + 72*sp[k1,k2]*sp[k3,k4]^
      2 - 28*sp[k1,k2]*sp[k3,k4]^2*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
       + 20*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] - 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 60*sp[k1,k2]*sp[k4,q
      ] - 28*sp[k1,k2]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k4,q]^2 + 68*sp[k1
      ,k2]*sp[k4,q]^2*m - 56*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4]*m - 56*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 24*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       - 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 104*sp[k1,k3]*sp[k2
      ,k3]*sp[k2,q] + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 48*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,
      k3]*sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,k3]*sp[k2,k4]
      ^2 + 32*sp[k1,k3]*sp[k2,k4]^2*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 56*sp[k1,k3]*sp[k2,k4]*sp[
      k3,k4] + 20*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 120*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,q] - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] - 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1
      ,k3]*sp[k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m - 56*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*
      sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 56*sp[k1,
      k4]^2*sp[k2,k3] - 16*sp[k1,k4]^2*sp[k2,k3]*m + 56*sp[k1,k4]^2*sp[
      k2,q] - 16*sp[k1,k4]^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 72*sp[k1,k4]*sp[k1,q
      ]*sp[k2,q] - 28*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k4]*sp[
      k2,k3] - 4*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]
      *sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 40*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,k4] + 12*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 40*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q] + 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 96*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q] - 36*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 
      104*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1,k4]
      *sp[k2,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 
      16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m - 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[
      k4,q]*m + 44*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k4]*sp[k2,q]*m + 120*
      sp[k1,k4]*sp[k2,q]^2 - 44*sp[k1,k4]*sp[k2,q]^2*m - 112*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 36*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q] - 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[
      k1,k4]*sp[k2,q]*sp[k4,q] - 36*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 72*
      sp[k1,q]^2*sp[k2,k4] + 28*sp[k1,q]^2*sp[k2,k4]*m + 24*sp[k1,q]*
      sp[k2,k3]^2 + 160*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,q]
      *sp[k2,k3]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 24*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 20*
      sp[k1,q]*sp[k2,k4] + 12*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,
      k4]^2 + 8*sp[k1,q]*sp[k2,k4]^2*m - 24*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       - 4*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 12*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m + 40*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 12*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m + 112*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 44*sp[k1,q]*sp[k2,
      k4]*sp[k4,q]*m - 80*sp[k1,q]*sp[k2,q]^2 + 32*sp[k1,q]*sp[k2,q]^2*
      m - 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,
      k4]*m - 80*sp[k1,q]*sp[k2,q]*sp[k4,q] + 32*sp[k1,q]*sp[k2,q]*sp[
      k4,q]*m] + amp[10,5]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[ - k2 - k4]]^2*den[sp[k3 - q]]*num[ - 64*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 64*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4
      ]*m^2 - 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 32*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q
      ] - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[
      10,6]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]
      *den[sp[ - k2 - k4]]*den[sp[ - k2 + q]]*den[sp[k3 - q]]*num[32*
      sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]
      *m + 32*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1
      ,k2]^2*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 48*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       - 80*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q]*m^2 + 32*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 96*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 192*sp[
      k1,k2]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 32*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m
       - 256*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 144*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,
      k3] - 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k2]
      *sp[k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 
      64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
      *m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] + 48*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 272*sp[k1,k2]
      *sp[k3,k4] - 104*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*
      m^2 + 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 112*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 448*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] + 224*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 24*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 48*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*
      m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,k3]*
      sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 
      160*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q
      ]*m + 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 144*sp[k1,k3]*
      sp[k2,k4] + 72*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2
       - 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 256*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k3]*sp[k2,q]^2 - 48*sp[k1,k3]*
      sp[k2,q]^2*m - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 64*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 80*sp[k1,k4]*sp[k1,q]*sp[k2,q
      ]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m^2 - 240*sp[k1,k4]*sp[k2,k3
      ] + 104*sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 96*
      sp[k1,k4]*sp[k2,k3]^2 - 80*sp[k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]
      *sp[k2,k3]^2*m^2 + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 80*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m^2 + 320*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 176*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 192*sp[k1,q]^2*
      sp[k2,k4] - 112*sp[k1,q]^2*sp[k2,k4]*m + 16*sp[k1,q]^2*sp[k2,k4]*
      m^2 - 96*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,q]*sp[k2,k3]^2*m + 32*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m
       - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q
      ]*m - 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4]*m + 192*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 192*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m^2 - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2] + amp[10,7]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[
       - k2 - k4]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[16*sp[k1,k2]^
      2 + 16*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1
      ,k2]^2*sp[k4,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k1,
      k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 16*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,
      k2]*sp[k1,q]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q] + 40*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]
       + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4]*m + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,
      k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 96*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] + 40*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 
      184*sp[k1,k2]*sp[k3,k4] - 60*sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,k2]*
      sp[k3,k4]*m^2 + 144*sp[k1,k2]*sp[k3,k4]^2 - 96*sp[k1,k2]*sp[k3,k4
      ]^2*m + 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 24*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 24*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 224*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] + 72*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16
      *sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] + 112*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,k3
      ]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 120*sp[k1,k3]*sp[k2,k4] + 60*sp[k1,k3]*sp[k2,
      k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,
      q] + 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 176*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] + 112*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 8*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2
       - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,k3]*sp[k2,q
      ]^2 - 56*sp[k1,k3]*sp[k2,q]^2*m + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] - 56*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 48*sp[k1,k4]^2*sp[k2,
      k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m - 48*sp[k1,k4]^2*sp[k2,q] + 16*
      sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 112*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       - 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k4]*sp[k1,q]*sp[k2,q
      ]*m - 168*sp[k1,k4]*sp[k2,k3] + 60*sp[k1,k4]*sp[k2,k3]*m - 4*sp[
      k1,k4]*sp[k2,k3]*m^2 - 48*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*
      sp[k2,k3]^2*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 144*sp[k1,k4]*
      sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       - 40*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 40*sp[k1,k4]*sp[k2,
      k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 80*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 
      128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m + 128*sp[k1,q]^2*sp[k2,k4] - 56*sp[k1,q]^2*sp[k2,k4]*m - 48*sp[
      k1,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 48*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 128*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 
      32*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
      *m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 56*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 56*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m] + amp[10,8]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 - k4]]*den[sp[
      k3 - q]]*num[ - 64*sp[k1,k2]^2*sp[k2,k3] + 32*sp[k1,k2]^2*sp[k2,
      k3]*m + 128*sp[k1,k2]^2*sp[k2,q] - 64*sp[k1,k2]^2*sp[k2,q]*m + 64
      *sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2
      *sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]
      *sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 
      128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k4]
      *sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,
      k2]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 192*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 128*sp[
      k1,k2]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 
      128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2
      ,k4]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]^2 + 48*sp[k1,k2]*
      sp[k3,k4]^2*m - 8*sp[k1,k2]*sp[k3,k4]^2*m^2 - 64*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m^2 + 32*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^
      2*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3]*m + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k4
      ]^2 + 32*sp[k1,k3]*sp[k2,k4]^2*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 8*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]^2
       - 16*sp[k1,k4]*sp[k2,k3]^2*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 48*sp[
      k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m^2 + 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 160*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m + 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q] + 208*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m^2 - 192*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]
      *sp[k2,k4]^2*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m] + amp[10,9]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4
      *Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[sp[ - k2 + 
      q]]*den[sp[k3 - q]]*num[ - 64*sp[k1,k2]^2 + 32*sp[k1,k2]^2*m + 
      128*sp[k1,k2]^2*sp[k2,k3] - 64*sp[k1,k2]^2*sp[k2,k3]*m - 64*sp[k1
      ,k2]^2*sp[k2,q] + 32*sp[k1,k2]^2*sp[k2,q]*m - 32*sp[k1,k2]^2*sp[
      k3,k4] - 64*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k3,q]*m + 64
      *sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k4] + 
      32*sp[k1,k2]*sp[k1,k4]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,
      q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2
      ]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[
      k1,k2]*sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 128
      *sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]
      *m - 160*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m - 
      64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]
      *m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,
      k2]*sp[k2,k4]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]
       - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,k4]
      *sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k4,q]^2 - 48*sp[k1,k2]*sp[k4,q]^2
      *m + 8*sp[k1,k2]*sp[k4,q]^2*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q
      ] - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[k2,
      k4]^2 - 16*sp[k1,k3]*sp[k2,k4]^2*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m - 320*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 208*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 192*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[
      k1,k4]*sp[k2,k4] - 96*sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,
      k4]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,
      k4]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 128*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 32*sp[k1,k4]*sp[k2,q]^2 + 16*
      sp[k1,k4]*sp[k2,q]^2*m - 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 160*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*
      m^2 - 64*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,q]*sp[
      k4,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 32*sp[k1,q]^2*sp[k2
      ,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,q]*sp[k2,k4]^2
       + 32*sp[k1,q]*sp[k2,k4]^2*m + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 
      16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 64*sp[k1,q]*sp[k2,k4]*
      sp[k4,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k4
      ]*sp[k4,q]*m^2] + amp[10,10]*color[ - Ca*Cf*Na*Tf + 1/2*Ca^2*Na*
      Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*den[
      sp[k3 - q]]*num[ - 256*sp[k1,k2]^2 + 96*sp[k1,k2]^2*m + 352*sp[k1
      ,k2]^2*sp[k3,q] - 96*sp[k1,k2]^2*sp[k3,q]*m + 192*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 96*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 96*sp[
      k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m
       - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m - 256*sp[k1,k2]*sp[k1,k4] + 96*sp[k1,k2]*sp[k1,k4]*m + 352*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k3]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*
      sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1
      ,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*
      sp[k1,q]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 256*sp[k1,k2]*sp[k2,k4] + 96*
      sp[k1,k2]*sp[k2,k4]*m + 352*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 96*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k4,q
      ] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k3,k4]^2
       - 80*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[k1,k2]*sp[k3,k4]^2*m^2 - 192
      *sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 192*sp[k1,k2]*sp[k4,q]^2
       - 80*sp[k1,k2]*sp[k4,q]^2*m + 8*sp[k1,k2]*sp[k4,q]^2*m^2 - 96*
      sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m + 96*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 48*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]
      *sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 80*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2
       + 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 48*sp[k1,k4]*sp[k1,q]
      *sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4]*sp[
      k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 96*sp[k1,k4]*
      sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m + 96*sp[k1,k4]*sp[k2,k3]
      *sp[k2,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 192*sp[k1,k4]*sp[
      k2,k3]*sp[k3,k4] + 80*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 8
      *sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*
      m^2 + 512*sp[k1,k4]*sp[k2,k4] - 320*sp[k1,k4]*sp[k2,k4]*m + 48*
      sp[k1,k4]*sp[k2,k4]*m^2 - 704*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 368*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*
      m^2 - 96*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m + 96*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       - 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 192*sp[k1,k4]*sp[k2,q]*
      sp[k4,q] + 80*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,q
      ]*sp[k4,q]*m^2 - 96*sp[k1,q]^2*sp[k2,k4] + 16*sp[k1,q]^2*sp[k2,k4
      ]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k4]
      *sp[k2,q]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 192*sp[k1,
      q]*sp[k2,k4]*sp[k4,q] + 80*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 8*sp[
      k1,q]*sp[k2,k4]*sp[k4,q]*m^2] + amp[10,11]*color[1/2*Ca*Cf*Na*Tf
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - 
      k2 - k4]]*den[sp[k3 - q]]*num[ - 32*sp[k1,k2]^2*sp[k3,k4] + 16*
      sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^
      2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m + 192*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q] + 256*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 144*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4
      ]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m
       - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 80*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 96*sp[k1,k2]*
      sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m - 128*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q] + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*
      sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2
      ]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 80*
      sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*
      m^2 - 128*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3,k4]*m - 8*sp[
      k1,k2]*sp[k3,k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 224*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2
       + 192*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 112*sp[k1,k2]*sp[k3,q]*sp[k4
      ,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 192*sp[k1,k3]^2*sp[
      k2,k4] + 112*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]^2*sp[k2,k4]*
      m^2 - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 64*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 32*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,q]*m - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k3]*sp[k2,k3]
      *sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 160*sp[k1,k3]*
      sp[k2,k4] - 80*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*m^2
       - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q]*m + 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,k3]*sp[k2,k4
      ]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,k3]
      *sp[k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m + 192*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] - 80*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2
      ,q]*sp[k3,k4]*m^2 - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]
      *sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 48*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 
      32*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*
      sp[k2,k3]*m^2 - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 8*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m^2 + 320*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 176*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m^2 - 96*sp[k1,k4]*sp[k2,q]^2 + 80*sp[k1,k4]*sp[k2,q]^2*m - 16*
      sp[k1,k4]*sp[k2,q]^2*m^2 - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 80*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]^2 - 48*sp[k1,q]*sp[k2,k3]^2*m + 96*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m
       + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 160*sp[k1,q]*sp[k2,k3]*
      sp[k2,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,q
      ]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 48*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*
      m^2 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 224*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[10,12]*color[1/2*Ca*Cf*Na*Tf]*
      den[sp[k1 - q]]*den[sp[ - k2 - k4]]^2*den[sp[k3 - q]]*num[128*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4] - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m
       + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2
      ,k4]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 - 64
      *sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k4]*
      sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 128*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[k1,q]*sp[k2,k4]*
      sp[k4,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,
      k4]*sp[k4,q]*m^2] + amp[10,13]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 - 
      q]]*den[sp[ - k2 - k4]]*den[sp[ - k3 - k4]]*den[sp[k3 - q]]*num[
       - 16*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,
      k2]^2*sp[k4,q] - 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]
       - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 40*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k3
      ]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 48*
      sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m
       + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k3]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,
      k3]*m + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 40*sp[k1,k2]*sp[k2,k3]*
      sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*sp[k2,k4]*
      m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]
      *sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k2
      ,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k2]*
      sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m + 224*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q] - 72*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 24*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 24*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 144
      *sp[k1,k2]*sp[k4,q]^2 - 96*sp[k1,k2]*sp[k4,q]^2*m + 16*sp[k1,k2]*
      sp[k4,q]^2*m^2 + 128*sp[k1,k3]^2*sp[k2,k4] - 56*sp[k1,k3]^2*sp[k2
      ,k4]*m - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,k3]*m - 112*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 48*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 
      64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]
      *m + 192*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 56*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k3]*sp[k2,k4]*m + 
      32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
      *m - 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 56*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k3]*sp[k2
      ,k4]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2,q]^2 - 16*sp[k1,k3]*sp[k2,q]
      ^2*m - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m + 48*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2
      ,q]*sp[k4,q]*m + 48*sp[k1,k4]^2*sp[k2,k3] - 16*sp[k1,k4]^2*sp[k2,
      k3]*m + 48*sp[k1,k4]^2*sp[k2,q] - 16*sp[k1,k4]^2*sp[k2,q]*m + 32*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k2,k3] - 8*
      sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 128*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       - 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q]*m + 80*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k4]*sp[k2,k4]*m + 80*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 48*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m + 48*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4] - 40*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       + 40*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,
      q]*m^2 - 144*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 96*sp[k1,k4]*sp[k2,q]*
      sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,q]*
      sp[k2,k3]^2 + 56*sp[k1,q]*sp[k2,k3]^2*m - 64*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] + 40*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 112*sp[k1,q]*sp[
      k2,k3]*sp[k2,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 128*sp[k1,q]
      *sp[k2,k3]*sp[k3,k4] + 56*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,q]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 8
      *sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*
      m^2 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k3
      ,q]*m - 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 176*sp[k1,q]*sp[k2,k4
      ]*sp[k4,q] + 112*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,q]*sp[
      k2,k4]*sp[k4,q]*m^2 - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q
      ]*sp[k2,q]*sp[k3,k4]*m] + amp[10,15]*color[ - Ca*Cf*Na*Tf]*den[
      sp[ - k2 - k4]]^2*den[sp[ - k3 + q]]*den[sp[k3 - q]]*num[ - 192*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k4,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4] - 224*sp[k1,k4]*sp[
      k2,k4]*m + 48*sp[k1,k4]*sp[k2,k4]*m^2 - 352*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] + 272*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,
      q]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 
      192*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 128*sp[k1,q]*sp[k2,k4]*sp[k4,q]
      *m - 16*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2] + amp[11,1]*color[ - 
      Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k4 - q]]*
      num[ - 48*sp[k1,k2] + 24*sp[k1,k2]*m + 24*sp[k1,k2]*sp[k1,k4] - 
      12*sp[k1,k2]*sp[k1,k4]*m - 24*sp[k1,k2]*sp[k1,q] + 12*sp[k1,k2]*
      sp[k1,q]*m + 24*sp[k1,k2]*sp[k2,k4] - 12*sp[k1,k2]*sp[k2,k4]*m - 
      24*sp[k1,k2]*sp[k2,q] + 12*sp[k1,k2]*sp[k2,q]*m + 12*sp[k1,k2]*
      sp[k3,k4] - 12*sp[k1,k2]*sp[k3,k4]*m - 12*sp[k1,k2]*sp[k3,q] + 12
      *sp[k1,k2]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k4,q] - 48*sp[k1,k2]*sp[
      k4,q]*m - 12*sp[k1,k3]*sp[k2,k4] + 12*sp[k1,k3]*sp[k2,k4]*m + 12*
      sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m - 12*sp[k1,k4]*sp[k2
      ,k3] + 12*sp[k1,k4]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k2,k4] - 24*sp[
      k1,k4]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,q] + 24*sp[k1,k4]*sp[k2,q
      ]*m + 12*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,
      q]*sp[k2,k4] + 24*sp[k1,q]*sp[k2,k4]*m + 48*sp[k1,q]*sp[k2,q] - 
      24*sp[k1,q]*sp[k2,q]*m] + amp[11,1]*color[ - 1/2*Ca^2*Na*Tf]*den[
      sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k4 - q]]*num[ - 28*sp[k1,
      k2] + 12*sp[k1,k2]*m - 8*sp[k1,k2]*sp[k1,k4] + 12*sp[k1,k2]*sp[k1
      ,k4]*m - 4*sp[k1,k2]*sp[k1,k4]*m^2 - 32*sp[k1,k2]*sp[k1,q] + 24*
      sp[k1,k2]*sp[k1,q]*m - 4*sp[k1,k2]*sp[k1,q]*m^2 - 8*sp[k1,k2]*sp[
      k2,k4] + 12*sp[k1,k2]*sp[k2,k4]*m - 4*sp[k1,k2]*sp[k2,k4]*m^2 - 
      32*sp[k1,k2]*sp[k2,q] + 24*sp[k1,k2]*sp[k2,q]*m - 4*sp[k1,k2]*sp[
      k2,q]*m^2 + 32*sp[k1,k2]*sp[k3,k4] - 28*sp[k1,k2]*sp[k3,k4]*m + 4
      *sp[k1,k2]*sp[k3,k4]*m^2 + 20*sp[k1,k2]*sp[k3,q] - 16*sp[k1,k2]*
      sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,q]*m^2 + 48*sp[k1,k2]*sp[k4,q] - 
      24*sp[k1,k2]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4] + 12*sp[k1,k3]*
      sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3] + 12*
      sp[k1,k4]*sp[k2,k3]*m + 24*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]*sp[
      k2,k4]*m - 24*sp[k1,k4]*sp[k2,q] + 12*sp[k1,k4]*sp[k2,q]*m - 4*
      sp[k1,q]*sp[k2,k3] - 24*sp[k1,q]*sp[k2,k4] + 12*sp[k1,q]*sp[k2,k4
      ]*m + 24*sp[k1,q]*sp[k2,q] - 8*sp[k1,q]*sp[k2,q]*m] + amp[11,1]*
      color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[
      sp[k4 - q]]*num[20*sp[k1,k2] - 12*sp[k1,k2]*m - 32*sp[k1,k2]*sp[
      k1,k4] + 24*sp[k1,k2]*sp[k1,k4]*m - 4*sp[k1,k2]*sp[k1,k4]*m^2 - 8
      *sp[k1,k2]*sp[k1,q] + 12*sp[k1,k2]*sp[k1,q]*m - 4*sp[k1,k2]*sp[k1
      ,q]*m^2 - 32*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m - 4*
      sp[k1,k2]*sp[k2,k4]*m^2 - 8*sp[k1,k2]*sp[k2,q] + 12*sp[k1,k2]*sp[
      k2,q]*m - 4*sp[k1,k2]*sp[k2,q]*m^2 + 20*sp[k1,k2]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*
      sp[k3,q] - 28*sp[k1,k2]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,q]*m^2 - 
      48*sp[k1,k2]*sp[k4,q] + 24*sp[k1,k2]*sp[k4,q]*m - 4*sp[k1,k3]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,q]*m - 4*sp[
      k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k4] + 8*sp[k1,k4]*sp[k2,k4]
      *m + 24*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,q
      ]*sp[k2,k3] + 12*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,q]*sp[k2,k4] - 
      12*sp[k1,q]*sp[k2,k4]*m - 24*sp[k1,q]*sp[k2,q] + 16*sp[k1,q]*sp[
      k2,q]*m] + amp[11,2]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[k1 + k2]]*den[sp[ - k3 - k4]]*den[sp[k4 - q]]*num[104*sp[
      k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*sp[k3,k4]*m - 208*sp[k1,k2]^2
      *sp[k3,q] + 64*sp[k1,k2]^2*sp[k3,q]*m - 104*sp[k1,k2]^2*sp[k4,q]
       + 32*sp[k1,k2]^2*sp[k4,q]*m + 48*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,
      k2]*sp[k1,k3]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 20*sp[k1,k2]
      *sp[k1,k3]*sp[k1,k4]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 40*sp[
      k1,k2]*sp[k1,k3]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 
      20*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 24*
      sp[k1,k2]*sp[k1,k4] - 12*sp[k1,k2]*sp[k1,k4]*m - 56*sp[k1,k2]*sp[
      k1,k4]^2 + 28*sp[k1,k2]*sp[k1,k4]^2*m + 40*sp[k1,k2]*sp[k1,k4]*
      sp[k1,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] + 20*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 224*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k4] + 56*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 80
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 4*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k1,
      k4]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 40*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 20*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k3] - 
      24*sp[k1,k2]*sp[k2,k3]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 20*
      sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,q]
       - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,
      k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1
      ,k2]*sp[k2,k4] - 12*sp[k1,k2]*sp[k2,k4]*m - 56*sp[k1,k2]*sp[k2,k4
      ]^2 + 28*sp[k1,k2]*sp[k2,k4]^2*m + 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q
      ] - 20*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 8*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4] - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,
      k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k2]*
      sp[k2,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 32*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 
      16*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m
       + 40*sp[k1,k2]*sp[k3,k4] - 8*sp[k1,k2]*sp[k3,k4]*m + 52*sp[k1,k2
      ]*sp[k3,k4]^2 - 28*sp[k1,k2]*sp[k3,k4]^2*m + 72*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 24*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 16*sp[k1
      ,k2]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k3,q]^2
       + 40*sp[k1,k2]*sp[k3,q]^2*m - 72*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k4,q] + 8*sp[k1
      ,k2]*sp[k4,q]*m + 52*sp[k1,k2]*sp[k4,q]^2 - 28*sp[k1,k2]*sp[k4,q]
      ^2*m + 8*sp[k1,k3]^2*sp[k2,k4] - 4*sp[k1,k3]^2*sp[k2,k4]*m - 16*
      sp[k1,k3]^2*sp[k2,q] + 8*sp[k1,k3]^2*sp[k2,q]*m - 8*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4] + 12*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 8*sp[k1,k3]*sp[k1,
      q]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4] + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[
      k2,k3]*sp[k2,q] - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k3]
      *sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 64*
      sp[k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m
       + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m - 8*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]^2 - 12*sp[
      k1,k3]*sp[k2,k4]^2*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 24*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       + 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q
      ]*m - 16*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,q]^2 - 8*sp[k1,
      k3]*sp[k2,q]^2*m - 52*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]
      *sp[k2,q]*sp[k3,k4]*m + 72*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 32*sp[k1
      ,k3]*sp[k2,q]*sp[k3,q]*m + 52*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k4]^2*sp[k2,k3] - 12*sp[
      k1,k4]^2*sp[k2,k3]*m - 24*sp[k1,k4]^2*sp[k2,q] + 12*sp[k1,k4]^2*
      sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k3]*m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 12*sp[k1,k4]*
      sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 4*sp[k1,k4
      ]*sp[k1,q]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*sp[k2
      ,k3]^2 - 4*sp[k1,k4]*sp[k2,k3]^2*m - 24*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,k4] + 12*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,q] - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 44*sp[k1,k4]*sp[
      k2,k3]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 8*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k4]*sp[k2,k4] + 24*sp[k1,k4]
      *sp[k2,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 72*sp[
      k1,k4]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m
       - 200*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 72*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4
      ]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,q]^2 - 4*
      sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 8*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 44*
      sp[k1,k4]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 
      16*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]^2*sp[k2,k3]*m + 8*sp[k1,q]^2
      *sp[k2,k4] - 4*sp[k1,q]^2*sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k3] - 
      16*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 8*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1
      ,q]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 52*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 
      72*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m
       + 52*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m - 8*sp[k1,q]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k4]^2 + 12*sp[k1,q
      ]*sp[k2,k4]^2*m - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,q]*sp[
      k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 44*sp[k1,
      q]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 64*sp[
      k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 64*
      sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2,q]*sp[k3,q]*m + 32
      *sp[k1,q]*sp[k2,q]*sp[k4,q] - 16*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + 
      amp[11,3]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1
       + k2]]*den[sp[ - k3 + q]]*den[sp[k4 - q]]*num[52*sp[k1,k2] - 20*
      sp[k1,k2]*m - 88*sp[k1,k2]^2 + 16*sp[k1,k2]^2*m - 208*sp[k1,k2]^2
      *sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[k3,q
      ] - 32*sp[k1,k2]^2*sp[k3,q]*m + 104*sp[k1,k2]^2*sp[k4,q] - 32*sp[
      k1,k2]^2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 32*sp[k1,k2]*sp[k1
      ,k3]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 40*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,k4]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 20*sp[k1,k2]*
      sp[k1,k3]*sp[k1,q]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 40*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 
      20*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,
      k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k3,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*
      sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k4]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[
      k1,q] + 20*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 160*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 80*sp[k1,k2]
      *sp[k1,k4]*sp[k2,q] + 20*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,q]*m + 56
      *sp[k1,k2]*sp[k1,q]^2 - 28*sp[k1,k2]*sp[k1,q]^2*m - 80*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] + 20*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 80*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] + 20*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 224
      *sp[k1,k2]*sp[k1,q]*sp[k2,q] - 56*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m
       - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 4*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 4*sp[k1,k2]*sp[k1,q]*
      sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m + 
      80*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,
      k4]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 20*sp[k1,k2]*sp[k2,k3]*
      sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k2
      ]*sp[k2,k3]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,
      k2]*sp[k2,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 20*sp[k1,k2]*
      sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[
      k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,
      q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,q] - 
      32*sp[k1,k2]*sp[k2,q]*m + 56*sp[k1,k2]*sp[k2,q]^2 - 28*sp[k1,k2]*
      sp[k2,q]^2*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 4*sp[k1,k2]*
      sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 4*sp[k1,k2]
      *sp[k2,q]*sp[k4,q]*m + 120*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[
      k3,k4]*m + 88*sp[k1,k2]*sp[k3,k4]^2 - 40*sp[k1,k2]*sp[k3,k4]^2*m
       - 72*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3
      ,q]*m - 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q]*m - 80*sp[k1,k2]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,q]*m - 52
      *sp[k1,k2]*sp[k3,q]^2 + 28*sp[k1,k2]*sp[k3,q]^2*m + 24*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 80*sp[k1,
      k2]*sp[k4,q] + 32*sp[k1,k2]*sp[k4,q]*m - 52*sp[k1,k2]*sp[k4,q]^2
       + 28*sp[k1,k2]*sp[k4,q]^2*m - 16*sp[k1,k3]^2*sp[k2,k4] + 8*sp[k1
      ,k3]^2*sp[k2,k4]*m + 8*sp[k1,k3]^2*sp[k2,q] - 4*sp[k1,k3]^2*sp[k2
      ,q]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 4*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k1,q]*sp[k2,q]
       - 12*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k3] + 40
      *sp[k1,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 8*sp[
      k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 4
      *sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,k4
      ] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*
      sp[k3,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 64*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 28*sp[k1,k3]*
      sp[k2,k4] - 40*sp[k1,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]^2
       + 8*sp[k1,k3]*sp[k2,k4]^2*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 4
      *sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k4]*sp[k3,k4
      ] + 32*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 52*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 52*sp[k1,k3]*sp[k2
      ,k4]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*
      sp[k2,q] + 8*sp[k1,k3]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,q]^2 + 12*
      sp[k1,k3]*sp[k2,q]^2*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 44*sp[
      k1,k3]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      16*sp[k1,k4]^2*sp[k2,k3] + 8*sp[k1,k4]^2*sp[k2,k3]*m + 8*sp[k1,k4
      ]^2*sp[k2,q] - 4*sp[k1,k4]^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k1,
      q]*sp[k2,k4] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k4]*
      sp[k1,q]*sp[k2,q] - 12*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 28*sp[k1,
      k4]*sp[k2,k3] - 40*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]
      ^2 + 8*sp[k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 72*sp[k1,k4]*sp[k2,k3]
      *sp[k3,k4] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 52*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 52*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 72*
      sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k4]
      *sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 64*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k4
      ,q]*m - 4*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,
      k4]*sp[k2,q]^2 + 12*sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,q]
      *sp[k3,k4] + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m + 44*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 24*sp[k1,k4]*sp[k2
      ,q]*sp[k4,q]*m - 24*sp[k1,q]^2*sp[k2,k3] + 12*sp[k1,q]^2*sp[k2,k3
      ]*m - 24*sp[k1,q]^2*sp[k2,k4] + 12*sp[k1,q]^2*sp[k2,k4]*m - 4*sp[
      k1,q]*sp[k2,k3] + 8*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,q]*sp[k2,k3]^2
       - 4*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 8
      *sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       - 12*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4] + 44*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k4] + 8*sp[k1,q]*sp[k2,k4]*m + 8*
      sp[k1,q]*sp[k2,k4]^2 - 4*sp[k1,q]*sp[k2,k4]^2*m + 24*sp[k1,q]*sp[
      k2,k4]*sp[k2,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 44*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 24*sp[k1,
      q]*sp[k2,k4]*sp[k4,q]*m - 40*sp[k1,q]*sp[k2,q] + 8*sp[k1,q]*sp[k2
      ,q]*m - 200*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m + 72*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2,q
      ]*sp[k3,q]*m + 72*sp[k1,q]*sp[k2,q]*sp[k4,q] - 32*sp[k1,q]*sp[k2,
      q]*sp[k4,q]*m] + amp[11,4]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 - k2
      ]]*den[sp[k1 + k2]]*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[80*sp[
      k1,k2] - 40*sp[k1,k2]*m + 208*sp[k1,k2]^2 - 88*sp[k1,k2]^2*m - 
      304*sp[k1,k2]^2*sp[k4,q] + 112*sp[k1,k2]^2*sp[k4,q]*m - 80*sp[k1,
      k2]*sp[k1,k3] + 40*sp[k1,k2]*sp[k1,k3]*m + 128*sp[k1,k2]*sp[k1,k3
      ]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 104*sp[k1,k2]*
      sp[k1,k4] + 56*sp[k1,k2]*sp[k1,k4]*m - 48*sp[k1,k2]*sp[k1,k4]^2
       + 32*sp[k1,k2]*sp[k1,k4]^2*m - 4*sp[k1,k2]*sp[k1,k4]^2*m^2 + 48*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m
       - 8*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m^2 - 192*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k4]*m^2 + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m^2 + 
      96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 - 48*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m^2 + 104*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 48*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k1,q] - 40*sp[k1,k2]*
      sp[k1,q]*m - 48*sp[k1,k2]*sp[k1,q]^2 + 32*sp[k1,k2]*sp[k1,q]^2*m
       - 4*sp[k1,k2]*sp[k1,q]^2*m^2 + 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       + 8*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m^2 - 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 80*sp[k1,k2]*sp[k1,q]
      *sp[k2,q]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m^2 - 48*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 8*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m^2 + 96*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2
       - 104*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k1,q]*sp[k4,
      q]*m - 80*sp[k1,k2]*sp[k2,k3] + 40*sp[k1,k2]*sp[k2,k3]*m + 128*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 104*sp[k1,k2]*sp[k2,k4] + 56*sp[k1,k2]*sp[k2,k4]*m - 48*sp[k1,
      k2]*sp[k2,k4]^2 + 32*sp[k1,k2]*sp[k2,k4]^2*m - 4*sp[k1,k2]*sp[k2,
      k4]^2*m^2 + 48*sp[k1,k2]*sp[k2,k4]*sp[k2,q] - 8*sp[k1,k2]*sp[k2,
      k4]*sp[k2,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m^2 + 96*sp[k1,k2
      ]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 8*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,
      q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 + 104*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k2
      ,k4]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,q]*m
       - 48*sp[k1,k2]*sp[k2,q]^2 + 32*sp[k1,k2]*sp[k2,q]^2*m - 4*sp[k1,
      k2]*sp[k2,q]^2*m^2 - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2
      ]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 96*
      sp[k1,k2]*sp[k2,q]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 
      8*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 104*sp[k1,k2]*sp[k2,q]*sp[k4,
      q] + 48*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,k4] + 
      56*sp[k1,k2]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k3,k4]^2 + 40*sp[k1,k2
      ]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 + 96*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q]*m^2 + 40*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k3,q] - 40*sp[k1,k2
      ]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,q]^2*
      m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 - 40*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 288*sp[k1,k2]*sp[k4,q] + 
      144*sp[k1,k2]*sp[k4,q]*m + 208*sp[k1,k2]*sp[k4,q]^2 - 96*sp[k1,k2
      ]*sp[k4,q]^2*m - 128*sp[k1,k3]*sp[k2,k3] + 48*sp[k1,k3]*sp[k2,k3]
      *m + 176*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4] - 56*sp[k1,k3]*sp[k2,k4]*m + 
      48*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4
      ]*m - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m - 40*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q]*m - 40*sp[k1,k3]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,q]*m - 
      24*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*
      m + 48*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q
      ]*m + 40*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m + 24*sp[k1,k4]^2*sp[k2,q] - 16*sp[k1,k4]^2*sp[k2,q]*m - 
      24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]
      *m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]*sp[k1,q]*sp[k2
      ,q]*m + 64*sp[k1,k4]*sp[k2,k3] - 56*sp[k1,k4]*sp[k2,k3]*m + 48*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m
       - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,
      q]*m - 40*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m - 128*sp[k1,k4]*sp[k2,k4] + 72*sp[k1,k4]*sp[k2,k4]*m
       - 24*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2
      ,q]*m + 128*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,k4]*sp[k2,k4]
      *sp[k4,q]*m + 80*sp[k1,k4]*sp[k2,q] - 40*sp[k1,k4]*sp[k2,q]*m - 
      24*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m - 80*sp[k1,k4
      ]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1
      ,q]^2*sp[k2,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m - 40*sp[k1,q]*sp[k2,
      k3] + 40*sp[k1,q]*sp[k2,k3]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]
       - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 48*sp[k1,q]*sp[k2,k3]*sp[k3
      ,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k4]
       - 40*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q
      ]*sp[k2,k4]^2*m + 24*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m - 80*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,
      q]*sp[k2,k4]*sp[k4,q]*m - 80*sp[k1,q]*sp[k2,q] + 40*sp[k1,q]*sp[
      k2,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k4,q] - 64*sp[k1,q]*sp[k2,q]*
      sp[k4,q]*m] + amp[11,5]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]
      *den[sp[k1 + k3]]*den[sp[ - k2 - k4]]*den[sp[k4 - q]]*num[ - 16*
      sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k2,k4] + 16*sp[k1,k2]^2*sp[k2,k4]
      *m + 64*sp[k1,k2]^2*sp[k2,q] - 32*sp[k1,k2]^2*sp[k2,q]*m + 16*sp[
      k1,k2]^2*sp[k3,k4]*m - 8*sp[k1,k2]^2*sp[k3,q]*m + 80*sp[k1,k2]^2*
      sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k2]*sp[k1,k3]
      *sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 8*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4] - 16*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 80*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2
       - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3]*m - 144*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]
      *sp[k1,q]*sp[k2,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 32*
      sp[k1,k2]*sp[k1,q]*sp[k4,q] - 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q]
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,
      k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 80*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,k4] - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 4
      *sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k2,q]
      *sp[k3,k4] - 24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 32*sp[k1,
      k2]*sp[k2,q]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*
      sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1,k2]*sp[k3,k4]^2
      *m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 24*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2
       - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,q]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 40*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 96*sp[k1,k3]*
      sp[k2,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 96*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 
      32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
      *m + 64*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1
      ,k3]*sp[k2,k4]^2 - 8*sp[k1,k3]*sp[k2,k4]^2*m + 4*sp[k1,k3]*sp[k2,
      k4]^2*m^2 + 176*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 72*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 8*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 
      64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
      *m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] - 80*sp[k1,k3]*sp[k2,q]^2 + 32*sp[k1,k3]*sp[k2,q]^2*m - 
      64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
      *m - 80*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q]*m + 8*sp[k1,k4]^2*sp[k2,k3]*m - 4*sp[k1,k4]^2*sp[k2,k3]*m^2
       - 32*sp[k1,k4]^2*sp[k2,q] + 8*sp[k1,k4]^2*sp[k2,q]*m + 8*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 
      32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*
      m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 24*sp[k1,k4]*sp[k1,q]*sp[k2,
      q]*m - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m - 64*sp[
      k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m + 24*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 128
      *sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 32*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[
      k2,k3]*sp[k3,k4]*m^2 - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 4*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q]
       - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 112*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 144*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q
      ]^2*sp[k2,k4] + 24*sp[k1,q]^2*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3]
      ^2 - 8*sp[k1,q]*sp[k2,k3]^2*m + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 8*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m + 144*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 24*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 24*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[11,6]*color[1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[sp[ - k2 + q]]*den[sp[k4 - 
      q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1,k2]^2*sp[k2,k4] - 32*sp[k1,k2
      ]^2*sp[k2,k4]*m - 32*sp[k1,k2]^2*sp[k2,q] + 16*sp[k1,k2]^2*sp[k2,
      q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m + 16*sp[k1,k2]^2*sp[k3,q]*m - 80
      *sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]*
      sp[k1,k3] - 8*sp[k1,k2]*sp[k1,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 8*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*sp[k1,
      k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 144*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,q] + 8*sp[k1,
      k2]*sp[k1,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 80*sp[k1,k2]
      *sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[
      k1,k2]*sp[k1,q]*sp[k2,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 8*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2
       - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,q]*sp[k4,q
      ]*m + 16*sp[k1,k2]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]
       - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k2,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k2
      ,k3]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,k2]
      *sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 80*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 
      80*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4]*m - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1
      ,k2]*sp[k2,q]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 4*sp[
      k1,k2]*sp[k2,q]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k3,k4] - 48*sp[k1
      ,k2]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 24*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 64*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,q]*m + 32*sp[k1,k2]*
      sp[k3,q]^2 - 24*sp[k1,k2]*sp[k3,q]^2*m + 4*sp[k1,k2]*sp[k3,q]^2*
      m^2 - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 4*sp[
      k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,
      k3]*sp[k2,k3]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 40*sp[k1,k3]
      *sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 32*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 
      16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4] + 80*
      sp[k1,k3]*sp[k2,k4]^2 - 32*sp[k1,k3]*sp[k2,k4]^2*m - 176*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q] + 72*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,q]
       - 8*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k2,q]^2 + 8*sp[k1,k3]
      *sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,q]^2*m^2 - 64*sp[k1,k3]*sp[k2,q
      ]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,
      k3]*sp[k2,q]*sp[k3,q]*m^2 - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 64*
      sp[k1,k4]^2*sp[k2,q] + 24*sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       + 32*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]
      *m - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1
      ,k4]*sp[k2,k3]^2 - 8*sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,k4] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 24*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 144*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,q]^2*sp[
      k2,k3]*m + 4*sp[k1,q]^2*sp[k2,k3]*m^2 - 32*sp[k1,q]^2*sp[k2,k4]
       + 8*sp[k1,q]^2*sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,
      q]*sp[k2,k3]^2*m + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 24*
      sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2
       + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3
      ,k4]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,q]*sp[k2,k3]
      *sp[k3,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[
      k2,k3]*sp[k4,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 144*sp[k1,q]
      *sp[k2,k4]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 32*sp[
      k1,q]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m]
       + amp[11,7]*color[1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + 
      k3]]*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[ - 128*sp[k1,k2]^2 + 
      48*sp[k1,k2]^2*m + 176*sp[k1,k2]^2*sp[k4,q] - 48*sp[k1,k2]^2*sp[
      k4,q]*m + 80*sp[k1,k2]*sp[k1,k3] - 40*sp[k1,k2]*sp[k1,k3]*m - 128
      *sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       + 104*sp[k1,k2]*sp[k1,k4] - 56*sp[k1,k2]*sp[k1,k4]*m + 96*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 48
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       + 24*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m^2 - 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m^2 - 104*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 48*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,q] + 40*sp[k1,k2]*
      sp[k1,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k2]*
      sp[k1,q]*sp[k2,q]*m - 12*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 4*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 24*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 
      4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 + 104*sp[k1,k2]*sp[k1,q]*sp[k4,
      q] - 48*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k2,k3]
       + 48*sp[k1,k2]*sp[k2,k3]*m + 176*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 
      48*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 12*sp[k1,k2]*sp[k2,
      k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 12*sp[k1,k2
      ]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 24*
      sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2
       + 104*sp[k1,k2]*sp[k3,k4] - 56*sp[k1,k2]*sp[k3,k4]*m + 96*sp[k1,
      k2]*sp[k3,k4]^2 - 40*sp[k1,k2]*sp[k3,k4]^2*m + 4*sp[k1,k2]*sp[k3,
      k4]^2*m^2 - 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 104*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 80*
      sp[k1,k2]*sp[k3,q] + 40*sp[k1,k2]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k3
      ,q]^2 - 40*sp[k1,k2]*sp[k3,q]^2*m + 4*sp[k1,k2]*sp[k3,q]^2*m^2 + 
      104*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 4*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       - 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 128*sp[k1,k3]*sp[k2,k3]
       - 48*sp[k1,k3]*sp[k2,k3]*m - 176*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 
      48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 104*sp[k1,k3]*sp[k2,k4] + 56*
      sp[k1,k3]*sp[k2,k4]*m - 96*sp[k1,k3]*sp[k2,k4]^2 + 40*sp[k1,k3]*
      sp[k2,k4]^2*m - 4*sp[k1,k3]*sp[k2,k4]^2*m^2 + 96*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[
      k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 12*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 104*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 80*sp[k1,k3]*sp[k2
      ,q] - 40*sp[k1,k3]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,q]^2 + 40*sp[
      k1,k3]*sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,q]^2*m^2 + 12*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 24*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2
       - 104*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,q]*sp[k4,
      q]*m - 24*sp[k1,k4]^2*sp[k2,k3]*m + 4*sp[k1,k4]^2*sp[k2,k3]*m^2
       - 24*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m + 24*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 
      24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]
      *m - 24*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k4]*sp[k1,q]*sp[k2
      ,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 48*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 
      40*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 4*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 24*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 24*
      sp[k1,q]^2*sp[k2,k3]*m + 4*sp[k1,q]^2*sp[k2,k3]*m^2 + 24*sp[k1,q]
      ^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,q]*
      sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 + 48*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 4*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k3,q]
       + 40*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,
      q]*m^2 + 24*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[11,8]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k2]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[k4 - q]]*num[ - 
      16*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k1,k4] + 16*sp[k1,k2]^2*sp[k1,
      k4]*m + 64*sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^2*sp[k1,q]*m + 16*
      sp[k1,k2]^2*sp[k3,k4]*m - 8*sp[k1,k2]^2*sp[k3,q]*m + 80*sp[k1,k2]
      ^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 16*sp[k1,k2]*sp[k1,k3]*sp[
      k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k1,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k2]
      *sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 
      8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k4,q
      ] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 144*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2
      ]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 48*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 4*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]
       - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4]*m^2 - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 8*sp[
      k1,k2]*sp[k2,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2
      ]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1,k2]*sp[k3,k4]
      ^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 32*sp[k1,k2]*sp[k3,k4]*sp[k3
      ,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 48*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m - 64*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]
      ^2*sp[k2,k4]*m + 32*sp[k1,k3]^2*sp[k2,q] - 8*sp[k1,k3]^2*sp[k2,q]
      *m + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 4*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
       + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 128*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]
      *sp[k2,k4]*m^2 + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1
      ,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]
      ^2*m - 4*sp[k1,k3]*sp[k2,k4]^2*m^2 + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,
      q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k4
      ]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m^2 - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 4*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q
      ] - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,q]
      *sp[k4,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]^2*sp[
      k2,k3] - 8*sp[k1,k4]^2*sp[k2,k3]*m + 4*sp[k1,k4]^2*sp[k2,k3]*m^2
       + 176*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 72*sp[k1,k4]*sp[k1,q]*sp[k2
      ,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,
      k3] - 24*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 8*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 
      64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
      *m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 16*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 8*sp[k1,k4]*sp[k2,k4
      ]*sp[k2,q]*m - 112*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 40*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,q]^2 + 24*sp[k1,k4]*sp[
      k2,q]^2*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k4]*sp[k2
      ,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 24*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m - 80*sp[k1,q]^2*sp[k2,k3] + 32*sp[k1,q]^2*sp[
      k2,k3]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3
      ]*sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 24*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,q]*sp[k2,k4]^2 + 8*sp[k1,q]*sp[
      k2,k4]^2*m + 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,q]*sp[k2,
      k4]*sp[k2,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m + 144*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q
      ]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 24*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[11,10]*color[1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k3 + q]]*den[sp[k4 - 
      q]]*num[32*sp[k1,k2]^2 - 8*sp[k1,k2]^2*m + 104*sp[k1,k2]^2*sp[k3,
      k4] - 32*sp[k1,k2]^2*sp[k3,k4]*m - 40*sp[k1,k2]^2*sp[k3,q] + 16*
      sp[k1,k2]^2*sp[k3,q]*m - 40*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2
      *sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k3] + 8*sp[k1,k2]*sp[k1,k3]*m - 
      80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,
      k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k1,q]*m - 72*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 136*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 40*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1
      ,k4]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]
      *sp[k1,q]*m - 88*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3]*m + 56*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 24*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 104*sp[k1,k2]*sp[k1,q
      ] + 48*sp[k1,k2]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1,q]^2 + 40*sp[k1,
      k2]*sp[k1,q]^2*m + 104*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 8*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4]*m - 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 
      40*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4] + 20*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,q]*
      sp[k3,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 104*sp[k1,k2]*sp[k1,
      q]*sp[k4,q] - 36*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 48*sp[k1,k2]*sp[
      k2,k3]*sp[k4,q] - 24*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2
      ]*sp[k2,k4] - 8*sp[k1,k2]*sp[k2,k4]*m + 88*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,k2
      ]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 16*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 
      40*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 12*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k3,k4] + 4*sp[k1,k2]*sp[k3,k4]*m - 72*sp[k1,k2
      ]*sp[k3,k4]^2 + 28*sp[k1,k2]*sp[k3,k4]^2*m + 48*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q] - 20*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] + 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 60*sp[
      k1,k2]*sp[k4,q] + 28*sp[k1,k2]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k4,q
      ]^2 - 68*sp[k1,k2]*sp[k4,q]^2*m - 24*sp[k1,k3]^2*sp[k2,q] - 64*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m + 104*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4] + 4
      *sp[k1,k3]*sp[k2,k4]*m - 56*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*
      sp[k2,k4]^2*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m + 40*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 12*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4]*m + 40*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 12*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       + 36*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] + 24*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 80*sp[k1,k4]^2*sp[k2,k3] - 32*sp[k1,k4]^2*sp[k2,k3]*
      m + 32*sp[k1,k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m + 48*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] + 20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       + 24*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,q]
      *m - 8*sp[k1,k4]*sp[k2,k3] + 20*sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48
      *sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 20*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m
       + 56*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 20*sp[k1,k4]*sp[k2,k3]*sp[
      k3,k4]*m - 120*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 44*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m + 104*sp[k1,k4]*sp[k2,k4] - 40*sp[k1,k4]*sp[
      k2,k4]*m + 56*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,
      k4]*sp[k2,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k4]*
      sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 
      16*sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m + 20*sp[k1,k4]*sp[k2,q] - 12*
      sp[k1,k4]*sp[k2,q]*m + 72*sp[k1,k4]*sp[k2,q]^2 - 28*sp[k1,k4]*sp[
      k2,q]^2*m - 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 40*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] + 12*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 112*sp[k1,k4]
      *sp[k2,q]*sp[k4,q] + 44*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,
      q]^2*sp[k2,k3] - 32*sp[k1,q]^2*sp[k2,k3]*m - 120*sp[k1,q]^2*sp[k2
      ,k4] + 44*sp[k1,q]^2*sp[k2,k4]*m + 80*sp[k1,q]^2*sp[k2,q] - 32*
      sp[k1,q]^2*sp[k2,q]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 24*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 
      16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 44*sp[k1,q]*sp[k2,k4] + 20
      *sp[k1,q]*sp[k2,k4]*m - 56*sp[k1,q]*sp[k2,k4]^2 + 16*sp[k1,q]*sp[
      k2,k4]^2*m - 72*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 28*sp[k1,q]*sp[k2,
      k4]*sp[k2,q]*m + 112*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 36*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 4*sp[k1,
      q]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 36*sp[
      k1,q]*sp[k2,k4]*sp[k4,q]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k4,q] - 
      32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + amp[11,11]*color[1/4*Ca^2*Na*
      Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[
      k4 - q]]*num[16*sp[k1,k2]^2*m + 64*sp[k1,k2]^2*sp[k1,k4] - 32*sp[
      k1,k2]^2*sp[k1,k4]*m - 32*sp[k1,k2]^2*sp[k1,q] + 16*sp[k1,k2]^2*
      sp[k1,q]*m - 8*sp[k1,k2]^2*sp[k3,k4]*m + 16*sp[k1,k2]^2*sp[k3,q]*
      m - 80*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[
      k1,k2]*sp[k1,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,
      k2]*sp[k1,k3]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*
      m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 80*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m
       - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k4]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q]*m - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 24*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2
       - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 144*sp[k1,k2]*sp[k1,q]*sp[k2
      ,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*
      sp[k2,q] + 192*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 24*sp[k1,k2]*
      sp[k1,q]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 + 16*sp[
      k1,k2]*sp[k2,k3] - 8*sp[k1,k2]*sp[k2,k3]*m + 16*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*
      sp[k2,k4] - 24*sp[k1,k2]*sp[k2,k4]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 + 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,
      k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,q] + 8*sp[k1,k2]*sp[k2,q]*m
       + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,
      q]*m - 4*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k2,q]*
      sp[k4,q] + 24*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k3
      ,k4] - 48*sp[k1,k2]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
       - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m^2 - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,q]*m
       + 32*sp[k1,k2]*sp[k3,q]^2 - 24*sp[k1,k2]*sp[k3,q]^2*m + 4*sp[k1,
      k2]*sp[k3,q]^2*m^2 - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m + 32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^
      2*sp[k2,k4]*m - 64*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]
      *m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 40*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 128*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] - 40*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m^2 + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 32
      *sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k1,q]*sp[
      k2,q]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,
      k3] - 16*sp[k1,k3]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k4] + 
      24*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ] + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,q]^
      2*m + 4*sp[k1,k3]*sp[k2,q]^2*m^2 + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4
      ]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 32*sp[k1,k3]*sp[k2,q]*
      sp[k3,q] + 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 24*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 80*sp[k1,k4]^2*sp[k2,k3] - 32*sp[k1,k4]^2*
      sp[k2,k3]*m - 176*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 72*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 16*sp[k1
      ,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 24*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,q]*m - 80*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q]
       - 24*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q] + 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,q]
      ^2 + 8*sp[k1,k4]*sp[k2,q]^2*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       - 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,q]^2*sp[k2,k3]
       + 8*sp[k1,q]^2*sp[k2,k3]*m - 4*sp[k1,q]^2*sp[k2,k3]*m^2 + 16*sp[
      k1,q]*sp[k2,k3] - 8*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] + 40*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,q]*
      sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 4
      *sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]
      *m + 4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 16*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] - 64*sp[k1,q]*sp[k2,k4]^2 + 24*sp[k1,q]*sp[k2,k4]^2*m + 
      32*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m + 144*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 40*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m] + amp[11,13]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[sp[k4 - q]]*num[
       - 40*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m + 104*
      sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 40*sp[k1,k2]^2
      *sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m - 80*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 24*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 72*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       + 88*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,
      k3]*sp[k3,q]*m - 136*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 40*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m + 12*sp[k1,k2]*sp[k1,k4]*m + 80*sp[k1,k2]*
      sp[k1,k4]^2 - 40*sp[k1,k2]*sp[k1,k4]^2*m - 64*sp[k1,k2]*sp[k1,k4]
      *sp[k1,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 104*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 112*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,k4] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 
      24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*
      m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 8*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 20*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m + 104*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 36*sp[k1,k2]*
      sp[k1,k4]*sp[k4,q]*m - 88*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 24*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k3]*m - 56*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 24*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k1,q]*sp[
      k3,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,q]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k2,
      k3] - 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 48*sp[k1,k2]*sp[k2,k4] + 12*sp[k1,k2]*sp[k2,k4]*m + 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 12*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
      *m - 40*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 12*sp[k1,k2]*sp[k2,k4]*sp[
      k4,q]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]
      *sp[k3,k4]*m - 88*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k2]*sp[
      k2,q]*sp[k3,q]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 8*sp[k1,k2]*
      sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4] + 8*sp[k1,k2]*sp[k3,
      k4]*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 20*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,q] - 16*sp[k1,k2]*sp[k3,q]*m
       + 72*sp[k1,k2]*sp[k3,q]^2 - 28*sp[k1,k2]*sp[k3,q]^2*m - 32*sp[k1
      ,k2]*sp[k3,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 36*sp[
      k1,k2]*sp[k4,q] - 20*sp[k1,k2]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k4,q
      ]^2 + 68*sp[k1,k2]*sp[k4,q]^2*m - 24*sp[k1,k3]^2*sp[k2,k4] + 104*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[
      k1,q]*sp[k2,k3]*m + 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,
      k3]*sp[k2,k3]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 40*sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 24*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] + 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,
      k3]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*
      sp[k2,q]*m + 56*sp[k1,k3]*sp[k2,q]^2 - 16*sp[k1,k3]*sp[k2,q]^2*m
       - 40*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 12*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 12*sp[k1,k3]*sp[k2,q]*
      sp[k3,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 36*sp[k1,k3]*sp[k2,
      q]*sp[k4,q]*m - 16*sp[k1,k4]^2*sp[k2,k3] + 32*sp[k1,k4]^2*sp[k2,
      k3]*m + 80*sp[k1,k4]^2*sp[k2,k4] - 32*sp[k1,k4]^2*sp[k2,k4]*m - 
      120*sp[k1,k4]^2*sp[k2,q] + 44*sp[k1,k4]^2*sp[k2,q]*m - 48*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3] - 20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 24*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       - 16*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]
      *m - 56*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 56*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q]*m - 8*sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k4]*m - 72*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q] + 28*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 
      24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m - 80*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[
      k4,q]*m - 20*sp[k1,k4]*sp[k2,q] + 12*sp[k1,k4]*sp[k2,q]*m - 56*
      sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m + 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 112*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q] - 36*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*
      sp[k1,k4]*sp[k2,q]*sp[k4,q] - 36*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 
      80*sp[k1,q]^2*sp[k2,k3] + 32*sp[k1,q]^2*sp[k2,k3]*m + 32*sp[k1,q]
      ^2*sp[k2,k4] - 8*sp[k1,q]^2*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*m
       + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 20*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m - 56*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,q]*m + 120*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 44*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4]*m - 56*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 20*sp[k1,q]*
      sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,
      q]*sp[k2,k3]*sp[k4,q]*m + 12*sp[k1,q]*sp[k2,k4] - 4*sp[k1,q]*sp[
      k2,k4]*m + 72*sp[k1,q]*sp[k2,k4]^2 - 28*sp[k1,q]*sp[k2,k4]^2*m + 
      56*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       - 40*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 12*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m - 12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 112*sp[k1,q]*sp[k2,k4]
      *sp[k4,q] - 44*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,
      q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,q]*sp[
      k2,q]*sp[k3,q] + 32*sp[k1,q]*sp[k2,q]*sp[k3,q]*m - 32*sp[k1,q]*
      sp[k2,q]*sp[k4,q] + 16*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + amp[11,14]
      *color[ - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 - k3]]*
      den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[128*sp[k1,k2]^2 - 48*sp[k1
      ,k2]^2*m - 176*sp[k1,k2]^2*sp[k4,q] + 48*sp[k1,k2]^2*sp[k4,q]*m
       + 128*sp[k1,k2]*sp[k1,k3] - 48*sp[k1,k2]*sp[k1,k3]*m - 176*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*
      m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,
      k4]*sp[k3,k4]*m^2 + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 4*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m^2 + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16
      *sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,q]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 24*sp[k1,k2]*sp[k1,
      q]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 80*sp[k1,k2]*
      sp[k2,k3] + 40*sp[k1,k2]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 104*sp[k1,k2]*sp[
      k2,k4] + 56*sp[k1,k2]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 12*sp[k1,k2]*sp[k2,
      k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 104*sp[k1,
      k2]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 80*
      sp[k1,k2]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,q]*m + 12*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 24*sp[k1,
      k2]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 104
      *sp[k1,k2]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m
       - 104*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]*sp[k3,k4]*m - 96*sp[k1,
      k2]*sp[k3,k4]^2 + 40*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,
      k4]^2*m^2 + 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 104*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 80*
      sp[k1,k2]*sp[k3,q] - 40*sp[k1,k2]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k3
      ,q]^2 + 40*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 - 
      104*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 4*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       - 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 - 128*sp[k1,k3]*sp[k2,k3]
       + 48*sp[k1,k3]*sp[k2,k3]*m + 176*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 
      48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,k4]^2*m - 
      4*sp[k1,k3]*sp[k2,k4]^2*m^2 - 24*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m^2 - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 4*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 
      24*sp[k1,k3]*sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,q]^2*m^2 - 48*sp[k1
      ,k3]*sp[k2,q]*sp[k3,k4] - 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 4*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k3,q]
       - 40*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,
      q]*m^2 + 96*sp[k1,k4]^2*sp[k2,k3] - 40*sp[k1,k4]^2*sp[k2,k3]*m + 
      4*sp[k1,k4]^2*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 8
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*
      m^2 + 104*sp[k1,k4]*sp[k2,k3] - 56*sp[k1,k4]*sp[k2,k3]*m + 96*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m
       + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,
      k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 104*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,k4]*sp[k2
      ,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 24*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1
      ,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m - 24*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,q]^2*
      sp[k2,k3] - 40*sp[k1,q]^2*sp[k2,k3]*m + 4*sp[k1,q]^2*sp[k2,k3]*
      m^2 - 80*sp[k1,q]*sp[k2,k3] + 40*sp[k1,q]*sp[k2,k3]*m - 48*sp[k1,
      q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 
      40*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,q]*
      m^2 - 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m^2 + 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 4*sp[k1,q]*sp[
      k2,k3]*sp[k3,q]*m^2 + 104*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,
      q]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]*
      sp[k2,k4]^2*m + 24*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q]*sp[
      k2,k4]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]
      *sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[11,15]*color[ - 1/4*Ca^2*Na*Tf]
      *den[sp[k1 + k2]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*den[sp[
      k4 - q]]*num[ - 32*sp[k1,k2]^2 + 8*sp[k1,k2]^2*m - 104*sp[k1,k2]^
      2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 40*sp[k1,k2]^2*sp[k3,q
      ] - 16*sp[k1,k2]^2*sp[k3,q]*m + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[
      k1,k2]^2*sp[k4,q]*m + 88*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,k4]*m - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 
      48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k4,
      q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4]
       + 8*sp[k1,k2]*sp[k1,k4]*m + 72*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 
      16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 40*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 24*sp[
      k1,k2]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 
      56*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
      *m + 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 40*sp[k1,k2]*sp[k1,q]*sp[
      k2,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 12*sp[k1,k2]*sp[k1,q]
      *sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 12*sp[k1,k2]*sp[
      k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3] - 8*sp[k1,k2]*sp[k2,k3]
      *m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[k2,k3]*
      sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[
      k2,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,
      k2]*sp[k2,k3]*sp[k3,k4]*m - 88*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 32*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 136*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k4]*m
       - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k2
      ,q]*m + 80*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]
      *sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2
      ]*sp[k2,k4]*sp[k4,q]*m + 104*sp[k1,k2]*sp[k2,q] - 48*sp[k1,k2]*
      sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,q]^2 - 40*sp[k1,k2]*sp[k2,q]^2*m
       + 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 20*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m - 104*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 36*sp[k1,k2]*sp[k2
      ,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4] - 4*sp[k1,k2]*sp[k3,k4]*m
       + 72*sp[k1,k2]*sp[k3,k4]^2 - 28*sp[k1,k2]*sp[k3,k4]^2*m - 48*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] + 20*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*
      m - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 4*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ]*m + 60*sp[k1,k2]*sp[k4,q] - 28*sp[k1,k2]*sp[k4,q]*m - 160*sp[k1
      ,k2]*sp[k4,q]^2 + 68*sp[k1,k2]*sp[k4,q]^2*m - 56*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 56*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q] + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 48*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] - 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 
      64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4]*m - 104*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k3]*sp[k2,k3]
      *sp[k2,q]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4
      ]*m - 80*sp[k1,k3]*sp[k2,k4]^2 + 32*sp[k1,k3]*sp[k2,k4]^2*m - 48*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       - 56*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 20*sp[k1,k3]*sp[k2,k4]*sp[
      k3,k4]*m + 120*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 44*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 12*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]^2 + 32*sp[k1,k3]*sp[
      k2,q]^2*m - 56*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 56*sp[k1,k4]^2*sp[k2,k3] - 16*sp[k1,k4]^2*
      sp[k2,k3]*m + 56*sp[k1,k4]^2*sp[k2,q] - 16*sp[k1,k4]^2*sp[k2,q]*m
       + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ]*m - 56*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4]*m + 72*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 28*sp[k1,k4]*sp[k1,q]
      *sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3] - 4*sp[k1,k4]*sp[k2,k3]*m + 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m - 40*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 12*sp[k1,k4]*sp[
      k2,k3]*sp[k3,k4]*m - 40*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 12*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 36*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 104*sp[k1,k4]*sp[k2,k4] + 40*sp[
      k1,k4]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 8*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] - 32*
      sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,k4]*sp[
      k4,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m + 44*sp[k1,k4]*sp[k2,q]
       - 20*sp[k1,k4]*sp[k2,q]*m + 120*sp[k1,k4]*sp[k2,q]^2 - 44*sp[k1,
      k4]*sp[k2,q]^2*m - 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 36*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 4*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k4,q] - 36*
      sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 72*sp[k1,q]^2*sp[k2,k4] + 28*sp[
      k1,q]^2*sp[k2,k4]*m + 24*sp[k1,q]*sp[k2,k3]^2 + 160*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,q
      ]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 24*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 20*sp[k1,q]*sp[k2,k4] + 12*sp[k1,
      q]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k4]^2 + 8*sp[k1,q]*sp[k2,k4]^2
      *m - 24*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 4*sp[k1,q]*sp[k2,k4]*sp[k2,
      q]*m + 12*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 40*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 112*sp[k1,q]*sp[k2,
      k4]*sp[k4,q] - 44*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 80*sp[k1,q]*sp[
      k2,q]^2 + 32*sp[k1,q]*sp[k2,q]^2*m - 24*sp[k1,q]*sp[k2,q]*sp[k3,
      k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,q]*sp[
      k4,q] + 32*sp[k1,q]*sp[k2,q]*sp[k4,q]*m] + amp[11,16]*color[1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4
      ]]*den[sp[k4 - q]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*
      sp[k3,k4]*m - 104*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k3,q]*
      m - 40*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m - 24*sp[
      k1,k2]*sp[k1,k3] - 104*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 48*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 88*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 24*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       - 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k1,k4] - 
      12*sp[k1,k2]*sp[k1,k4]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 112*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k4] + 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 56*sp[k1,k2]*sp[k1,k4]
      *sp[k2,q] - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q] + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 40*sp[k1,k2
      ]*sp[k1,k4]*sp[k4,q] - 12*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 72*sp[
      k1,k2]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 
      24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*
      m - 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m + 88*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,q]*
      sp[k3,q]*m - 40*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,q
      ]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,k2]*
      sp[k2,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 40*sp[
      k1,k2]*sp[k2,k3]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 
      32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 136*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q] - 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 12*sp[k1,k2]*sp[
      k2,k4]*m - 80*sp[k1,k2]*sp[k2,k4]^2 + 40*sp[k1,k2]*sp[k2,k4]^2*m
       + 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k2
      ,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4]*m - 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 20*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m - 104*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 36*sp[k1,
      k2]*sp[k2,k4]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 80*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       + 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]
       - 8*sp[k1,k2]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 20
      *sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       - 4*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,q] + 16*
      sp[k1,k2]*sp[k3,q]*m - 72*sp[k1,k2]*sp[k3,q]^2 + 28*sp[k1,k2]*sp[
      k3,q]^2*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 8*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m - 36*sp[k1,k2]*sp[k4,q] + 20*sp[k1,k2]*sp[k4,q]*m + 
      160*sp[k1,k2]*sp[k4,q]^2 - 68*sp[k1,k2]*sp[k4,q]^2*m - 48*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q] + 20*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 56*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       + 56*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q
      ]*m - 48*sp[k1,k3]*sp[k2,k3] + 8*sp[k1,k3]*sp[k2,k3]*m - 104*sp[
      k1,k3]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m
       + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,q]*m + 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m + 56*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k4]*m + 
      16*sp[k1,k3]*sp[k2,k4]^2 - 32*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] + 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 56*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m - 4*sp[k1,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,q]^2 - 32*sp[
      k1,k3]*sp[k2,q]^2*m - 120*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 44*sp[k1
      ,k3]*sp[k2,q]*sp[k3,k4]*m + 56*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 20*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 
      12*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 72*sp[k1,k4]^2*sp[k2,q] + 28*
      sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3]*m + 72*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 28*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 56*sp[k1,k4]*sp[k1,q]*sp[k2,q]
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 40*sp[k1,k4]*sp[k2,k3] + 24
      *sp[k1,k4]*sp[k2,k3]^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 32*
      sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 160*sp[k1,k4]*sp[k2,k3]*sp[k2,q
      ] + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 24*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k4]*sp[k2,
      k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k4] + 8*sp[k1,k4]*sp[k2,k4]*m
       - 80*sp[k1,k4]*sp[k2,k4]^2 + 32*sp[k1,k4]*sp[k2,k4]^2*m - 24*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 24
      *sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 80*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k4
      ,q]*m - 12*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1
      ,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m + 40*sp[k1,k4]*sp[k2,q
      ]*sp[k3,k4] - 12*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 12*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m - 112*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 44*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m - 56*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q]^2
      *sp[k2,k3]*m + 56*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*
      m - 32*sp[k1,q]*sp[k2,k3] + 12*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 40*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m
       + 40*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 12*sp[k1,q]*sp[k2,k3]*sp[k3,q
      ]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 36*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m + 20*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m + 120*
      sp[k1,q]*sp[k2,k4]^2 - 44*sp[k1,q]*sp[k2,k4]^2*m + 16*sp[k1,q]*
      sp[k2,k4]*sp[k2,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q
      ]*sp[k2,k4]*sp[k3,k4] - 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 112*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 36*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 
      96*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 36*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m
       - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2,q]*sp[k3,
      q]*m + 32*sp[k1,q]*sp[k2,q]*sp[k4,q] - 16*sp[k1,q]*sp[k2,q]*sp[k4
      ,q]*m] + amp[12,1]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[k1 + k3]]*den[sp[k4 - q]]*num[32*sp[k1,k2]*sp[k1,k4] - 16*
      sp[k1,k2]*sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,q] + 8*sp[k1,k2]*sp[k1
      ,q]*m + 8*sp[k1,k2]*sp[k3,k4] + 4*sp[k1,k2]*sp[k3,k4]*m - 4*sp[k1
      ,k2]*sp[k3,k4]*m^2 - 40*sp[k1,k2]*sp[k3,q] + 28*sp[k1,k2]*sp[k3,q
      ]*m - 4*sp[k1,k2]*sp[k3,q]*m^2 - 40*sp[k1,k3]*sp[k2,k4] + 28*sp[
      k1,k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 + 8*sp[k1,k3]*sp[
      k2,q] + 4*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 + 24*
      sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[
      k2,k3]*m^2 + 24*sp[k1,q]*sp[k2,k3] - 20*sp[k1,q]*sp[k2,k3]*m + 4*
      sp[k1,q]*sp[k2,k3]*m^2] + amp[12,1]*color[1/4*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 + k3]]*den[sp[k4 - q]]*num[ - 16*sp[k1,k2]
      *sp[k1,k4] + 8*sp[k1,k2]*sp[k1,k4]*m + 32*sp[k1,k2]*sp[k1,q] - 16
      *sp[k1,k2]*sp[k1,q]*m - 40*sp[k1,k2]*sp[k3,k4] + 28*sp[k1,k2]*sp[
      k3,k4]*m - 4*sp[k1,k2]*sp[k3,k4]*m^2 + 8*sp[k1,k2]*sp[k3,q] + 4*
      sp[k1,k2]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k3,q]*m^2 + 8*sp[k1,k3]*sp[
      k2,k4] + 4*sp[k1,k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 40
      *sp[k1,k3]*sp[k2,q] + 28*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2
      ,q]*m^2 + 24*sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k4]*sp[k2,k3]*m + 4*
      sp[k1,k4]*sp[k2,k3]*m^2 + 24*sp[k1,q]*sp[k2,k3] - 20*sp[k1,q]*sp[
      k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*m^2] + amp[12,1]*color[1/2*Ca^2*
      Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k3]]*den[sp[k4 - q]]*num[
       - 48*sp[k1,k2]*sp[k1,k4] + 24*sp[k1,k2]*sp[k1,k4]*m + 48*sp[k1,
      k2]*sp[k1,q] - 24*sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]*sp[k3,k4]
       + 24*sp[k1,k2]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k3,q] - 24*sp[k1,k2
      ]*sp[k3,q]*m + 48*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m
       - 48*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k3]*sp[k2,q]*m] + amp[12,2]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k3]]*
      den[sp[ - k3 - k4]]*den[sp[k4 - q]]*num[ - 40*sp[k1,k2]^2*sp[k3,
      k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[k3,q] - 32*
      sp[k1,k2]^2*sp[k3,q]*m + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2
      *sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 24*sp[k1,k2]*sp[k1,k3]*m
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k1,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,
      k3]*sp[k1,q]*m + 56*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4]*m - 88*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 24*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[
      k1,k4] + 48*sp[k1,k2]*sp[k1,k4]*m + 80*sp[k1,k2]*sp[k1,k4]^2 - 40
      *sp[k1,k2]*sp[k1,k4]^2*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       - 8*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 112*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 104*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 104*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] + 36*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k4]
      *sp[k4,q]*m - 72*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 40*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 40*sp[
      k1,k2]*sp[k2,k4]*sp[k3,k4] - 12*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m
       + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 12*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 60*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m
       - 160*sp[k1,k2]*sp[k3,k4]^2 + 68*sp[k1,k2]*sp[k3,k4]^2*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,
      q]*m + 72*sp[k1,k2]*sp[k3,q]^2 - 28*sp[k1,k2]*sp[k3,q]^2*m + 48*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 20*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 
      32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^2*sp[k2,k4]*m + 80*sp[k1,
      k3]^2*sp[k2,q] - 32*sp[k1,k3]^2*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 48*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
      *m + 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]
      *sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3] + 56*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,k3]*
      sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[
      k1,k3]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 
      16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
      *m + 76*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m - 72*sp[k1
      ,k3]*sp[k2,k4]^2 + 28*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 112*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4] - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 12
      *sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       + 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 12*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 56*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q] + 20*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 120*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 44*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 120*sp[k1,k4]
      ^2*sp[k2,k3] - 44*sp[k1,k4]^2*sp[k2,k3]*m + 80*sp[k1,k4]^2*sp[k2,
      k4] - 32*sp[k1,k4]^2*sp[k2,k4]*m + 16*sp[k1,k4]^2*sp[k2,q] - 32*
      sp[k1,k4]^2*sp[k2,q]*m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 104*sp[k1,k4]*sp[k1,q]*sp[k2,
      q] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 68*sp[k1,k4]*sp[k2,k3] + 
      24*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4
      ]*sp[k2,k3]^2*m + 72*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 28*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4]*m - 56*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 24*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 
      36*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] + 36*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,k4]*sp[
      k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       + 56*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m - 24*sp[k1,q]^2*sp[k2,k4] - 56*sp[k1,q]*sp[k2,k3]^2 + 16*sp[
      k1,q]*sp[k2,k3]^2*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 36*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m - 40*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 12
      *sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 12*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] + 48*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m] + amp[12,3]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]
      ]*den[sp[k1 + k3]]*den[sp[ - k3 + q]]*den[sp[k4 - q]]*num[32*sp[
      k1,k2]^2 - 8*sp[k1,k2]^2*m + 104*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1
      ,k2]^2*sp[k3,k4]*m - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[
      k3,q]*m - 40*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 40*
      sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 88*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] + 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 80*sp[k1,k2]*
      sp[k1,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 
      40*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
      *m - 32*sp[k1,k2]*sp[k1,k4] + 8*sp[k1,k2]*sp[k1,k4]*m + 64*sp[k1,
      k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 72*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,k4]*m + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 40*sp[k1,k2]
      *sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k4,q]*m - 104*sp[k1,k2]*sp[k1,q] + 48*sp[k1,
      k2]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1,q]^2 + 40*sp[k1,k2]*sp[k1,q]^
      2*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3]*m + 104*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,
      q]*sp[k2,k4]*m - 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k2]*
      sp[k1,q]*sp[k2,q]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 20*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m + 104*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 36*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 
      8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3] - 8*sp[
      k1,k2]*sp[k2,k3]*m + 88*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,
      k2]*sp[k2,k3]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 8*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q]
      *sp[k3,k4] + 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] + 12*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k2]*
      sp[k3,k4] + 4*sp[k1,k2]*sp[k3,k4]*m - 72*sp[k1,k2]*sp[k3,k4]^2 + 
      28*sp[k1,k2]*sp[k3,k4]^2*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 8*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       - 20*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 60*sp[k1,k2]*sp[k3,q] + 28
      *sp[k1,k2]*sp[k3,q]*m + 160*sp[k1,k2]*sp[k3,q]^2 - 68*sp[k1,k2]*
      sp[k3,q]^2*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 4*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q]*m + 80*sp[k1,k3]^2*sp[k2,k4] - 32*sp[k1,k3]^2*sp[k2,
      k4]*m + 32*sp[k1,k3]^2*sp[k2,q] - 8*sp[k1,k3]^2*sp[k2,q]*m - 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 20*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 104*sp[k1,k3]*sp[k2,k3] - 40*sp[
      k1,k3]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*
      sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]
       + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,k3]*sp[k2,k3]*
      sp[k3,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k3]*
      sp[k2,k4] + 20*sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] + 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 56*sp[k1,k3]*sp[k2,k4
      ]*sp[k3,k4] - 20*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 120*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q] + 44*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 
      20*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m + 72*sp[k1,k3]*
      sp[k2,q]^2 - 28*sp[k1,k3]*sp[k2,q]^2*m - 12*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 44*sp[k1,k3]*sp[
      k2,q]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 12*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k4]^2*sp[k2,q] + 48*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 104*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 48*sp[
      k1,k4]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 16*
      sp[k1,k4]*sp[k2,k3] + 4*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[
      k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m - 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 40*sp[k1,k4]*sp[k2,k3]
      *sp[k3,k4] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 96*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] + 36*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 48*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,
      q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 120*sp[k1,q]^2*sp[k2,k3]
       + 44*sp[k1,q]^2*sp[k2,k3]*m + 16*sp[k1,q]^2*sp[k2,k4] - 32*sp[k1
      ,q]^2*sp[k2,k4]*m + 80*sp[k1,q]^2*sp[k2,q] - 32*sp[k1,q]^2*sp[k2,
      q]*m - 44*sp[k1,q]*sp[k2,k3] + 20*sp[k1,q]*sp[k2,k3]*m - 56*sp[k1
      ,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m + 56*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 72*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] + 28*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 112*sp[k1
      ,q]*sp[k2,k3]*sp[k3,k4] - 36*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 96*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] + 36*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 
      16*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       + 56*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2
      ,q]*sp[k3,q]*m] + amp[12,4]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - 
      k2]]*den[sp[k1 + k3]]*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[ - 
      128*sp[k1,k2]^2 + 48*sp[k1,k2]^2*m + 176*sp[k1,k2]^2*sp[k4,q] - 
      48*sp[k1,k2]^2*sp[k4,q]*m + 80*sp[k1,k2]*sp[k1,k3] - 40*sp[k1,k2]
      *sp[k1,k3]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 64*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m + 104*sp[k1,k2]*sp[k1,k4] - 56*sp[k1,k2]*sp[
      k1,k4]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 4*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 - 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*
      m - 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 - 104*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1
      ,q] + 40*sp[k1,k2]*sp[k1,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[
      k2,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 12*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 24*sp[k1,k2]*
      sp[k1,q]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 + 104*sp[
      k1,k2]*sp[k1,q]*sp[k4,q] - 48*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 128
      *sp[k1,k2]*sp[k2,k3] + 48*sp[k1,k2]*sp[k2,k3]*m + 176*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q] - 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2
       - 12*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 - 12*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m^2 + 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k2
      ]*sp[k2,q]*sp[k3,q]*m^2 + 104*sp[k1,k2]*sp[k3,k4] - 56*sp[k1,k2]*
      sp[k3,k4]*m + 96*sp[k1,k2]*sp[k3,k4]^2 - 40*sp[k1,k2]*sp[k3,k4]^2
      *m + 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ] - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m^2 - 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3
      ,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k3,q] + 40*sp[k1,k2]*sp[k3,q]*m
       + 96*sp[k1,k2]*sp[k3,q]^2 - 40*sp[k1,k2]*sp[k3,q]^2*m + 4*sp[k1,
      k2]*sp[k3,q]^2*m^2 + 104*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 48*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]
      *m^2 + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 48*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 40*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2
       + 128*sp[k1,k3]*sp[k2,k3] - 48*sp[k1,k3]*sp[k2,k3]*m - 176*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 104
      *sp[k1,k3]*sp[k2,k4] + 56*sp[k1,k3]*sp[k2,k4]*m - 96*sp[k1,k3]*
      sp[k2,k4]^2 + 40*sp[k1,k3]*sp[k2,k4]^2*m - 4*sp[k1,k3]*sp[k2,k4]^
      2*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 8*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 24*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 12*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m^2 + 104*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m + 80*sp[k1,k3]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,q]*m - 96
      *sp[k1,k3]*sp[k2,q]^2 + 40*sp[k1,k3]*sp[k2,q]^2*m - 4*sp[k1,k3]*
      sp[k2,q]^2*m^2 + 12*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m^2 - 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[
      k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 104*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 
      48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k4]^2*sp[k2,k3]*m + 4
      *sp[k1,k4]^2*sp[k2,k3]*m^2 - 24*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,
      k4]^2*sp[k2,q]*m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3]*m^2 + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 24*sp[k1,k4]*sp[k1,q]*sp[k2,q]
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4] - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,k4]*m^2 - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 4*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 96*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 40*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q]*m^2 + 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]
      *sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,q]^2*sp[k2,k3]*m + 4*sp[k1
      ,q]^2*sp[k2,k3]*m^2 + 24*sp[k1,q]^2*sp[k2,k4] - 16*sp[k1,q]^2*sp[
      k2,k4]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]
      *sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q
      ]*sp[k2,k3]*sp[k2,q]*m^2 + 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 4*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 40*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 24*sp[k1,q]*sp[k2,
      k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 24*sp[k1,q]*sp[
      k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[12,5]*
      color[1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 - k4]]*
      den[sp[k4 - q]]*num[64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2
       - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,k3]*sp[k2,k3]*sp[
      k2,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 64*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4
      ]*m^2 + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,k4
      ]*sp[k3,q]*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,k3]
      *sp[k2,q]*sp[k3,k4] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m^2] + amp[12,6]*color[ - 1/2*Ca*Cf*Na*
      Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 + q]]*den[sp[k4 - q]]*num[64*
      sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[
      k2,k3]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,k3]*
      sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 64
      *sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 
      128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,
      q]*sp[k3,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[
      k2,q]*sp[k3,q]*m^2] + amp[12,7]*color[ - Ca*Cf*Na*Tf]*den[sp[k1
       + k3]]^2*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[256*sp[k1,k3]*
      sp[k2,k3] - 224*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k2,k3]*
      m^2 - 352*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 272*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 192*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4] + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 192*sp[
      k1,k3]*sp[k2,q]*sp[k3,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16
      *sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2] + amp[12,8]*color[ - 1/2*Ca*Cf*
      Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[
       - k2 - k3]]*den[sp[k4 - q]]*num[64*sp[k1,k2]^2*sp[k1,k4] - 32*
      sp[k1,k2]^2*sp[k1,k4]*m - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,k2]
      ^2*sp[k1,q]*m - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,q
      ] - 64*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m
       - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k1,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 128*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 
      192*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q
      ]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 48*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]
       - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k3
      ,k4]^2 - 48*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[k1,k2]*sp[k3,k4]^2*m^2
       + 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k3
      ,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 128*sp[k1,k3]^2*sp[
      k2,k4] - 32*sp[k1,k3]^2*sp[k2,k4]*m - 64*sp[k1,k3]^2*sp[k2,q] + 
      16*sp[k1,k3]^2*sp[k2,q]*m - 256*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 
      128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 320*sp[k1,
      k3]*sp[k1,q]*sp[k2,k3] - 208*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 128*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*sp[k2
      ,k4]^2*m - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 48*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 32*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m - 32*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m
       - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,
      k3]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 48*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 48*sp[
      k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 160*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 96*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 
      16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2] + amp[12,9]*color[ - 1/2*Ca*
      Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[
      sp[ - k2 + q]]*den[sp[k4 - q]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 16*
      sp[k1,k2]^2*sp[k3,k4]*m + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^
      2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]*sp[k1,k3]
       + 16*sp[k1,k2]*sp[k1,k3]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 
      48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k1
      ,k4] - 32*sp[k1,k2]*sp[k1,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3
      ] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 192*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 8*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 48*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 80*sp[k1,k2]
      *sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2 - 96*
      sp[k1,k2]*sp[k1,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 
      32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 256*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4] + 144*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 80*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 
      128*sp[k1,k2]*sp[k3,k4] - 64*sp[k1,k2]*sp[k3,k4]*m + 8*sp[k1,k2]*
      sp[k3,k4]*m^2 + 448*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 224*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 192*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]
      *sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 48*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 - 
      160*sp[k1,k3]*sp[k2,k4] + 80*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k3]*
      sp[k2,k4]*m^2 + 192*sp[k1,k3]*sp[k2,k4]^2 - 112*sp[k1,k3]*sp[k2,
      k4]^2*m + 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 32*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 192*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] + 112*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 256*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       - 160*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^2 - 128*sp[k1,k4]^2*sp[k2,q] + 48*sp[k1,k4]^2*sp[k2,q]*m
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2
      ,k3]*m^2 + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q
      ]*sp[k2,k4]*m - 160*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k4]*
      sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k4]*sp[k2
      ,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,k4] - 80*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 48*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 320*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 176*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q]*m^2 - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 
      96*sp[k1,q]^2*sp[k2,k3] - 80*sp[k1,q]^2*sp[k2,k3]*m + 16*sp[k1,q]
      ^2*sp[k2,k3]*m^2 + 96*sp[k1,q]^2*sp[k2,k4] - 32*sp[k1,q]^2*sp[k2,
      k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 80*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 192*sp[k1,q
      ]*sp[k2,k4]*sp[k3,k4] + 80*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 
      32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 224*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] + 112*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4]*m^2] + amp[12,11]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[k4 - 
      q]]*num[64*sp[k1,k2]^2 - 32*sp[k1,k2]^2*m - 128*sp[k1,k2]^2*sp[k1
      ,k4] + 64*sp[k1,k2]^2*sp[k1,k4]*m + 64*sp[k1,k2]^2*sp[k1,q] - 32*
      sp[k1,k2]^2*sp[k1,q]*m + 32*sp[k1,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^
      2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m
       + 64*sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*m - 128*sp[k1,
      k2]*sp[k1,k3]*sp[k1,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64
      *sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]
      *sp[k3,k4]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 160*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q] - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 128*sp[k1,
      k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 
      192*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[
      k3,q]*m + 64*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3]*m + 64*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 64*sp[k1,
      k2]*sp[k3,q]^2 + 48*sp[k1,k2]*sp[k3,q]^2*m - 8*sp[k1,k2]*sp[k3,q]
      ^2*m^2 - 64*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m + 
      128*sp[k1,k3]^2*sp[k2,q] - 32*sp[k1,k3]^2*sp[k2,q]*m + 320*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k3] - 208*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 
      32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 96*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 256*sp[k1,k3]*sp[k1,q
      ]*sp[k2,k3] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 32*sp[
      k1,k3]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 128
      *sp[k1,k3]*sp[k2,k3] + 96*sp[k1,k3]*sp[k2,k3]*m - 16*sp[k1,k3]*
      sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 32*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k3
      ,q]*m + 32*sp[k1,k3]*sp[k2,q]^2 - 16*sp[k1,k3]*sp[k2,q]^2*m - 32*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*
      m^2 + 64*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k3]*sp[k2,q]*sp[
      k3,q]*m + 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 32*sp[k1,k4]*sp[k1,
      q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 192*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 32*sp[k1,q]^2*sp[k2,k3] - 
      16*sp[k1,q]^2*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 48
      *sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]
       + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 256*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 160*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,q]*
      sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[
      12,12]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[sp[k4 - q]]*num[ - 32*sp[
      k1,k2]^2 + 32*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m
       + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m - 32*sp[k1
      ,k2]^2*sp[k4,q] + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 48*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 48*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k4] - 32*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 96*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4] - 80*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[
      k1,k2]*sp[k1,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 
      16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 192*sp[k1,k2]*sp[k1,q]*
      sp[k2,q] - 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 8*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 48*sp[
      k1,k2]*sp[k1,q]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 80*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 
      32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
      *m + 256*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 144*sp[k1,k2]*sp[k2,q]*sp[
      k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 - 272*sp[k1,k2]*sp[
      k3,k4] + 104*sp[k1,k2]*sp[k3,k4]*m - 8*sp[k1,k2]*sp[k3,k4]*m^2 - 
      192*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 112*sp[k1,k2]*sp[k3,k4]*sp[k4,
      q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 448*sp[k1,k2]*sp[k3,
      q]*sp[k4,q] - 224*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 24*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 48*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*
      m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 144*sp[k1,
      k3]*sp[k2,k4] - 72*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*
      m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 160*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 192*
      sp[k1,k3]*sp[k2,q]^2 + 112*sp[k1,k3]*sp[k2,q]^2*m - 16*sp[k1,k3]*
      sp[k2,q]^2*m^2 - 192*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 112*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[
      k1,k4]^2*sp[k2,k3] + 80*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*
      sp[k2,k3]*m^2 + 96*sp[k1,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q]
      *m - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3]*m^2 - 160*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k4]
      *sp[k1,q]*sp[k2,q]*m + 240*sp[k1,k4]*sp[k2,k3] - 104*sp[k1,k4]*
      sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q] - 80*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m^2 - 224*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 112*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*
      m^2 + 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4]*m - 192*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 80*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]^2
      *sp[k2,k4] + 48*sp[k1,q]^2*sp[k2,k4]*m + 64*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 80*sp[k1,q]*
      sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m^2 - 320*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] + 176*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4]*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + 
      amp[12,14]*color[ - Ca*Cf*Na*Tf + 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]
      ]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[ - 
      256*sp[k1,k2]^2 + 96*sp[k1,k2]^2*m + 352*sp[k1,k2]^2*sp[k4,q] - 
      96*sp[k1,k2]^2*sp[k4,q]*m - 256*sp[k1,k2]*sp[k1,k3] + 96*sp[k1,k2
      ]*sp[k1,k3]*m + 352*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 96*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m + 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 
      32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 192*sp[k1,
      k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 48*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 
      96*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m
       - 256*sp[k1,k2]*sp[k2,k3] + 96*sp[k1,k2]*sp[k2,k3]*m + 352*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 96*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*
      m - 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]
      *sp[k3,k4]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,q]*m + 192*sp[k1,k2]*sp[k3,k4]^2 - 80*sp[k1,k2]*sp[k3
      ,k4]^2*m + 8*sp[k1,k2]*sp[k3,k4]^2*m^2 - 192*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*sp[k3,q]^2 - 80*sp[k1,k2]*sp[k3
      ,q]^2*m + 8*sp[k1,k2]*sp[k3,q]^2*m^2 + 96*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 48*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1
      ,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 512*
      sp[k1,k3]*sp[k2,k3] - 320*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*
      sp[k2,k3]*m^2 - 704*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 368*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 96*
      sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m + 96*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q] + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[
      k1,k3]*sp[k2,k4]*sp[k3,k4] + 80*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m
       - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q]*m^2 - 96*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q
      ]^2*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 192*sp[k1,k3]*
      sp[k2,q]*sp[k3,q] + 80*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k3
      ]*sp[k2,q]*sp[k3,q]*m^2 - 96*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]
      ^2*sp[k2,k3]*m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,k4] + 80*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,k3]
      *sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 96*
      sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*m - 48*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 96*sp[
      k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 96*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m
       - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 192*sp[k1,q]*sp[k2,k3]*
      sp[k3,q] + 80*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,q]*sp[k2,k3
      ]*sp[k3,q]*m^2] + amp[12,15]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k3
      ]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*den[sp[k4 - q]]*num[16*
      sp[k1,k2]^2 + 16*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,q]
       + 16*sp[k1,k2]^2*sp[k4,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1
      ,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 48*sp[k1,k2]*
      sp[k1,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 16*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,q]
       + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,q]*
      sp[k4,q] + 40*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,
      k3] + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2
      ]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 96
      *sp[k1,k2]*sp[k2,q]*sp[k3,q] + 40*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m
       + 184*sp[k1,k2]*sp[k3,k4] - 60*sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,
      k2]*sp[k3,k4]*m^2 + 144*sp[k1,k2]*sp[k3,k4]^2 - 96*sp[k1,k2]*sp[
      k3,k4]^2*m + 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 24*sp[k1,k2]*sp[k3,k4
      ]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 24*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 224*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] + 72*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 
      16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q
      ] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,
      k3]*sp[k2,k4] + 112*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 48*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q]*m - 120*sp[k1,k3]*sp[k2,k4] + 60*sp[k1,k3
      ]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4
      ]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 176*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4] + 112*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,
      k3]*sp[k2,q]^2 - 56*sp[k1,k3]*sp[k2,q]^2*m + 32*sp[k1,k3]*sp[k2,q
      ]*sp[k3,k4] - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k3]*
      sp[k2,q]*sp[k4,q] - 56*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 48*sp[k1,
      k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m - 48*sp[k1,k4]^2*sp[
      k2,q] + 16*sp[k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ]*m + 112*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k4]*sp[k1,q]*
      sp[k2,k4]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k4]*sp[k1
      ,q]*sp[k2,q]*m - 168*sp[k1,k4]*sp[k2,k3] + 60*sp[k1,k4]*sp[k2,k3]
      *m - 4*sp[k1,k4]*sp[k2,k3]*m^2 - 48*sp[k1,k4]*sp[k2,k3]^2 + 16*
      sp[k1,k4]*sp[k2,k3]^2*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 144*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q] - 40*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,q]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 40*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 80*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m + 128*sp[k1,q]^2*sp[k2,k4] - 56*sp[k1,q]^2*sp[k2,k4]*m
       - 48*sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m + 32*sp[k1
      ,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 
      48*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]
      *m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 56*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 56*sp[k1,q]
      *sp[k2,q]*sp[k3,k4]*m] + amp[12,16]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k3]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k4 - q
      ]]*num[16*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,q] - 16*
      sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,k2]*sp[
      k1,k3]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k4]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]
      *sp[k1,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 160*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 48*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 
      16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*
      m - 96*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 40*sp[k1,k2]*sp[k1,k4]*sp[
      k4,q]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,q]
      *sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 48*sp[k1,k2]*sp[k1
      ,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 48*sp[k1,k2]*
      sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 48*sp[k1,
      k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 48
      *sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m
       - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,k4] - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2
      ]*sp[k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m - 24*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 224*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] + 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 144*sp[
      k1,k2]*sp[k3,q]^2 + 96*sp[k1,k2]*sp[k3,q]^2*m - 16*sp[k1,k2]*sp[
      k3,q]^2*m^2 + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[
      k3,q]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 40*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]
       - 80*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k3]*sp[k2,k3]*m + 112*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16
      *sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2,k4] - 
      16*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k4]^2 + 56*sp[k1,
      k3]*sp[k2,k4]^2*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,k3
      ]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      56*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m^2 + 176*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 112*sp[k1,k3]*sp[
      k2,q]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 64*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1
      ,k3]*sp[k2,q]*sp[k4,q]*m^2 + 128*sp[k1,k4]^2*sp[k2,q] - 56*sp[k1,
      k4]^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 112*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 
      16*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k4]*sp[k2,k3]*m - 48*sp[k1,k4]*
      sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m + 64*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 48*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 128
      *sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 192*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 56*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 56*sp[k1,k4]*sp[k2,q
      ]*sp[k3,k4]*m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m + 48*sp[k1,q]^2*sp[k2,k3] - 16*sp[k1,q]^2*sp[k2,
      k3]*m - 48*sp[k1,q]^2*sp[k2,k4] + 16*sp[k1,q]^2*sp[k2,k4]*m - 48*
      sp[k1,q]*sp[k2,k3]^2 + 16*sp[k1,q]*sp[k2,k3]^2*m + 8*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 40*sp[k1,q
      ]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 
      144*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 96*sp[k1,q]*sp[k2,k3]*sp[k3,q]*
      m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 48*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] - 40*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[13,1]*color[ - 1/2*Ca^2*Na*
      Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 - k3]]*den[sp[k4 - q]]*num[
      48*sp[k1,k2]*sp[k2,k4] - 24*sp[k1,k2]*sp[k2,k4]*m - 48*sp[k1,k2]*
      sp[k2,q] + 24*sp[k1,k2]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k3,k4] - 24*
      sp[k1,k2]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k3,q] + 24*sp[k1,k2]*sp[
      k3,q]*m - 48*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 48*
      sp[k1,q]*sp[k2,k3] - 24*sp[k1,q]*sp[k2,k3]*m] + amp[13,1]*color[
       - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 - k3]]*den[
      sp[k4 - q]]*num[16*sp[k1,k2]*sp[k2,k4] - 8*sp[k1,k2]*sp[k2,k4]*m
       - 32*sp[k1,k2]*sp[k2,q] + 16*sp[k1,k2]*sp[k2,q]*m + 40*sp[k1,k2]
      *sp[k3,k4] - 28*sp[k1,k2]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k3,k4]*m^2
       - 8*sp[k1,k2]*sp[k3,q] - 4*sp[k1,k2]*sp[k3,q]*m + 4*sp[k1,k2]*
      sp[k3,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4] + 20*sp[k1,k3]*sp[k2,k4]*m
       - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 24*sp[k1,k3]*sp[k2,q] + 20*sp[k1,
      k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2 - 8*sp[k1,k4]*sp[k2,k3]
       - 4*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k2,k3]*m^2 + 40*sp[k1
      ,q]*sp[k2,k3] - 28*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,k3]*
      m^2] + amp[13,1]*color[1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[ - k2 - k3]]*den[sp[k4 - q]]*num[ - 32*sp[k1,k2]*sp[k2,k4] + 
      16*sp[k1,k2]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k2,q] - 8*sp[k1,k2]*
      sp[k2,q]*m - 8*sp[k1,k2]*sp[k3,k4] - 4*sp[k1,k2]*sp[k3,k4]*m + 4*
      sp[k1,k2]*sp[k3,k4]*m^2 + 40*sp[k1,k2]*sp[k3,q] - 28*sp[k1,k2]*
      sp[k3,q]*m + 4*sp[k1,k2]*sp[k3,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4] + 
      20*sp[k1,k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 24*sp[k1,
      k3]*sp[k2,q] + 20*sp[k1,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,q]*m^2
       + 40*sp[k1,k4]*sp[k2,k3] - 28*sp[k1,k4]*sp[k2,k3]*m + 4*sp[k1,k4
      ]*sp[k2,k3]*m^2 - 8*sp[k1,q]*sp[k2,k3] - 4*sp[k1,q]*sp[k2,k3]*m
       + 4*sp[k1,q]*sp[k2,k3]*m^2] + amp[13,2]*color[1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[ - k2 - k3]]*den[sp[ - k3 - k4]]*den[
      sp[k4 - q]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,
      k4]*m - 104*sp[k1,k2]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k3,q]*m - 40
      *sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m - 24*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 72*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 
      40*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4
      ]*m - 88*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k3]*
      sp[k3,q]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q]*m - 56*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k3]*m - 112*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 40*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4] + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q] + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 104*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 
      48*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
      *m + 64*sp[k1,k2]*sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*m - 64*sp[k1
      ,k2]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 
      80*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q]
      *m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q]*m + 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k2,k4] - 48*sp[k1,k2]*
      sp[k2,k4]*m - 80*sp[k1,k2]*sp[k2,k4]^2 + 40*sp[k1,k2]*sp[k2,k4]^2
      *m + 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[
      k2,q]*m + 104*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 36*sp[k1,k2]*sp[k2,
      k4]*sp[k3,k4]*m - 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 20*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 8*sp[k1
      ,k2]*sp[k2,k4]*sp[k4,q]*m + 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 40
      *sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] + 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 60*sp[k1,k2]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k3,k4]*m + 160*sp[k1,k2]*sp[k3,k4]^2 - 68*sp[
      k1,k2]*sp[k3,k4]^2*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 8*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 4*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 72*sp[k1,k2]*sp[k3,q]^2 + 28*sp[
      k1,k2]*sp[k3,q]^2*m - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 20*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m + 56*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]
      ^2*sp[k2,k4]*m + 56*sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q
      ]*m - 56*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m - 72*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 28*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q]*m - 56*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[
      k1,k3]*sp[k1,q]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 
      24*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3] + 16*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2
      ,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,k3]
      *sp[k3,k4]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k3]*sp[
      k2,k3]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q]*m + 68*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*
      sp[k2,k4]*m - 120*sp[k1,k3]*sp[k2,k4]^2 + 44*sp[k1,k3]*sp[k2,k4]^
      2*m + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q]*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 36*sp[k1,k3]*sp[k2,
      k4]*sp[k3,k4]*m + 112*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 36*sp[k1,k3]
      *sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 4*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 36*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 40*sp[k1,k3]*sp[k2,q]*sp[k3,q]
       - 12*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q] + 12*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 72*sp[k1,k4]^2*sp[k2,k3]
       - 28*sp[k1,k4]^2*sp[k2,k3]*m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 76*sp[k1,k4]*sp[k2,k3] + 
      24*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]^2 + 8*sp[k1,k4]
      *sp[k2,k3]^2*m + 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 4*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4]*m - 160*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 48*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
       + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 12*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m + 40*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q]*m - 80*sp[k1,k4]*sp[k2,k4]^2 + 32*sp[k1,k4]*sp[k2,
      k4]^2*m - 48*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,k4]*sp[k2,k4
      ]*sp[k2,q]*m - 80*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k4]*
      sp[k2,k4]*sp[k3,k4]*m - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q]*m + 24*sp[k1,k4]*sp[k2,q]^2 - 24*sp[k1,
      k4]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 24*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] - 80*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,
      q]*sp[k2,k3]^2*m + 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 20*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1
      ,q]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 12*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k3,q]
       - 20*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 120*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] - 44*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k4]^
      2 + 32*sp[k1,q]*sp[k2,k4]^2*m - 104*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 56*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[13,3]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[ - k2 - k3]]*
      den[sp[ - k3 + q]]*den[sp[k4 - q]]*num[ - 32*sp[k1,k2]^2 + 8*sp[
      k1,k2]^2*m - 104*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]
      *m + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m + 40*sp[
      k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[
      k1,k3] + 8*sp[k1,k2]*sp[k1,k3]*m + 72*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k3]
      *sp[k2,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 88*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 40*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 40*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 
      88*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m - 104*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]
      *sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m - 56*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[
      k1,k2]*sp[k1,q]*sp[k2,k4]*m + 112*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 
      40*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ] - 12*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,q]*sp[
      k3,q] - 12*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k3]
      *m + 80*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k2]*sp[k2,k3]*
      sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[
      k2,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,
      k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 8
      *sp[k1,k2]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 136*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,k4
      ]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 104*sp[k1,k2]*
      sp[k2,q] - 48*sp[k1,k2]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,q]^2 - 40
      *sp[k1,k2]*sp[k2,q]^2*m + 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 20*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 104*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       + 36*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4] - 
      4*sp[k1,k2]*sp[k3,k4]*m + 72*sp[k1,k2]*sp[k3,k4]^2 - 28*sp[k1,k2]
      *sp[k3,k4]^2*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 8*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 20*sp[k1
      ,k2]*sp[k3,k4]*sp[k4,q]*m + 60*sp[k1,k2]*sp[k3,q] - 28*sp[k1,k2]*
      sp[k3,q]*m - 160*sp[k1,k2]*sp[k3,q]^2 + 68*sp[k1,k2]*sp[k3,q]^2*m
       - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]
      *m + 56*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^2*sp[k2,k4]*m + 56*
      sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 56*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 56*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      56*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
      *m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m + 72*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 28*sp[k1,k3]*sp[k1,q]*
      sp[k2,q]*m - 104*sp[k1,k3]*sp[k2,k3] + 40*sp[k1,k3]*sp[k2,k3]*m
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,k3]*sp[k2,k3
      ]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,k3]*
      sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q] + 16*sp[
      k1,k3]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 
      16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4] - 4*
      sp[k1,k3]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 4*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 12
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ] - 36*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 44*sp[k1,k3]*sp[k2
      ,q] - 20*sp[k1,k3]*sp[k2,q]*m + 120*sp[k1,k3]*sp[k2,q]^2 - 44*sp[
      k1,k3]*sp[k2,q]^2*m - 112*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 36*sp[k1
      ,k3]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 36*
      sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 
      4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       - 20*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3] - 20
      *sp[k1,k4]*sp[k2,k3]*m - 80*sp[k1,k4]*sp[k2,k3]^2 + 32*sp[k1,k4]*
      sp[k2,k3]^2*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 20*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 56*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 
      20*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 120*sp[k1,k4]*sp[k2,k3]
      *sp[k4,q] - 44*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 104*sp[k1,k4]*sp[
      k2,k4]*sp[k2,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 48*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[
      k1,k4]*sp[k2,q]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m - 56*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 72*sp[k1
      ,q]^2*sp[k2,k3] + 28*sp[k1,q]^2*sp[k2,k3]*m - 20*sp[k1,q]*sp[k2,
      k3] + 12*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1
      ,q]*sp[k2,k3]^2*m + 160*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 48*sp[k1,q
      ]*sp[k2,k3]*sp[k2,k4]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 4*sp[
      k1,q]*sp[k2,k3]*sp[k2,q]*m + 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 
      112*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 44*sp[k1,q]*sp[k2,k3]*sp[k3,q]*
      m + 40*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,q]*sp[k2,k3]*sp[k4,
      q]*m + 24*sp[k1,q]*sp[k2,k4]^2 - 48*sp[k1,q]*sp[k2,k4]*sp[k2,q]
       + 32*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 24*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m - 80*sp[k1,q]*sp[k2,q]^2 + 32*sp[k1,q]*sp[k2,q]^2*m - 24*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 
      80*sp[k1,q]*sp[k2,q]*sp[k3,q] + 32*sp[k1,q]*sp[k2,q]*sp[k3,q]*m]
       + amp[13,4]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[
       - k2 - k3]]*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[128*sp[k1,k2]
      ^2 - 48*sp[k1,k2]^2*m - 176*sp[k1,k2]^2*sp[k4,q] + 48*sp[k1,k2]^2
      *sp[k4,q]*m + 128*sp[k1,k2]*sp[k1,k3] - 48*sp[k1,k2]*sp[k1,k3]*m
       - 176*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*
      m + 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 48*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[
      k1,q]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 12*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 24*
      sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m^2
       - 80*sp[k1,k2]*sp[k2,k3] + 40*sp[k1,k2]*sp[k2,k3]*m + 128*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 104*
      sp[k1,k2]*sp[k2,k4] + 56*sp[k1,k2]*sp[k2,k4]*m - 24*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 12*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2
       + 104*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k2,k4]*sp[
      k4,q]*m + 80*sp[k1,k2]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,q]*m + 12*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*
      m^2 - 24*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,q]*sp[
      k3,q]*m^2 - 104*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,
      q]*sp[k4,q]*m - 104*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]*sp[k3,k4]*
      m - 96*sp[k1,k2]*sp[k3,k4]^2 + 40*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[
      k1,k2]*sp[k3,k4]^2*m^2 + 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 8*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2
       + 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m + 80*sp[k1,k2]*sp[k3,q] - 40*sp[k1,k2]*sp[k3,q]*m - 96*
      sp[k1,k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,k2]*
      sp[k3,q]^2*m^2 - 104*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2
       + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,
      q]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 48*sp[k1,k3]*sp[k1,q]
      *sp[k2,k4] + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 40*sp[k1,k3]
      *sp[k1,q]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m^2 - 128*
      sp[k1,k3]*sp[k2,k3] + 48*sp[k1,k3]*sp[k2,k3]*m + 176*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1
      ,k3]*sp[k2,k4]^2*m - 4*sp[k1,k3]*sp[k2,k4]^2*m^2 - 24*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 96*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*
      m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 48*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q]*m^2 + 24*sp[k1,k3]*sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,
      q]^2*m^2 - 48*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 4*sp[k1,k3]*sp[k2,q]
      *sp[k3,k4]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*
      sp[k2,q]*sp[k3,q] - 40*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 4*sp[k1,k3
      ]*sp[k2,q]*sp[k3,q]*m^2 + 96*sp[k1,k4]^2*sp[k2,k3] - 40*sp[k1,k4]
      ^2*sp[k2,k3]*m + 4*sp[k1,k4]^2*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m^2 + 104*sp[k1,k4]*sp[k2,k3] - 56*sp[k1,k4]*
      sp[k2,k3]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 40*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 48*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 12*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 104*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 24*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m - 24*sp[k1,k4]*sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m - 24*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 
      96*sp[k1,q]^2*sp[k2,k3] - 40*sp[k1,q]^2*sp[k2,k3]*m + 4*sp[k1,q]^
      2*sp[k2,k3]*m^2 - 80*sp[k1,q]*sp[k2,k3] + 40*sp[k1,q]*sp[k2,k3]*m
       - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*sp[k2,k3
      ]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,
      k3]*sp[k2,q]*m^2 - 12*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,q]
      *sp[k2,k3]*sp[k3,k4]*m^2 + 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 4*
      sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 104*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,q]*sp[k2,k4]^2 - 
      16*sp[k1,q]*sp[k2,k4]^2*m + 24*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
       - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[13,5]*color[1/2*Ca
      *Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*
      den[sp[ - k2 - k4]]*den[sp[k4 - q]]*num[ - 64*sp[k1,k2]^2*sp[k2,
      k4] + 32*sp[k1,k2]^2*sp[k2,k4]*m + 128*sp[k1,k2]^2*sp[k2,q] - 64*
      sp[k1,k2]^2*sp[k2,q]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^
      2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m
       - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m
       + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,k4]
      *sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3] - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]
      *sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*
      sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*
      m + 128*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[
      k2,q]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k2]*
      sp[k2,k3]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 16
      *sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 192*sp[k1,k2]*sp[k2,k4]*sp[k3,
      q] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 160*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[
      k3,k4]^2 + 48*sp[k1,k2]*sp[k3,k4]^2*m - 8*sp[k1,k2]*sp[k3,k4]^2*
      m^2 - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 96*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ]*m + 256*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k3]
      *sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 320*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q] + 208*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k4,
      q] + 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m^2 + 32*sp[k1,k3]*sp[k2,k4]^2 - 16*sp[k1,k3]*sp[k2,k4]^
      2*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 256*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 192*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 112*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m^2 + 32*sp[k1,k4]^2*sp[k2,k3] - 16*sp[k1,k4]^2*
      sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,k3]^2 + 32*sp[k1,k4]*sp[
      k2,k3]^2*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4]*m - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 48*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
      *m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2*
      m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,q]*sp[k2,k3]*sp[k3
      ,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m] + amp[13,6]*color[ - 1/
      2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - 
      k3]]*den[sp[ - k2 + q]]*den[sp[k4 - q]]*num[ - 64*sp[k1,k2]^2 + 
      32*sp[k1,k2]^2*m + 128*sp[k1,k2]^2*sp[k2,k4] - 64*sp[k1,k2]^2*sp[
      k2,k4]*m - 64*sp[k1,k2]^2*sp[k2,q] + 32*sp[k1,k2]^2*sp[k2,q]*m - 
      32*sp[k1,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]
      ^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3]
       + 32*sp[k1,k2]*sp[k1,k3]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 64*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 
      64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,q]*sp[
      k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,q
      ]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,k3]*m
       + 128*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k2,k3]*sp[
      k2,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,
      k3]*sp[k2,q]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k2]*
      sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 160*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 192*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[
      k2,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 8*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k3,q]^2 - 48*sp[k1,
      k2]*sp[k3,q]^2*m + 8*sp[k1,k2]*sp[k3,q]^2*m^2 + 128*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 32*sp[
      k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 128
      *sp[k1,k3]*sp[k2,k3] - 96*sp[k1,k3]*sp[k2,k3]*m + 16*sp[k1,k3]*
      sp[k2,k3]*m^2 - 320*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 208*sp[k1,k3]
      *sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 
      256*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,
      q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 128*sp[k1,k3]*sp[k2,
      k3]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 
      112*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3
      ,q]*m^2 - 32*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m - 
      256*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 160*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m - 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 64*sp[k1,k3]*sp[k2,
      q]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k3]*sp[
      k2,q]*sp[k3,q]*m^2 - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k2,k3]^2 - 16*sp[k1,k4
      ]*sp[k2,k3]^2*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1
      ,q]^2*sp[k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,
      k3]^2 + 32*sp[k1,q]*sp[k2,k3]^2*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 64*sp[k1,q
      ]*sp[k2,k3]*sp[k3,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1
      ,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[13,7]*color[ - Ca*Cf*Na*Tf + 1/
      2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*den[sp[ - k4
       + q]]*den[sp[k4 - q]]*num[ - 256*sp[k1,k2]^2 + 96*sp[k1,k2]^2*m
       + 352*sp[k1,k2]^2*sp[k4,q] - 96*sp[k1,k2]^2*sp[k4,q]*m - 256*sp[
      k1,k2]*sp[k1,k3] + 96*sp[k1,k2]*sp[k1,k3]*m + 352*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q] - 96*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 192*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4]*m + 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k2,q]*m - 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 256*sp[k1,k2]*sp[k2,k3] + 
      96*sp[k1,k2]*sp[k2,k3]*m + 352*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]
       - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*
      sp[k2,q]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 192*sp[k1,
      k2]*sp[k3,k4]^2 - 80*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[k1,k2]*sp[k3,
      k4]^2*m^2 - 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 192*sp[k1
      ,k2]*sp[k3,q]^2 - 80*sp[k1,k2]*sp[k3,q]^2*m + 8*sp[k1,k2]*sp[k3,q
      ]^2*m^2 + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4]*m - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*
      sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 512*sp[k1,k3]*sp[k2,k3] - 320*sp[
      k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k2,k3]*m^2 - 704*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 368*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 48*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[
      k1,k3]*sp[k2,k4]^2*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 32*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 
      80*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,
      k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,k3]*sp[k2,k4]
      *sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,k3]*
      sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m + 96*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4]*m^2 - 192*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 80*sp[k1,k3]
      *sp[k2,q]*sp[k3,q]*m - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 96*sp[
      k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m + 96*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 
      48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
      *m - 192*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q]*m^2 - 96*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q
      ]^2*sp[k2,k3]*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 16*sp[k1
      ,q]*sp[k2,k3]*sp[k2,q]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 - 192*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 80*sp[k1,q]*sp[k2,k3]*sp[
      k3,q]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[13,8]*color[
       - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]^2*den[
      sp[k4 - q]]*num[ - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 
      128*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 128*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k3]*sp[k2,
      k3]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4
      ]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,k3
      ]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 64*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m^2] + amp[13,9]*color[ - 1/2*Ca*Cf*Na*
      Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[
       - k2 + q]]*den[sp[k4 - q]]*num[32*sp[k1,k2]^2 - 32*sp[k1,k2]^2*
      sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q]
       + 16*sp[k1,k2]^2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1
      ,k2]*sp[k1,k3] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 
      96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 80*sp[k1,k2]*sp[k1
      ,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 96*sp[k1,
      k2]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 192*sp[k1,k2]*sp[k1,q]*sp[k2,q] + 
      64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 256*sp[k1,k2]*sp[k1,q]*
      sp[k3,q] + 144*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1
      ,q]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4] - 96*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4] + 80*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 
      16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k4,
      q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 48*sp[k1,k2
      ]*sp[k2,q]*sp[k4,q]*m + 272*sp[k1,k2]*sp[k3,k4] - 104*sp[k1,k2]*
      sp[k3,k4]*m + 8*sp[k1,k2]*sp[k3,k4]*m^2 + 192*sp[k1,k2]*sp[k3,k4]
      *sp[k4,q] - 112*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m^2 - 448*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 224*sp[k1
      ,k2]*sp[k3,q]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 
      64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
      *m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[
      k1,q]*sp[k2,q] - 80*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,q]*m^2 - 240*sp[k1,k3]*sp[k2,k4] + 104*sp[k1,k3]*
      sp[k2,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]^
      2 - 80*sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 
      16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ]*m^2 - 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 80*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 320*sp[k1,k3]*
      sp[k2,q]*sp[k4,q] - 176*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m^2 + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 8
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 144*sp[k1,k4]*sp[k2,k3] + 72*
      sp[k1,k4]*sp[k2,k3]*m - 8*sp[k1,k4]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 160*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 160*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 
      224*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q]*m + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k4]*sp[k2,q
      ]^2 - 48*sp[k1,k4]*sp[k2,q]^2*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       + 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,q]*sp[k3
      ,k4]*m^2 + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q]*m + 192*sp[k1,q]^2*sp[k2,k3] - 112*sp[k1,q]^2*sp[k2,k3
      ]*m + 16*sp[k1,q]^2*sp[k2,k3]*m^2 + 32*sp[k1,q]*sp[k2,k3]*sp[k2,
      k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] - 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k4]^2 + 32*sp[k1,q]*sp[k2,k4
      ]^2*m - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k4]*
      sp[k2,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4]*m + 192*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 80*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 256*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m - 
      8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[13,10]*color[1/4*Ca^2*Na
      *Tf]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k3 + q]]*den[
      sp[k4 - q]]*num[16*sp[k1,k2]^2 + 16*sp[k1,k2]^2*sp[k3,k4] + 16*
      sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]*sp[
      k1,k3] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,
      k2]*sp[k1,k3]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 48*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 160*sp[k1,
      k2]*sp[k1,q]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m - 16*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 96
      *sp[k1,k2]*sp[k1,q]*sp[k3,q] + 40*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4
      ,q]*m + 16*sp[k1,k2]*sp[k2,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]
       - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] + 48*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,
      k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 40*sp[k1,
      k2]*sp[k2,q]*sp[k4,q]*m + 184*sp[k1,k2]*sp[k3,k4] - 60*sp[k1,k2]*
      sp[k3,k4]*m + 4*sp[k1,k2]*sp[k3,k4]*m^2 + 144*sp[k1,k2]*sp[k3,k4]
      ^2 - 96*sp[k1,k2]*sp[k3,k4]^2*m + 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 
      24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ]*m^2 + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]
      *sp[k4,q]*m^2 - 224*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 72*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m - 48*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*
      sp[k2,k4]*m - 48*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m
       + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 112*sp[k1,k3]*sp[k1,q
      ]*sp[k2,k3] - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 8*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 24*sp[k1,k3]
      *sp[k1,q]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q]*m - 168*sp[k1,k3]*sp[k2,k4] + 60*sp[k1,k3
      ]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*m^2 - 48*sp[k1,k3]*sp[k2,k4
      ]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
      *m - 144*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 96*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 48*sp[k1,k3]
      *sp[k2,k4]*sp[k3,q] - 40*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      40*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q
      ]*m^2 - 48*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 32*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 40*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3]*m - 120*sp[k1,k4]*sp[k2,k3] + 60*sp[k1,k4]*
      sp[k2,k3]*m - 4*sp[k1,k4]*sp[k2,k3]*m^2 + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m - 176*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 112*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 
      64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,
      k3]*sp[k4,q]*m^2 + 112*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k4
      ]*sp[k2,k4]*sp[k2,q]*m + 80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,q]^2 - 56*sp[k1
      ,k4]*sp[k2,q]^2*m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 56*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,q]^2*sp[k2,k3] - 56*sp[k1,
      q]^2*sp[k2,k3]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 16*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 
      56*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,q]*sp[k2,k4]^2 + 16*
      sp[k1,q]*sp[k2,k4]^2*m - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 24*sp[
      k1,q]*sp[k2,k4]*sp[k2,q]*m - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 16
      *sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]
       - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 192*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4] + 56*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[13,11]*color[1/2*
      Ca*Cf*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]^2*den[sp[k4 - q]
      ]*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 64*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 16*sp[
      k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*sp[k2,k3] + 64*sp[k1
      ,k3]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k2,k3]*m^2 - 64*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 64*sp[k1,q]*
      sp[k2,k3]*sp[k3,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,
      q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[13,12]*color[1/2*Ca*Cf*Na*Tf - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - k2 - 
      k4]]*den[sp[k4 - q]]*num[ - 32*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,
      k2]^2*sp[k3,k4]*m - 32*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[
      k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]
      *sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 48*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k3]*m + 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 64*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 144*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 - 32*sp[k1,k2]
      *sp[k1,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 96*sp[
      k1,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 
      32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
      *m - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 80*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4]*m - 8*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[
      k2,k3] - 16*sp[k1,k2]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,
      q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k2,k4]
       + 32*sp[k1,k2]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 
      32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k2,k4]
      *sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m + 96*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 80*sp[k1,k2]
      *sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m^2 + 96*
      sp[k1,k2]*sp[k2,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 
      128*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3,k4]*m - 8*sp[k1,k2]*
      sp[k3,k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 224*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 192*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] + 80*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 16*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 48*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*
      m^2 + 32*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1
      ,k3]*sp[k2,k4]*m^2 - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 8*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 320*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      176*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 24*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 - 96*sp[k1,k3]*sp[k2,q]^2 + 80*sp[k1,k3]*sp[k2,q]^2*m - 
      16*sp[k1,k3]*sp[k2,q]^2*m^2 - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 80
      *sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 - 192*sp[k1,k4]^2*sp[k2,k3] + 112*sp[k1,k4]^2*sp[k2,k3]*m - 
      16*sp[k1,k4]^2*sp[k2,k3]*m^2 - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 160*sp[k1,k4]*sp[k2,k3]
       - 80*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k4]*sp[k2,k3]*m^2 - 32*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 
      192*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 112*sp[k1,k4]*sp[k2,k3]*sp[k4,
      q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,
      k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 256*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,k4]*sp[k2,q]^2 + 32*sp[k1,
      k4]*sp[k2,q]^2*m + 192*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 80*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 96*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 
      96*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
      *m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,
      k3]*sp[k2,q]*m^2 - 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 160*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 128*
      sp[k1,q]*sp[k2,k4]^2 - 48*sp[k1,q]*sp[k2,k4]^2*m + 160*sp[k1,q]*
      sp[k2,k4]*sp[k2,q] - 64*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 128*sp[k1
      ,q]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 64*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 
      8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 224*sp[k1,q]*sp[k2,q]*sp[k3,
      k4] - 112*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 8*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^2] + amp[13,13]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 - q]]
      *den[sp[ - k2 - k3]]*den[sp[ - k3 - k4]]*den[sp[k4 - q]]*num[16*
      sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*
      sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,
      k3]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[k3,k4]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      48*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 160*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 96*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4] - 40*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 16*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 48
      *sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m
       - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3] + 16*sp[k1,k2]*sp[k2,k3]*m
       - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4
      ,q]*m - 80*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m + 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       - 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k4
      ,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]*
      sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 48*sp[k1,k2]*sp[k2,
      q]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k2]*sp[
      k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,
      q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 224*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] + 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 144*sp[k1,k2]*
      sp[k3,q]^2 + 96*sp[k1,k2]*sp[k3,q]^2*m - 16*sp[k1,k2]*sp[k3,q]^2*
      m^2 + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m^2 - 48*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m
       - 48*sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m + 112*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k3] - 48*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m
       + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 24*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,
      q]*sp[k2,k3] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m - 80*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k3]*sp[k2,
      k3]*m - 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[k2,k4]*m + 8
      *sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2
      ,q]^2 - 16*sp[k1,k3]*sp[k2,q]^2*m - 48*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] + 40*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2 + 144*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 96*sp[k1,k3]*
      sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 48*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 40*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 8*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]^2*sp[k2,k3] + 56*
      sp[k1,k4]^2*sp[k2,k3]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 40*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k2,k3] - 16*sp[
      k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]
       - 56*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[
      k2,q] + 24*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q] + 56*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 48*sp[k1,k4]*
      sp[k2,q]^2 + 16*sp[k1,k4]*sp[k2,q]^2*m + 128*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 48*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] - 40*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[
      k1,q]*sp[k2,k3]*sp[k2,q] + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 8*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 + 176*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 112*sp[k1,q]*sp[k2,k3]*
      sp[k3,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[
      k2,k3]*sp[k4,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,q]*sp[k2,k4]^2 - 56*sp[k1,q]*
      sp[k2,k4]^2*m + 112*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,q]*sp[
      k2,k4]*sp[k2,q]*m + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 56*sp[k1,q
      ]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[13,14]*color[ - Ca*Cf*Na*Tf]
      *den[sp[ - k2 - k3]]^2*den[sp[ - k4 + q]]*den[sp[k4 - q]]*num[256
      *sp[k1,k3]*sp[k2,k3] - 224*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*
      sp[k2,k3]*m^2 - 352*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 272*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 192*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
      *m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k3
      ]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 
      192*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 128*sp[k1,q]*sp[k2,k3]*sp[k3,q]
      *m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2] + amp[14,1]*color[ - 
      Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k2]]*den[sp[k3 + k4]]
      *num[24*sp[k1,k2]*sp[k1,k3] - 12*sp[k1,k2]*sp[k1,k3]*m + 24*sp[k1
      ,k2]*sp[k1,k4] - 12*sp[k1,k2]*sp[k1,k4]*m + 24*sp[k1,k2]*sp[k2,k3
      ] - 12*sp[k1,k2]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k2,k4] - 12*sp[k1,
      k2]*sp[k2,k4]*m - 96*sp[k1,k2]*sp[k3,k4] + 48*sp[k1,k2]*sp[k3,k4]
      *m - 12*sp[k1,k2]*sp[k3,q] + 12*sp[k1,k2]*sp[k3,q]*m - 12*sp[k1,
      k2]*sp[k4,q] + 12*sp[k1,k2]*sp[k4,q]*m + 48*sp[k1,k3]*sp[k2,k3]
       - 24*sp[k1,k3]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,
      k3]*sp[k2,k4]*m + 12*sp[k1,k3]*sp[k2,q] - 12*sp[k1,k3]*sp[k2,q]*m
       + 48*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m + 48*sp[k1,
      k4]*sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k4]*m + 12*sp[k1,k4]*sp[k2,q]
       - 12*sp[k1,k4]*sp[k2,q]*m + 12*sp[k1,q]*sp[k2,k3] - 12*sp[k1,q]*
      sp[k2,k3]*m + 12*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4]*m] + 
      amp[14,1]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1
       + k2]]*den[sp[k3 + k4]]*num[32*sp[k1,k2]*sp[k1,k3] - 24*sp[k1,k2
      ]*sp[k1,k3]*m + 4*sp[k1,k2]*sp[k1,k3]*m^2 - 8*sp[k1,k2]*sp[k1,k4]
       + 12*sp[k1,k2]*sp[k1,k4]*m - 4*sp[k1,k2]*sp[k1,k4]*m^2 + 32*sp[
      k1,k2]*sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*m + 4*sp[k1,k2]*sp[k2,
      k3]*m^2 - 8*sp[k1,k2]*sp[k2,k4] + 12*sp[k1,k2]*sp[k2,k4]*m - 4*
      sp[k1,k2]*sp[k2,k4]*m^2 - 48*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*
      sp[k3,k4]*m + 20*sp[k1,k2]*sp[k3,q] - 16*sp[k1,k2]*sp[k3,q]*m + 4
      *sp[k1,k2]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k4,q] + 28*sp[k1,k2]*
      sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 + 24*sp[k1,k3]*sp[k2,k3] - 
      8*sp[k1,k3]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[k2,k4] - 12*sp[k1,k3]*
      sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,q] + 24*sp[k1,k4]*sp[k2,k3] - 12*
      sp[k1,k4]*sp[k2,k3]*m + 24*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]*sp[
      k2,k4]*m + 16*sp[k1,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,q]*m - 4*
      sp[k1,q]*sp[k2,k3] + 16*sp[k1,q]*sp[k2,k4] - 12*sp[k1,q]*sp[k2,k4
      ]*m] + amp[14,1]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k2]]*den[sp[k3 + k4]]*num[8*sp[k1,k2]*sp[k1,k3] - 12*sp[
      k1,k2]*sp[k1,k3]*m + 4*sp[k1,k2]*sp[k1,k3]*m^2 - 32*sp[k1,k2]*sp[
      k1,k4] + 24*sp[k1,k2]*sp[k1,k4]*m - 4*sp[k1,k2]*sp[k1,k4]*m^2 + 8
      *sp[k1,k2]*sp[k2,k3] - 12*sp[k1,k2]*sp[k2,k3]*m + 4*sp[k1,k2]*sp[
      k2,k3]*m^2 - 32*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m - 
      4*sp[k1,k2]*sp[k2,k4]*m^2 + 48*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]
      *sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,q] - 28*sp[k1,k2]*sp[k3,q]*m + 
      4*sp[k1,k2]*sp[k3,q]*m^2 - 20*sp[k1,k2]*sp[k4,q] + 16*sp[k1,k2]*
      sp[k4,q]*m - 4*sp[k1,k2]*sp[k4,q]*m^2 - 24*sp[k1,k3]*sp[k2,k3] + 
      16*sp[k1,k3]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[k2,k4] + 12*sp[k1,k3]*
      sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,q]*m - 
      24*sp[k1,k4]*sp[k2,k3] + 12*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,k4]*
      sp[k2,k4] + 8*sp[k1,k4]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k2,q] - 16*
      sp[k1,q]*sp[k2,k3] + 12*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,q]*sp[k2,
      k4]] + amp[14,2]*color[ - Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[
      k1 + k2]]*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[304*sp[k1,k2]^
      2*sp[k3,k4] - 112*sp[k1,k2]^2*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k3
      ]^2 + 32*sp[k1,k2]*sp[k1,k3]^2*m - 4*sp[k1,k2]*sp[k1,k3]^2*m^2 - 
      48*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k1,k4
      ]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m^2 - 192*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k3] + 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 8*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3]*m^2 - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 8*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
      *m^2 - 104*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 48*sp[k1,k2]*sp[k1,k3]
      *sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 48*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 8*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 48*sp[k1,k2]*sp[k1,k4]^2 + 32*
      sp[k1,k2]*sp[k1,k4]^2*m - 4*sp[k1,k2]*sp[k1,k4]^2*m^2 - 96*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 8*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m^2 - 192*sp[k1,k2]*sp[k1,k4]*sp[k2
      ,k4] + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 8*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k4]*m^2 - 104*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 48*sp[k1,k2]
      *sp[k1,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 8*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2
       - 96*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k4
      ,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 48*sp[k1,k2]*
      sp[k2,k3]^2 + 32*sp[k1,k2]*sp[k2,k3]^2*m - 4*sp[k1,k2]*sp[k2,k3]^
      2*m^2 - 48*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 8*sp[k1,k2]*sp[k2,k3]*
      sp[k2,k4]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m^2 - 104*sp[k1,k2]
      *sp[k2,k3]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 96*
      sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m
       - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 48*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m^2 - 48*sp[k1,k2]*sp[k2,k4]^2 + 32*sp[k1,k2]*sp[k2,
      k4]^2*m - 4*sp[k1,k2]*sp[k2,k4]^2*m^2 - 104*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 48*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m^2 - 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 64*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4]*m + 152*sp[k1,k2]*sp[k3,k4] - 56*sp[k1,k2]*sp[k3,k4]*m + 208
      *sp[k1,k2]*sp[k3,k4]^2 - 96*sp[k1,k2]*sp[k3,k4]^2*m + 40*sp[k1,k2
      ]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 40*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 
      96*sp[k1,k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,k2]
      *sp[k3,q]^2*m^2 - 96*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 8*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 96*sp[
      k1,k2]*sp[k4,q]^2 + 40*sp[k1,k2]*sp[k4,q]^2*m - 4*sp[k1,k2]*sp[k4
      ,q]^2*m^2 - 24*sp[k1,k3]^2*sp[k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m
       + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k3]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]
      *sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] + 64*
      sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 24*sp[k1,k3]*sp[k2,k4]^2 + 16*
      sp[k1,k3]*sp[k2,k4]^2*m - 80*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 32*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       + 48*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 48*sp[k1,k3]*sp[k2,q]*sp[
      k3,q] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 24*sp[k1,k3]*sp[k2,q]*
      sp[k4,q] + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k4]^2*sp[k2
      ,k3] + 16*sp[k1,k4]^2*sp[k2,k3]*m - 24*sp[k1,k4]*sp[k2,k3]^2 + 16
      *sp[k1,k4]*sp[k2,k3]^2*m + 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k4]*sp[k2,k3]*sp[k3,k4
      ] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 128*sp[k1,k4]*sp[k2,k4]*
      sp[k3,k4] + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] + 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 48*sp[k1,
      k4]*sp[k2,q]*sp[k4,q] - 8*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 40*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] + 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 
      48*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m
       + 24*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]
      *m - 40*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 48*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m + 48*sp[k1,q]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,q]*sp[k2,k4
      ]*sp[k4,q]*m - 176*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m] + amp[14,3]*color[ - 1/2*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 + k2]]*den[sp[ - k3 + q]]*den[sp[k3 + k4]]
      *num[ - 104*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 
      104*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 208*sp[k1,
      k2]^2*sp[k4,q] - 64*sp[k1,k2]^2*sp[k4,q]*m - 24*sp[k1,k2]*sp[k1,
      k3] + 12*sp[k1,k2]*sp[k1,k3]*m + 56*sp[k1,k2]*sp[k1,k3]^2 - 28*
      sp[k1,k2]*sp[k1,k3]^2*m + 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 20*
      sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,q]
       + 20*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m + 224*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] - 56*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] - 20*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 80*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q] + 20*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 8*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q
      ]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m - 48*sp[k1,k2]*sp[k1,k4] + 24*sp[k1,k2]*sp[k1,k4]*m - 
      80*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,k4]*sp[k1,q]
      *m + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m - 160*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 8*sp[k1,k2
      ]*sp[k1,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3] + 20*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 160*sp[k1,k2]*sp[k1,
      q]*sp[k2,k4] + 40*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1
      ,k2]*sp[k1,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[
      k1,k2]*sp[k1,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m - 24*
      sp[k1,k2]*sp[k2,k3] + 12*sp[k1,k2]*sp[k2,k3]*m + 56*sp[k1,k2]*sp[
      k2,k3]^2 - 28*sp[k1,k2]*sp[k2,k3]^2*m + 40*sp[k1,k2]*sp[k2,k3]*
      sp[k2,k4] - 20*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 40*sp[k1,k2]*sp[
      k2,k3]*sp[k2,q] + 20*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 8*sp[k1,k2]
      *sp[k2,k3]*sp[k3,k4] + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q] - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 48*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m - 80*sp[k1,
      k2]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m
       + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*
      sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k2,q]*sp[k4,q]*m - 40*sp[k1,k2]*sp[k3,k4] + 8*sp[k1,k2]*
      sp[k3,k4]*m - 52*sp[k1,k2]*sp[k3,k4]^2 + 28*sp[k1,k2]*sp[k3,k4]^2
      *m - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 72*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q] - 8*sp[k1,k2]*sp[k3,q]*m - 52
      *sp[k1,k2]*sp[k3,q]^2 + 28*sp[k1,k2]*sp[k3,q]^2*m + 72*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k4,q] - 16*sp[k1,k2]*sp[k4,q]*m + 88*sp[k1,k2]*sp[k4,q]^2
       - 40*sp[k1,k2]*sp[k4,q]^2*m - 24*sp[k1,k3]^2*sp[k2,k4] + 12*sp[
      k1,k3]^2*sp[k2,k4]*m + 24*sp[k1,k3]^2*sp[k2,q] - 12*sp[k1,k3]^2*
      sp[k2,q]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 12*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 4*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 4*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 
      12*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,q]*sp[k2
      ,q] - 4*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 24*sp[k1,k3]*sp[k2,k3] + 
      24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 12*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 12*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,k3]*sp[
      k2,k3]*sp[k3,k4]*m + 72*sp[k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,
      k3]*sp[k2,k3]*sp[k3,q]*m + 200*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 96*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4] - 8*sp[k1,
      k3]*sp[k2,k4]^2 + 4*sp[k1,k3]*sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 44*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q] - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 4*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,q] - 8*sp[k1,k3]
      *sp[k2,q]^2 + 4*sp[k1,k3]*sp[k2,q]^2*m - 4*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 44*sp[k1,k3]*sp[k2,q]
      *sp[k3,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] - 8*sp[k1,k4]^2*sp[k2,k3] + 4*sp[k1,k4]^2*sp[k2,k3]*m
       + 16*sp[k1,k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m - 16*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3] + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q]
      *m + 8*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]^2 + 12*sp[k1,
      k4]*sp[k2,k3]^2*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 4*sp[k1
      ,k4]*sp[k2,k3]*sp[k2,q]*m + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 24
      *sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q] + 32*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 
      8*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,
      k4] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,k4]
      *sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[
      k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k4
      ]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m
       + 52*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m - 52*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 72*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,
      q]*sp[k4,q]*m - 8*sp[k1,q]^2*sp[k2,k3] + 4*sp[k1,q]^2*sp[k2,k3]*m
       - 16*sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m + 8*sp[k1,q
      ]*sp[k2,k3] + 24*sp[k1,q]*sp[k2,k3]^2 - 12*sp[k1,q]*sp[k2,k3]^2*m
       + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ]*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 4*sp[k1,q]*sp[k2,k3]*sp[k2,
      q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 8*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4]*m + 44*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]
      *sp[k3,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,
      k4] + 16*sp[k1,q]*sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2,k4]^2*m + 16*sp[
      k1,q]*sp[k2,k4]*sp[k2,q] - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 52*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m
       - 52*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m - 72*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k4]*sp[
      k4,q]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m - 32*sp[k1,q]*sp[k2,q]*sp[k3,q] + 16*sp[k1,q]*sp[k2,q
      ]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,q]*sp[k4,q] + 32*sp[k1,q]*sp[k2,
      q]*sp[k4,q]*m] + amp[14,4]*color[1/2*Ca^2*Na*Tf]*den[sp[ - k1 - 
      k2]]*den[sp[k1 + k2]]*den[sp[k3 + k4]]*den[sp[ - k4 + q]]*num[104
      *sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*sp[k3,k4]*m - 208*sp[k1,
      k2]^2*sp[k3,q] + 64*sp[k1,k2]^2*sp[k3,q]*m - 104*sp[k1,k2]^2*sp[
      k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m + 48*sp[k1,k2]*sp[k1,k3] - 24*
      sp[k1,k2]*sp[k1,k3]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 20*sp[
      k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 
      40*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4] + 20*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 160*sp[k1,k2]*sp[k1,k3
      ]*sp[k2,q] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 32*sp[k1,
      k2]*sp[k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       + 24*sp[k1,k2]*sp[k1,k4] - 12*sp[k1,k2]*sp[k1,k4]*m - 56*sp[k1,
      k2]*sp[k1,k4]^2 + 28*sp[k1,k2]*sp[k1,k4]^2*m + 40*sp[k1,k2]*sp[k1
      ,k4]*sp[k1,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m - 80*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] + 20*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 224*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 56*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*
      m + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[
      k2,q]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 4*sp[k1,k2]*sp[k1,k4]
      *sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 4*sp[k1,k2]*
      sp[k1,k4]*sp[k4,q]*m + 160*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 40*sp[
      k1,k2]*sp[k1,q]*sp[k2,k3]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 
      20*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*
      sp[k3,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,
      q]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 48*sp[k1,k2]*sp[
      k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,
      k4] + 20*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k2,k3]
      *sp[k2,q] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[
      k2,k3]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,
      k2]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 32*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 24*sp[k1,k2]*sp[k2,k4] - 12*sp[k1,k2]*sp[k2,k4]*m - 56*sp[k1,
      k2]*sp[k2,k4]^2 + 28*sp[k1,k2]*sp[k2,k4]^2*m + 40*sp[k1,k2]*sp[k2
      ,k4]*sp[k2,q] - 20*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 8*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8
      *sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m
       - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,q]*
      sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,q
      ]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k3,k4] - 8*sp[k1,k2]*sp[k3,k4]*m
       + 52*sp[k1,k2]*sp[k3,k4]^2 - 28*sp[k1,k2]*sp[k3,k4]^2*m + 72*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      24*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
      *m - 16*sp[k1,k2]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,q]*m - 88*sp[k1,
      k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,q]^2*m - 72*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k4
      ,q] + 8*sp[k1,k2]*sp[k4,q]*m + 52*sp[k1,k2]*sp[k4,q]^2 - 28*sp[k1
      ,k2]*sp[k4,q]^2*m + 8*sp[k1,k3]^2*sp[k2,k4] - 4*sp[k1,k3]^2*sp[k2
      ,k4]*m - 16*sp[k1,k3]^2*sp[k2,q] + 8*sp[k1,k3]^2*sp[k2,q]*m - 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m
       - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 12*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]
      *sp[k2,q]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 8*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 8*sp[k1,
      k3]*sp[k1,q]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3] - 8*sp[k1,k3]*
      sp[k2,k3]*sp[k2,k4] + 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q] - 8*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32
      *sp[k1,k3]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]
      *m + 64*sp[k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[
      k3,q]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]^2
       - 12*sp[k1,k3]*sp[k2,k4]^2*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 
      4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,
      k4] + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q] + 4*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 8*sp[k1,k3]*sp[k2,k4]
      *sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,q]^2 - 8
      *sp[k1,k3]*sp[k2,q]^2*m - 52*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 16*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 72*sp[k1,k3]*sp[k2,q]*sp[k3,q]
       - 32*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m + 52*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,k4]^2*sp[k2,k3]
       - 12*sp[k1,k4]^2*sp[k2,k3]*m - 24*sp[k1,k4]^2*sp[k2,q] + 12*sp[
      k1,k4]^2*sp[k2,q]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3]*m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 12*sp[
      k1,k4]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 4*
      sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 8*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,
      k4]*sp[k2,k3]^2 - 4*sp[k1,k4]*sp[k2,k3]^2*m - 24*sp[k1,k4]*sp[k2,
      k3]*sp[k2,k4] + 12*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q] - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 44*sp[k1
      ,k4]*sp[k2,k3]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4
      *sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 
      8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k4]*sp[k2,k4] + 24*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 12*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       + 72*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[
      k3,k4]*m - 200*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q]*m - 72*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*
      sp[k2,k4]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,q] + 8*sp[k1,k4]*sp[k2,q
      ]^2 - 4*sp[k1,k4]*sp[k2,q]^2*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       + 8*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,
      q] - 44*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k4]*sp[k2,q]*sp[k4
      ,q]*m + 16*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]^2*sp[k2,k3]*m + 8*
      sp[k1,q]^2*sp[k2,k4] - 4*sp[k1,q]^2*sp[k2,k4]*m - 16*sp[k1,q]*sp[
      k2,k3] - 16*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 8*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m
       - 16*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 8*sp[k1,q]*sp[k2,k3]*sp[k2,q]
      *m - 52*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4]*m + 72*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,q]*sp[k2,k3]
      *sp[k3,q]*m + 52*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 8*sp[k1,q]*sp[k2,k4] - 24*sp[k1,q]*sp[k2,k4]^2
       + 12*sp[k1,q]*sp[k2,k4]^2*m - 8*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 4*
      sp[k1,q]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 
      8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]
       - 44*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q
      ]*m - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,q] - 32*sp[k1,q]*sp[k2,q]*sp[
      k3,q]*m + 32*sp[k1,q]*sp[k2,q]*sp[k4,q] - 16*sp[k1,q]*sp[k2,q]*
      sp[k4,q]*m] + amp[14,6]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]
      *den[sp[k1 + k3]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[ - 32*
      sp[k1,k2]^2*sp[k1,k3] + 16*sp[k1,k2]^2*sp[k1,k3]*m - 64*sp[k1,k2]
      ^2*sp[k1,k4] + 32*sp[k1,k2]^2*sp[k1,k4]*m - 80*sp[k1,k2]^2*sp[k3,
      k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,q]*m - 8*
      sp[k1,k2]^2*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 16*sp[k1,k2]*
      sp[k1,k3]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k1,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 144*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 32
      *sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
       + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[
      k3,q]*m^2 - 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k1
      ,k3]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,k4] + 32*sp[k1,k2]*sp[k1,k4]
      *m + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k1,q]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 24*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 
      24*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k3,q
      ]*m^2 - 80*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k1,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[
      k3,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 24*sp[k1,k2]*sp[k3,k4] + 12*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 64*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       - 32*sp[k1,k2]*sp[k3,q]^2 + 24*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,
      k2]*sp[k3,q]^2*m^2 + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 24*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*
      sp[k1,k3]^2*sp[k2,q] + 8*sp[k1,k3]^2*sp[k2,q]*m - 4*sp[k1,k3]^2*
      sp[k2,q]*m^2 + 176*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 72*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 24*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*
      m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m + 96*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,q]
      *sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 8*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 24*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 
      112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ]*m + 56*sp[k1,k3]*sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4]*m - 64*sp[
      k1,k3]*sp[k2,k4]^2 + 24*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] - 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 144*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 
      48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 80*sp[
      k1,k4]^2*sp[k2,q] - 32*sp[k1,k4]^2*sp[k2,q]*m - 128*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3]*m^2 - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 96*
      sp[k1,k4]*sp[k1,q]*sp[k2,q] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 
      56*sp[k1,k4]*sp[k2,k3] + 20*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k4]*
      sp[k2,k3]^2 - 8*sp[k1,k4]*sp[k2,k3]^2*m + 64*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 144*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 
      80*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m + 80*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m - 64*sp[k1,q]^2*sp[k2,k3] + 16*sp[k1,q]^2*sp[k2,k3]*m
       - 32*sp[k1,q]^2*sp[k2,k4] + 8*sp[k1,q]^2*sp[k2,k4]*m - 8*sp[k1,q
      ]*sp[k2,k3]^2*m + 4*sp[k1,q]*sp[k2,k3]^2*m^2 + 8*sp[k1,q]*sp[k2,
      k3]*sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q
      ]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 32*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 
      4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 32*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,q]*sp[
      k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[14,7]*
      color[ - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k3]]*den[
      sp[k3 + k4]]*den[sp[ - k4 + q]]*num[ - 40*sp[k1,k2]^2*sp[k3,k4]
       + 16*sp[k1,k2]^2*sp[k3,k4]*m + 104*sp[k1,k2]^2*sp[k3,q] - 32*sp[
      k1,k2]^2*sp[k3,q]*m + 40*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*
      sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k3] + 24*sp[k1,k2]*sp[k1,k3]*m + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,
      k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 40*sp[k1,k2]*sp[k1,k3]*
      sp[k1,q]*m + 56*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m - 88*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 24*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 40*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,
      k4] + 48*sp[k1,k2]*sp[k1,k4]*m + 80*sp[k1,k2]*sp[k1,k4]^2 - 40*
      sp[k1,k2]*sp[k1,k4]^2*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       - 8*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 112*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] - 40*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 104*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 104*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] + 36*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       + 136*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 20*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8*sp[k1,k2]*sp[k1,k4]
      *sp[k4,q]*m - 72*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4]*m - 136*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 40*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,q]*sp[k4
      ,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q]*m + 40*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4] - 8*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 40*sp[
      k1,k2]*sp[k2,k4]*sp[k3,k4] - 12*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m
       + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 12*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 60*sp[k1,k2]*sp[k3,k4] + 24*sp[k1,k2]*sp[k3,k4]*m
       - 160*sp[k1,k2]*sp[k3,k4]^2 + 68*sp[k1,k2]*sp[k3,k4]^2*m + 32*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m
       + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 4*sp[k1,k2]*sp[k3,k4]*sp[k4,
      q]*m + 72*sp[k1,k2]*sp[k3,q]^2 - 28*sp[k1,k2]*sp[k3,q]^2*m + 48*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 20*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 
      32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^2*sp[k2,k4]*m + 80*sp[k1,
      k3]^2*sp[k2,q] - 32*sp[k1,k3]^2*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 24*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4] - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 48*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
      *m + 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 48*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m + 64*sp[k1,k3]*sp[k1,q]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,q]
      *sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3] + 56*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 32*sp[k1,k3]*
      sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[
      k1,k3]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m - 
      16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
      *m + 76*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m - 72*sp[k1
      ,k3]*sp[k2,k4]^2 + 28*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 20*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 112*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4] - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 12
      *sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       + 12*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 12*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 56*sp[k1,k3]*sp[k2,q
      ]*sp[k3,q] + 20*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 120*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 44*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 120*sp[k1,k4]
      ^2*sp[k2,k3] - 44*sp[k1,k4]^2*sp[k2,k3]*m + 80*sp[k1,k4]^2*sp[k2,
      k4] - 32*sp[k1,k4]^2*sp[k2,k4]*m + 16*sp[k1,k4]^2*sp[k2,q] - 32*
      sp[k1,k4]^2*sp[k2,q]*m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 104*sp[k1,k4]*sp[k1,q]*sp[k2,
      q] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 68*sp[k1,k4]*sp[k2,k3] + 
      24*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4
      ]*sp[k2,k3]^2*m + 72*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 28*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4]*m - 56*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 24*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 
      36*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] + 36*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k4,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,k4]*sp[
      k2,k4]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m + 24*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       + 56*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m - 24*sp[k1,q]^2*sp[k2,k4] - 56*sp[k1,q]*sp[k2,k3]^2 + 16*sp[
      k1,q]*sp[k2,k3]^2*m + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 4*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 36*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m - 40*sp[k1,q]*sp[k2,k3]*sp[k3,q] + 12
      *sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 12*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,q]*sp[k2,k4]*sp[k3
      ,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] + 48*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m] + amp[14,9]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*
      den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*num[64*sp[k1
      ,k2]^2*sp[k1,k3] - 32*sp[k1,k2]^2*sp[k1,k3]*m + 32*sp[k1,k2]^2*
      sp[k1,k4] - 16*sp[k1,k2]^2*sp[k1,k4]*m + 80*sp[k1,k2]^2*sp[k3,k4]
       - 16*sp[k1,k2]^2*sp[k3,k4]*m + 8*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[
      k1,k2]^2*sp[k4,q]*m + 80*sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1
      ,k3]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 32*sp[k1,k2]*sp[k1,k3]
      *sp[k1,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k3]*m - 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 24*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q] + 24*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,k3]
      *sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k1,k4] - 16*sp[k1,k2]*sp[k1,k4]*m
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k1,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k1
      ,q]*m - 144*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q] + 192*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 24*
      sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*
      m^2 - 8*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*
      sp[k2,k4]*m - 80*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 8*sp[k1,k2]*
      sp[k1,q]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,
      k2]*sp[k1,q]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 8*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*
      m^2 - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4]*m + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[
      k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 + 16*sp[k1
      ,k2]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 24*
      sp[k1,k2]*sp[k3,k4] - 12*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 32*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 
      4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k4,q]^2 - 24*
      sp[k1,k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 - 80*sp[k1,k3
      ]^2*sp[k2,q] + 32*sp[k1,k3]^2*sp[k2,q]*m - 176*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q] + 72*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m^2 + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 128*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4] - 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,q]
       + 40*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] + 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k3]*sp[k2,
      k3]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 56*sp[k1,k3]*
      sp[k2,k4] - 20*sp[k1,k3]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k4]^2
       + 8*sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 
      16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 144*sp[k1,k3]*sp[k2,k4]*sp[k3
      ,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 32*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q] - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 80*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k3]*
      sp[k2,q]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,
      k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m + 4*sp[k1,k4]^2*sp[k2,q
      ]*m^2 - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 24*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,q] + 32*sp[k1,
      k4]*sp[k1,q]*sp[k2,q]*m - 56*sp[k1,k4]*sp[k2,k3] + 20*sp[k1,k4]*
      sp[k2,k3]*m + 64*sp[k1,k4]*sp[k2,k3]^2 - 24*sp[k1,k4]*sp[k2,k3]^2
      *m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 144*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 24*sp[k1,k4]*sp[k2,k4]*sp[k2
      ,q]*m + 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 112*sp[k1,k4]*sp[k2,
      k4]*sp[k3,q] - 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,q]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 + 
      32*sp[k1,q]^2*sp[k2,k3] - 8*sp[k1,q]^2*sp[k2,k3]*m + 64*sp[k1,q]^
      2*sp[k2,k4] - 16*sp[k1,q]^2*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4] - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 8*
      sp[k1,q]*sp[k2,k4]^2*m - 4*sp[k1,q]*sp[k2,k4]^2*m^2 - 96*sp[k1,q]
      *sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 
      32*sp[k1,q]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m
       - 4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[14,10]*color[1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 + k4]]*den[sp[ - k3 + q]]*
      den[sp[k3 + k4]]*num[40*sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*
      sp[k3,k4]*m - 40*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m
       - 104*sp[k1,k2]^2*sp[k4,q] + 32*sp[k1,k2]^2*sp[k4,q]*m + 128*sp[
      k1,k2]*sp[k1,k3] - 48*sp[k1,k2]*sp[k1,k3]*m - 80*sp[k1,k2]*sp[k1,
      k3]^2 + 40*sp[k1,k2]*sp[k1,k3]^2*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k1
      ,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 112*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3] + 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 24*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 
      104*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q
      ]*m + 104*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 36*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] - 8*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,q]*m - 136*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 20*sp[k1,k2]
      *sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4] - 24*sp[k1,k2]*sp[
      k1,k4]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 40*sp[k1,k2]*sp[k1,
      k4]*sp[k1,q]*m - 56*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3]*m + 88*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 24*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 
      16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k1
      ,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 72*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 136*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] - 40*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 
      88*sp[k1,k2]*sp[k1,q]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m
       - 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,q]*sp[k4,q
      ]*m - 40*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 12*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 12*sp[k1,k2]*sp[
      k2,k3]*sp[k4,q]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 8*sp[k1,k2
      ]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,k4]*sp[k4,q]
       + 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4] - 24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 60*sp[k1,k2]*sp[k3,
      k4] - 24*sp[k1,k2]*sp[k3,k4]*m + 160*sp[k1,k2]*sp[k3,k4]^2 - 68*
      sp[k1,k2]*sp[k3,k4]^2*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 4*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 8
      *sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       + 20*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 72*sp[k1,k2]*sp[k4,q]^2 + 
      28*sp[k1,k2]*sp[k4,q]^2*m - 80*sp[k1,k3]^2*sp[k2,k3] + 32*sp[k1,
      k3]^2*sp[k2,k3]*m - 120*sp[k1,k3]^2*sp[k2,k4] + 44*sp[k1,k3]^2*
      sp[k2,k4]*m - 16*sp[k1,k3]^2*sp[k2,q] + 32*sp[k1,k3]^2*sp[k2,q]*m
       + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,k3]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 8*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k4]*m + 48*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 20*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k3]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 4*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m - 104*sp[k1,k3]*sp[k1,q]*sp[k2,q] + 
      32*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m - 72*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] + 28*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 80*sp[k1,k3]*sp[k2,k3]
      *sp[k3,k4] + 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m - 24*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 68*sp[k1
      ,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m + 56*sp[k1,k3]*sp[k2,k4
      ]^2 - 16*sp[k1,k3]*sp[k2,k4]^2*m + 56*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] - 24*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] + 36*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 112*sp[k1,k3
      ]*sp[k2,k4]*sp[k4,q] - 36*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 
      56*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       - 32*sp[k1,k4]^2*sp[k2,k3] + 8*sp[k1,k4]^2*sp[k2,k3]*m - 80*sp[
      k1,k4]^2*sp[k2,q] + 32*sp[k1,k4]^2*sp[k2,q]*m - 160*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3] + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 64*sp[
      k1,k4]*sp[k1,q]*sp[k2,q] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 76*
      sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 72*sp[k1,k4]*sp[
      k2,k3]^2 - 28*sp[k1,k4]*sp[k2,k3]^2*m - 56*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 48*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q] + 20*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 112*sp[k1,
      k4]*sp[k2,k3]*sp[k3,k4] + 44*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 40
      *sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m
       - 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,k4] - 
      56*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]
      *m - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4] + 16*sp[k1,k4]*sp[k2,k4]*
      sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,k4
      ]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 12*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4]*m + 120*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 
      44*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 56*sp[k1,k4]*sp[k2,q]*sp[k4,q]
       - 20*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m + 24*sp[k1,q]^2*sp[k2,k3] - 8
      *sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m
       - 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 56*sp[k1,q]*sp[k2,k4]^2
       - 16*sp[k1,q]*sp[k2,k4]^2*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 
      36*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ] + 12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 40*sp[k1,q]*sp[k2,k4]*sp[
      k4,q] - 12*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m - 48*sp[k1,q]*sp[k2,q]*
      sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[14,11]*color[
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k2
       - k3]]*den[sp[k3 + k4]]*num[ - 32*sp[k1,k2]^2*sp[k2,k3] + 16*sp[
      k1,k2]^2*sp[k2,k3]*m - 64*sp[k1,k2]^2*sp[k2,k4] + 32*sp[k1,k2]^2*
      sp[k2,k4]*m - 80*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]
      *m - 16*sp[k1,k2]^2*sp[k3,q]*m - 8*sp[k1,k2]^2*sp[k4,q]*m + 64*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 80*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 24*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 4*sp[k1,
      k2]*sp[k1,k3]*sp[k3,q]*m^2 - 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 
      144*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 48*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k4]
      *sp[k2,k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4] - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 
      32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
      *m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m - 64*sp[k1,k2]*sp[k2,k3] + 16*sp[k1,k2]*sp[k2,k3]*m + 32*
      sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m
       - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 192*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 80*sp[k1,k2]*
      sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[
      k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 48*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,q] - 24*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m^2 - 80*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,
      k2]*sp[k2,k4]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       - 16*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 24*sp[k1,k2]*sp[k3,k4] + 
      12*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k3,q]^2 + 
      24*sp[k1,k2]*sp[k3,q]^2*m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 + 32*sp[k1
      ,k2]*sp[k3,q]*sp[k4,q] - 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 4*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1
      ,k3]^2*sp[k2,k4]*m - 8*sp[k1,k3]^2*sp[k2,q]*m + 4*sp[k1,k3]^2*sp[
      k2,q]*m^2 - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 8*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 24*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 4*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
       + 24*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k3]*m^2 - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q
      ]*sp[k2,k4]*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q]*m^2 - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4] + 20*sp[
      k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 
      32*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m - 144*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q]*m - 64*sp[k1,k3]*sp[k2,q]^2 + 16*sp[k1,k3]*sp[k2,q]^2*m + 
      96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
      *m + 32*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k3
      ,q]*m + 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 + 16*sp[k1,k3]*sp[k2,q]
      *sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 64*sp[k1,k4]^2*
      sp[k2,k3] + 24*sp[k1,k4]^2*sp[k2,k3]*m + 48*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m^2 + 56*sp[k1,k4]*sp[k2,k3] - 20*sp[k1,k4]*sp[k2,
      k3]*m + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 144*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 80*sp[
      k1,k4]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 
      32*sp[k1,k4]*sp[k2,q]^2 + 8*sp[k1,k4]*sp[k2,q]^2*m - 96*sp[k1,k4]
      *sp[k2,q]*sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 32*sp[
      k1,k4]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*
      sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 4*sp[k1,q]*sp[
      k2,k3]^2*m^2 + 176*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 72*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*sp[
      k1,q]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 16*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m - 
      4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m^2 + 80*sp[k1,q]*sp[k2,k4]^2 - 32*sp[k1,q]*sp[k2,k4]^2*m + 
      96*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m
       + 80*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[14,12]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]
      ]*den[sp[k1 - q]]*den[sp[ - k2 - k4]]*den[sp[k3 + k4]]*num[64*sp[
      k1,k2]^2*sp[k2,k3] - 32*sp[k1,k2]^2*sp[k2,k3]*m + 32*sp[k1,k2]^2*
      sp[k2,k4] - 16*sp[k1,k2]^2*sp[k2,k4]*m + 80*sp[k1,k2]^2*sp[k3,k4]
       - 16*sp[k1,k2]^2*sp[k3,k4]*m + 8*sp[k1,k2]^2*sp[k3,q]*m + 16*sp[
      k1,k2]^2*sp[k4,q]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,k3]*m - 144*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 
      48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k2,
      q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 80*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 
      32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 24*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4]*m + 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3] - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 8*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,
      k2]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*
      sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 32*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,q]*m - 48*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 24*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*
      m^2 + 64*sp[k1,k2]*sp[k2,k4] - 16*sp[k1,k2]*sp[k2,k4]*m - 32*sp[
      k1,k2]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 
      192*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 24*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 - 80*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1
      ,k2]*sp[k2,q]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m - 64*sp[
      k1,k2]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 24*
      sp[k1,k2]*sp[k3,k4] - 12*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 32*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] + 24*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 
      4*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k4,q]^2 - 24*
      sp[k1,k2]*sp[k4,q]^2*m + 4*sp[k1,k2]*sp[k4,q]^2*m^2 + 64*sp[k1,k3
      ]^2*sp[k2,k4] - 24*sp[k1,k3]^2*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3] + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k4] - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 8*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2
       - 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 16*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q] - 80*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 56*sp[k1,k3]*sp[k2,k4] + 20*sp[k1,k3]*sp[k2,
      k4]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 24*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,q]*m - 144*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k3]
      *sp[k2,k4]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,q]^2 - 8*sp[k1,k3]*sp[
      k2,q]^2*m + 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,
      q]*sp[k3,k4]*m + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 8*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 32*sp[k1,k4]^2*sp[k2,k3] + 8*sp[k1,k4]^2*sp[k2
      ,k3]*m + 8*sp[k1,k4]^2*sp[k2,q]*m - 4*sp[k1,k4]^2*sp[k2,q]*m^2 + 
      16*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
      *m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k4]*sp[k1,q]*sp[
      k2,k4]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 + 56*sp[k1,k4]*sp[
      k2,k3] - 20*sp[k1,k4]*sp[k2,k3]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q] - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m^2 + 144*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 8*sp[k1,
      k4]*sp[k2,k3]*sp[k4,q]*m + 24*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 4*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 + 112*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q] - 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,q]^2
       - 16*sp[k1,k4]*sp[k2,q]^2*m - 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 
      24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 32*sp[k1,k4]*sp[k2,q]*
      sp[k4,q] + 24*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k4]*sp[k2,q
      ]*sp[k4,q]*m^2 - 80*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,q]*sp[k2,k3]^
      2*m - 176*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 72*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 96*sp[k1,q]*
      sp[k2,k3]*sp[k2,q] + 40*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 80*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 64*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 
      32*sp[k1,q]*sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2,k4]^2*m + 4*sp[k1,q]*
      sp[k2,k4]^2*m^2 - 96*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,q]*
      sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 64*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 4*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m^2 - 8*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 
      4*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[14,13]*color[1/2*Ca^2
      *Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[
      sp[k3 + k4]]*num[ - 176*sp[k1,k2]^2*sp[k3,k4] + 48*sp[k1,k2]^2*
      sp[k3,k4]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k3]*m + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4]*m + 104*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 
      48*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,q]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 12*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 48*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*
      m + 104*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 48*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m - 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m^2 - 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 4*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 
      64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,
      q]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 12*sp[k1,k2]*sp[k2,k3
      ]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 12*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 - 24*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*
      m^2 + 176*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 152*sp[k1,k2]*sp[k3,k4] + 56*sp[k1,k2]*sp[k3,k4]*m
       - 104*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k3,q]^2 - 40*sp[k1,k2]*sp[k3,q]^
      2*m + 4*sp[k1,k2]*sp[k3,q]^2*m^2 + 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ]*m^2 + 96*sp[k1,k2]*sp[k4,q]^2 - 40*sp[k1,k2]*sp[k4,q]^2*m + 4*
      sp[k1,k2]*sp[k4,q]^2*m^2 + 24*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3
      ]^2*sp[k2,k4]*m + 24*sp[k1,k3]^2*sp[k2,q]*m - 4*sp[k1,k3]^2*sp[k2
      ,q]*m^2 - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k4]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 8*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3
      ] - 40*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3]*m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 4*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 96*sp[k1,k3
      ]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 4*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 48*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m^2 - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k3,q] + 40*sp[k1,k3]
      *sp[k2,q]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m^2 - 48*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 4*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 4*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 24*sp[k1,k4]^2*sp[k2,k3] - 16*
      sp[k1,k4]^2*sp[k2,k3]*m + 24*sp[k1,k4]^2*sp[k2,q]*m - 4*sp[k1,k4]
      ^2*sp[k2,q]*m^2 + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 96*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m
       + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m^2 - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k4]
      *sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 40*sp[
      k1,k4]*sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2
       + 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m - 48*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 4*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 96*sp[k1,k4]*sp[k2,
      q]*sp[k4,q] + 40*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k4]*sp[
      k2,q]*sp[k4,q]*m^2 + 96*sp[k1,q]*sp[k2,k3]^2 - 40*sp[k1,q]*sp[k2,
      k3]^2*m + 4*sp[k1,q]*sp[k2,k3]^2*m^2 + 96*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 104*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m - 24*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 4*sp[
      k1,q]*sp[k2,k3]*sp[k3,q]*m^2 - 12*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       - 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 96*sp[k1,q]*sp[k2,k4]^2 - 
      40*sp[k1,q]*sp[k2,k4]^2*m + 4*sp[k1,q]*sp[k2,k4]^2*m^2 + 104*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 
      12*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 - 24*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2,k4]*sp[
      k4,q]*m^2 + 176*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[14,14]*color[1/4*Ca^2*Na*Tf]*den[sp[k1 + k2]
      ]*den[sp[ - k2 - k3]]*den[sp[k3 + k4]]*den[sp[ - k4 + q]]*num[40*
      sp[k1,k2]^2*sp[k3,k4] - 16*sp[k1,k2]^2*sp[k3,k4]*m - 104*sp[k1,k2
      ]^2*sp[k3,q] + 32*sp[k1,k2]^2*sp[k3,q]*m - 40*sp[k1,k2]^2*sp[k4,q
      ] + 16*sp[k1,k2]^2*sp[k4,q]*m - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 40*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,k4] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 88*sp[k1,k2]*
      sp[k1,k3]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 40*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 56*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m - 112*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 40*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4]*m - 24*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m - 40*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 12*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 12*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
       - 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 104*sp[k1,k2]*sp[k1,q]*sp[
      k2,k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 48*sp[k1,k2]*sp[k1,q
      ]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 64*sp[k1,k2]*
      sp[k2,k3] - 24*sp[k1,k2]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[
      k2,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 80*sp[k1,k2]*sp[k2,
      k3]*sp[k2,q] - 40*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k2]*
      sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 80*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 
      40*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
      *m + 128*sp[k1,k2]*sp[k2,k4] - 48*sp[k1,k2]*sp[k2,k4]*m - 80*sp[
      k1,k2]*sp[k2,k4]^2 + 40*sp[k1,k2]*sp[k2,k4]^2*m + 64*sp[k1,k2]*
      sp[k2,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 104*sp[
      k1,k2]*sp[k2,k4]*sp[k3,k4] - 36*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m
       - 136*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 20*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,k4]
      *sp[k4,q]*m + 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 40*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] + 16*sp[k1,k2]
      *sp[k2,q]*sp[k3,q]*m - 88*sp[k1,k2]*sp[k2,q]*sp[k4,q] + 32*sp[k1,
      k2]*sp[k2,q]*sp[k4,q]*m + 60*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*
      sp[k3,k4]*m + 160*sp[k1,k2]*sp[k3,k4]^2 - 68*sp[k1,k2]*sp[k3,k4]^
      2*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 8*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 4*sp[k1,k2]*sp[k3,k4]
      *sp[k4,q]*m - 72*sp[k1,k2]*sp[k3,q]^2 + 28*sp[k1,k2]*sp[k3,q]^2*m
       - 48*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 20*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ]*m + 56*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^2*sp[k2,k4]*m + 56*
      sp[k1,k3]^2*sp[k2,q] - 16*sp[k1,k3]^2*sp[k2,q]*m - 56*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 72*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4] + 28*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m
       - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q
      ]*m - 56*sp[k1,k3]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,q]*sp[
      k2,k3]*m + 56*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 24*sp[k1,k3]*sp[k1,q
      ]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3] + 16*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4] + 8*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[
      k2,k3]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32*sp[k1,k3
      ]*sp[k2,k3]*sp[k3,k4] + 16*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 64*
      sp[k1,k3]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,q]*m
       + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m + 68*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m - 120*
      sp[k1,k3]*sp[k2,k4]^2 + 44*sp[k1,k3]*sp[k2,k4]^2*m + 48*sp[k1,k3]
      *sp[k2,k4]*sp[k2,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 96*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,k4] + 36*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 
      112*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 36*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 4*sp[k1,k3]*sp[k2,k4]*sp[
      k4,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 36*sp[k1,k3]*sp[k2,q]
      *sp[k3,k4]*m + 40*sp[k1,k3]*sp[k2,q]*sp[k3,q] - 12*sp[k1,k3]*sp[
      k2,q]*sp[k3,q]*m - 40*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 12*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 72*sp[k1,k4]^2*sp[k2,k3] - 28*sp[k1,k4]^2*
      sp[k2,k3]*m - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 20*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 76*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,
      k3]*m - 32*sp[k1,k4]*sp[k2,k3]^2 + 8*sp[k1,k4]*sp[k2,k3]^2*m + 24
      *sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*
      m - 160*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 48*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 44*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m - 12*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 40*sp[k1,k4
      ]*sp[k2,k3]*sp[k4,q] - 12*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 80*sp[
      k1,k4]*sp[k2,k4]^2 + 32*sp[k1,k4]*sp[k2,k4]^2*m - 48*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 80*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*m - 
      24*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
      *m + 24*sp[k1,k4]*sp[k2,q]^2 - 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 
      16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ] - 80*sp[k1,q]*sp[k2,k3]^2 + 32*sp[k1,q]*sp[k2,k3]^2*m + 48*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] + 20*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 
      64*sp[k1,q]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m
       + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 12*sp[k1,q]*sp[k2,k3]*sp[k3,
      k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k3,q] - 20*sp[k1,q]*sp[k2,k3]*
      sp[k3,q]*m + 120*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 44*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 16*sp[k1,q]*sp[k2,k4]^2 + 32*sp[k1,q]*sp[k2,k4]^
      2*m - 104*sp[k1,q]*sp[k2,k4]*sp[k2,q] + 32*sp[k1,q]*sp[k2,k4]*sp[
      k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4]*m - 56*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q]*m - 48*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m] + amp[14,15]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k2]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*den[sp[k3 + 
      k4]]*num[ - 40*sp[k1,k2]^2*sp[k3,k4] + 16*sp[k1,k2]^2*sp[k3,k4]*m
       + 40*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m + 104*sp[
      k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 112*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k3] - 40*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 56*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 24
      *sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       + 40*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 12*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 12*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 8*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3]*m - 72*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 
      8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 40*sp[k1,k2]*sp[k1,k4]*sp[k3,
      q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 88*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 104*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 88*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 48*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 
      128*sp[k1,k2]*sp[k2,k3] + 48*sp[k1,k2]*sp[k2,k3]*m + 80*sp[k1,k2]
      *sp[k2,k3]^2 - 40*sp[k1,k2]*sp[k2,k3]^2*m + 64*sp[k1,k2]*sp[k2,k3
      ]*sp[k2,k4] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*
      sp[k2,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m - 104*sp[
      k1,k2]*sp[k2,k3]*sp[k3,k4] + 36*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,
      q]*m + 136*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 20*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4] + 24*sp[k1,k2]*sp[k2,k4]*m - 
      80*sp[k1,k2]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k2]*sp[k2,k4]*sp[k2,q]
      *m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4]*m - 40*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q]*m - 80*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k2
      ]*sp[k2,k4]*sp[k4,q]*m - 136*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 40*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 88*sp[k1,k2]*sp[k2,q]*sp[k3,q]
       - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k2,q]*sp[k4
      ,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m - 60*sp[k1,k2]*sp[k3,k4]
       + 24*sp[k1,k2]*sp[k3,k4]*m - 160*sp[k1,k2]*sp[k3,k4]^2 + 68*sp[
      k1,k2]*sp[k3,k4]^2*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 4*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 8*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       - 20*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 72*sp[k1,k2]*sp[k4,q]^2 - 
      28*sp[k1,k2]*sp[k4,q]^2*m - 72*sp[k1,k3]^2*sp[k2,k4] + 28*sp[k1,
      k3]^2*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 28*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k3]*m + 56*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k4] - 20*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k3]
      ^2 - 32*sp[k1,k3]*sp[k2,k3]^2*m - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4
      ] - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k3]*
      sp[k2,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m + 80*sp[k1,k3]*sp[k2
      ,k3]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,k3
      ]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 76*sp[
      k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,
      k4]^2 - 8*sp[k1,k3]*sp[k2,k4]^2*m + 160*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q] - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 112*sp[k1,k3]*sp[k2,k4]
      *sp[k3,k4] - 44*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 40*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] + 12*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 12*sp[k1
      ,k3]*sp[k2,k4]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,q]^2 + 24*sp[k1,k3
      ]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[
      k1,k3]*sp[k2,q]*sp[k4,q] - 56*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4
      ]^2*sp[k2,k3]*m - 56*sp[k1,k4]^2*sp[k2,q] + 16*sp[k1,k4]^2*sp[k2,
      q]*m - 56*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 56*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m - 68*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,
      k3]*m + 120*sp[k1,k4]*sp[k2,k3]^2 - 44*sp[k1,k4]*sp[k2,k3]^2*m - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 8*sp[k1,k4]*sp[k2,k3]*sp[k2,k4
      ]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 4*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 36*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 4*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m - 112*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 36*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m + 32*
      sp[k1,k4]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,k4]*
      m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4
      ]*sp[k4,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 36*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m + 40*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 12*sp[k1,k4]
      *sp[k2,q]*sp[k3,q]*m - 40*sp[k1,k4]*sp[k2,q]*sp[k4,q] + 12*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]^2 - 32*sp[k1,q]*
      sp[k2,k3]^2*m - 48*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 20*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 104*sp[k1,q]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,q
      ]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 56*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16
      *sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k4]^2 - 32*sp[
      k1,q]*sp[k2,k4]^2*m + 64*sp[k1,q]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,q
      ]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 12*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m - 120*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      44*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 56*sp[k1,q]*sp[k2,k4]*sp[k4,q]
       + 20*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,q]*sp[k2,q]*sp[k3,
      k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[14,16]*color[ - 1/2
      *Ca^2*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - 
      k4]]*den[sp[k3 + k4]]*num[176*sp[k1,k2]^2*sp[k3,k4] - 48*sp[k1,k2
      ]^2*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 16*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k3]*m - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 24*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
      *m - 4*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 + 12*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 - 48*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m
       + 12*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q]*m^2 + 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k1
      ,k4]*sp[k4,q]*m^2 - 176*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 48*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4]*m - 104*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 48
      *sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,q
      ]*m - 4*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 + 12*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 104*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 12*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2
       + 24*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k2,k4]*sp[
      k4,q]*m^2 + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2
      ,q]*sp[k3,k4]*m + 152*sp[k1,k2]*sp[k3,k4] - 56*sp[k1,k2]*sp[k3,k4
      ]*m + 104*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m + 104*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[
      k3,k4]*sp[k4,q]*m - 96*sp[k1,k2]*sp[k3,q]^2 + 40*sp[k1,k2]*sp[k3,
      q]^2*m - 4*sp[k1,k2]*sp[k3,q]^2*m^2 - 96*sp[k1,k2]*sp[k3,q]*sp[k4
      ,q] - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m^2 - 96*sp[k1,k2]*sp[k4,q]^2 + 40*sp[k1,k2]*sp[k4,q]^2*m
       - 4*sp[k1,k2]*sp[k4,q]^2*m^2 - 96*sp[k1,k3]^2*sp[k2,q] + 40*sp[
      k1,k3]^2*sp[k2,q]*m - 4*sp[k1,k3]^2*sp[k2,q]*m^2 - 96*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] - 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 8*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m^2 + 96*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 40
      *sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*
      m^2 + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 4*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 24*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 96*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 4*
      sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 24*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 24*sp[k1,k3]*sp[k2,k4]^2
       + 16*sp[k1,k3]*sp[k2,k4]^2*m - 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k2
      ,q]*m^2 + 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q]*m - 104*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k3]*sp[k2,q]*sp[k3,q]*m - 4*sp[k1
      ,k3]*sp[k2,q]*sp[k3,q]*m^2 + 12*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 4
      *sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 96*sp[k1,k4]^2*sp[k2,q] + 40*
      sp[k1,k4]^2*sp[k2,q]*m - 4*sp[k1,k4]^2*sp[k2,q]*m^2 + 48*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3] + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k4
      ]*m^2 - 24*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m + 
      24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4]*m - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 4*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 24*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 96*sp[k1
      ,k4]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 4*
      sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 24*sp[k1,k4]*sp[k2,k4]*sp[k3,q
      ] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 104*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] + 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 12*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m + 4*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 24*sp[k1,
      k4]*sp[k2,q]*sp[k4,q]*m - 4*sp[k1,k4]*sp[k2,q]*sp[k4,q]*m^2 - 24*
      sp[k1,q]*sp[k2,k3]^2*m + 4*sp[k1,q]*sp[k2,k3]^2*m^2 - 24*sp[k1,q]
      *sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 96*
      sp[k1,q]*sp[k2,k3]*sp[k3,q] - 40*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m + 
      4*sp[k1,q]*sp[k2,k3]*sp[k3,q]*m^2 + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ] + 4*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 4*sp[k1,q]*sp[k2,k3]*sp[k4,
      q]*m^2 - 24*sp[k1,q]*sp[k2,k4]^2*m + 4*sp[k1,q]*sp[k2,k4]^2*m^2
       + 48*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]
      *m - 4*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,q]*sp[k2,k4]*
      sp[k4,q] - 40*sp[k1,q]*sp[k2,k4]*sp[k4,q]*m + 4*sp[k1,q]*sp[k2,k4
      ]*sp[k4,q]*m^2 - 176*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m] + amp[15,1]*color[ - 1/4*Ca^2*Na*Tf]*den[
      sp[ - k1 - k2]]*den[sp[k1 + k3]]*den[sp[ - k2 - k4]]*num[ - 64*
      sp[k1,k2]^2 + 32*sp[k1,k2]^2*m - 64*sp[k1,k2]*sp[k1,k4] + 32*sp[
      k1,k2]*sp[k1,k4]*m - 64*sp[k1,k2]*sp[k2,k3] + 32*sp[k1,k2]*sp[k2,
      k3]*m + 96*sp[k1,k2]*sp[k3,k4] - 80*sp[k1,k2]*sp[k3,k4]*m + 16*
      sp[k1,k2]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4] - 80*sp[k1,k3]*
      sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*m^2 - 160*sp[k1,k4]*sp[k2,k3
      ] + 112*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2] + 
      amp[15,3]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1
       + k3]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[ - 16*sp[k1,k2
      ]^2 - 32*sp[k1,k2]^2*sp[k1,k3] + 16*sp[k1,k2]^2*sp[k1,k3]*m + 64*
      sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]^2*sp[k1,q]*m + 16*sp[k1,k2]^2
      *sp[k3,k4]*m + 80*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*
      m - 8*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]
       + 16*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 144*sp[k1,k2]*sp[
      k1,k3]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 4*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]
       + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k1
      ,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 8*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 8
      *sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m - 80*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
       + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k4] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q
      ]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 48*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 4*sp[k1,k2]
      *sp[k1,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 32*sp[
      k1,k2]*sp[k1,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k3] - 8*sp[k1,k2]
      *sp[k2,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 32
      *sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 24*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m
       - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] + 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 4*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,q]*sp[k3,q] - 8*sp[k1,k2]*sp[
      k2,q]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4
      ]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1,k2]*sp[k3,k4]^2*m - 4*
      sp[k1,k2]*sp[k3,k4]^2*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48
      *sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q]*m - 32*sp[k1,k3]^2*sp[k2,k4] - 8*sp[k1,k3]^2*sp[k2,k4]
      *m + 4*sp[k1,k3]^2*sp[k2,k4]*m^2 + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k3]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 96*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 48*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 176*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] - 72*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] - 24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q] - 8*sp[k1,k3]*sp[
      k2,k3]*sp[k2,q]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,
      k3]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*
      sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 40*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2
       - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 4*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]^2 + 24*sp[k1,k3]*sp[k2,q]^2*
      m + 144*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4]*m - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 24*sp[k1,k3]*sp[k2,q]
      *sp[k4,q]*m - 64*sp[k1,k4]^2*sp[k2,k3] + 16*sp[k1,k4]^2*sp[k2,k3]
      *m + 32*sp[k1,k4]^2*sp[k2,q] - 8*sp[k1,k4]^2*sp[k2,q]*m - 128*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 96*sp[k1,k4]*sp[k1,q]*sp[k2,
      k4] + 40*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k1,q]*
      sp[k2,q] - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[k1,k4]*sp[k2,k3]*m + 8*
      sp[k1,k4]*sp[k2,k3]^2*m - 4*sp[k1,k4]*sp[k2,k3]^2*m^2 + 8*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 
      32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*sp[k1,k4]*sp[k2,
      k3]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 32*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 24*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 80*sp[k1,q]^2*sp[k2,k4] + 32*sp[k1,q]^2*sp[k2,k4]*m
       - 32*sp[k1,q]*sp[k2,k3]^2 + 8*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,
      q]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 64*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] - 24*sp[k1,q]*sp[k2,k3]*sp[k2,q]*m - 
      32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m + 144*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m] + amp[15,4]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[
       - k1 - k2]]*den[sp[k1 + k3]]*den[sp[ - k2 - k4]]*den[sp[ - k4 + 
      q]]*num[ - 16*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k2,k4] + 16*sp[k1,
      k2]^2*sp[k2,k4]*m + 64*sp[k1,k2]^2*sp[k2,q] - 32*sp[k1,k2]^2*sp[
      k2,q]*m + 16*sp[k1,k2]^2*sp[k3,k4]*m - 8*sp[k1,k2]^2*sp[k3,q]*m
       + 80*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 24*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4] - 16
      *sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k4] - 80*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[
      k1,k4]*sp[k3,k4]*m^2 - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 8
      *sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 144*sp[k1,k2]*sp[k1,q]*sp[k2,k4
      ] + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[
      k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2,q]*m + 4*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k1,q]*sp[k4,q] - 8*sp[k1,k2]*sp[
      k1,q]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k3] - 32*sp[k1,k2]*sp[k2,k3
      ]*sp[k2,k4] + 16*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 64*sp[k1,k2]*
      sp[k2,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 
      32*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*
      m + 80*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 24*sp[k1,k2]*sp[k2,
      k4]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 192*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 48*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*sp[k2,q]*sp[
      k3,q] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,q]*m + 80*sp[k1,k2]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1
      ,k2]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 32*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 4*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 
      48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ] + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4] - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k4]*m^2 - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k3
      ]*sp[k1,k4]*sp[k2,q]*m + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 40*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m + 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,
      k3]*sp[k2,q]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4] - 24*sp[k1,k3]*sp[
      k2,k4]*m - 32*sp[k1,k3]*sp[k2,k4]^2 - 8*sp[k1,k3]*sp[k2,k4]^2*m
       + 4*sp[k1,k3]*sp[k2,k4]^2*m^2 + 176*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 72*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[
      k2,q]*m^2 + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 4*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 
      16*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 80*sp[k1,k3]*sp[k2,q]^2 + 32*
      sp[k1,k3]*sp[k2,q]^2*m - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 24*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m - 80*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32
      *sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 8*sp[k1,k4]^2*sp[k2,k3]*m - 4*
      sp[k1,k4]^2*sp[k2,k3]*m^2 - 32*sp[k1,k4]^2*sp[k2,q] + 8*sp[k1,k4]
      ^2*sp[k2,q]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m^2 + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 8*sp[
      k1,k4]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,q] - 24
      *sp[k1,k4]*sp[k1,q]*sp[k2,q]*m - 96*sp[k1,k4]*sp[k2,k3] + 24*sp[
      k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[
      k2,k3]^2*m + 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 40*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2
       + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[
      k3,k4]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 16*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 96*sp[k1
      ,k4]*sp[k2,k3]*sp[k4,q] - 24*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 112
      *sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 8*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4]*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 48*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,q]^2*sp[k2,k4] + 24*sp[k1,q]^2*sp[k2,k4]*m
       + 32*sp[k1,q]*sp[k2,k3]^2 - 8*sp[k1,q]*sp[k2,k3]^2*m + 48*sp[k1,
      q]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 16*
      sp[k1,q]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 8
      *sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 144*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] + 24*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[15,5]*
      color[ - Cf^2*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 - k4]]^2*
      num[128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 192*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4]*m + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 16*sp[k1,k3]
      *sp[k2,k4]*sp[k3,k4]*m^3] + amp[15,6]*color[ - Cf^2*Na*Tf + 1/2*
      Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 - k4]]*den[sp[ - k2
       + q]]*num[128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 128*
      sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m
       - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] + 288*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^3 + 128*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 8*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m^3 + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 160*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 8*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^3] + amp[15,7]*color[1/2*Ca*Cf*Na*
      Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 - k4]]*den[sp[ - k4 + q]]*
      num[64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*
      sp[k2,k3]*sp[k2,q] + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32*sp[
      k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 128*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 
      32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3
      ,k4] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2] + amp[15,8]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf
       - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[ - k2
       - k3]]*den[sp[ - k2 - k4]]*num[128*sp[k1,k2]^3 - 64*sp[k1,k2]^3*
      m + 128*sp[k1,k2]^2*sp[k1,k3] - 64*sp[k1,k2]^2*sp[k1,k3]*m + 128*
      sp[k1,k2]^2*sp[k1,k4] - 64*sp[k1,k2]^2*sp[k1,k4]*m + 128*sp[k1,k2
      ]^2*sp[k2,k3] - 64*sp[k1,k2]^2*sp[k2,k3]*m + 128*sp[k1,k2]^2*sp[
      k2,k4] - 64*sp[k1,k2]^2*sp[k2,k4]*m + 256*sp[k1,k2]^2*sp[k3,k4]
       - 64*sp[k1,k2]^2*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m - 256*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3] + 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 128
      *sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]
      *m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k3] - 256*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 192*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m^2 - 
      128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,
      k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[
      k2,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1
      ,k2]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 
      16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m^2 - 1024*sp[k1,k2]*sp[k3,k4]^2 + 704*sp[k1,k2]
      *sp[k3,k4]^2*m - 144*sp[k1,k2]*sp[k3,k4]^2*m^2 + 8*sp[k1,k2]*sp[
      k3,k4]^2*m^3 + 128*sp[k1,k3]^2*sp[k2,k4] - 96*sp[k1,k3]^2*sp[k2,
      k4]*m + 16*sp[k1,k3]^2*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3] + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 96*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*
      m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 96*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 128*sp[k1,k3
      ]*sp[k2,k4]^2 - 96*sp[k1,k3]*sp[k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,
      k4]^2*m^2 + 1024*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 704*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m + 144*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 8
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^3 + 128*sp[k1,k4]^2*sp[k2,k3] - 
      96*sp[k1,k4]^2*sp[k2,k3]*m + 16*sp[k1,k4]^2*sp[k2,k3]*m^2 + 128*
      sp[k1,k4]*sp[k2,k3]^2 - 96*sp[k1,k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]
      *sp[k2,k3]^2*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 96*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2
       + 1024*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 704*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4]*m + 144*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 8*sp[k1,k4]
      *sp[k2,k3]*sp[k3,k4]*m^3] + amp[15,9]*color[ - Cf^2*Na*Tf + Ca*Cf
      *Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[
      sp[ - k2 - k4]]*den[sp[ - k2 + q]]*num[ - 64*sp[k1,k2]^2*sp[k3,k4
      ] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[k1,k2]^2*sp[k3,q] - 64*sp[
      k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*sp[k3,q]*m^2 + 64*sp[k1,k2]^
      2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[
      k1,k3]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 96*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*
      m^2 + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m + 256*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 
      64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,
      q]*m^2 - 256*sp[k1,k2]*sp[k1,k4]*sp[k4,q] + 128*sp[k1,k2]*sp[k1,
      k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m^2 - 64*sp[k1,
      k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 16*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4
      ] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 256*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,
      q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 96*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 896*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 608*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 8*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 
      256*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*sp[k2,k4]^2*m - 16*sp[
      k1,k3]*sp[k2,k4]^2*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 32*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m + 256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      128*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 + 256*sp[k1,k4]^2*sp[k2,q] - 128*sp[k1,k4]^2*sp[k2,q]*m
       + 16*sp[k1,k4]^2*sp[k2,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3]*m^2 - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m^2 + 640*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 480*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m + 112*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m^3 - 640*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 416*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,k4]
      *sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m^2 + 640*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 480*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 8*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m^3] + amp[15,10]*color[ - 1/2*Ca*Cf*Na
      *Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 + k4]]*den[sp[
       - k2 - k4]]*den[sp[ - k3 + q]]*num[64*sp[k1,k2]^2*sp[k1,k3] - 32
      *sp[k1,k2]^2*sp[k1,k3]*m - 128*sp[k1,k2]^2*sp[k1,q] + 64*sp[k1,k2
      ]^2*sp[k1,q]*m - 64*sp[k1,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^2*sp[k3,
      q] + 32*sp[k1,k2]^2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q] + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4]*m
       + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k3]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1
      ,k3]*sp[k2,k4]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 192*sp[k1,k2]*sp[k1,k3]*sp[k4,q
      ] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,k4]*
      sp[k1,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k1,q]*m + 64*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 128*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 
      64*sp[k1,k2]*sp[k1,k4]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
      *m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,q]*sp[
      k2,k3]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[k1,
      q]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 48*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 16*sp[
      k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 
      64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
      *m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[k3,k4]^2
       - 48*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[k1,k2]*sp[k3,k4]^2*m^2 + 64*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       + 8*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 32*sp[k1,k3]^2*sp[k2,k4]
       + 16*sp[k1,k3]^2*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
       - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 256*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4]*m^2 - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       + 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 48*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 256
      *sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*
      m - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,k4]^2*sp[k2,
      k3] - 32*sp[k1,k4]^2*sp[k2,k3]*m - 64*sp[k1,k4]^2*sp[k2,q] + 16*
      sp[k1,k4]^2*sp[k2,q]*m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 320*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 
      208*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,
      k4]*m^2 - 32*sp[k1,k4]*sp[k2,k3]^2 + 16*sp[k1,k4]*sp[k2,k3]^2*m
       - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,k4]*sp[k2,k3]*sp[k2
      ,q]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 48*sp[k1,k4]*sp[k2,k3]
      *sp[k3,k4]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 32*sp[k1,k4]
      *sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 128*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 96*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]
      *sp[k2,k4]*sp[k3,k4] - 112*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[15,11]*color[ - Cf^2*Na*
      Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q
      ]]*den[sp[ - k2 - k3]]*den[sp[ - k2 - k4]]*num[ - 64*sp[k1,k2]^2*
      sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[k1,k2]^2*sp[k3,q]
       - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^2*sp[k4,q] - 64*sp[k1
      ,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]^2*sp[k4,q]*m^2 + 256*sp[k1,k2]*
      sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m
       - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q]*m + 256*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 128*sp[k1,k2]*sp[k1,
      k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 + 64*sp[k1
      ,k2]*sp[k1,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k4]
      *sp[k2,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,
      k2]*sp[k1,k4]*sp[k3,q]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*
      sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
       + 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[
      k2,k4]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 256*sp[
      k1,k2]*sp[k2,k3]*sp[k3,q] + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m - 
      16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3
      ]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 64*
      sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       - 896*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 608*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 8*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q]*m^3 - 256*sp[k1,k3]^2*sp[k2,k4] + 128*sp[k1,k3]^2
      *sp[k2,k4]*m - 16*sp[k1,k3]^2*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,
      k4]*sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 128*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2
      ,k4] - 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k3]
      *sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 640*sp[k1,k3]
      *sp[k2,k3]*sp[k4,q] + 416*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*
      m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 640*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       - 480*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 112*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2 - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^3 + 64*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m^2 + 640*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 480*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m^3 + 256*sp[k1,q]*sp[k2,k3]^2 - 128*
      sp[k1,q]*sp[k2,k3]^2*m + 16*sp[k1,q]*sp[k2,k3]^2*m^2 + 64*sp[k1,q
      ]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 256*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m
       + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2] + amp[15,12]*color[ - 
      Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k4]]^2*num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 128
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k4]*m^2 + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 160*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 8*sp[k1,k3
      ]*sp[k2,k4]*sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4] + 128
      *sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]
      *m^2 - 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,k4]*sp[k2,k4]
      *sp[k3,q]*m - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 160*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*
      m^2 - 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^3] + amp[15,13]*color[ - 1/
      2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - q]]*
      den[sp[ - k2 - k4]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]^2*sp[
      k3,k4] - 32*sp[k1,k2]^2*sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 32
      *sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 192*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*
      m + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[
      k2,q]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 48*sp[k1,k2]*sp[k1,
      k3]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 32*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]
       + 16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 96*sp[k1,k2]*
      sp[k1,k4]*sp[k4,q] - 80*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 16*sp[k1
      ,k2]*sp[k1,k4]*sp[k4,q]*m^2 + 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] - 
      48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4] - 48*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 256*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q] - 144*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,
      k2]*sp[k2,k3]*sp[k3,q]*m^2 + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 16
      *sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       - 80*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q]*m^2 + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 448*sp[k1,k2]*sp[k3
      ,k4]*sp[k3,q] - 224*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 24*sp[k1,k2]
      *sp[k3,k4]*sp[k3,q]*m^2 + 192*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 112*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*
      m^2 + 128*sp[k1,k3]^2*sp[k2,k4] - 48*sp[k1,k3]^2*sp[k2,k4]*m - 64
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
      *m - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[
      k1,k4]*sp[k2,q]*m^2 - 96*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 
      64*sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 80*sp[k1,k3]*sp[k2,k3]*sp[k2,q]
      *m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 48*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 
      128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q
      ]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 48*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 320*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4] + 176*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 96*sp[k1,k4]^2*sp[k2,k3] - 32*sp[
      k1,k4]^2*sp[k2,k3]*m - 96*sp[k1,k4]^2*sp[k2,q] + 80*sp[k1,k4]^2*
      sp[k2,q]*m - 16*sp[k1,k4]^2*sp[k2,q]*m^2 + 32*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] - 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4] + 48*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4]*m^2 - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*
      sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 192*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       + 80*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 8*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q]*m^2 - 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,
      k3]*sp[k4,q]*m + 224*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 112*sp[k1,k4]
      *sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 96*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 80*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 192*sp[k1,q]*sp[k2,k3]^2
       + 112*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]^2*m^2 + 32*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 192*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 112*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 256*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] + 160*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 24*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[15,14]*color[1/2*Ca*Cf*Na*Tf
       - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k3]]*den[sp[
       - k2 - k4]]*den[sp[ - k4 + q]]*num[ - 64*sp[k1,k2]^2*sp[k2,k4]
       + 32*sp[k1,k2]^2*sp[k2,k4]*m + 128*sp[k1,k2]^2*sp[k2,q] - 64*sp[
      k1,k2]^2*sp[k2,q]*m + 64*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2*
      sp[k3,q] + 64*sp[k1,k2]^2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m - 
      128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4]*m + 160*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k3]
      *sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m + 64
      *sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 16*sp[k1,k2]*sp[k1,k4]*sp[
      k3,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k3] - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,
      k2]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 
      128*sp[k1,k2]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,q
      ]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k3]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k3,q] + 16*sp[k1,k2]*sp[
      k2,k3]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 16*
      sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 192*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 160*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[
      k3,k4]^2 + 48*sp[k1,k2]*sp[k3,k4]^2*m - 8*sp[k1,k2]*sp[k3,k4]^2*
      m^2 - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 96*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 
      128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ]*m + 256*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k3]
      *sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 320*sp[k1,
      k3]*sp[k2,k3]*sp[k2,q] + 208*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[k4,
      q] + 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m^2 + 32*sp[k1,k3]*sp[k2,k4]^2 - 16*sp[k1,k3]*sp[k2,k4]^
      2*m + 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 48*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 256*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m
       + 24*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 192*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 112*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m^2 + 32*sp[k1,k4]^2*sp[k2,k3] - 16*sp[k1,k4]^2*
      sp[k2,k3]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 16*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,k3]^2 + 32*sp[k1,k4]*sp[
      k2,k3]^2*m - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k4]*sp[
      k2,k3]*sp[k2,k4]*m - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 16*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 48*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]
      *m^2 - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,k3]^2 - 16*sp[k1,q]*sp[k2,k3]^2*
      m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,q]*sp[k2,k3]*sp[k3
      ,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m] + amp[15,15]*color[ - 1/
      2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k4]]^2*den[sp[ - 
      k3 + q]]*num[ - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 64
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4] + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
      *m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 128*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 32*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k4] - 128*
      sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*
      m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[15,16]*color[ - 1/2*Ca*Cf*Na
      *Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 - k4]]*den[
      sp[ - k2 + q]]*den[sp[ - k3 - k4]]*num[ - 32*sp[k1,k2]^2*sp[k3,k4
      ] + 32*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*m - 32*sp[
      k1,k2]^2*sp[k4,q] + 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 96*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q] - 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 96*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 80*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m
       + 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 32*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3] - 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] + 64*sp[k1,k2]*sp[
      k1,k4]*sp[k2,k4]*m + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 48*sp[k1,
      k2]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 16*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[k1,k4]*sp[k4,q]
       - 144*sp[k1,k2]*sp[k1,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k4]*
      sp[k4,q]*m^2 - 32*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 16*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2
      ]*sp[k1,q]*sp[k2,k4]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 96*sp[
      k1,k2]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m
       + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,q] - 80*sp[k1,k2]*sp[k2,k3]*sp[k3
      ,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] + 48*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 8
      *sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 192*sp[k1,k2]*sp[k3,k4]
      *sp[k3,q] - 112*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q]*m^2 + 448*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 224*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q]*m + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2
       + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q]*m^2 - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4]*m - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 160*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 32
      *sp[k1,k3]*sp[k2,k3]*sp[k2,q] + 48*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m
       - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,q]*m^2 + 224*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q] - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2
      ,k3]*sp[k4,q]*m^2 + 128*sp[k1,k3]*sp[k2,k4]^2 - 48*sp[k1,k3]*sp[
      k2,k4]^2*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q]*m - 8*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 64*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 8*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 128*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q] + 48*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 256*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 160*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 24*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m^2 - 192*sp[k1,k4]^2*sp[k2,q] + 112*sp[k1,k4]^2*
      sp[k2,q]*m - 16*sp[k1,k4]^2*sp[k2,q]*m^2 - 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3] + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[
      k1,q]*sp[k2,k4] + 80*sp[k1,k4]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k4]*m^2 + 96*sp[k1,k4]*sp[k2,k3]^2 - 32*sp[k1,k4
      ]*sp[k2,k3]^2*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q]*m - 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 
      32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 192*sp[k1,k4]*sp[k2,k3]*sp[k4
      ,q] + 80*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m^2 + 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 96*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 192*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 96*sp[k1,q]*sp[k2,k3]^2
       + 80*sp[k1,q]*sp[k2,k3]^2*m - 16*sp[k1,q]*sp[k2,k3]^2*m^2 + 16*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 8*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 80*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 320*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4] + 176*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 24*sp[k1,
      q]*sp[k2,k4]*sp[k3,k4]*m^2] + amp[16,1]*color[ - 1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*num[ - 
      64*sp[k1,k2]^2 + 32*sp[k1,k2]^2*m - 64*sp[k1,k2]*sp[k1,k3] + 32*
      sp[k1,k2]*sp[k1,k3]*m - 64*sp[k1,k2]*sp[k2,k4] + 32*sp[k1,k2]*sp[
      k2,k4]*m + 96*sp[k1,k2]*sp[k3,k4] - 80*sp[k1,k2]*sp[k3,k4]*m + 16
      *sp[k1,k2]*sp[k3,k4]*m^2 - 160*sp[k1,k3]*sp[k2,k4] + 112*sp[k1,k3
      ]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k4]*m^2 + 96*sp[k1,k4]*sp[k2,
      k3] - 80*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k2,k3]*m^2] + 
      amp[16,3]*color[ - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1
       + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k3 + q]]*num[ - 16*sp[k1,k2
      ]^2 - 32*sp[k1,k2]^2*sp[k2,k3] + 16*sp[k1,k2]^2*sp[k2,k3]*m + 64*
      sp[k1,k2]^2*sp[k2,q] - 32*sp[k1,k2]^2*sp[k2,q]*m + 16*sp[k1,k2]^2
      *sp[k3,k4]*m + 80*sp[k1,k2]^2*sp[k3,q] - 16*sp[k1,k2]^2*sp[k3,q]*
      m - 8*sp[k1,k2]^2*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3] + 64*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k3] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 80
      *sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       - 8*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,k3]*sp[
      k3,k4]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 24*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 24*sp[k1
      ,k2]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 8*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 144*sp[k1,k2]*sp[k1,q]*sp[k2,k3]
       + 48*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k2]*sp[k1,q]*sp[k2
      ,k4]*m + 96*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*
      sp[k2,q]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*
      sp[k1,q]*sp[k3,q] - 8*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 32*sp[k1,k2
      ]*sp[k2,k3]*sp[k2,k4] + 16*sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m + 64*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 24*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*
      m + 4*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 192*sp[k1,k2]*sp[k2,k3]
      *sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[
      k2,k4] + 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q] - 32*sp[k1,k2]*sp[k2,k4]
      *sp[k2,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m + 80*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 8*
      sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m + 48*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       - 24*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4]*m^2 + 80*sp[k1,k2]*sp[k2,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,q]
      *sp[k4,q]*m + 80*sp[k1,k2]*sp[k3,k4] - 24*sp[k1,k2]*sp[k3,k4]*m
       - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[
      k1,k2]*sp[k3,k4]^2*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 48*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]
       + 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 4*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m^2 - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q]*m + 8*sp[k1,k3]^2*sp[k2,k4]*m - 4*sp[k1,k3]^2*sp[k2,k4
      ]*m^2 - 32*sp[k1,k3]^2*sp[k2,q] + 8*sp[k1,k3]^2*sp[k2,q]*m + 32*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m + 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q] + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1
      ,q]*sp[k2,k3] - 8*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 8*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*
      sp[k1,k3]*sp[k1,q]*sp[k2,q] - 24*sp[k1,k3]*sp[k1,q]*sp[k2,q]*m + 
      24*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 4*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4]*m^2 - 112*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 40*sp[k1,k3]*sp[k2,
      k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*
      m - 64*sp[k1,k3]*sp[k2,k4]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m - 128*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 40*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m
       - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 24*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 4
      *sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] + 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 144*sp[k1,k3]*sp[k2,q]*
      sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 48*sp[k1,k4]*sp[k1,
      q]*sp[k2,k3] - 40*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*
      sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]^2 - 8*sp[k1,k4]*sp[k2,k3]^2*
      m + 4*sp[k1,k4]*sp[k2,k3]^2*m^2 + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4
      ] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 176*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 72*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,k4]*m^2 - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 4*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,k4]*sp[k2,k4]*
      sp[k2,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2
      ,k4]*sp[k3,q] + 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,k4]*
      sp[k2,q]^2 + 32*sp[k1,k4]*sp[k2,q]^2*m - 64*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 80*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]^2
      *sp[k2,k3] + 24*sp[k1,q]^2*sp[k2,k3]*m + 48*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 144*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4] - 48*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[k1,q
      ]*sp[k2,k3]*sp[k4,q] + 24*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 32*sp[
      k1,q]*sp[k2,k4]^2 - 8*sp[k1,q]*sp[k2,k4]^2*m + 16*sp[k1,q]*sp[k2,
      k4]*sp[k2,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 8*sp[k1,q]*sp[k2
      ,k4]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 24*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 24*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m] + amp[16,4]*color[ - 1/4*Ca^2*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[
       - k4 + q]]*num[ - 16*sp[k1,k2]^2 - 32*sp[k1,k2]^2*sp[k1,k4] + 16
      *sp[k1,k2]^2*sp[k1,k4]*m + 64*sp[k1,k2]^2*sp[k1,q] - 32*sp[k1,k2]
      ^2*sp[k1,q]*m + 16*sp[k1,k2]^2*sp[k3,k4]*m - 8*sp[k1,k2]^2*sp[k3,
      q]*m + 80*sp[k1,k2]^2*sp[k4,q] - 16*sp[k1,k2]^2*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k1,k3] - 32*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] + 16*sp[k1
      ,k2]*sp[k1,k3]*sp[k1,k4]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,q] - 32
      *sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4
      ]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q] + 8*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m + 80*sp[k1,k2]
      *sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 32*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 
      144*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q
      ]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 - 192*sp[k1,k2]
      *sp[k1,k4]*sp[k3,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 32*sp[
      k1,k2]*sp[k1,q]*sp[k2,k3] + 24*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 
      80*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]
      *m + 96*sp[k1,k2]*sp[k1,q]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k2
      ,q]*m + 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 24*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4]*m + 4*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 80*sp[k1,k2]*
      sp[k1,q]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,q]*m - 16*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q] + 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k2,k4] - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 4*sp[k1
      ,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 8*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 24*sp[k1,k2]*sp[k2,k4]*sp[k4
      ,q]*m + 4*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 + 32*sp[k1,k2]*sp[k2,q
      ]*sp[k4,q] - 8*sp[k1,k2]*sp[k2,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k3
      ,k4] - 24*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]^2 + 24*
      sp[k1,k2]*sp[k3,k4]^2*m - 4*sp[k1,k2]*sp[k3,k4]^2*m^2 - 32*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q] + 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 4*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,
      q] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 64*sp[k1,k3]^2*sp[
      k2,k4] + 16*sp[k1,k3]^2*sp[k2,k4]*m + 32*sp[k1,k3]^2*sp[k2,q] - 8
      *sp[k1,k3]^2*sp[k2,q]*m + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 32*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 24*sp[k1,k3]*sp[k1,k4]*sp[k2,k4
      ]*m - 4*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 48*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 96*sp[k1,k3]*sp[
      k1,q]*sp[k2,k3] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 128*sp[k1,
      k3]*sp[k1,q]*sp[k2,k4] + 40*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 4*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 16*sp[k1,k3]*sp[k1,q]*sp[k2,q]
       - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m - 96*sp[k1,k3]*sp[k2,k4] + 24*sp[k1,k3]*sp[k2,k4]*m + 8*sp[
      k1,k3]*sp[k2,k4]^2*m - 4*sp[k1,k3]*sp[k2,k4]^2*m^2 + 8*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m - 4*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 32*
      sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 24*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*
      m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m + 4*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 96*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] - 24*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 32*sp[k1
      ,k3]*sp[k2,q]*sp[k3,k4] - 8*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 96*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] - 24*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      32*sp[k1,k4]^2*sp[k2,k3] - 8*sp[k1,k4]^2*sp[k2,k3]*m + 4*sp[k1,k4
      ]^2*sp[k2,k3]*m^2 + 176*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 72*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3]*m + 4*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 
      64*sp[k1,k4]*sp[k2,k3] - 24*sp[k1,k4]*sp[k2,k3]*m + 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4] - 24*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 4*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
       - 40*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 4*sp[k1,k4]*sp[k2,k3]*sp[
      k2,q]*m^2 + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 4*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,k4]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 16*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q]*m - 4*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 
      16*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]
       - 8*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 112*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q] + 40*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,k4]*sp[k2,q]
      ^2 + 24*sp[k1,k4]*sp[k2,q]^2*m + 144*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       - 48*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] + 24*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 80*sp[k1,q]^2*sp[k2,k3
      ] + 32*sp[k1,q]^2*sp[k2,k3]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       + 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 80*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 32*sp[k1,q]*sp[k2
      ,k4]^2 + 8*sp[k1,q]*sp[k2,k4]^2*m + 64*sp[k1,q]*sp[k2,k4]*sp[k2,q
      ] - 24*sp[k1,q]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4] + 8*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 144*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 80*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4] + 24*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[16,5]*
      color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 - k4]]*
      num[128*sp[k1,k2]^3 - 64*sp[k1,k2]^3*m + 128*sp[k1,k2]^2*sp[k1,k3
      ] - 64*sp[k1,k2]^2*sp[k1,k3]*m + 128*sp[k1,k2]^2*sp[k1,k4] - 64*
      sp[k1,k2]^2*sp[k1,k4]*m + 128*sp[k1,k2]^2*sp[k2,k3] - 64*sp[k1,k2
      ]^2*sp[k2,k3]*m + 128*sp[k1,k2]^2*sp[k2,k4] - 64*sp[k1,k2]^2*sp[
      k2,k4]*m + 256*sp[k1,k2]^2*sp[k3,k4] - 64*sp[k1,k2]^2*sp[k3,k4]*m
       + 128*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[
      k1,k4]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 192*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m^2 - 128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]
       + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 256*sp[k1,k2]
      *sp[k1,k4]*sp[k2,k4] + 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 32*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,k4] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k2
      ]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 96*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4
      ]*m^2 - 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k4
      ]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 1024*sp[k1
      ,k2]*sp[k3,k4]^2 + 704*sp[k1,k2]*sp[k3,k4]^2*m - 144*sp[k1,k2]*
      sp[k3,k4]^2*m^2 + 8*sp[k1,k2]*sp[k3,k4]^2*m^3 + 128*sp[k1,k3]^2*
      sp[k2,k4] - 96*sp[k1,k3]^2*sp[k2,k4]*m + 16*sp[k1,k3]^2*sp[k2,k4]
      *m^2 - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k3]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 128*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4] + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*sp[
      k2,k4] + 96*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,
      k3]*sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k2,k4]^2 - 96*sp[k1,k3]*sp[
      k2,k4]^2*m + 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 1024*sp[k1,k3]*sp[k2,
      k4]*sp[k3,k4] - 704*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 144*sp[k1,
      k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^3
       + 128*sp[k1,k4]^2*sp[k2,k3] - 96*sp[k1,k4]^2*sp[k2,k3]*m + 16*
      sp[k1,k4]^2*sp[k2,k3]*m^2 + 128*sp[k1,k4]*sp[k2,k3]^2 - 96*sp[k1,
      k4]*sp[k2,k3]^2*m + 16*sp[k1,k4]*sp[k2,k3]^2*m^2 - 128*sp[k1,k4]*
      sp[k2,k3]*sp[k2,k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[
      k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 1024*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4] - 704*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 144*sp[k1,k4]*sp[k2,
      k3]*sp[k3,k4]*m^2 - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^3] + amp[16
      ,6]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*
      num[ - 64*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64
      *sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m + 64*sp[k1,k2]^
      2*sp[k4,q] - 64*sp[k1,k2]^2*sp[k4,q]*m + 16*sp[k1,k2]^2*sp[k4,q]*
      m^2 + 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k3]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 32*sp[k1,
      k2]*sp[k1,k3]*sp[k2,q]*m - 256*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 128
      *sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]
      *m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*
      sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m - 
      16*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 64*sp[k1
      ,k2]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m^2
       + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,
      k4]*m + 256*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 64*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] + 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4]*m^2 - 896*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 608*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*
      m^2 + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^3 + 256*sp[k1,k3]^2*sp[k2,
      q] - 128*sp[k1,k3]^2*sp[k2,q]*m + 16*sp[k1,k3]^2*sp[k2,q]*m^2 + 
      64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
      *m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,q]*
      sp[k2,k3]*m^2 - 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 96*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 64*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4
      ]*m^2 - 640*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 416*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 8*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 64*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2
       + 640*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 480*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m + 112*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 128*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2
       + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,
      k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 256*sp[k1,k4]*sp[k2
      ,k3]^2 + 128*sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2,k3]^2*
      m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 128*sp[k1,k4]*sp[
      k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 128*sp[
      k1,q]*sp[k2,k3]*sp[k2,k4] + 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 
      16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 640*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 480*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^3] + amp[16,
      7]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*num[64*
      sp[k1,k2]^2*sp[k1,k4] - 32*sp[k1,k2]^2*sp[k1,k4]*m - 128*sp[k1,k2
      ]^2*sp[k1,q] + 64*sp[k1,k2]^2*sp[k1,q]*m - 64*sp[k1,k2]^2*sp[k3,
      k4] + 32*sp[k1,k2]^2*sp[k3,q] - 64*sp[k1,k2]^2*sp[k4,q] + 32*sp[
      k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k1,k4] - 32*sp[k1
      ,k2]*sp[k1,k3]*sp[k1,k4]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k1,q] + 
      64*sp[k1,k2]*sp[k1,k3]*sp[k1,q]*m + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,
      k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 128*sp[k1,k2]*sp[k1,k3]*
      sp[k3,k4] + 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 64*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m - 64*sp[k1,k2
      ]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 128*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k4]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,
      k4]*sp[k2,q]*m + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 16*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4]*m + 192*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m - 160*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 
      64*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k2,
      k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 160*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] + 48*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[
      k2,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k2
      ]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 32*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m
       + 64*sp[k1,k2]*sp[k3,k4]^2 - 48*sp[k1,k2]*sp[k3,k4]^2*m + 8*sp[
      k1,k2]*sp[k3,k4]^2*m^2 + 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 48*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m + 8*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2
       + 128*sp[k1,k3]^2*sp[k2,k4] - 32*sp[k1,k3]^2*sp[k2,k4]*m - 64*
      sp[k1,k3]^2*sp[k2,q] + 16*sp[k1,k3]^2*sp[k2,q]*m - 256*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k4] - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k1,k4]
      *sp[k2,q] + 320*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 208*sp[k1,k3]*sp[
      k1,q]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 + 96*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 
      128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 32*sp[k1,k3]*sp[k2,k4
      ]^2 + 16*sp[k1,k3]*sp[k2,k4]^2*m - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] + 48*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m - 8*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4]*m^2 + 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 8*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k4]^2*sp[k2,k3]
       + 16*sp[k1,k4]^2*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 128*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 64*sp[k1,k4]*
      sp[k2,k3]*sp[k3,k4] + 48*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 8*sp[
      k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q]
       + 160*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 24*sp[k1,k4]*sp[k2,k3]*
      sp[k3,q]*m^2 - 96*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 192*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 112*sp[k1
      ,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2]
       + amp[16,8]*color[ - Cf^2*Na*Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2
       - k3]]^2*num[128*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 192*sp[k1,k4]*
      sp[k2,k3]*sp[k3,k4]*m + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 16
      *sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^3] + amp[16,9]*color[ - Cf^2*Na*
      Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2 - k3]]*den[
      sp[ - k2 + q]]*num[128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,
      k4]*sp[k2,k3]*sp[k2,k4]*m + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2
       + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 160*sp[k1,k4]*sp[k2,k3]*sp[
      k4,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,k4]*sp[k2
      ,k3]*sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 128*sp[k1,
      k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 
      256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,k4]*sp[k2,k4]*sp[k3,
      q]*m - 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4
      ]*sp[k3,q]*m^3 + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 160*sp[k1,k4]
      *sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^3] + amp[16,10]*color[1/2*Ca*Cf*Na
      *Tf]*den[sp[k1 + k4]]^2*den[sp[ - k2 - k3]]*den[sp[ - k3 + q]]*
      num[64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[
      k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k4]*
      sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[
      k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]
       - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k2,k4]*sp[k2,q] + 128*sp[k1,k4]*
      sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 64*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m
       - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 64*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4]*m^2] + amp[16,11]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf
      *Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]^2*
      num[128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 128*sp[k1,k3
      ]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,
      q] + 288*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^3 + 128*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 64*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 160*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 - 8*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m^3] + amp[16,12]*color[ - Cf^2*Na*Tf + Ca*Cf
      *Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[
       - k2 - k3]]*den[sp[ - k2 - k4]]*num[ - 64*sp[k1,k2]^2*sp[k3,k4]
       + 32*sp[k1,k2]^2*sp[k3,k4]*m + 64*sp[k1,k2]^2*sp[k3,q] - 64*sp[
      k1,k2]^2*sp[k3,q]*m + 16*sp[k1,k2]^2*sp[k3,q]*m^2 + 64*sp[k1,k2]^
      2*sp[k4,q] - 32*sp[k1,k2]^2*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k2,k4] - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[
      k1,k3]*sp[k2,q] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m - 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,q]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 256*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[
      k1,k4]*sp[k2,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m + 256*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4] - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 
      16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 64*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m^2 - 64*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*
      sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m^2 - 64*
      sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m
       - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[
      k2,k3]*sp[k4,q] + 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*
      m^2 - 256*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 128*sp[k1,k2]*sp[k2,k4]*
      sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 + 64*sp[k1,k2]*
      sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 896*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q] + 608*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 
      128*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 8*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m^3 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 96*sp[
      k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2
       + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,
      k4]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 - 128*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] + 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q]*m^2 + 640*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 480*
      sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 112*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
      *m^2 - 8*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^3 - 256*sp[k1,k4]^2*sp[k2
      ,k3] + 128*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]*m^2
       + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,
      k3]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 256*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m
       + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 640*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] + 416*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^3 + 640*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 480*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       + 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m^3 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 256*sp[k1,q]*sp[k2,k4]^2 - 128*sp[k1,q]*sp[
      k2,k4]^2*m + 16*sp[k1,q]*sp[k2,k4]^2*m^2 + 256*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m^2] + amp[16,13]*color[1/2*Ca*Cf*Na*Tf - 1/4*
      Ca^2*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*
      den[sp[ - k3 - k4]]*num[32*sp[k1,k2]^2*sp[k3,k4] - 32*sp[k1,k2]^2
      *sp[k3,q] + 16*sp[k1,k2]^2*sp[k3,q]*m + 32*sp[k1,k2]^2*sp[k4,q]
       - 16*sp[k1,k2]^2*sp[k4,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]
       + 32*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,q]*m + 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,k3]
      *sp[k3,k4]*m - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 80*sp[k1,k2]*sp[
      k1,k3]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 + 32*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] - 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 
      32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,
      k3]*m + 192*sp[k1,k2]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 16*sp[k1,k2]*
      sp[k1,k4]*sp[k2,q]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] - 48*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 
      32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q
      ]*m^2 - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k2]*sp[k1,q]*
      sp[k2,k3]*m - 96*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 48*sp[k1,k2]*sp[
      k1,q]*sp[k2,k4]*m - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4]*m - 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 80*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2
       - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m - 256*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 144*sp[k1,k2]*sp[k2,k4
      ]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2 - 32*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4] - 192*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 112*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2
       - 448*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 224*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 - 96*sp[k1,k3]^2*
      sp[k2,k4] + 32*sp[k1,k3]^2*sp[k2,k4]*m + 96*sp[k1,k3]^2*sp[k2,q]
       - 80*sp[k1,k3]^2*sp[k2,q]*m + 16*sp[k1,k3]^2*sp[k2,q]*m^2 + 160*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*
      m + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m^2 + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k3]
      *sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 - 32*
      sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m
       - 224*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 112*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2
      ,k4]*sp[k2,q] - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 96*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 32*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 192*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q] - 80*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 8
      *sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 + 96*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4] - 80*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m^2 - 128*sp[k1,k4]^2*sp[k2,k3] + 48*sp[k1,k4]^2*sp[k2,
      k3]*m + 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 8*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m^2 + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48
      *sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*
      m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 80*sp[k1,k4]*sp[k2
      ,k4]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 256*sp[k1
      ,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 8*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 320*sp[k1,k4]*sp[k2,q]*sp[k3,
      k4] - 176*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m^2 - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 160*
      sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*
      m^2 + 192*sp[k1,q]*sp[k2,k4]^2 - 112*sp[k1,q]*sp[k2,k4]^2*m + 16*
      sp[k1,q]*sp[k2,k4]^2*m^2 + 192*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 112
      *sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
      *m^2] + amp[16,14]*color[ - 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k4]]*
      den[sp[ - k2 - k3]]^2*den[sp[ - k4 + q]]*num[ - 64*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 
      128*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,
      k3]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,k3
      ]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 64*sp[k1,k4]
      *sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k3
      ,q] + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 32*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q]*m^2 + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2] + amp[
      16,15]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k4]]*
      den[sp[ - k2 - k3]]*den[sp[ - k2 - k4]]*den[sp[ - k3 + q]]*num[
       - 64*sp[k1,k2]^2*sp[k2,k3] + 32*sp[k1,k2]^2*sp[k2,k3]*m + 128*
      sp[k1,k2]^2*sp[k2,q] - 64*sp[k1,k2]^2*sp[k2,q]*m + 64*sp[k1,k2]^2
      *sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,q] - 32*sp[k1,k2]^2*sp[k3,q]*m
       - 32*sp[k1,k2]^2*sp[k4,q] - 64*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] + 
      32*sp[k1,k2]*sp[k1,k3]*sp[k2,k3]*m - 64*sp[k1,k2]*sp[k1,k3]*sp[k2
      ,k4] + 64*sp[k1,k2]*sp[k1,k3]*sp[k2,q] - 32*sp[k1,k2]*sp[k1,k3]*
      sp[k2,q]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 16*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 128*sp[k1,
      k2]*sp[k1,k4]*sp[k2,k3] + 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 
      160*sp[k1,k2]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k1,k4]*sp[k2,q
      ]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k2,k3] + 64*sp[k1,k2]*sp[
      k1,q]*sp[k2,k3]*m + 32*sp[k1,k2]*sp[k1,q]*sp[k2,k4] + 16*sp[k1,k2
      ]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[k2,k4] + 32*
      sp[k1,k2]*sp[k2,k3]*sp[k2,k4]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k3,k4
      ] + 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 192*sp[k1,k2]*sp[k2,k3]*
      sp[k4,q] + 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[
      k2,k4]*sp[k2,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k2,q]*m + 128*sp[k1,
      k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 64
      *sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       - 64*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 16*sp[k1,k2]*sp[k2,k4]*sp[k4
      ,q]*m + 160*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 48*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]^2 + 48*sp[k1,k2]*sp[k3,k4]^2
      *m - 8*sp[k1,k2]*sp[k3,k4]^2*m^2 - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ] + 48*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q]*m^2 + 32*sp[k1,k3]^2*sp[k2,k4] - 16*sp[k1,k3]^2*sp[k2,k4]*m
       - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k3]*m + 96*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q]*m + 32*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] + 16*sp[
      k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,k4]^2 + 32*sp[
      k1,k3]*sp[k2,k4]^2*m - 96*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*sp[k1
      ,k3]*sp[k2,k4]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 48
      *sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[k3,k4
      ]*m^2 - 32*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 8*sp[k1,k3]*sp[k2,k4]
      *sp[k4,q]*m^2 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 48*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3]^2 - 16*sp[k1,k4]*
      sp[k2,k3]^2*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,k4]
      *sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 
      32*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]
      *m + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 48*sp[k1,k4]*sp[k2,k3]*
      sp[k3,k4]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 256*sp[k1,k4]
      *sp[k2,k3]*sp[k4,q] - 160*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 24*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,k4]*sp[k2,k4]*sp[k2,q]
       + 208*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m - 32*sp[k1,k4]*sp[k2,k4]*
      sp[k2,q]*m^2 - 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 96*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 - 192*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] + 112*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       - 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 64*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] + 64*sp[k1,q]*sp[k2,k4]^2 - 16*sp[k1,q]*sp[k2,k4]^2*m
       + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m] + amp[16,16]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[
      sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*den[sp[ - k3
       - k4]]*num[32*sp[k1,k2]^2*sp[k3,k4] + 32*sp[k1,k2]^2*sp[k3,q] - 
      16*sp[k1,k2]^2*sp[k3,q]*m - 32*sp[k1,k2]^2*sp[k4,q] + 16*sp[k1,k2
      ]^2*sp[k4,q]*m + 192*sp[k1,k2]*sp[k1,k3]*sp[k2,k3] - 64*sp[k1,k2]
      *sp[k1,k3]*sp[k2,k3]*m - 32*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 96*
      sp[k1,k2]*sp[k1,k3]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k3]*sp[k2,q]*m
       - 256*sp[k1,k2]*sp[k1,k3]*sp[k3,q] + 144*sp[k1,k2]*sp[k1,k3]*sp[
      k3,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q] + 16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 32*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 96*
      sp[k1,k2]*sp[k1,k4]*sp[k2,q] + 48*sp[k1,k2]*sp[k1,k4]*sp[k2,q]*m
       - 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 80*sp[k1,k2]*sp[k1,k4]*sp[k3
      ,q]*m - 8*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 - 32*sp[k1,k2]*sp[k1,q
      ]*sp[k2,k3] + 16*sp[k1,k2]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k2]*
      sp[k1,q]*sp[k2,k4] - 16*sp[k1,k2]*sp[k1,q]*sp[k2,k4]*m - 32*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 48*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m^2 + 96*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2
      ,k4]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,k2]
      *sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,k2]*sp[k2,k4]*sp[k4,q] + 80*sp[
      k1,k2]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k4,q]*m^2
       - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m - 448*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 224*sp[k1,k2]*sp[k3,k4
      ]*sp[k3,q]*m - 24*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 - 192*sp[k1,k2
      ]*sp[k3,k4]*sp[k4,q] + 112*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 16*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 192*sp[k1,k3]^2*sp[k2,q] - 112
      *sp[k1,k3]^2*sp[k2,q]*m + 16*sp[k1,k3]^2*sp[k2,q]*m^2 - 32*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m + 8*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 
      64*sp[k1,k3]*sp[k1,q]*sp[k2,k3] - 80*sp[k1,k3]*sp[k1,q]*sp[k2,k3]
      *m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k3]*m^2 + 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 64*sp[k1,k3]*sp[
      k2,k3]*sp[k2,k4] - 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m - 256*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q] + 96*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 8*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 - 96*sp[k1,k3]*sp[k2,k4]^2 + 32*
      sp[k1,k3]*sp[k2,k4]^2*m - 32*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 16*
      sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 192*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 80*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 8*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m^2 + 96*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,
      k4]*sp[k4,q]*m + 192*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 112*sp[k1,k3]
      *sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 + 64*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 48*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m
       + 8*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 128*sp[k1,k4]*sp[k2,k3]^2
       + 48*sp[k1,k4]*sp[k2,k3]^2*m + 160*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 96*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 8*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 48*sp[k1,k4
      ]*sp[k2,k3]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 48*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m + 8*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2
       + 32*sp[k1,k4]*sp[k2,k4]*sp[k2,q] - 48*sp[k1,k4]*sp[k2,k4]*sp[k2
      ,q]*m + 16*sp[k1,k4]*sp[k2,k4]*sp[k2,q]*m^2 - 224*sp[k1,k4]*sp[k2
      ,k4]*sp[k3,q] + 112*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 8*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 160*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 24*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*
      m^2 - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 8*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 320*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 176*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m + 24*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 96*
      sp[k1,q]*sp[k2,k4]^2 - 80*sp[k1,q]*sp[k2,k4]^2*m + 16*sp[k1,q]*
      sp[k2,k4]^2*m^2 + 96*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 80*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2])
