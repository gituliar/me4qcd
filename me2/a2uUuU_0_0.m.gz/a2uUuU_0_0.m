(amp[1,1]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k2]]*
      den[sp[k1 - q]]*den[sp[k2 + k3]]*den[sp[k3 - q]]*num[128*sp[k1,k2
      ]*sp[k1,k3]*sp[k3,k4] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q] - 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m^2 - 256*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 128*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2
       - 448*sp[k1,k2]*sp[k3,k4] + 304*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1
      ,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 640*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 480*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 
      112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,
      q]*m^3 - 256*sp[k1,k3]^2*sp[k2,k4] + 160*sp[k1,k3]^2*sp[k2,k4]*m
       - 16*sp[k1,k3]^2*sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,
      k3] - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k3]*m^2 - 256*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 128*sp[k1,k3]
      *sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 256
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*
      m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k2,k3]
      *sp[k4,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 704*sp[k1,k3]*sp[
      k2,k4] - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2
       - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m^2 - 256*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 896*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 608*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^3 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1
      ,q]*sp[k2,k3]*m - 448*sp[k1,k4]*sp[k2,k3] + 304*sp[k1,k4]*sp[k2,
      k3]*m - 64*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 
      256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,
      q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 256*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 96*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2
       + 640*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 480*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m + 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3
      ]*sp[k4,q]*m^3 - 640*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 320*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 256*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m
       + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[1,2]*color[ - 4/9*Cf
      *Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[
      sp[k2 + k3]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[k4,
      q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 128*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2
       - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m - 416*sp[k1,k2]*sp[k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 56
      *sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 256*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 512*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ] - 384*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 256*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 16*sp[k1
      ,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 320*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       + 160*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 544*sp[k1,k3]*
      sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*
      m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 320*sp[k1,k3]*sp[k2,k4]*sp[k4,q
      ] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[
      k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 128*sp[k1,k4]^2*sp[k2,k3] + 96*sp[
      k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]*m^2 + 128*sp[k1,
      k4]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 224*sp[k1,k4]*sp[k2,k3] + 208*
      sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*
      sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 64*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 256*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,
      q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 32*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q]
       + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[1,3]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k4]]*
      den[sp[k1 - q]]*den[sp[ - k2 + q]]*den[sp[k2 + k3]]*num[128*sp[k1
      ,k2]^2*sp[k3,k4] + 128*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,
      k2]*sp[k1,k3]*sp[k4,q] - 256*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 64*
      sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q
      ] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*
      sp[k3,k4] + 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2
      ,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k2]
      *sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q] - 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 64*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q] + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3
      ]*sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3]*m + 32*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,
      k4]*sp[k2,k3]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 32
      *sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3
      ,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] + 48*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[1,4]*color[4/9*
      Na*Tf^2]*den[sp[ - k1 - k4]]*den[sp[k1 - q]]*den[sp[k2 + k3]]*
      den[sp[k3 - q]]*num[ - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 64*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]
       - 32*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 64*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 
      128*sp[k1,k3]^2*sp[k2,k4] + 256*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 
      64*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] + 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 128*sp[k1,k3]*sp[k1,q
      ]*sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[
      k2,k3]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k4]
      *sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 32*sp[
      k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 128*sp[k1,k4]
      *sp[k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 128*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 
      64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m] + amp[1,5]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]^2*den[sp[ - k2
       - k3]]*den[sp[k2 + k3]]*num[64*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2
      ]*sp[k3,k4]*m + 64*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m
       - 128*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,
      k4]*sp[k2,k3]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 192*sp[k1,q
      ]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 128
      *sp[k1,q]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,q]*sp[k2,q]*sp[k3,
      k4]*m] + amp[1,6]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1
       - q]]^2*den[sp[k2 + k3]]*den[sp[ - k3 - k4]]*num[ - 64*sp[k1,k2]
      *sp[k3,k4] + 80*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k3]*sp[k2,k4] - 144*
      sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*
      sp[k2,k4]*m^3 - 64*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[k2,k3]*m
       - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] - 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m
       + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m^3 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 160*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[1,7]*color[4/9*Na*
      Tf^2]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[
      sp[ - k4 + q]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*
      sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k3,k4] - 32*sp[k1
      ,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 128*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[
      k1,k3]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64
      *sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[
      k1,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 128*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 256*
      sp[k1,k4]^2*sp[k2,k3] + 64*sp[k1,k4]^2*sp[k2,k3]*m + 256*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3] - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 448*
      sp[k1,k4]*sp[k2,k3] + 192*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*
      sp[k2,k3]*m^2 + 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 64*sp[k1
      ,k4]*sp[k2,q]*sp[k3,k4] + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 64*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 512*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 256*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m^2 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[1,8]
      *color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 - q]]*den[sp[ - 
      k2 + q]]*den[sp[k2 + k3]]*den[sp[ - k3 - k4]]*num[ - 128*sp[k1,k2
      ]^2*sp[k3,k4] + 96*sp[k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3
      ,k4]*m^2 + 256*sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 160*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2 + 64*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]
       + 96*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k2,k3]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 96*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2
       + 256*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 160*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      96*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m^2 - 224*sp[k1,k2]*sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m - 
      56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 320*sp[k1,k3]*sp[k1,q]*sp[
      k2,k4] + 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4]*m^2 + 544*sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,
      k4]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 
      64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^2 + 256*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 128*sp[k1,k4]*sp[
      k1,q]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 416*sp[
      k1,k4]*sp[k2,k3] + 272*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2
      ,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 512*sp[
      k1,q]*sp[k2,k3]*sp[k4,q] - 384*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96
      *sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*
      m^3 - 640*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 256*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[2,1]*color[4/9*Na*Tf^2]*
      den[sp[ - k1 - k2]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*den[sp[k3 - 
      q]]*num[256*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1
      ,k2]*sp[k1,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32
      *sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4] + 16*sp[
      k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 32*sp[k1,
      k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 32*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 128*sp[k1,k3]^2*sp[k2,k4] - 128*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q] - 32*sp[k1,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3
      ,k4]*m - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2
      ,k3] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*
      sp[k3,q] + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,
      q]*sp[k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 128*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m]
       + amp[2,2]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 - q]
      ]*den[sp[k3 + k4]]*den[sp[ - k4 + q]]*num[ - 64*sp[k1,k2]*sp[k1,
      k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 256*sp[k1,k2]*
      sp[k1,k4]*sp[k3,k4] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m + 128*
      sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m
       + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3
      ,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*sp[k1,k2]*sp[k3,k4]*m + 128*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m
       - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,q]*sp[k4,
      q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 64*sp[k1,k3]*sp[k1,k4]
      *sp[k2,q] - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 32*sp[k1,k3]*sp[k2,
      k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k4]^2*sp[k2,
      k3] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*sp[k2,k3]
       - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q] + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 16*sp[k1,k4]*sp[k2
      ,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 48*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]
      *sp[k2,k4]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[2,3]*color[ - 4/9*Cf*Na*Tf
       + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k4]]*den[sp[k1 - q]]*den[sp[ - k2
       + q]]*den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]^2*sp[k3,k4] + 96*sp[
      k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 256*sp[k1,
      k2]*sp[k1,k3]*sp[k2,k4] - 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 
      16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2 - 320*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] + 160*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 96*sp[
      k1,k2]*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*
      m^2 + 256*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k1,k4]*
      sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4] - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,
      q] + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 224*sp[k1,k2]*
      sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       - 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4
      ,q]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q]*m + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 544*sp[k1,k3]*
      sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*
      m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 320*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] + 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[
      k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 416*sp[k1,k4]*sp[k2,k3] + 
      272*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,
      k4]*sp[k2,k3]*m^3 + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,
      k4]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 
      512*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 384*sp[k1,k4]*sp[k2,q]*sp[k3,q]
      *m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m^3 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q
      ]*sp[k2,k3]*sp[k4,q]*m - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 128*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 256*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m^3] + amp[2,4]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf
      ]*den[sp[ - k1 - k4]]*den[sp[k1 - q]]*den[sp[k3 + k4]]*den[sp[k3
       - q]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 96*sp[k1,k2]*sp[k1
      ,k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 256*sp[
      k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 
      16*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k1,k4]*sp[
      k3,q] - 96*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m - 448*sp[k1,k2]*sp[k3,k4] + 304*sp[k1,k2]*
      sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*
      m^3 - 256*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 128*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 256*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m^2 - 256*sp[k1,k3]^2*sp[k2,k4] + 160*sp[k1
      ,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]^2*sp[k2,k4]*m^2 + 128*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k3] - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2
      ,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m + 256*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] - 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[
      k1,q]*sp[k2,k4]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 128*sp[
      k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2
       + 704*sp[k1,k3]*sp[k2,k4] - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1
      ,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 256*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[
      k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4]
       - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 896*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 608*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 256*sp[k1,k4
      ]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 448*sp[k1,k4]*sp[k2,k3] + 304*
      sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*
      sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m + 640*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 480*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2
       - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 96*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3
      ]*sp[k3,k4]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 640*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 320*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 640*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 480*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[2,5]*
      color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 - q]]^2*den[sp[
       - k2 - k3]]*den[sp[k3 + k4]]*num[ - 64*sp[k1,k2]*sp[k3,k4] + 80*
      sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*
      sp[k3,k4]*m^3 + 128*sp[k1,k3]*sp[k2,k4] - 144*sp[k1,k3]*sp[k2,k4]
      *m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 64*
      sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[
      k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] - 160*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 - 256*sp[k1,
      q]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 96*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^3 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 160*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m^3] + amp[2,6]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]^2
      *den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]*sp[k3,
      k4] + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 64*
      sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[
      k2,k3] - 32*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,
      q] + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,q]*sp[k2,
      q]*sp[k3,k4] - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*
      sp[k2,q]*sp[k3,k4]*m^2] + amp[2,7]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca
      *Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[k3 + k4]]*den[
      sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 96*
      sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4
      ]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q]*m + 256*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 128*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 416*
      sp[k1,k2]*sp[k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*
      sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*sp[k1,k2]*
      sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 256*sp[k1,
      k3]*sp[k1,k4]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m + 
      16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[
      k2,q] - 320*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 160*sp[k1,k3]*sp[k1,q]
      *sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 544*sp[k1,k3
      ]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*
      m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q]
       - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1,k4]^2*sp[
      k2,k3] + 96*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]*
      m^2 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 224*sp[k1,k4]
      *sp[k2,k3] + 208*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q
      ] - 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m^2 - 320*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 256*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[k1,k4]*sp[k2,q]*
      sp[k3,q] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,
      q]*sp[k3,q]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 256*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 
      32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 640*sp[k1,q]*sp[k2,k4]*sp[k3,
      q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 512*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 384*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3]
       + amp[2,8]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]*den[sp[ - k2 + q]]
      *den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[ - 256*sp[k1,k2]^2*sp[
      k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k3]*sp[
      k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[k1,k4
      ]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 256*sp[k1,k2]*sp[
      k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 64*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 256*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 
      448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2
      ]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 64*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*
      sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 128*sp[k1,k3]*sp[
      k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 64*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2
      ,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,q]
      *sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2
      ,k3]*sp[k2,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1
      ,q]*sp[k2,k4]*sp[k3,q]*m + 512*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 256*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2] + amp[3,1]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - 
      k1 - k2]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[k3 - q]]*
      num[ - 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k3]
      *sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 + 256*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q
      ] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 416*sp[k1,k2]*sp[
      k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*m^2
       + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 256*sp[k1,k2]*sp[k3,k4]*sp[k3,q]
       - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m^2 + 512*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 384*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 256*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]
       - 160*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*
      sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 544*sp[k1,k3]*
      sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*
      m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q]
       - 320*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 256*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 224*sp[k1,k4]*sp[k2,k3] + 208*
      sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*
      sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]^2 + 96*sp[k1,k4]*sp[k2,k3
      ]^2*m - 16*sp[k1,k4]*sp[k2,k3]^2*m^2 + 128*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 96*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 
      256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 256*sp[k1,k4]*sp[k2,q]*sp[k3,q]
      *m + 80*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m^3 - 320*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 160*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 - 128
      *sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m
       + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,q]*sp[k2,k3]*sp[k4,
      q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 640*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[
      k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + 
      amp[3,2]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k2]
      ]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[ - k4 + q]]*num[128*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,k2]*sp[k2,k4]*
      sp[k3,k4] - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[
      k2,k4]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m - 256*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 
      128*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,q]*sp[k3,
      k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4] + 304*sp[k1,k2]*sp[k3,k4]*m - 
      64*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 
      640*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 480*sp[k1,k2]*sp[k3,q]*sp[k4,q]
      *m + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m^3 + 704*sp[k1,k3]*sp[k2,k4] - 432*sp[k1,k3]*sp[k2,k4]*
      m + 80*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 256*
      sp[k1,k3]*sp[k2,k4]^2 + 160*sp[k1,k3]*sp[k2,k4]^2*m - 16*sp[k1,k3
      ]*sp[k2,k4]^2*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 160*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 
      256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k4,
      q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 640*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] + 320*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m^2 - 448*sp[k1,k4]*sp[k2,k3] + 304*sp[k1,k4]*
      sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*
      m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 96*sp[k1,k4]*sp[k2,k3]*
      sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m^2 + 128*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 256*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,k4]*sp[k2,k4]*
      sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m^2 + 640*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 480*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 - 256*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4] + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 128*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2
       - 256*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 128*sp[k1,q]*sp[k2,k4]*sp[
      k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 896*sp[k1,q]*sp[
      k2,k4]*sp[k3,q] + 608*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q
      ]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 
      256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[3,3]*color[4/9*Na*
      Tf^2]*den[sp[ - k1 - k4]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]^2*
      num[64*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m + 64*sp[k1,
      k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,q]
      *sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k4]*sp[
      k2,k3] + 96*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 + 
      256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 192*sp[k1,k4]*sp[k2,q]*sp[k3,q]
      *m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]*sp[k2,q]*
      sp[k3,k4] + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3,4]*color[4/
      9*Na*Tf^2]*den[sp[ - k1 - k4]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]
      ]*den[sp[k3 - q]]*num[128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 64*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64
      *sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k3,k4] - 32*sp[
      k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 128*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q]
       + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 128*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 
      32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 448*sp[k1,k4]*sp[k2,k3] + 192*
      sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 - 256*sp[k1,k4
      ]*sp[k2,k3]^2 + 64*sp[k1,k4]*sp[k2,k3]^2*m + 256*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 256*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 512*sp[
      k1,k4]*sp[k2,q]*sp[k3,q] - 256*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32
      *sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4
      ] - 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 256*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] - 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]
      *sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3,5]*
      color[4/9*Na*Tf^2]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2
       - k3]]*den[sp[ - k2 + q]]*num[128*sp[k1,k2]^2*sp[k3,k4] + 128*
      sp[k1,k2]*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q]
       - 256*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k2]*sp[k1,k4]*sp[
      k2,k3]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 128*sp[k1,k2]
      *sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 64*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32
      *sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 16*sp[k1,
      k2]*sp[k3,q]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 32*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4]
       + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 
      128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3
      ]*m + 32*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k4]*sp[k2,k3]*m + 128*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 
      128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k2
      ,k4]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,
      k4]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 48*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m] + amp[3,6]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*
      Tf]*den[sp[k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 + q]]*den[sp[
       - k3 - k4]]*num[ - 128*sp[k1,k2]^2*sp[k3,k4] + 96*sp[k1,k2]^2*
      sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k1,
      k3]*sp[k2,k4] - 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m + 16*sp[k1,k2
      ]*sp[k1,k3]*sp[k2,k4]*m^2 - 320*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      160*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,k2]*sp[k1,
      k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m^2 + 256*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 
      16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4] - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q
      ]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k2]
      *sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 128*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 224*sp[k1,k2]*sp[k3,k4] + 
      208*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,
      k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 96*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m
       + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 544*sp[k1,k3]*sp[k2,k4] - 
      368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,
      k3]*sp[k2,k4]*m^3 - 320*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 160*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 - 
      640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[k2,q]*sp[k4,q]
      *m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m^3 - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 32*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m - 416*sp[k1,k4]*sp[k2,k3] + 272*sp[k1,k4]*
      sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*
      m^3 + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 512*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] - 384*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 
      64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
      *m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 256*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 80*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3]
       + amp[3,7]*color[4/9*Na*Tf^2]*den[sp[k1 + k4]]*den[sp[ - k2 - k3
      ]]*den[sp[ - k2 + q]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k2]*
      sp[k2,k4]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4] + 64*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 16*sp[k1,k2
      ]*sp[k3,q]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,k4] - 128*sp[k1,k3]*
      sp[k2,k4]^2 + 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q] + 128*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 48*sp[k1,k3
      ]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]*sp[k2,k3] + 16*sp[k1,k4]*sp[
      k2,k3]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k4]*sp[k2
      ,k3]*sp[k2,k4]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k4
      ]*sp[k2,k3]*sp[k2,q]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 128*sp[k1,q]*sp[
      k2,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 128*sp[k1,
      q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[
      k1,q]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 
      16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[3,8]*color[ - 4/9*Cf*Na*
      Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]^2*den[sp[
       - k3 - k4]]*num[ - 64*sp[k1,k2]*sp[k3,k4] + 80*sp[k1,k2]*sp[k3,
      k4]*m - 32*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 
      128*sp[k1,k3]*sp[k2,k4] - 144*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3
      ]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2
      ,q]*sp[k4,q] + 288*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 96*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 64*
      sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[
      k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,q]*
      sp[k3,q] - 160*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2
      ,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 128*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] - 160*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 64*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^3] + amp[4,1]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[ - 
      k2 + q]]*den[sp[k3 + k4]]*den[sp[k3 - q]]*num[ - 256*sp[k1,k2]*
      sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m + 128*
      sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m
       - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3
      ,q]*m + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*sp[k1,k2]*sp[k3,k4]*m
       + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k3,k4]*sp[
      k3,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,
      k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k3
      ]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 32*sp[k1
      ,k4]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3]^2 - 128*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,k4]*
      sp[k2,q]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q
      ]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 16
      *sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q]
       - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,q]*sp[k3
      ,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[4,2]*color[4/9*Na*
      Tf^2]*den[sp[ - k1 - k2]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*
      den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q]*m + 256*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 
      64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k2,q
      ]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k2]*
      sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*sp[k1,k2]*sp[
      k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 32*sp[k1,k3]*
      sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]*sp[
      k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m] + amp[4,3]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*
      den[sp[ - k1 - k4]]*den[sp[ - k2 + q]]^2*den[sp[k3 + k4]]*num[ - 
      64*sp[k1,k2]*sp[k3,k4] + 80*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*
      sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k3]*sp[k2,
      k4] - 144*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*
      sp[k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 288*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 64*sp[k1,k4]*sp[k2,k3]
       + 80*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[
      k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2
       - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,q]*sp[
      k3,k4] - 160*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,q]*sp[k2,q]
      *sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[4,4]*
      color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k4]]*den[sp[
       - k2 + q]]*den[sp[k3 + k4]]*den[sp[k3 - q]]*num[ - 128*sp[k1,k2]
      *sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k2,k3]*sp[k4
      ,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k2,k4]*
      sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[
      k2,q]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,
      k2]*sp[k2,q]*sp[k3,k4]*m^2 - 416*sp[k1,k2]*sp[k3,k4] + 272*sp[k1,
      k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,
      k4]*m^3 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 256*sp[k1,k3]*sp[k2,k3]*sp[k2,k4] - 160*sp[
      k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*
      m^2 - 320*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 160*sp[k1,k3]*sp[k2,k3]*
      sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 544*sp[k1,k3]*
      sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*
      m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 320*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] + 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 640*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 112*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^3 - 224*sp[k1,k4]*sp[k2,k3] + 208*sp[k1,k4]*sp[k2,k3]*m - 56*
      sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,
      k4]*sp[k2,k3]^2 + 96*sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2
      ,k3]^2*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 96*sp[k1,k4]*sp[
      k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 128*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 
      16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[
      k3,q] - 256*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 80*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 + 64*sp[k1,q]*
      sp[k2,k3]*sp[k2,k4] + 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2
       + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,q]*sp[k2,k3]*sp[k4,
      q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 256*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q] + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[
      k2,k4]*sp[k3,q]*m^2 + 512*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 384*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8
      *sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[4,5]*color[ - 4/9*Cf*Na*
      Tf + 2/9*Ca*Na*Tf]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[ - 
      k2 + q]]*den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]^2*sp[k3,k4] + 96*
      sp[k1,k2]^2*sp[k3,k4]*m - 16*sp[k1,k2]^2*sp[k3,k4]*m^2 + 256*sp[
      k1,k2]*sp[k1,k3]*sp[k2,k4] - 160*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m
       + 16*sp[k1,k2]*sp[k1,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k2]*sp[k1,k3]*
      sp[k4,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,k2]*sp[k1
      ,k4]*sp[k2,k3]*m - 16*sp[k1,k2]*sp[k1,k4]*sp[k2,k3]*m^2 - 128*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 
      128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 96*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,
      k3]*sp[k4,q] - 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*
      sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 160*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*
      m^2 + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,q]*
      sp[k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 224*sp[k1,k2]
      *sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       - 96*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4
      ,q]*m^2 + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*sp[k1,k4
      ]*sp[k2,q]*m - 320*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 160*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 544*
      sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*
      sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4
      ]*sp[k2,q] - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 256*sp[k1
      ,k4]*sp[k1,q]*sp[k2,k3] - 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m + 16
      *sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 416*sp[k1,k4]*sp[k2,k3] + 272
      *sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]
      *sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 32*sp[k1
      ,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*
      sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m + 512*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 384*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 - 640*sp[k1,q]*sp[
      k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q
      ]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 
      256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 80*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^3] + amp[4,6]*color[4/9*Na*Tf^2]*den[sp[k1 - q]]*den[sp[
       - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 + k4]]*num[ - 256*sp[k1
      ,k2]^2*sp[k3,k4] + 64*sp[k1,k2]^2*sp[k3,k4]*m + 128*sp[k1,k2]*sp[
      k1,k3]*sp[k2,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2
      ]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 256*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 
      64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
       + 256*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4]*m - 448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16
      *sp[k1,k2]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 64*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q]
       - 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4] - 32
      *sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 128*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 
      64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3] - 32*
      sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[
      k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 128
      *sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[
      k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 512*sp[k1,q]*sp[k2,q]*
      sp[k3,k4] - 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2
      ,q]*sp[k3,k4]*m^2] + amp[4,7]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*
      Tf]*den[sp[ - k2 - k3]]*den[sp[ - k2 + q]]*den[sp[k3 + k4]]*den[
      sp[ - k4 + q]]*num[128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,k2
      ]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 
      128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,k4]*sp[k3,
      k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*sp[
      k2,k4]*sp[k3,q] + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,
      k2]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 448*sp[k1,k2]*sp[k3,k4] + 304
      *sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]
      *sp[k3,k4]*m^3 - 256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 128*sp[k1,k2]
      *sp[k3,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 256
      *sp[k1,k2]*sp[k3,q]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 704*sp[k1,k3]*sp[k2,k4]
       - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[
      k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,k4]^2 + 160*sp[k1,k3]*
      sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 256*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 320*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 448*sp[k1,k4]
      *sp[k2,k3] + 304*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 128
      *sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 128*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 640*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 480*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m + 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^3 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 
      32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 896*sp[k1,q]*sp[k2,k4]*sp[k3,
      q] + 608*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 640*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 480*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 112*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3]
       + amp[4,8]*color[4/9*Na*Tf^2]*den[sp[ - k2 + q]]^2*den[sp[ - k3
       - k4]]*den[sp[k3 + k4]]*num[ - 128*sp[k1,k2]*sp[k3,k4] + 96*sp[
      k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 64*sp[k1,k3]*
      sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k3]
       - 32*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 
      64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ] - 192*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^2] + amp[5,1]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k2]]*
      den[sp[k1 + k2]]*den[sp[k3 - q]]^2*num[ - 128*sp[k1,k2]*sp[k3,k4]
       + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 256*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 192*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 
      32*sp[k1,k3]*sp[k2,k4]*m + 64*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*
      sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 64*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m] + amp[5,2]*color[4/9*Na*Tf^2]*den[sp[ - k1
       - k2]]*den[sp[k1 + k2]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[
       - 448*sp[k1,k2]*sp[k3,k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1
      ,k2]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*sp[k3,k4]^2 + 64*sp[k1,k2]*sp[
      k3,k4]^2*m + 256*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 64*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q]*m + 512*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 256*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 + 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4]
       - 32*sp[k1,k3]*sp[k2,k4]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]
       - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q] - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k3]*sp[k2,q]*
      sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k4]*sp[k2
      ,k3] - 32*sp[k1,k4]*sp[k2,k3]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4] - 64*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q] + 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,
      q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]
      *sp[k2,k3]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1
      ,q]*sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4]
       - 64*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[5,3]*color[ - 4/9*Cf*
      Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k4]]*den[sp[k1 + k2]]*den[
      sp[ - k2 + q]]*den[sp[k3 - q]]*num[ - 128*sp[k1,k2]*sp[k2,k3]*sp[
      k3,k4] + 96*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2 + 
      64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]
      *m - 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m - 416*sp[k1,k2]*sp[k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 
      56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 256*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 512*sp[k1,k2]*sp[k3,q]*sp[
      k4,q] - 384*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 96*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 256*sp[k1,k3]
      *sp[k2,k3]*sp[k2,k4] - 160*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*
      sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,
      q] + 544*sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[
      k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*
      sp[k2,k4]*sp[k2,q] - 320*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 160*sp[k1
      ,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2
       + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 224*sp[k1,k4]*
      sp[k2,k3] + 208*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]^2 + 96*
      sp[k1,k4]*sp[k2,k3]^2*m - 16*sp[k1,k4]*sp[k2,k3]^2*m^2 + 128*sp[
      k1,k4]*sp[k2,k3]*sp[k2,q] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 
      16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] - 96*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3
      ]*sp[k3,q]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 256*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m + 80*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m^3 - 320*sp[k1,q]*sp[k2,k3]*sp[k2,k4]
       + 160*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[
      k2,k4]*m^2 - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 96*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 640*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m^3 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m] + amp[5,4]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*
      den[sp[ - k1 - k4]]*den[sp[k1 + k2]]*den[sp[k3 - q]]^2*num[ - 64*
      sp[k1,k2]*sp[k3,k4] + 80*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[
      k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] - 160*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3
      ,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 128*sp[k1,
      k3]*sp[k2,k4] - 144*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4
      ]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 64*sp[k1,k4]*sp[k2,k3] + 80*
      sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*
      sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m^3 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      288*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3] + amp[5,5]*color[ - 4/
      9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1 - q]]*den[
      sp[ - k2 - k3]]*den[sp[k3 - q]]*num[128*sp[k1,k2]*sp[k1,k3]*sp[k3
      ,k4] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,k3
      ]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k1,k3]*sp[k4,q]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 96*sp[
      k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2
       - 256*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k1,q]*sp[
      k3,k4]*m - 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2 - 448*sp[k1,k2]*
      sp[k3,k4] + 304*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ] - 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 640*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] - 480*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 112*sp[k1,k2]*sp[
      k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 - 256*sp[
      k1,k3]^2*sp[k2,k4] + 160*sp[k1,k3]^2*sp[k2,k4]*m - 16*sp[k1,k3]^2
      *sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 96*sp[k1,k3]
      *sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m^2 - 
      256*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,
      q]*m - 16*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*
      sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 704*sp[k1,k3]*sp[k2,k4] - 432*
      sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*
      sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 160*sp[k1,k3]*
      sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m^2 - 256*
      sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m
       - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 896*sp[k1,k3]*sp[k2,q]*
      sp[k4,q] + 608*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 + 128*sp[
      k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 
      448*sp[k1,k4]*sp[k2,k3] + 304*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4
      ]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 256*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m - 16*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 128*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 640*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] - 480*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 112*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3
       - 640*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 320*sp[k1,q]*sp[k2,k4]*sp[k3
      ,q]*m - 32*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 256*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[
      k2,q]*sp[k3,k4]*m^2] + amp[5,6]*color[4/9*Na*Tf^2]*den[sp[k1 + k2
      ]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[sp[k3 - q]]*num[256*
      sp[k1,k2]*sp[k1,k3]*sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*
      m - 128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k1,k3]*sp[
      k4,q]*m + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,k4
      ]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1,k2]*
      sp[k1,q]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4] + 16*sp[k1,k2]*sp[
      k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] + 32*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m - 128*sp[k1,k3]^2*sp[k2,k4] - 128*sp[k1,k3]*
      sp[k1,k4]*sp[k2,k3] + 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 128*sp[k1
      ,k3]*sp[k1,q]*sp[k2,k4] + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*
      sp[k1,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 128*sp[
      k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 
      64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       + 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 32*sp[k1,k4]*sp[k2,k3] + 64*
      sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 
      16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k3,k4
      ] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 64*sp[k1,q]*sp[k2,k3]*sp[
      k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*
      sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,
      q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[5,7]*
      color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k2]]*den[sp[ - 
      k2 - k3]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[ - 224*sp[k1,k2]
      *sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*sp[k1,k2]*sp[k3,k4]^2 + 96*
      sp[k1,k2]*sp[k3,k4]^2*m - 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 128*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k3,k4]*sp[
      k4,q] - 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 256*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 
      32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 544*sp[k1,k3]*sp[k2,k4] - 368
      *sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]
      *sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 160*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 + 
      64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 320*sp[k1,k3]*sp[k2,k4]*sp[k4,q
      ] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k4]*
      sp[k4,q]*m^2 - 320*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 160*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m^2 - 640*
      sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m
       - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^3 - 416*sp[k1,k4]*sp[k2,k3] + 272*sp[k1,k4]*sp[k2,k3]*m
       - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,k4]*sp[k2,k3
      ]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 256*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 128*sp[k1,k4]*sp[k2,
      q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 256*sp[k1,q]*sp[
      k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,
      q]*sp[k2,k3]*sp[k3,k4]*m^2 + 512*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 
      384*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,q]*sp[k2,k3]*sp[k4,q
      ]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,q]*sp[k2,k4]
      *sp[k3,k4] - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,q]*sp[k2
      ,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[5,8]*color[4/9*Na*Tf^2]*den[
      sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 - q
      ]]*num[ - 256*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,
      k3]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]
      *sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,k2]*sp[k2,k4]*sp[k3,q] + 32*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 16*
      sp[k1,k2]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 32*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k4] - 
      64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k3]*sp[k2,q]*sp[k3,
      k4]*m + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k3] + 128*sp[k1,k4]*sp[k2,k3]^2
       - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[
      k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 48*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,q]*sp[k2
      ,k3]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] - 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,
      q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*
      sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m]
       + amp[6,1]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - 
      k2]]*den[sp[k1 + k4]]*den[sp[k3 - q]]^2*num[ - 64*sp[k1,k2]*sp[k3
      ,k4] + 80*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]*m^2 + 4*
      sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 160*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 128*sp[k1,k3]*sp[k2,k4]
       - 144*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[
      k1,k3]*sp[k2,k4]*m^3 - 64*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]*sp[
      k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3
       + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 160*sp[k1,k4]*sp[k2,q]*sp[k3
      ,q]*m + 64*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]
      *sp[k3,q]*m^3 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 288*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m - 96*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m^3] + amp[6,2]*color[ - 4/9*Cf*Na*Tf + 
      2/9*Ca*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[k1 + k4]]*den[sp[k3 - q]
      ]*den[sp[ - k4 + q]]*num[ - 224*sp[k1,k2]*sp[k3,k4] + 208*sp[k1,
      k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,
      k4]*m^3 - 128*sp[k1,k2]*sp[k3,k4]^2 + 96*sp[k1,k2]*sp[k3,k4]^2*m
       - 16*sp[k1,k2]*sp[k3,k4]^2*m^2 + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ] - 96*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*
      sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 96*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 256*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 256*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 80*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[
      k4,q]*m^3 + 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,
      k3]*sp[k4,q]*m + 544*sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4
      ]*m + 72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 
      256*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3
      ,k4]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m^2 - 320*sp[k1,k3]*sp[
      k2,k4]*sp[k3,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,
      k3]*sp[k2,k4]*sp[k3,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64
      *sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       + 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^2 - 416*sp[k1,k4]*sp[k2,k3] + 272*sp[k1,k4]*sp[k2,k3]*m
       - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*
      sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*
      m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 + 256*sp[k1,k4]*sp[k2,k3
      ]*sp[k3,q] - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m^2 - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q]
       - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 256*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] - 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,
      q]*sp[k3,k4]*m^2 + 512*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 384*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q]*m + 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3 - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4
      ] + 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,k3]*
      sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 320*sp[k1,q]*sp[k2,
      k4]*sp[k3,k4] + 160*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4]*m^2 - 640*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*
      sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*
      m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,q]*
      sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,
      q]*sp[k3,k4]*m^2] + amp[6,3]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k4
      ]]*den[sp[k1 + k4]]*den[sp[ - k2 + q]]*den[sp[k3 - q]]*num[128*
      sp[k1,k2]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k2]*sp[k2,k3]*sp[k4,q]
       + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k2,q]*sp[k3
      ,k4] + 128*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m - 64*
      sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k2,k3]*sp[k2,
      k4] - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4]
       - 32*sp[k1,k3]*sp[k2,k4]*m - 64*sp[k1,k3]*sp[k2,k4]*sp[k2,q] - 
      64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4
      ] - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q]*m - 448*sp[k1,k4]*sp[k2,k3] + 192*sp[k1,k4]*sp[k2,k3]*m - 16*
      sp[k1,k4]*sp[k2,k3]*m^2 - 256*sp[k1,k4]*sp[k2,k3]^2 + 64*sp[k1,k4
      ]*sp[k2,k3]^2*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 64*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 64*sp[
      k1,k4]*sp[k2,k3]*sp[k3,q]*m + 512*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 
      256*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q
      ]*m^2 - 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*sp[k1,q]*sp[k2,k3]*
      sp[k3,k4] + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,q]*sp[k2,
      k3]*sp[k4,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m] + amp[6,4]*color[4/9*Na*Tf^2]*den[sp[
       - k1 - k4]]*den[sp[k1 + k4]]*den[sp[k3 - q]]^2*num[64*sp[k1,k2]*
      sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,q]*sp[
      k4,q] + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4]
       - 32*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,
      k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 + 256*sp[k1,k4]*sp[
      k2,q]*sp[k3,q] - 192*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 32*sp[k1,k4]
      *sp[k2,q]*sp[k3,q]*m^2 - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 64*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m] + amp[6,5]*color[4/9*Na*Tf^2]*den[sp[
      k1 + k4]]*den[sp[k1 - q]]*den[sp[ - k2 - k3]]*den[sp[k3 - q]]*
      num[ - 128*sp[k1,k2]*sp[k1,k3]*sp[k3,k4] + 64*sp[k1,k2]*sp[k1,k3]
      *sp[k4,q] + 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m + 64*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*
      sp[k3,k4] + 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k3,
      q]*sp[k4,q] + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 128*sp[k1,k3]^2*
      sp[k2,k4] + 256*sp[k1,k3]*sp[k1,k4]*sp[k2,k3] - 64*sp[k1,k3]*sp[
      k1,k4]*sp[k2,k3]*m - 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] + 32*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q]*m + 128*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 128
      *sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m
       - 32*sp[k1,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 64
      *sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 
      16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k4]*sp[k1,q]*sp[k2,
      k3] + 32*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]
       + 16*sp[k1,k4]*sp[k2,k3]*m - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 
      32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,
      q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,q]*sp[k2,
      k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[
      k2,k4]*sp[k3,q] - 48*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[6,6]
      *color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k4]]*den[sp[k1
       - q]]*den[sp[ - k3 - k4]]*den[sp[k3 - q]]*num[128*sp[k1,k2]*sp[
      k1,k3]*sp[k3,k4] - 96*sp[k1,k2]*sp[k1,k3]*sp[k3,k4]*m + 16*sp[k1,
      k2]*sp[k1,k3]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 
      128*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[k4
      ,q]*m^2 + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 96*sp[k1,k2]*sp[k1,
      k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m^2 + 128*sp[k1,
      k2]*sp[k1,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m - 448*
      sp[k1,k2]*sp[k3,k4] + 304*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*
      sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 256*sp[k1,k2]*sp[k3,
      k4]*sp[k3,q] + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m - 16*sp[k1,k2]*
      sp[k3,k4]*sp[k3,q]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 128*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 - 256*sp[k1,k3]^2*sp[k2,k4] + 160*sp[k1,k3]^2*sp[k2,k4]*m - 
      16*sp[k1,k3]^2*sp[k2,k4]*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]
       - 96*sp[k1,k3]*sp[k1,k4]*sp[k2,k3]*m + 16*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k3]*m^2 + 128*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 32*sp[k1,k3]*
      sp[k1,k4]*sp[k2,q]*m + 256*sp[k1,k3]*sp[k1,q]*sp[k2,k4] - 160*sp[
      k1,k3]*sp[k1,q]*sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2
       - 256*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k3]*sp[
      k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m^2 + 704*sp[k1,k3]*sp[
      k2,k4] - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2
       - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,k4]*sp[k3,q]
       - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m + 16*sp[k1,k3]*sp[k2,k4]*
      sp[k3,q]*m^2 + 128*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*
      sp[k2,q]*sp[k3,k4]*m - 896*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 608*sp[
      k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2
       + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 256*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3] + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k1,
      q]*sp[k2,k3]*m^2 - 448*sp[k1,k4]*sp[k2,k3] + 304*sp[k1,k4]*sp[k2,
      k3]*m - 64*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 
      128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q
      ]*m + 640*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 480*sp[k1,k4]*sp[k2,q]*
      sp[k3,q]*m + 112*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*
      sp[k2,q]*sp[k3,q]*m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 96*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2
       + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,q]*sp[k2,k3]*sp[k4
      ,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 640*sp[k1,q]*sp[k2,
      k4]*sp[k3,q] + 320*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 32*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m^2 + 640*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 480*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 112*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3] + amp[6,7]*color[4/9*Na*
      Tf^2]*den[sp[k1 + k4]]*den[sp[ - k2 - k3]]*den[sp[k3 - q]]*den[
      sp[ - k4 + q]]*num[32*sp[k1,k2]*sp[k3,k4] + 128*sp[k1,k2]*sp[k3,
      k4]^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 128*sp[k1,k2]*sp[k3,k4
      ]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 48*sp[k1,k2]*sp[k3,
      q]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,k4] + 128*sp[k1,k3]*sp[
      k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k3]
      *sp[k2,k4]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] + 64*sp[k1,
      k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 32*sp[
      k1,k4]*sp[k2,k3] - 16*sp[k1,k4]*sp[k2,k3]*m - 256*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m + 128*sp[k1,
      k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m + 128*
      sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[
      k2,q]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 32*sp[k1,q]
      *sp[k2,k3]*sp[k3,k4]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 64
      *sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,q]*sp[k2,q]*sp[k3,k4
      ]*m] + amp[6,8]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1
       + k4]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*den[sp[k3 - q]]*
      num[ - 128*sp[k1,k2]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k2]*sp[k2,k3]
      *sp[k3,k4]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[k3,k4]*m^2 - 128*sp[k1,
      k2]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m + 64*
      sp[k1,k2]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m
       + 256*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k2]*sp[k2,q]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 416*sp[k1,k2]*
      sp[k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*
      m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q
      ] + 32*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 256*sp[k1,k3]*sp[k2
      ,k3]*sp[k2,k4] - 160*sp[k1,k3]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,
      k3]*sp[k2,k3]*sp[k2,k4]*m^2 - 320*sp[k1,k3]*sp[k2,k3]*sp[k4,q] + 
      160*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[k4
      ,q]*m^2 + 544*sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 
      72*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 320*sp[
      k1,k3]*sp[k2,k4]*sp[k2,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m - 
      16*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[
      k3,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4]*m - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m^3 - 224*sp[k1,k4]*sp[k2,k3] + 208*sp[k1,
      k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,
      k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]^2 + 96*sp[k1,k4]*sp[k2,k3]^2*m
       - 16*sp[k1,k4]*sp[k2,k3]^2*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q
      ] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 96*sp[k1,k4]*
      sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 + 256*
      sp[k1,k4]*sp[k2,q]*sp[k3,q] - 256*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m
       + 80*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[
      k3,q]*m^3 + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 256*sp[k1,q]*sp[k2,
      k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m + 16*sp[k1,q]*
      sp[k2,k3]*sp[k3,k4]*m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 96*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*
      m^2 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 512*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 384*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 96*sp[k1
      ,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3]
       + amp[7,1]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[sp[k1 + k2
      ]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*num[ - 448*sp[k1,k2]*sp[k3,
      k4] + 192*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 - 
      256*sp[k1,k2]*sp[k3,k4]^2 + 64*sp[k1,k2]*sp[k3,k4]^2*m + 256*sp[
      k1,k2]*sp[k3,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m + 
      256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ]*m + 512*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 256*sp[k1,k2]*sp[k3,q]*
      sp[k4,q]*m + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 128*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2
      ,k4]*m + 128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,
      k4]*sp[k3,q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4] - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 32*sp[k1,k3]*
      sp[k2,q]*sp[k4,q]*m + 128*sp[k1,k4]*sp[k2,k3] - 32*sp[k1,k4]*sp[
      k2,k3]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] - 64*sp[k1,k4]*sp[k2
      ,k3]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 128*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[
      k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 32*
      sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4]
       - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,
      q]*m + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 64*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m] + amp[7,2]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k2]]*den[
      sp[k1 + k2]]*den[sp[ - k4 + q]]^2*num[ - 128*sp[k1,k2]*sp[k3,k4]
       + 96*sp[k1,k2]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k3,k4]*m^2 + 256*
      sp[k1,k2]*sp[k3,q]*sp[k4,q] - 192*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m
       + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 64*sp[k1,k3]*sp[k2,k4] - 
      32*sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 64*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m + 64*sp[k1,k4]*sp[k2,k3] - 32*sp[k1
      ,k4]*sp[k2,k3]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m] + amp[7,3]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*
      Na*Tf]*den[sp[ - k1 - k4]]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*
      den[sp[ - k4 + q]]*num[128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 + 128*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] - 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 256*sp[
      k1,k2]*sp[k2,q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 
      16*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m^2 - 448*sp[k1,k2]*sp[k3,k4] + 
      304*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,
      k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q]*m + 640*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 480*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 112*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 704*sp[k1,k3]*sp[k2,k4]
       - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[
      k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,k4]^2 + 160*sp[k1,k3]*
      sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 256*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 320*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 448*sp[k1,k4]
      *sp[k2,k3] + 304*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m^2 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,q] - 32*sp[k1,k4]*
      sp[k2,k3]*sp[k2,q]*m - 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 128*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2
       + 128*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,k4]*sp[k2,q
      ]*sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 640*sp[k1,
      k4]*sp[k2,q]*sp[k3,q] - 480*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 112*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^3 - 256*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 128*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m - 16*sp[k1,q]*sp[k2,k3]*sp[k2,k4]*m^2 + 256*sp[k1,q]*
      sp[k2,k3]*sp[k4,q] - 128*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^2 - 256*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,
      k4]*m^2 - 896*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 608*sp[k1,q]*sp[k2,k4
      ]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m^3 + 256*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 128*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*
      m^2] + amp[7,4]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - 
      k1 - k4]]*den[sp[k1 + k2]]*den[sp[k3 - q]]*den[sp[ - k4 + q]]*
      num[ - 224*sp[k1,k2]*sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m - 56*
      sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*sp[k1,
      k2]*sp[k3,k4]^2 + 96*sp[k1,k2]*sp[k3,k4]^2*m - 16*sp[k1,k2]*sp[k3
      ,k4]^2*m^2 + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 96*sp[k1,k2]*sp[
      k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 128*sp[
      k1,k2]*sp[k3,k4]*sp[k4,q] - 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 
      16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 256*sp[k1,k2]*sp[k3,q]*sp[
      k4,q] - 256*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[k3,q]
      *sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 64*sp[k1,k3]*
      sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 544*sp[
      k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*sp[k2
      ,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,k4]*
      sp[k3,k4] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k3]*
      sp[k2,k4]*sp[k3,k4]*m^2 - 320*sp[k1,k3]*sp[k2,k4]*sp[k3,q] + 160*
      sp[k1,k3]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k3]*sp[k2,k4]*sp[k3,q]*
      m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[k2,q]
      *sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 416*sp[k1,k4]*
      sp[k2,k3] + 272*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4] + 96*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]
      *sp[k3,k4]*m^2 + 256*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 128*sp[k1,k4]
      *sp[k2,k3]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k3,q]*m^2 - 128
      *sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3
      ,q]*m + 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]
      *sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 512*sp[k1,k4
      ]*sp[k2,q]*sp[k3,q] - 384*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 96*sp[
      k1,k4]*sp[k2,q]*sp[k3,q]*m^2 - 8*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^3
       - 128*sp[k1,q]*sp[k2,k3]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k3]*sp[k3
      ,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m - 320*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 160*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m^2 - 640*
      sp[k1,q]*sp[k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m
       - 112*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m^3 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q
      ]*sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[7,5]*
      color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k2]]*den[sp[k1
       - q]]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*
      sp[k1,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[
      k1,k2]*sp[k1,k4]*sp[k3,k4] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m
       - 16*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m^2 + 256*sp[k1,k2]*sp[k1,k4]
      *sp[k3,q] - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[
      k1,k4]*sp[k3,q]*m^2 - 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4] + 32*sp[k1
      ,k2]*sp[k1,q]*sp[k3,k4]*m - 416*sp[k1,k2]*sp[k3,k4] + 272*sp[k1,
      k2]*sp[k3,k4]*m - 56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,
      k4]*m^3 + 256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,
      k4]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 512*sp[k1,
      k2]*sp[k3,q]*sp[k4,q] - 384*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 96*
      sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*
      m^3 + 256*sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,k4]
      *sp[k2,k4]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 - 320*sp[k1,
      k3]*sp[k1,k4]*sp[k2,q] + 160*sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m - 16*
      sp[k1,k3]*sp[k1,k4]*sp[k2,q]*m^2 + 64*sp[k1,k3]*sp[k1,q]*sp[k2,k4
      ] + 544*sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[
      k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 - 320*sp[k1,k3]*
      sp[k2,k4]*sp[k4,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m - 16*sp[
      k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q]
       + 480*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 128*sp[k1,k4]^2*
      sp[k2,k3] + 96*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*sp[k2,k3]
      *m^2 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k4]*sp[k1,q]*
      sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 224*sp[k1,k4]
      *sp[k2,k3] + 208*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q
      ] - 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m^2 + 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 128*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 128*sp[
      k1,k4]*sp[k2,q]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q]
       - 256*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k3]*sp[
      k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,q]*sp[k2
      ,k4]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 256*sp[k1,q]
      *sp[k2,k4]*sp[k3,q] + 128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[
      k1,q]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 
      32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[7,6]*color[4/9*Na*Tf^2]*
      den[sp[k1 + k2]]*den[sp[k1 - q]]*den[sp[ - k3 - k4]]*den[sp[ - k4
       + q]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 32*sp[k1,k2]*sp[
      k1,k3]*sp[k4,q]*m - 256*sp[k1,k2]*sp[k1,k4]*sp[k3,k4] + 64*sp[k1,
      k2]*sp[k1,k4]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 32
      *sp[k1,k2]*sp[k1,k4]*sp[k3,q]*m + 128*sp[k1,k2]*sp[k1,q]*sp[k3,k4
      ] - 32*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m + 32*sp[k1,k2]*sp[k3,k4] - 
      16*sp[k1,k2]*sp[k3,k4]*m + 128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 32*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]
       + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*sp[
      k2,k4] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,q]*
      sp[k2,k4] + 32*sp[k1,k3]*sp[k2,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*sp[
      k4,q]*m + 128*sp[k1,k4]^2*sp[k2,k3] - 128*sp[k1,k4]*sp[k1,q]*sp[
      k2,k3] + 32*sp[k1,k4]*sp[k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q
      ] - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,q]*sp[
      k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 64*sp[k1,k4]*sp[k2,q
      ]*sp[k3,q] - 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m - 64*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q] + 48*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m + 64*sp[
      k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128
      *sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m]
       + amp[7,7]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[k1 + k2]
      ]*den[sp[ - k2 - k3]]*den[sp[ - k4 + q]]^2*num[ - 64*sp[k1,k2]*
      sp[k3,k4] + 80*sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]*m^2
       + 4*sp[k1,k2]*sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 
      160*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q
      ]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 128*sp[k1,k3]*sp[k2,
      k4] - 144*sp[k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*
      sp[k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 288*
      sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q]*
      m^2 + 8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 64*sp[k1,k4]*sp[k2,k3]
       + 80*sp[k1,k4]*sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[
      k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 160*sp[
      k1,q]*sp[k2,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2
       - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3] + amp[7,8]*color[4/9*Na*
      Tf^2]*den[sp[k1 + k2]]*den[sp[ - k2 + q]]*den[sp[ - k3 - k4]]*
      den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1
      ,k2]*sp[k2,k3]*sp[k4,q]*m + 256*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 
      64*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k2,k4]*sp[
      k3,q] + 32*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,k2]*sp[k2,q
      ]*sp[k3,k4] + 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 32*sp[k1,k2]*
      sp[k3,k4] + 16*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,k4]*
      sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*sp[k1,k2]*sp[
      k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 32*sp[k1,k3]*
      sp[k2,k4] - 128*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*sp[k2,k4]*
      sp[k2,q] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,
      q]*sp[k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]*sp[
      k2,k3] - 128*sp[k1,k4]*sp[k2,k3]*sp[k2,k4] + 64*sp[k1,k4]*sp[k2,
      k3]*sp[k2,q] + 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q] + 64*sp[k1,k4]*sp[
      k2,k4]*sp[k3,q] + 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*
      sp[k2,q]*sp[k3,k4]*m - 64*sp[k1,k4]*sp[k2,q]*sp[k3,q] + 16*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 64*
      sp[k1,q]*sp[k2,k3]*sp[k4,q] + 16*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] + 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4
      ]*m - 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[
      k3,q]*m + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m] + amp[8,1]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*
      den[sp[ - k1 - k2]]*den[sp[k2 + k3]]*den[sp[k3 - q]]*den[sp[ - k4
       + q]]*num[ - 224*sp[k1,k2]*sp[k3,k4] + 208*sp[k1,k2]*sp[k3,k4]*m
       - 56*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*
      sp[k1,k2]*sp[k3,k4]^2 + 96*sp[k1,k2]*sp[k3,k4]^2*m - 16*sp[k1,k2]
      *sp[k3,k4]^2*m^2 + 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 96*sp[k1,k2
      ]*sp[k3,k4]*sp[k3,q]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k3,q]*m^2 + 
      128*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 96*sp[k1,k2]*sp[k3,k4]*sp[k4,q
      ]*m + 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 256*sp[k1,k2]*sp[k3,q
      ]*sp[k4,q] - 256*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 80*sp[k1,k2]*sp[
      k3,q]*sp[k4,q]*m^2 - 8*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 64*sp[k1
      ,k3]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 544
      *sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*
      sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 256*sp[k1,k3]*sp[k2,
      k4]*sp[k3,k4] - 160*sp[k1,k3]*sp[k2,k4]*sp[k3,k4]*m + 16*sp[k1,k3
      ]*sp[k2,k4]*sp[k3,k4]*m^2 + 64*sp[k1,k3]*sp[k2,k4]*sp[k3,q] - 320
      *sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*
      m - 16*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m^2 - 320*sp[k1,k3]*sp[k2,q]*
      sp[k3,k4] + 160*sp[k1,k3]*sp[k2,q]*sp[k3,k4]*m - 16*sp[k1,k3]*sp[
      k2,q]*sp[k3,k4]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 480*sp[k1
      ,k3]*sp[k2,q]*sp[k4,q]*m - 112*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 
      8*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^3 - 416*sp[k1,k4]*sp[k2,k3] + 272
      *sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]
      *sp[k2,k3]*m^3 - 128*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 96*sp[k1,k4]
      *sp[k2,k3]*sp[k3,k4]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k3,k4]*m^2 - 
      128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k3,q
      ]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 128*sp[k1,k4]*sp[k2,k3]*
      sp[k4,q]*m + 16*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m^2 + 64*sp[k1,k4]*
      sp[k2,k4]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 128*sp[
      k1,k4]*sp[k2,q]*sp[k3,k4] + 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 
      128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m + 256*sp[k1,q]*sp[k2,k3]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4]*m + 16*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m^2 + 512*sp[k1,q]*sp[
      k2,k3]*sp[k4,q] - 384*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 96*sp[k1,q]
      *sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*
      sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 256*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 
      128*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,q]*sp[k2,k4]*sp[k3,q
      ]*m^2 + 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 96*sp[k1,q]*sp[k2,q]*
      sp[k3,k4]*m + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2] + amp[8,2]*
      color[ - 4/9*Cf*Na*Tf + 2/9*Ca*Na*Tf]*den[sp[ - k1 - k2]]*den[sp[
      k2 + k3]]*den[sp[ - k4 + q]]^2*num[ - 64*sp[k1,k2]*sp[k3,k4] + 80
      *sp[k1,k2]*sp[k3,k4]*m - 32*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]
      *sp[k3,k4]*m^3 + 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 160*sp[k1,k2]*
      sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 - 8*sp[
      k1,k2]*sp[k3,q]*sp[k4,q]*m^3 + 128*sp[k1,k3]*sp[k2,k4] - 144*sp[
      k1,k3]*sp[k2,k4]*m + 48*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[
      k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 288*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 96*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 + 8*sp[k1,
      k3]*sp[k2,q]*sp[k4,q]*m^3 - 64*sp[k1,k4]*sp[k2,k3] + 80*sp[k1,k4]
      *sp[k2,k3]*m - 32*sp[k1,k4]*sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]
      *m^3 + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 160*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m^3] + amp[8,3]*color[4/9*Na*Tf^2]*den[sp[ - k1
       - k4]]*den[sp[ - k2 + q]]*den[sp[k2 + k3]]*den[sp[ - k4 + q]]*
      num[64*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k2]*sp[k2,k3]*sp[
      k4,q]*m - 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] + 64*sp[k1,k2]*sp[k2,
      k4]*sp[k3,q] + 64*sp[k1,k2]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k2]*sp[
      k3,k4] + 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,q]*
      sp[k4,q] + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,
      k4] - 128*sp[k1,k3]*sp[k2,k4]^2 + 128*sp[k1,k3]*sp[k2,k4]*sp[k2,q
      ] + 128*sp[k1,k3]*sp[k2,k4]*sp[k4,q] + 64*sp[k1,k3]*sp[k2,q]*sp[
      k4,q] - 48*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 32*sp[k1,k4]*sp[k2,k3]
       + 16*sp[k1,k4]*sp[k2,k3]*m + 256*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]
       - 64*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m - 128*sp[k1,k4]*sp[k2,k3]*
      sp[k2,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m - 128*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q] + 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 128*sp[k1,
      k4]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m + 64*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m
       + 128*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,q]*sp[k3,
      q]*m - 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] + 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 128*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q]*m + 64*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,q]*
      sp[k2,k4]*sp[k3,q] + 16*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 64*sp[k1,
      q]*sp[k2,q]*sp[k3,k4] + 16*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8
      ,4]*color[4/9*Na*Tf^2]*den[sp[ - k1 - k4]]*den[sp[k2 + k3]]*den[
      sp[k3 - q]]*den[sp[ - k4 + q]]*num[32*sp[k1,k2]*sp[k3,k4] + 128*
      sp[k1,k2]*sp[k3,k4]^2 - 128*sp[k1,k2]*sp[k3,k4]*sp[k3,q] - 128*
      sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 64*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      48*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[k4,q
      ] + 32*sp[k1,k3]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,k3]*sp[k2,k4] + 
      128*sp[k1,k3]*sp[k2,k4]*sp[k3,k4] - 64*sp[k1,k3]*sp[k2,k4]*sp[k3,
      q] - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 64*sp[k1,k3]*sp[k2,q]*sp[
      k3,k4] + 64*sp[k1,k3]*sp[k2,q]*sp[k4,q] - 16*sp[k1,k3]*sp[k2,q]*
      sp[k4,q]*m + 32*sp[k1,k4]*sp[k2,k3] - 16*sp[k1,k4]*sp[k2,k3]*m - 
      256*sp[k1,k4]*sp[k2,k3]*sp[k3,k4] + 64*sp[k1,k4]*sp[k2,k3]*sp[k3,
      k4]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k3,q] - 32*sp[k1,k4]*sp[k2,k3]
      *sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[
      k2,k3]*sp[k4,q]*m - 64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,k4
      ]*sp[k2,k4]*sp[k3,q]*m + 128*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 32*
      sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m - 128*sp[k1,k4]*sp[k2,q]*sp[k3,q]
       + 32*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 128*sp[k1,q]*sp[k2,k3]*sp[
      k3,k4] - 32*sp[k1,q]*sp[k2,k3]*sp[k3,k4]*m - 128*sp[k1,q]*sp[k2,
      k3]*sp[k4,q] + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m - 64*sp[k1,q]*sp[
      k2,k4]*sp[k3,k4] + 64*sp[k1,q]*sp[k2,k4]*sp[k3,q] - 16*sp[k1,q]*
      sp[k2,k4]*sp[k3,q]*m + 64*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 16*sp[k1,
      q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,5]*color[4/9*Na*Tf^2]*den[sp[k1
       - q]]*den[sp[ - k2 - k3]]*den[sp[k2 + k3]]*den[sp[ - k4 + q]]*
      num[128*sp[k1,k2]*sp[k1,k3]*sp[k4,q] + 128*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4] - 64*sp[k1,k2]*sp[k1,k4]*sp[k3,q] - 64*sp[k1,k2]*sp[k1,
      q]*sp[k3,k4] + 128*sp[k1,k2]*sp[k3,k4] - 32*sp[k1,k2]*sp[k3,k4]*m
       - 64*sp[k1,k2]*sp[k3,k4]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,q]*sp[k4
      ,q] + 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 128*sp[k1,k3]*sp[k1,k4]*
      sp[k2,k4] - 64*sp[k1,k3]*sp[k1,k4]*sp[k2,q] - 64*sp[k1,k3]*sp[k1,
      q]*sp[k2,k4] + 128*sp[k1,k3]*sp[k2,k4] - 32*sp[k1,k3]*sp[k2,k4]*m
       - 64*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 128*sp[k1,k3]*sp[k2,q]*sp[k4
      ,q] + 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m - 256*sp[k1,k4]^2*sp[k2,k3
      ] + 64*sp[k1,k4]^2*sp[k2,k3]*m + 256*sp[k1,k4]*sp[k1,q]*sp[k2,k3]
       - 64*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m - 448*sp[k1,k4]*sp[k2,k3] + 
      192*sp[k1,k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 + 256*sp[
      k1,k4]*sp[k2,k3]*sp[k4,q] - 64*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m - 
      64*sp[k1,k4]*sp[k2,k4]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,k4]
       + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 64*sp[k1,k4]*sp[k2,q]*sp[k3,
      q]*m + 512*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 256*sp[k1,q]*sp[k2,k3]*
      sp[k4,q]*m + 32*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 + 128*sp[k1,q]*
      sp[k2,k4]*sp[k3,k4] - 128*sp[k1,q]*sp[k2,k4]*sp[k3,q] + 32*sp[k1,
      q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,q]*sp[k3,k4] + 32*
      sp[k1,q]*sp[k2,q]*sp[k3,k4]*m] + amp[8,6]*color[ - 4/9*Cf*Na*Tf
       + 2/9*Ca*Na*Tf]*den[sp[k1 - q]]*den[sp[k2 + k3]]*den[sp[ - k3 - 
      k4]]*den[sp[ - k4 + q]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[k4,q] - 32*
      sp[k1,k2]*sp[k1,k3]*sp[k4,q]*m - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,k4
      ] + 96*sp[k1,k2]*sp[k1,k4]*sp[k3,k4]*m - 16*sp[k1,k2]*sp[k1,k4]*
      sp[k3,k4]*m^2 - 128*sp[k1,k2]*sp[k1,k4]*sp[k3,q] + 32*sp[k1,k2]*
      sp[k1,k4]*sp[k3,q]*m + 256*sp[k1,k2]*sp[k1,q]*sp[k3,k4] - 128*sp[
      k1,k2]*sp[k1,q]*sp[k3,k4]*m + 16*sp[k1,k2]*sp[k1,q]*sp[k3,k4]*m^2
       - 416*sp[k1,k2]*sp[k3,k4] + 272*sp[k1,k2]*sp[k3,k4]*m - 56*sp[k1
      ,k2]*sp[k3,k4]*m^2 + 4*sp[k1,k2]*sp[k3,k4]*m^3 - 128*sp[k1,k2]*
      sp[k3,k4]*sp[k4,q] + 32*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m + 128*sp[
      k1,k2]*sp[k3,q]*sp[k4,q] - 32*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 256
      *sp[k1,k3]*sp[k1,k4]*sp[k2,k4] - 160*sp[k1,k3]*sp[k1,k4]*sp[k2,k4
      ]*m + 16*sp[k1,k3]*sp[k1,k4]*sp[k2,k4]*m^2 + 64*sp[k1,k3]*sp[k1,
      k4]*sp[k2,q] - 320*sp[k1,k3]*sp[k1,q]*sp[k2,k4] + 160*sp[k1,k3]*
      sp[k1,q]*sp[k2,k4]*m - 16*sp[k1,k3]*sp[k1,q]*sp[k2,k4]*m^2 + 544*
      sp[k1,k3]*sp[k2,k4] - 368*sp[k1,k3]*sp[k2,k4]*m + 72*sp[k1,k3]*
      sp[k2,k4]*m^2 - 4*sp[k1,k3]*sp[k2,k4]*m^3 + 64*sp[k1,k3]*sp[k2,k4
      ]*sp[k4,q] - 256*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 128*sp[k1,k3]*sp[
      k2,q]*sp[k4,q]*m - 16*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 128*sp[k1
      ,k4]^2*sp[k2,k3] + 96*sp[k1,k4]^2*sp[k2,k3]*m - 16*sp[k1,k4]^2*
      sp[k2,k3]*m^2 + 128*sp[k1,k4]*sp[k1,q]*sp[k2,k3] - 96*sp[k1,k4]*
      sp[k1,q]*sp[k2,k3]*m + 16*sp[k1,k4]*sp[k1,q]*sp[k2,k3]*m^2 - 224*
      sp[k1,k4]*sp[k2,k3] + 208*sp[k1,k4]*sp[k2,k3]*m - 56*sp[k1,k4]*
      sp[k2,k3]*m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,
      k3]*sp[k4,q] - 96*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k4]*
      sp[k2,k3]*sp[k4,q]*m^2 - 320*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 160*
      sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*
      m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,k4] - 128*sp[k1,k4]*sp[k2,q]*
      sp[k3,k4]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m^2 + 128*sp[k1,k4]
      *sp[k2,q]*sp[k3,q] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,
      k4]*sp[k2,q]*sp[k3,q]*m^2 + 256*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 256
      *sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 80*sp[k1,q]*sp[k2,k3]*sp[k4,q]*
      m^2 - 8*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^3 + 64*sp[k1,q]*sp[k2,k4]*
      sp[k3,k4] - 32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 640*sp[k1,q]*sp[
      k2,k4]*sp[k3,q] + 480*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 112*sp[k1,q
      ]*sp[k2,k4]*sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 
      512*sp[k1,q]*sp[k2,q]*sp[k3,k4] - 384*sp[k1,q]*sp[k2,q]*sp[k3,k4]
      *m + 96*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[
      k3,k4]*m^3] + amp[8,7]*color[4/9*Na*Tf^2]*den[sp[ - k2 - k3]]*
      den[sp[k2 + k3]]*den[sp[ - k4 + q]]^2*num[64*sp[k1,k2]*sp[k3,k4]
       - 32*sp[k1,k2]*sp[k3,k4]*m - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q] + 
      64*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m + 64*sp[k1,k3]*sp[k2,k4] - 32*
      sp[k1,k3]*sp[k2,k4]*m - 128*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 64*sp[
      k1,k3]*sp[k2,q]*sp[k4,q]*m - 128*sp[k1,k4]*sp[k2,k3] + 96*sp[k1,
      k4]*sp[k2,k3]*m - 16*sp[k1,k4]*sp[k2,k3]*m^2 + 256*sp[k1,q]*sp[k2
      ,k3]*sp[k4,q] - 192*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m + 32*sp[k1,q]*
      sp[k2,k3]*sp[k4,q]*m^2] + amp[8,8]*color[ - 4/9*Cf*Na*Tf + 2/9*Ca
      *Na*Tf]*den[sp[ - k2 + q]]*den[sp[k2 + k3]]*den[sp[ - k3 - k4]]*
      den[sp[ - k4 + q]]*num[128*sp[k1,k2]*sp[k2,k3]*sp[k4,q] - 96*sp[
      k1,k2]*sp[k2,k3]*sp[k4,q]*m + 16*sp[k1,k2]*sp[k2,k3]*sp[k4,q]*m^2
       + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,k4] - 96*sp[k1,k2]*sp[k2,k4]*sp[
      k3,k4]*m + 16*sp[k1,k2]*sp[k2,k4]*sp[k3,k4]*m^2 - 256*sp[k1,k2]*
      sp[k2,k4]*sp[k3,q] + 128*sp[k1,k2]*sp[k2,k4]*sp[k3,q]*m - 16*sp[
      k1,k2]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k2]*sp[k2,q]*sp[k3,k4]
       - 32*sp[k1,k2]*sp[k2,q]*sp[k3,k4]*m - 448*sp[k1,k2]*sp[k3,k4] + 
      304*sp[k1,k2]*sp[k3,k4]*m - 64*sp[k1,k2]*sp[k3,k4]*m^2 + 4*sp[k1,
      k2]*sp[k3,k4]*m^3 - 256*sp[k1,k2]*sp[k3,k4]*sp[k4,q] + 128*sp[k1,
      k2]*sp[k3,k4]*sp[k4,q]*m - 16*sp[k1,k2]*sp[k3,k4]*sp[k4,q]*m^2 + 
      256*sp[k1,k2]*sp[k3,q]*sp[k4,q] - 128*sp[k1,k2]*sp[k3,q]*sp[k4,q]
      *m + 16*sp[k1,k2]*sp[k3,q]*sp[k4,q]*m^2 + 704*sp[k1,k3]*sp[k2,k4]
       - 432*sp[k1,k3]*sp[k2,k4]*m + 80*sp[k1,k3]*sp[k2,k4]*m^2 - 4*sp[
      k1,k3]*sp[k2,k4]*m^3 - 256*sp[k1,k3]*sp[k2,k4]^2 + 160*sp[k1,k3]*
      sp[k2,k4]^2*m - 16*sp[k1,k3]*sp[k2,k4]^2*m^2 + 256*sp[k1,k3]*sp[
      k2,k4]*sp[k2,q] - 160*sp[k1,k3]*sp[k2,k4]*sp[k2,q]*m + 16*sp[k1,
      k3]*sp[k2,k4]*sp[k2,q]*m^2 + 256*sp[k1,k3]*sp[k2,k4]*sp[k4,q] - 
      160*sp[k1,k3]*sp[k2,k4]*sp[k4,q]*m + 16*sp[k1,k3]*sp[k2,k4]*sp[k4
      ,q]*m^2 - 640*sp[k1,k3]*sp[k2,q]*sp[k4,q] + 320*sp[k1,k3]*sp[k2,q
      ]*sp[k4,q]*m - 32*sp[k1,k3]*sp[k2,q]*sp[k4,q]*m^2 - 448*sp[k1,k4]
      *sp[k2,k3] + 304*sp[k1,k4]*sp[k2,k3]*m - 64*sp[k1,k4]*sp[k2,k3]*
      m^2 + 4*sp[k1,k4]*sp[k2,k3]*m^3 + 128*sp[k1,k4]*sp[k2,k3]*sp[k2,
      k4] - 96*sp[k1,k4]*sp[k2,k3]*sp[k2,k4]*m + 16*sp[k1,k4]*sp[k2,k3]
      *sp[k2,k4]*m^2 - 256*sp[k1,k4]*sp[k2,k3]*sp[k2,q] + 128*sp[k1,k4]
      *sp[k2,k3]*sp[k2,q]*m - 16*sp[k1,k4]*sp[k2,k3]*sp[k2,q]*m^2 + 128
      *sp[k1,k4]*sp[k2,k3]*sp[k4,q] - 32*sp[k1,k4]*sp[k2,k3]*sp[k4,q]*m
       - 256*sp[k1,k4]*sp[k2,k4]*sp[k3,q] + 128*sp[k1,k4]*sp[k2,k4]*sp[
      k3,q]*m - 16*sp[k1,k4]*sp[k2,k4]*sp[k3,q]*m^2 + 128*sp[k1,k4]*sp[
      k2,q]*sp[k3,k4] - 96*sp[k1,k4]*sp[k2,q]*sp[k3,k4]*m + 16*sp[k1,k4
      ]*sp[k2,q]*sp[k3,k4]*m^2 + 256*sp[k1,k4]*sp[k2,q]*sp[k3,q] - 128*
      sp[k1,k4]*sp[k2,q]*sp[k3,q]*m + 16*sp[k1,k4]*sp[k2,q]*sp[k3,q]*
      m^2 + 128*sp[k1,q]*sp[k2,k3]*sp[k2,k4] - 32*sp[k1,q]*sp[k2,k3]*
      sp[k2,k4]*m + 640*sp[k1,q]*sp[k2,k3]*sp[k4,q] - 480*sp[k1,q]*sp[
      k2,k3]*sp[k4,q]*m + 112*sp[k1,q]*sp[k2,k3]*sp[k4,q]*m^2 - 8*sp[k1
      ,q]*sp[k2,k3]*sp[k4,q]*m^3 + 128*sp[k1,q]*sp[k2,k4]*sp[k3,k4] - 
      32*sp[k1,q]*sp[k2,k4]*sp[k3,k4]*m - 896*sp[k1,q]*sp[k2,k4]*sp[k3,
      q] + 608*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m - 128*sp[k1,q]*sp[k2,k4]*
      sp[k3,q]*m^2 + 8*sp[k1,q]*sp[k2,k4]*sp[k3,q]*m^3 + 640*sp[k1,q]*
      sp[k2,q]*sp[k3,k4] - 480*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m + 112*sp[
      k1,q]*sp[k2,q]*sp[k3,k4]*m^2 - 8*sp[k1,q]*sp[k2,q]*sp[k3,k4]*m^3])
