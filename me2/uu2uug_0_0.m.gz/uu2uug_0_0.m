(amp[1,1]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*
      den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*num[160*sp[
      k1,k2]^2*sp[p1,p2] - 80*sp[k1,k2]^2*sp[p1,p2]*m + 8*sp[k1,k2]^2*
      sp[p1,p2]*m^2 + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 48*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 80*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 - 160
      *sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 80*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]
      *m - 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 16*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 128*sp[k1,k2
      ]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k2,k3]*sp[p1
      ,p2] - 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3]
      *sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 288*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] + 144*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2
      ]*sp[p1,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 32
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ] - 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 112*sp[k1,k3]
      *sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 
      192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 
      48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m^2 + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m - 64*sp[k1,p1]^2*sp[k2,p2] + 48*sp[k1,p1]^2*sp[k2
      ,p2]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 64*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m^2 - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m
       + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2]*m^2 - 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 192*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 64*sp[k1,p2
      ]^2*sp[k2,p1]*m + 8*sp[k1,p2]^2*sp[k2,p1]*m^2 - 288*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1] + 144*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 160*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 64*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 192*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[1,2]*color[1/2*Ca*Na*Tf^2]*
      den[sp[k1 + k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2
       - p2]]*num[32*sp[k1,k2]^2*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 96*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 32*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*
      m + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 64*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m
       + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 
      32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 128*sp[k1,p1
      ]^2*sp[k2,p2] + 32*sp[k1,p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 96*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 96*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2
      ] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 32*sp[k1,p2]^2*sp[k2,p1]
       + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]] + amp[1,3]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[
       - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k2 + k3]]*den[sp[k2 - p2]]*
      num[ - 32*sp[k1,k2]^2*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ] + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2]*m + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 32*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m - 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 96*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m + 128*sp[k1,p1]*sp[k2,p2]^2 - 32*sp[k1,p1]*sp[k2,p2]^2*m
       - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 
      128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m + 32*sp[k1,p2]*sp[k2,p1]^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m] + amp[1,4]*color[ - Ca*Na*Tf^2]*den[sp[ - k1
       + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*
      num[ - 32*sp[k1,k2]^2*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2
      ] - 32*sp[k1,k2]*sp[k1,p1]*sp[k1,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 128*sp[k1
      ,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 
      32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k2,p1]*
      sp[k2,p2]*m - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1
      ,k2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 
      32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[p1,p2]^2 + 64*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[
      k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 32*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2] + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 192*sp[k1,p1]^2*sp[k2,p2] - 64*sp[
      k1,p1]^2*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 96*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 
      64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,
      p2]*m - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]
      *sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[p1,p2] - 32*sp[
      k1,p1]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,p1]*sp[k2,p2]^2 - 64*sp[
      k1,p1]*sp[k2,p2]^2*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,p2]^2*
      sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2
      ,p1]^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 64*
      sp[k1,p2]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*
      m] + amp[1,5]*color[1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[k1
       - p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[96*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 64*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*
      m + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[p1,p2]^2 - 
      96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,
      p2]*m + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 32*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 
      32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,
      p2]^2 + 32*sp[k1,p1]*sp[k2,p2]^2*m + 96*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[
      k1,p2]^2*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2] + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[1
      ,6]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*
      den[sp[k1 - p1]]*den[sp[k2 + k3]]*den[sp[k2 - p2]]*num[ - 160*sp[
      k1,k2]^2*sp[p1,p2] + 80*sp[k1,k2]^2*sp[p1,p2]*m - 8*sp[k1,k2]^2*
      sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 80*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 192*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2] - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m^2 + 160*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 80*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*
      m^2 - 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 32*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1
      ]*sp[p1,p2] - 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*
      sp[k2,p1]*sp[p1,p2]*m^2 - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 
      128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,p2]*sp[p1,
      p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m^2 + 288*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 
      144*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m + 288*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 
      144*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m^2 - 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 32*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*
      m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m - 160*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 80*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k2,p2]
      *sp[p1,p2] + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m^2 - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 112*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 + 192*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p2]^2 - 48*
      sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 - 192*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p1] + 112*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 192*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 
      16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2] - 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]^2 + 64*sp[k1,p2]*sp[
      k2,p1]^2*m - 8*sp[k1,p2]*sp[k2,p1]^2*m^2 + 64*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[
      k2,p1]*sp[k2,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,p2]
      *sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[1,8]*color[1/2*Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[sp[
      k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 192*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 80*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
      *m^2 - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 288*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2] + 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p2] - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2]*m^2 + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,k2]
      *sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 96
      *sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
      *m - 192*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ] - 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[p1,p2]^2 + 80*sp[k1,k2]*sp[p1,p2
      ]^2*m - 8*sp[k1,k2]*sp[p1,p2]^2*m^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 48*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m^2 + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2
       - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] + 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] + 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m^2 + 64*sp[k1,p1]^2*sp[k2,p2] - 48*sp[k1,p1]^2*sp[k2,
      p2]*m + 8*sp[k1,p1]^2*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 112*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2
       + 192*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 112*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
      *m + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
      *m^2 + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m + 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 192*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1] - 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 64*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m^2 - 128*sp[k1,p2]*sp[k2,p1]^2 + 64*sp[k1,p2]*sp[k2,p1]^2*m - 8
      *sp[k1,p2]*sp[k2,p1]^2*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 
      288*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 144*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p2]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 160*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] - 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
       - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m^2] + amp[1,9]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*
      Tf]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*den[sp[
       - k3 + p2]]*num[288*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 144*sp[k1,k2
      ]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 
      96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m - 160*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 80*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 128*sp[k1,
      k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k2,k3]*sp[p1,
      p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k2,p1]
      *sp[k3,p2] - 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 96*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m^2 + 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] + 80*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 160
      *sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2]*sp[p1,p2]^2*m + 8*sp[k1,k2]
      *sp[p1,p2]^2*m^2 - 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 112*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2
       - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ] - 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,
      p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 
      192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 80*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 32*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 64*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 + 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 80*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 192
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,
      p2]^2 + 48*sp[k1,p1]*sp[k2,p2]^2*m - 8*sp[k1,p1]*sp[k2,p2]^2*m^2
       - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 96*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 8*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 
      64*sp[k1,p2]^2*sp[k2,p1]*m + 8*sp[k1,p2]^2*sp[k2,p1]*m^2 - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[
      k1,p2]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m
       - 8*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 288*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] - 144*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 160*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*
      m - 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[1,10]*
      color[ - 1/2*Ca*Na*Tf^2]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*
      den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 128*sp[k1
      ,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 
      32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] - 96*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[p1,p2]^2 - 128*sp[k1
      ,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 
      64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 128*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m + 128*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1]^2*sp[k2,p2]*m + 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ] + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 16
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 96*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 32*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p1]^2 + 
      64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 96*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[2,1]*
      color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + 
      k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p2]]*
      num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 320*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] - 160*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 16*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k2]*sp[k1,p2]*sp[p1
      ,p2] + 160*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2]*m^2 - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 480*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 
      32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1
      ,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2
       + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 256*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 256*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3] + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m^2 + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 96*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2
      ]*m^2 + 512*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 384*sp[k1,p1]*sp[k2,
      k3]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 256*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 96*sp[k1,p2]^2*sp[k2,
      p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 128*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m
       + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[2,2]*
      color[1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 + k3]]*den[
      sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p2]]*num[64*sp[k1
      ,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1
      ] - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 
      64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 256*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 128*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*
      m - 128*sp[k1,p2]^2*sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
       - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2] - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[2,3]
      *color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[k1
       - p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 128
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
      *m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 
      64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2] - 256*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 64*sp[k1,p1]*sp[k2,k3]
      *sp[k2,p2]*m + 512*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 256*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 
      256*sp[k1,p1]*sp[k2,p2]^2 - 64*sp[k1,p1]*sp[k2,p2]^2*m + 256*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m
       + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2] - 128*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]] + amp[2,
      4]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      den[sp[ - k2 + p2]]*den[sp[ - k3 + p2]]*num[ - 96*sp[k1,k2]*sp[k1
      ,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 32*sp[k1,k2
      ]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m
       - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[
      k3,p2]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[
      k2,p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 32*sp[k1,
      k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[p1,p2]^2 + 96*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*
      m - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2
      ]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]^
      2 - 32*sp[k1,p1]*sp[k2,p2]^2*m - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,
      p2]^2*sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2]
      *sp[k2,k3]*sp[k2,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ]*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[2,5]
      *color[Cf*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[
       - k3 + p2]]^2*num[ - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2] + amp[2,6]*color[ - Cf^2*Na*Tf + Ca*Cf*
      Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[
      sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[320*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2] - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      256*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,p2]*sp[p1
      ,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 480*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 32
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,k3]*sp[k2,p2
      ]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 320*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 160
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 96*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 256*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2] - 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m
       + 80*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,p2]^2 - 96*sp[k1,p1]*sp[k2,p2
      ]^2*m + 16*sp[k1,p1]*sp[k2,p2]^2*m^2 + 128*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ]*m^2 + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 384*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 
      32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[
      k2,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,
      p1]*sp[k2,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 
      128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[
      k3,p1]*m^2] + amp[2,7]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]
      *den[sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[
       - k3 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 48*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*
      m^2 - 192*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 96*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k2]
      *sp[k1,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 8*sp[
      k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 288*sp[k1,k2]*sp[k2,k3]*sp[p1,p2
      ] - 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 80*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
      *m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p2]
      *sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,k2
      ]*sp[k3,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] + 80*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p1]
      *sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 48*sp[k1,k2]*
      sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 160
      *sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2]*sp[p1,p2]^2*m + 8*sp[k1,k2]
      *sp[p1,p2]^2*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2
       + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ] - 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 192
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 192
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 112*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 64*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p2] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
      *m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 128*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] + 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]^2 - 64*sp[k1,p1]*sp[
      k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 288*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1] - 144*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 160*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*
      m - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 64*sp[k1,p2]^2*sp[k2,p1
      ] + 48*sp[k1,p2]^2*sp[k2,p1]*m - 8*sp[k1,p2]^2*sp[k2,p1]*m^2 - 
      192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 112*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 - 64*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m
       - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[
      k2,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2
       - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 32*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[2
      ,8]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[
      sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[sp[ - k3 + p1]]*den[sp[ - k3
       + p2]]*num[ - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 320*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 
      256*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1
      ,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[p1,p2]^2 + 160*
      sp[k1,k2]*sp[p1,p2]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 896*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2] + 608*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m
       - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^3 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      256*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,p1]*sp[p1
      ,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2]*m^2 + 640*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 480*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 
      8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2
      ,p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 
      128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 96*sp[k1
      ,p1]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2
       + 640*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 480*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 256*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p2] + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 96*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2
      ]*m^2 + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[2,9]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p1]]*den[sp[
       - k2 + p1]]*den[sp[ - k3 + p2]]^2*num[ - 256*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2] + 288*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 160*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3] + amp[2,10]*color[ - 1/
      4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 - p1]]*den[sp[ - k2
       + p2]]*den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]
       - 128*sp[k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,
      k3]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 
      32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2
      ,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m + 256*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 64*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2] - 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,
      p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[3,1]*
      color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*
      num[ - 256*sp[k1,k2]^2*sp[p1,p2] + 160*sp[k1,k2]^2*sp[p1,p2]*m - 
      16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 96*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 
      128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,p2
      ]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 
      16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,k2]*sp[k2,p2]*sp[k3,
      p1] - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1]*m^2 - 896*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 608*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2
       + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 256*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2] + 320*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 96*sp[k1,k3
      ]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 
      640*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 480*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2]*m + 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m^3 + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 128*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ]*m^2 - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 128*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 
      640*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 480*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2]*m + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m^3 + 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2] + amp[3,2
      ]*color[ - 1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 + k3]]*
      den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*num[ - 128*
      sp[k1,k2]^2*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 256*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m - 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 64*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 48*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m
       + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m] + 
      amp[3,3]*color[Cf*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*
      den[sp[k2 + k3]]^2*num[ - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m^2 - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 64*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m] + amp[3,4]*color[1/2*Ca*Na*Tf^2]*den[sp[
       - k1 + p1]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]
      ]*num[32*sp[k1,k2]^2*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[
      k2,p2]*m - 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,
      p2]*sp[k3,p1] + 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 32*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m + 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 96*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
       - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 64*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 96*sp[
      k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m
       + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[
      k2,p2]*m - 128*sp[k1,p1]*sp[k2,p2]^2 + 32*sp[k1,p1]*sp[k2,p2]^2*m
       + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1]*m - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2
      ,p2]*sp[k3,p2]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 16*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 
      128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2]*m - 32*sp[k1,p2]*sp[k2,p1]^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k2,
      p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]*m] + amp[3,5]*color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]
      *den[sp[ - k1 + p1]]*den[sp[k1 - p1]]*den[sp[k2 + k3]]*den[sp[ - 
      k3 + p2]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[
      k1,k2]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 
      32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2] - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 128*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 256*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*
      m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 256*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 512*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2] - 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 256*sp[k1,p1]*sp[k2,p2]^2 - 
      64*sp[k1,p1]*sp[k2,p2]^2*m + 256*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 
      64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1
      ,p2]*sp[k2,p2]*sp[k3,p1]] + amp[3,6]*color[ - Cf^2*Na*Tf + 1/2*Ca
      *Cf*Na*Tf]*den[sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[sp[k2 + k3]]^
      2*num[ - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 288*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       - 160*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 
      64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m^3] + amp[3,7]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]
      *den[sp[ - k1 + p2]]*den[sp[k1 - p1]]*den[sp[ - k2 + p1]]*den[sp[
      k2 + k3]]*num[160*sp[k1,k2]^2*sp[p1,p2] - 80*sp[k1,k2]^2*sp[p1,p2
      ]*m + 8*sp[k1,k2]^2*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2] - 80*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 80*sp[k1,k2]
      *sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 
      128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1] + 48*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*
      sp[k1,p2]*sp[k2,p1]*m^2 - 192*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 80*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
      *m^2 + 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 80*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m^2 + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]
      *sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 
      128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,
      p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 288*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2] + 144*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 288*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2] + 144*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m^2 + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m + 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 
      96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2
       + 192*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 160*sp[k1
      ,k3]*sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] - 112*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 192*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 
      16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[
      p1,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,
      p1]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2
       - 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1
      ]*sp[k2,p2]^2 - 64*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2
      ]^2*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 96*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m - 64*sp[k1,p2]*sp[k2,p1]^2 + 48*sp[k1,p2]*sp[k2,p1]^2*m - 8*sp[
      k1,p2]*sp[k2,p1]^2*m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] + 48*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m - 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[3,8]*color[ - 
      Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*
      den[sp[k1 - p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[320*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2] - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m
       + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 256*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2] - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 480*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 
      16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 320*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2] + 160*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k2,k3]*sp[k2,
      p2] + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p2]*m^2 + 512*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 384*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2
       - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 64*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[
      k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 + 256*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ] - 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 96*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1
      ]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 256*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]^2 - 96*sp[
      k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]^2*m^2 + 128*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[3,9]*color[ - Cf^2*Na*
      Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 - p1]]*den[sp[ - k2
       + p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[ - 64*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1
      ,k2]*sp[k2,p1]*sp[k3,p2]*m + 320*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 
      160*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1]*m^2 - 256*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 
      640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 480*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 160*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] + 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 512*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] - 384*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 
      128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k2
      ,p2]*sp[p1,p2] - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 96*sp[k1,p1]
      *sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 
      256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 256*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2]*m + 80*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,p2]^2 - 96*sp[k1,p1]*sp[
      k2,p2]^2*m + 16*sp[k1,p1]*sp[k2,p2]^2*m^2 + 128*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[
      k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2
      ] - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m] + amp[3,10]*color[1/4*Ca*Na*Tf^2 + d33[
      cOlpR1,cOlpR2]]*den[sp[k1 - p1]]*den[sp[ - k2 + p2]]*den[sp[k2 + 
      k3]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 
      64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 
      128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 128*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m + 256*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1
      ,p1]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 
      32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,p1]^2 - 128*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]] + amp[4,1]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[
      k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*
      num[ - 32*sp[k1,k2]^2*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2
      ] + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] + 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k2
      ]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
       + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 64*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,p1]^2*
      sp[k2,p2] + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2
      ] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 128*sp[k1,p2]^2*sp[
      k2,p1] - 32*sp[k1,p2]^2*sp[k2,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1]*m] + amp[4,2]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*
      den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2
       - p1]]*num[ - 160*sp[k1,k2]^2*sp[p1,p2] + 80*sp[k1,k2]^2*sp[p1,
      p2]*m - 8*sp[k1,k2]^2*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2] + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,
      k3]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 80*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2
       - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 96*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       + 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 80*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 160
      *sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
      *m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2] - 80*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 64*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]
      *m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 288*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2] - 144*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]
      *sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 192*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 48*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
      *m^2 - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m + 192*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64
      *sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
      *m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p1]^2*sp[k2,
      p2] + 64*sp[k1,p1]^2*sp[k2,p2]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m^2 + 
      32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,p1]*sp[k1,
      p2]*sp[k2,p1]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 48*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2
       + 288*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 144*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 160*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*
      m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,p1]*sp[k2,p1]
      *sp[k3,p2] - 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 64*sp[k1,p2]^
      2*sp[k2,p1] - 48*sp[k1,p2]^2*sp[k2,p1]*m + 8*sp[k1,p2]^2*sp[k2,p1
      ]*m^2 - 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
      *m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p1] + 112*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]
      *m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[4,3]*
      color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*
      den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[k2 - p1]]*num[160*sp[k1,
      k2]^2*sp[p1,p2] - 80*sp[k1,k2]^2*sp[p1,p2]*m + 8*sp[k1,k2]^2*sp[
      p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 80*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 160*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 80*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*
      m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]
      *sp[k3,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m^2 - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 48*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*
      m^2 - 192*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 80*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 32*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m + 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,k2]*sp[k2,p1]*
      sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 288*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] + 144*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p2
      ]*sp[p1,p2]*m^2 - 288*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 144*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2
       + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m + 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2
      ,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 32*sp[k1
      ,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2
       - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 160*sp[k1,k3]*sp[k2,p2]*
      sp[p1,p2] - 80*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 112*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ]*m^2 + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 192*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 48*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
      *m^2 - 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 192*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]^2 - 
      64*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*
      m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m^2 - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[
      k1,p2]*sp[k2,p1]^2 + 48*sp[k1,p2]*sp[k2,p1]^2*m - 8*sp[k1,p2]*sp[
      k2,p1]^2*m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p2]*
      sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 48*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m^2 + 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 192*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1] + 80*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[4,5]*color[ - 1/2*Ca*Cf*
      Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[
      sp[k2 - p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1
      ,p2] - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m^2 - 192*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 96*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
      *m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[k1,p2]
      *sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 + 288*sp[k1,k2
      ]*sp[k2,k3]*sp[p1,p2] - 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 160*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1] + 80*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m^2 + 192*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2] + 80*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,
      p2] + 48*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2]*sp[p1,p2
      ]^2*m + 8*sp[k1,k2]*sp[p1,p2]^2*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 8*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m^2 + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 48*sp[k1,
      k3]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2
       + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       + 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,k3]*sp[
      k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m
       - 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[
      p1,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 112*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 64
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 48*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]
      *m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 112
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2] + 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 
      16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]^2
       - 64*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 288
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 144*sp[k1,p1]*sp[k2,p2]*sp[k3,p1
      ]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 32*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2] - 160*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 64*
      sp[k1,p2]^2*sp[k2,p1] + 48*sp[k1,p2]^2*sp[k2,p1]*m - 8*sp[k1,p2]^
      2*sp[k2,p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 112*sp[k1,
      p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2
       - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 16*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1
      ,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 48*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*
      m^2 + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m^2] + amp[4,6]*color[1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2
      ]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[k2 - p1]]*num[32*sp[
      k1,k2]^2*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 96*
      sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*
      m + 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 128*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]^2 + 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2] - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,p2]*
      sp[k2,p1]^2 + 32*sp[k1,p2]*sp[k2,p1]^2*m + 96*sp[k1,p2]*sp[k2,p1]
      *sp[k2,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 128*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m]
       + amp[4,7]*color[Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1 - p2]
      ]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*num[32*sp[k1,k2]^2*sp[p1,
      p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k1,p2] + 32*sp[k1,k2]*sp[k1,p1]*
      sp[k1,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2] - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k2
      ]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 128*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] - 32*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]
      *sp[k2,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k2,p2]*m + 64*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 128*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*
      m + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 32*sp[k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 32*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2] + 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 
      32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1] - 32*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 96*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 128*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 32*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2] + 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 
      32*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p1
      ]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[p1,p2]*m - 32*sp[k1,p1]*
      sp[k2,p2]^2 - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 192*sp[k1,p2]^2*
      sp[k2,p1] + 64*sp[k1,p2]^2*sp[k2,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m
       - 192*sp[k1,p2]*sp[k2,p1]^2 + 64*sp[k1,p2]*sp[k2,p1]^2*m + 96*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*
      m + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p2]
      *sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 32*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[p1,p2
      ] + 32*sp[k1,p2]*sp[k2,p2]*sp[p1,p2]*m] + amp[4,8]*color[ - 1/2*
      Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1 - p2]]*den[sp[k2 - p1]]
      *den[sp[ - k3 + p1]]*num[32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]
       + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1
      ,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 
      16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 32*sp[k1,k2]*sp[k3,p2
      ]*sp[p1,p2] - 32*sp[k1,k2]*sp[p1,p2]^2 - 32*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1]*m - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]
      ^2*sp[k2,p2] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 16*sp[k1,p1]*sp[
      k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 
      128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,p1]^2 - 32*sp[k1,p2]*sp[k2,p1
      ]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 32*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
       - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[4,9]*color[1/2*Ca*Na
      *Tf^2]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*den[
      sp[ - k3 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 96*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2
      ] - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*sp[
      p1,p2]*m + 32*sp[k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k1
      ,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 128*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*
      m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 32
      *sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]^2
       - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,p2]^2*sp[
      k2,p1] + 32*sp[k1,p2]^2*sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2
      ]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 32*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1
      ] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,
      p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[4,10]*color[1/2*Ca*Cf*Na*Tf - 1/
      4*Ca^2*Na*Tf]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2 - p1
      ]]*den[sp[ - k3 + p1]]*num[ - 288*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
       + 144*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 128
      *sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
      *m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 192*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]
      *sp[p1,p2] + 80*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[
      k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 48*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*
      m^2 - 192*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[
      k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ] - 80*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[p1,p2]^2 + 80*sp[k1,k2]*sp[p1,p2
      ]^2*m - 8*sp[k1,k2]*sp[p1,p2]^2*m^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2] - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m^2 + 192*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 112*sp[k1
      ,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2
       - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] - 48*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2] - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]
      *sp[p1,p2]*m^2 - 128*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[k2
      ,p2]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3] + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2
      ] - 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2]*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p1]*sp[k2,
      p2] - 48*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2]*m^2 - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 288*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 144*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
      *m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 160*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2] - 80*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2]*m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 48*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
      *m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,p2]
      *sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]^2 - 48*
      sp[k1,p2]*sp[k2,p1]^2*m + 8*sp[k1,p2]*sp[k2,p1]^2*m^2 - 32*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p1]
      *sp[p1,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[
      k2,p1]*sp[p1,p2]*m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ]*m^2] + amp[5,1]*color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[sp[k1 + 
      k3]]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*den[sp[ - k3 + p2]]*
      num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 64
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 256*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 512*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 128*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2] - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]
       + 256*sp[k1,p2]^2*sp[k2,p1] - 64*sp[k1,p2]^2*sp[k2,p1]*m + 256*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 256*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[
      k2,p2]*sp[k3,p1]] + amp[5,2]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 
      1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - 
      p1]]*den[sp[ - k3 + p2]]*num[320*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 
      160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[
      p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 256*sp[k1
      ,k2]*sp[k1,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 
      16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 256*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]
      *m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 128*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m^2 - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 
      480*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 256*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 80*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m^3 + 512*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 384*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p2] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 128*sp[k1,p2]^2*
      sp[k2,p1] - 96*sp[k1,p2]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]
      *m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,k3]
      *sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 320*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 
      16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m^2 + 256*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 128*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ]*m^2] + amp[5,3]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na
      *Tf]*den[sp[ - k1 + p1]]*den[sp[k2 + k3]]*den[sp[k2 - p1]]*den[
      sp[ - k3 + p2]]*num[ - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 64*sp[
      k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m
       + 320*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k2
      ]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 640*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2] + 480*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m
       - 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2] + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 128
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m^2 + 512*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 384*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ] - 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,
      p1]*sp[k2,p2]^2 - 96*sp[k1,p1]*sp[k2,p2]^2*m + 16*sp[k1,p1]*sp[k2
      ,p2]^2*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 96*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1
      ,p2]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2
       + 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + 
      amp[5,4]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p1]]*den[sp[ - k2 + p2]]*den[sp[k2 - p1]]*den[sp[ - k3 + p2]]*
      num[ - 288*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 144*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 
      160*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 80*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k2]*sp[k1
      ,p2]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 8*sp[k1,k2]
      *sp[k1,p2]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2
      ] + 48*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k2]*
      sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128
      *sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]
      *m - 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 - 192*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 80*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m^2 + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 48*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 160*sp[k1,k2]
      *sp[p1,p2]^2 + 80*sp[k1,k2]*sp[p1,p2]^2*m - 8*sp[k1,k2]*sp[p1,p2]
      ^2*m^2 + 192*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 112*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 128*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 112*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[
      k1,k3]*sp[k2,p1]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m
       + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m^2 + 16*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 192*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 80*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 8*sp[
      k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       - 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[
      k3,p2]*m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p2
      ]^2 - 48*sp[k1,p1]*sp[k2,p2]^2*m + 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 
      96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 96*sp[k1,p1]
      *sp[k2,p2]*sp[p1,p2] - 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[
      k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p2]^2*sp[k2,p1] + 64*
      sp[k1,p2]^2*sp[k2,p1]*m - 8*sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 8
      *sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 64*sp[k1,p2
      ]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 8*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 288*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p1] + 144*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1]*m^2 + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 160*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2] - 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 8*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[5,5]*color[ - 
      Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k2 - p1]
      ]*den[sp[ - k3 + p2]]^2*num[ - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       + 288*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 128*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 
      64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 160*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3] + amp[5,6]*color[1/4*Ca*Na*
      Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[ - k1 + p2]]*den[sp[k2 + k3]]*
      den[sp[k2 - p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2
      ,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2
      ] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2
      ,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16
      *sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2] + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 64*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,p1]*
      sp[k2,p2]^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 128*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[
      p1,p2]*m + 256*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1,p2]*sp[k2
      ,p1]*sp[k2,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 
      32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[5,7]*color[1/2*Ca*Na*
      Tf^2]*den[sp[ - k1 + p2]]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*
      den[sp[ - k3 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1]*m + 64*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 96*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[
      k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m
       - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[
      k2,p2]^2 - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2]*m - 32*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,p2
      ]^2*sp[k2,p1] + 32*sp[k1,p2]^2*sp[k2,p1]*m - 96*sp[k1,p2]*sp[k2,
      k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 128*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2
      ] - 32*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 96*sp[k1,
      p2]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[5,8]*color[ - 1/4*Ca*Na*
      Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[ - k1 + p2]]*den[sp[k2 - p1]]*
      den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 128*sp[
      k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 
      32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 128*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 64*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[5,9]*color[Cf*Na*
      Tf^2]*den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*den[sp[ - k3 + p2]]^2*
      num[ - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2]*m + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 192*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 
      128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m] + amp[5,10]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*
      Ca^2*Na*Tf]*den[sp[ - k2 + p2]]*den[sp[k2 - p1]]*den[sp[ - k3 + 
      p1]]*den[sp[ - k3 + p2]]*num[ - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       + 320*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 256*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 
      256*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2]*m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[
      p1,p2]^2 + 160*sp[k1,k2]*sp[p1,p2]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2
      *m^2 - 896*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 608*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 640*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]
       - 480*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 112*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 
      640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 480*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,p1]
      *sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 
      128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 256*sp[k1
      ,p1]*sp[k2,p2]*sp[k3,p2] + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 
      16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*
      sp[p1,p2] - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[
      k2,p2]*sp[p1,p2]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ]*m^2 - 256*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1] + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m
       - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] - 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*
      sp[k3,p1]*m^2] + amp[6,1]*color[Cf*Na*Tf^2]*den[sp[k1 + k3]]^2*
      den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*num[ - 128*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 256*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2] - 192*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1] + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m] + amp[6,2]*color[ - 
      Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2 + 
      p2]]*den[sp[k2 - p1]]*num[ - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 
      288*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m^3] + amp[6,3]*color[ - Cf^2*Na*Tf + 3/
      2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + 
      k3]]*den[sp[k2 + k3]]*den[sp[k2 - p1]]*num[ - 256*sp[k1,k2]^2*sp[
      p1,p2] + 160*sp[k1,k2]^2*sp[p1,p2]*m - 16*sp[k1,k2]^2*sp[p1,p2]*
      m^2 - 256*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1,k3]
      *sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 128*sp[k1,
      k2]*sp[k1,p1]*sp[k2,p2] - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16
      *sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 128*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*sp[k1
      ,p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k2
      ]*sp[k1,p2]*sp[k2,p1]*m^2 + 256*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 
      128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m^2 - 256*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 
      128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,
      p2]*m + 256*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2,
      p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 896*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2] + 608*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m
       - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^3 + 256*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 128*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 
      128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 320*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m
       - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 640*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2] - 480*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 112*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 
      256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 640*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 480*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 112*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 
      256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 256*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1]*m^2] + amp[6,4]*color[1/2*Ca*Cf*Na*Tf - 
      1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[ - k2
       + p2]]*den[sp[k2 - p1]]*num[ - 160*sp[k1,k2]^2*sp[p1,p2] + 80*
      sp[k1,k2]^2*sp[p1,p2]*m - 8*sp[k1,k2]^2*sp[p1,p2]*m^2 - 32*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2] + 48*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,
      p2] - 48*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 128*sp[k1,k2
      ]*sp[k1,p1]*sp[p1,p2] + 80*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 8*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,p2]*sp[k2
      ,p1] - 80*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*sp[k1,p2]
      *sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]
      *sp[k1,p2]*sp[k3,p1]*m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 64
      *sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2
      ]*m^2 - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,k3
      ]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,
      k2]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] - 80*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k2,p2]
      *sp[k3,p1]*m^2 - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
      *m + 288*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 144*sp[k1,k2]*sp[k3,p2]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 32*sp[k1,k3]
      *sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[
      k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
       - 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2] + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k3
      ,p2] - 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 48*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2
       + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 48*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 64*sp[k1,
      p1]^2*sp[k2,p2] - 48*sp[k1,p1]^2*sp[k2,p2]*m + 8*sp[k1,p1]^2*sp[
      k2,p2]*m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[
      k1,p2]*sp[k2,k3]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 48*sp[
      k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*
      m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m^2 - 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 48*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 - 192*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 96*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,p1]
      *sp[k2,p1]*sp[k3,p2] - 112*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p1] - 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 192*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 112*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 
      128*sp[k1,p2]^2*sp[k2,p1] + 64*sp[k1,p2]^2*sp[k2,p1]*m - 8*sp[k1,
      p2]^2*sp[k2,p1]*m^2 + 288*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 144*sp[
      k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 16*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m - 160*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 80*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 - 128
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
      *m - 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p2] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 80*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
      *m^2] + amp[6,5]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*
      Tf]*den[sp[ - k1 + p1]]*den[sp[k1 + k3]]*den[sp[k2 - p1]]*den[sp[
       - k3 + p2]]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 64*sp[k1,
      k2]*sp[k1,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 
      320*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 160*sp[k1,k2]*sp[k1,p2]*sp[k3
      ,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k2]*sp[
      k1,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1
      ,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       + 480*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 
      16*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 + 128*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ] + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 256*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8
      *sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 256*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3] + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 128*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p2] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p2]*m^2 + 512*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 384*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2
       - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 256*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 + 128*sp[k1,p2]^2*sp[k2,p1] - 96*sp[k1,p2
      ]^2*sp[k2,p1]*m + 16*sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]
       + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[6
      ,6]*color[ - 1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[ - k1 + 
      p2]]*den[sp[k1 + k3]]*den[sp[k2 + k3]]*den[sp[k2 - p1]]*num[ - 
      128*sp[k1,k2]^2*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 
      128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2] + 256*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,k2]*sp[k1,p2]*
      sp[k2,p1]*m + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1]*m - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 128*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*
      m - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 64*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k1,
      p1]*sp[k2,p2] + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 48*sp[
      k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 64
      *sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
       + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 128*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 128*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m] + amp[6
      ,7]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1 + k3]]
      *den[sp[ - k2 + p1]]*den[sp[k2 - p1]]*num[ - 32*sp[k1,k2]^2*sp[p1
      ,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k2]*sp[
      k1,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 96*sp[k1,
      k2]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 16
      *sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 16*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 
      32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m + 32*sp[k1,p1]^2*sp[k2,p2] + 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 64*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p2]*m + 128*sp[k1,p2]^2*sp[k2,p1] - 32*sp[k1,p2]^2*sp[k2,
      p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 96*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[6,8]*
      color[1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[ - k1 + p2]]*
      den[sp[k1 + k3]]*den[sp[k2 - p1]]*den[sp[ - k3 + p1]]*num[64*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 
      128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 128*sp[
      k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m
       + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3
      ]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 48*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p1]^2*sp[k2,p2] - 128
      *sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]
      *m + 256*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1
      ,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 
      128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[6,9]*
      color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[sp[k1 + k3]]*den[sp[ - k2
       + p1]]*den[sp[k2 - p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] + 64*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] - 128
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
      *m - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 64*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2] - 256*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1
      ,k3]*sp[k2,k3]*sp[p1,p2]*m + 512*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 
      256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 32*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^2 - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1
      ,p1]*sp[k1,p2]*sp[k2,k3] - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 
      128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 256*sp[k1,p2]^2*sp[k2,
      p1] - 64*sp[k1,p2]^2*sp[k2,p1]*m + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] + 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]] + amp[6,10
      ]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1
       + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - p1]]*den[sp[ - k3 + p1]]*
      num[320*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 160*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2] - 256*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 160*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2
      ]*m^2 - 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1]*m - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64
      *sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m^2 - 256*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 128*sp[k1,k3]
      *sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 
      640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 480*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2]*m^3 + 512*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 384*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2
      ]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 64*sp[k1,k3]*sp[k2,
      p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 256*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1] - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 80*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m^3 + 128*sp[k1,p1]^2*sp[k2,p2] - 96*sp[k1,p1]^2*sp[k2,p2]*m
       + 16*sp[k1,p1]^2*sp[k2,p2]*m^2 + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 96*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ]*m^2 - 320*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 256*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m
       + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[7,1]*color[1/4*Ca
      *Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*
      den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 128*sp[k1,k2]*
      sp[k1,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[k1
      ,k2]*sp[k1,p2]*sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 
      16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 128*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] + 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 128*
      sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*
      m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m - 128*sp[k1,p1]^2*sp[k2,p2] - 128*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 256*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[7,2]*color[ - Cf^2*
      Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1
       - p2]]*den[sp[ - k2 + p2]]*den[sp[ - k3 + p1]]*num[ - 64*sp[k1,
      k2]*sp[k1,k3]*sp[p1,p2] + 320*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 160
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m^2 - 256*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1
      ,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 - 64*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 480*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 
      160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[
      k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 128*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*
      m - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k3
      ]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*
      m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 256*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p1]^2*sp[k2,p2] - 96*sp[k1,p1
      ]^2*sp[k2,p2]*m + 16*sp[k1,p1]^2*sp[k2,p2]*m^2 - 256*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3] + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 128*sp[k1,p1]*sp[k1,p2]*sp[k2
      ,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2
      ]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 96*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 
      64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,p1]*sp[k2,p1]*sp[k3,
      p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2
      ]*sp[k3,p1] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m^2 + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 384
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 256*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[7,3]*color[ - Cf^2*Na*Tf + Ca
      *Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*
      den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[320*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 256*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 256*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2] - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 480*sp[k1,k3]*sp[k2,k3]
      *sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] - 
      32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m^2 - 320*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 160*sp[k1
      ,k3]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2
       + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1]*m - 256*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 128*sp[k1,p1]*sp[
      k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 512*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 384*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m + 96*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8*sp[k1,p1]*sp[k2,k3]
      *sp[k3,p2]*m^3 + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 96*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2
      ]*m^2 + 256*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,
      p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m
       - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 96*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 256*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 80*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]^2 - 96*sp[k1,p2]*sp[k2,p1]^2*m
       + 16*sp[k1,p2]*sp[k2,p1]^2*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m^2] + amp[7,4]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na
      *Tf]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*
      den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 16*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 192*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       + 96*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[
      k3,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 80*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 64*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2 + 288*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2] - 144*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 80*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
      *m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]
      *sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 96*sp[k1,k2]
      *sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 192*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 32*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2] + 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[
      k3,p1]*sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 80*sp[
      k1,k2]*sp[k3,p2]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*
      m^2 + 160*sp[k1,k2]*sp[p1,p2]^2 - 80*sp[k1,k2]*sp[p1,p2]^2*m + 8*
      sp[k1,k2]*sp[p1,p2]^2*m^2 + 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 48
      *sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ]*m^2 - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1]*m - 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2] - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2] - 80*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] + 48*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 + 192*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 64*
      sp[k1,p1]^2*sp[k2,p2] + 48*sp[k1,p1]^2*sp[k2,p2]*m - 8*sp[k1,p1]^
      2*sp[k2,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 112*sp[k1,
      p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2
       - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 48*sp[k1,p1]*sp[k1,p2]*sp[
      k2,p1]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2 - 192*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2] + 112*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m^2 - 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]
      *sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 + 32
      *sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ]*m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 96*sp[k1,p1]
      *sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 96*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*
      m - 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 8*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 112*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ]*m^2 - 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,k3
      ]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,
      p2]*sp[k2,p1]^2 - 64*sp[k1,p2]*sp[k2,p1]^2*m + 8*sp[k1,p2]*sp[k2,
      p1]^2*m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 288*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2] - 144*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1
      ,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 160*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]
       + 80*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 112*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + 
      amp[7,5]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k3 + p1]]*den[sp[
       - k3 + p2]]*num[ - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 320*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2
       + 256*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2
      ]*sp[k3,p2]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[p1,p2]^2 + 
      160*sp[k1,k2]*sp[p1,p2]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 896*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 608*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m - 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2]*m^3 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2
       - 256*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,p1]*
      sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 256*sp[k1,k3]*sp[k2,p2]*sp[p1
      ,p2] + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,
      p2]*sp[p1,p2]*m^2 + 640*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 480*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2]*m + 112*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,
      k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1
      ]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1] + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p1]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 
      96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[p1
      ,p2]*m^2 + 640*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 480*sp[k1,p2]*sp[
      k2,k3]*sp[k3,p1]*m + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[p1
      ,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 256*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m - 16*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[p1
      ,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1
      ]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p2
      ]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2]
       + amp[7,6]*color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2]
      ]*den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[64*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 128*sp[k1
      ,k3]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 
      64*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]
      *sp[p1,p2] - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 128*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 
      128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,p1]*sp[k2,p1]*sp[k2
      ,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1] - 256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 64*sp[k1,p2]*sp[
      k2,k3]*sp[k2,p1]*m + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 256*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m^2 + 256*sp[k1,p2]*sp[k2,p1]^2 - 64*sp[k1,p2]*sp[k2,p1]^2*m + 
      256*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m] + amp[7,7]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*
      den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*den[sp[ - k3 + p1]]*num[32*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
       - 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1]*m + 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,
      k3]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*
      sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2
      ]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m + 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[
      p1,p2]^2 - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k1,
      p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 64*sp[k1,k3]
      *sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 16*
      sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 16*sp[k1,k3]*sp[k2,p1]
      *sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,k3]*
      sp[k2,p2]*sp[p1,p2] + 32*sp[k1,p1]^2*sp[k2,p2] - 96*sp[k1,p1]*sp[
      k1,p2]*sp[k2,p1] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,
      p1]*sp[k2,k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 64
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]
      *m + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,p1]*sp[k2,p1]*
      sp[k2,p2] - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1] - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2,p1
      ]^2 - 32*sp[k1,p2]*sp[k2,p1]^2*m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*
      sp[k2,p1]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 96*sp[
      k1,p2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m]
       + amp[7,8]*color[Cf*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1 - p2]
      ]*den[sp[ - k3 + p1]]^2*num[ - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
       + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1] + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 256*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2] + amp[7,9]*color[ - 1/4*Ca*Na*
      Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*
      den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k3,p1
      ]*sp[k3,p2] - 48*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 128*sp[
      k1,k2]*sp[p1,p2]^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 
      32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,
      p2]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 128*
      sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*
      m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 64*
      sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[7,10]*color[ - Cf^2
      *Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*
      den[sp[ - k3 + p1]]^2*num[ - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 
      288*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 64*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1
      ,p2]*sp[k2,k3]*sp[k3,p1]*m^3] + amp[8,1]*color[ - Cf^2*Na*Tf + Ca
      *Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]*
      den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[320*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] - 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 256*
      sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]
      *m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p2
      ]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 16*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k1,p1]*
      sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 - 256*sp[k1,k3
      ]*sp[k1,p2]*sp[k2,p1] + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 640*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2] + 480*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 512*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] - 384*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 96*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m^3 + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 256*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p1]^2*sp[
      k2,p2] - 96*sp[k1,p1]^2*sp[k2,p2]*m + 16*sp[k1,p1]^2*sp[k2,p2]*
      m^2 + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m^2 + 
      128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 320*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2] + 160*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1
      ,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 256*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
       - 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*
      sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 
      128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,p1
      ]*sp[k3,p1]*m] + amp[8,2]*color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[
      sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*den[sp[ - k3 + 
      p1]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1
      ]*sp[k3,p2] - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 128*sp[k1,k2]*
      sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       - 256*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,k3]*sp[k2
      ,k3]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 
      128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 512*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1] - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m^2 + 256*sp[k1,p1]^2*sp[k2,p2] - 64*sp[k1,p1]^2*
      sp[k2,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 128*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1] + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 64*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]
       - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 256*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2
      ]*sp[k2,p1]*sp[k3,p1]] + amp[8,3]*color[1/4*Ca*Na*Tf^2 + d33[
      cOlpR1,cOlpR2]]*den[sp[ - k1 + p1]]*den[sp[k2 + k3]]*den[sp[k2 - 
      p2]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 
      64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,
      p2] + 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 64*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 
      128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]
      *sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 128*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m + 256*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 64*sp[k1
      ,p1]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 
      32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 128*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 48*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 128*sp[k1,p2]*sp[k2,p1]^2 - 128*sp[k1,p2]
      *sp[k2,p1]*sp[k3,p1]] + amp[8,4]*color[1/2*Ca*Na*Tf^2]*den[sp[ - 
      k1 + p1]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]
      ]*num[ - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*sp[k1,k3
      ]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]
      *sp[k1,p1]*sp[p1,p2] + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       + 32*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 96*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 16*sp[k1,k2]
      *sp[k3,p1]*sp[p1,p2]*m - 32*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 32*
      sp[k1,k2]*sp[p1,p2]^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 32*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1
      ] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m - 32*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 
      32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p1]^2*sp[k2,p2] + 
      32*sp[k1,p1]^2*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m
       + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 128*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2]*m + 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 32*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2
      ]*m + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p1]*m + 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2]*m - 96*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,
      p1]*sp[k2,p2]*sp[p1,p2]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 16
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[p1,
      p2] - 32*sp[k1,p2]*sp[k2,p1]^2 - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]
       + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,p1]*
      sp[p1,p2] - 96*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2
      ,p2]*sp[k3,p1]*m] + amp[8,5]*color[ - 1/4*Ca*Na*Tf^2 + d33[cOlpR1
      ,cOlpR2]]*den[sp[ - k1 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]
      ]*den[sp[ - k3 + p2]]*num[64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 48*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,k2]*sp[k3,p1]*sp[p1,
      p2] + 128*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 128*sp[k1,k2]*sp[p1,p2]
      ^2 - 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 128*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 
      128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,
      p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 32*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2]*m - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m + 256*sp[k1,p1]*
      sp[k2,p2]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m - 64*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       + 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1] + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,p2]*sp[k2,
      p1]*sp[p1,p2] + 64*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m] + amp[8,6]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*
      Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*den[sp[k2 + k3]]*den[sp[
      k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 64*sp[k1,k2]*sp[k2,k3]*sp[p1
      ,p2] + 320*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k2]*sp[k2,p1
      ]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 
      16*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 640*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2] + 480*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 112*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3
       - 320*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 - 256*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2] + 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2]*m^2 + 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2
       + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 512*sp[k1,k3]*sp[k2,p2]*sp[
      k3,p1] - 384*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*
      m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m + 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1
      ,p1]*sp[k2,p1]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2
       - 128*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[
      k3,p2]*m + 256*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*
      m - 16*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1] - 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 80*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 
      128*sp[k1,p2]*sp[k2,p1]^2 - 96*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1
      ,p2]*sp[k2,p1]^2*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 96*sp[
      k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*
      m^2] + amp[8,7]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
       - k1 + p2]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + 
      p1]]*num[ - 288*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 144*sp[k1,k2]*sp[
      k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 160*
      sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*
      m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]
      *sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[
      k1,p1]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 32*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
       + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m + 192*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] - 96*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 80*sp[
      k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*
      m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 192*sp[k1,k2]
      *sp[k3,p1]*sp[k3,p2] + 96*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 32*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       - 48*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p1]*sp[
      p1,p2]*m^2 + 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 80*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m^2 - 160*
      sp[k1,k2]*sp[p1,p2]^2 + 80*sp[k1,k2]*sp[p1,p2]^2*m - 8*sp[k1,k2]*
      sp[p1,p2]^2*m^2 + 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 
      192*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 112*sp[k1,k3]*sp[k1,p2]*sp[k2
      ,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]
       + 112*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 16*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 192*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] - 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,k3]*sp[k2,p2
      ]*sp[k3,p1]*m^2 + 128*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 64*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 
      128*sp[k1,p1]^2*sp[k2,p2] + 64*sp[k1,p1]^2*sp[k2,p2]*m - 8*sp[k1,
      p1]^2*sp[k2,p2]*m^2 - 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 80*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m^2 + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 64*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m + 16*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 64*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 48*sp[k1,p1]*
      sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 32*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m^2 + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 288*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p2] + 144*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p2]*m^2 + 160*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 80*
      sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]
      *m^2 - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 48*sp[k1,p2]*sp[k2,k3]*
      sp[k2,p1]*m - 8*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m^2 + 64*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 8*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,p2]*sp[k2,k3]*sp[p1,p2
      ] + 80*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 64*sp[k1,p2]*sp[k2,p1]^2 - 48*sp[k1,p2]*sp[k2,p1]
      ^2*m + 8*sp[k1,p2]*sp[k2,p1]^2*m^2 - 32*sp[k1,p2]*sp[k2,p1]*sp[k3
      ,p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 8*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p1]*m^2 + 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m + 96*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 48*sp[
      k1,p2]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*
      m^2 + 192*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2]
      *sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[8,8]*
      color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[ - k1 + p2]]*den[
      sp[k2 - p2]]*den[sp[ - k3 + p1]]^2*num[ - 256*sp[k1,k2]*sp[k3,p1]
      *sp[k3,p2] + 288*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 96*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 + 
      128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 160*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3] + amp[8,9]*color[ - 
      Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*den[sp[ - k2 + p1]
      ]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*den[sp[ - k3 + p2]]*num[
       - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 320*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 256*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2] - 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*
      sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k3,p2]*sp[p1
      ,p2] - 160*sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,
      p2]*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[p1,p2]^2 + 160*sp[k1,k2]*sp[
      p1,p2]^2*m - 16*sp[k1,k2]*sp[p1,p2]^2*m^2 - 896*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2] + 608*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,
      k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3
       + 640*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 480*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 112*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]
      *sp[k2,p1]*sp[k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32
      *sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 640*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1] - 480*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 112*sp[k1,k3]*sp[k2,
      p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m
       + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 256*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p1]*sp[k3
      ,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p1]*m - 256*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 128
      *sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2]*m^2 + 128*sp[k1,p1]*sp[k2,p2]*sp[p1,p2] - 96*sp[k1,p1]*sp[k2,
      p2]*sp[p1,p2]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[p1,p2]*m^2 + 256*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m
       + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 256*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] + 128*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 256*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 128
      *sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,p2]*sp[k2,
      p1]*sp[k3,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*sp[p1,p2] - 96*sp[k1,p2
      ]*sp[k2,p1]*sp[p1,p2]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[p1,p2]*m^2 + 
      128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p2]*sp[k3,
      p1]*m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[8,10]*color[
      Cf*Na*Tf^2]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*den[sp[ - k3 + 
      p1]]^2*num[ - 128*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*
      sp[k3,p1]*sp[k3,p2]*m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 192*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1
      ]*m^2 - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 64*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1]*m] + amp[9,1]*color[ - 1/4*Ca*Na*Tf^2 + d33[cOlpR1,
      cOlpR2]]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - k2 + p1]]*
      den[sp[k2 + k3]]*num[ - 128*sp[k1,k2]^2*sp[p1,p2] - 128*sp[k1,k2]
      *sp[k1,k3]*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 64*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2] + 256*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 
      64*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 128*sp[k1,k2]*sp[k1,p2]*sp[
      k3,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 128*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2] + 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k2]
      *sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 64*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m - 64*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 128*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k3]*sp[
      k2,k3]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,
      k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 16*sp[k1,k3]*sp[k2,p2]
      *sp[k3,p1]*m - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*
      sp[k1,p2]*sp[k2,k3]*m - 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 64*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2] + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m
       + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 32*sp[k1,p2]*sp[k2,k3]*sp[
      k2,p1]*m + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2
      ,k3]*sp[k3,p1]*m] + amp[9,2]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*
      Tf - 1/2*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[k1 - p2]]*den[sp[ - 
      k2 + p2]]*den[sp[k2 + k3]]*num[ - 256*sp[k1,k2]^2*sp[p1,p2] + 160
      *sp[k1,k2]^2*sp[p1,p2]*m - 16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 256*sp[
      k1,k2]*sp[k1,k3]*sp[p1,p2] + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m
       - 16*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p2] - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*
      sp[k1,p1]*sp[k2,p2]*m^2 + 256*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 128
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2]*m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[
      k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m
       - 256*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,k3]*
      sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 256*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[k3
      ,p1] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 896*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2] + 608*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 128*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3
       - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[
      k2,p2]*m + 256*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,k3]*sp[
      k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 640*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 320*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m - 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k2,
      p1]*sp[k2,p2] + 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]
      *sp[k2,p1]*sp[k2,p2]*m^2 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^2 + 640*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 480*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8
      *sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 - 128*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,
      p2]*sp[k2,k3]*m^2 + 256*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 128*sp[k1
      ,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2
       + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 128*sp[k1,p2
      ]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 640*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 480*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]
      *m + 112*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3
      ]*sp[k3,p1]*m^3] + amp[9,3]*color[ - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf
      ]*den[sp[ - k1 + p1]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]^2*num[ - 
      256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 288*sp[k1,k3]*sp[k2,k3]*sp[p1
      ,p2]*m - 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2
      ,k3]*sp[p1,p2]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 160*sp[
      k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m^2 - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1] - 160*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 64*sp[k1,p2
      ]*sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3]
       + amp[9,4]*color[ - 1/2*Ca*Cf*Na*Tf + 1/4*Ca^2*Na*Tf]*den[sp[ - 
      k1 + p1]]*den[sp[k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*
      num[160*sp[k1,k2]^2*sp[p1,p2] - 80*sp[k1,k2]^2*sp[p1,p2]*m + 8*
      sp[k1,k2]^2*sp[p1,p2]*m^2 + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 
      80*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2]*m^2 - 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] + 48*sp[k1,k2]*sp[k1,
      p1]*sp[k2,p2]*m - 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 192*sp[k1
      ,k2]*sp[k1,p1]*sp[k3,p2] + 80*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 8
      *sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 - 160*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1] + 80*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1]*m^2 + 128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 64*sp[k1,
      k2]*sp[k1,p2]*sp[k3,p1]*m + 8*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m^2
       + 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] - 48*sp[k1,k2]*sp[k2,k3]*sp[
      p1,p2]*m + 8*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*sp[
      k2,p1]*sp[k3,p2]*m - 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m^2 - 128*
      sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*
      m - 8*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m^2 + 16*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1]*m + 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] - 80*sp[k1,k2]*
      sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2 + 128
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
      *m + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 - 288*sp[k1,k2]*sp[k3,p1
      ]*sp[p1,p2] + 144*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k3,p1]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] + 16*
      sp[k1,k2]*sp[k3,p2]*sp[p1,p2]*m + 96*sp[k1,k3]*sp[k1,p1]*sp[k2,p2
      ] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 288*sp[k1,k3]*sp[k1,p2]*
      sp[k2,p1] + 144*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*
      sp[k1,p2]*sp[k2,p1]*m^2 + 192*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 96*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
      *m^2 - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 8*sp[k1,k3]*sp[k2,p1]
      *sp[k2,p2]*m^2 - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*
      sp[k2,p1]*sp[k3,p2]*m + 160*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 80*
      sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]
      *m^2 - 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 48*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 192*sp[k1,k3]
      *sp[k2,p2]*sp[p1,p2] - 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2]*m^2 + 192*sp[k1,p1]*sp[k1,p2]*sp[k2,k3
      ] - 112*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 16*sp[k1,p1]*sp[k1,p2]*
      sp[k2,k3]*m^2 - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] + 32*sp[k1,p1]*
      sp[k2,k3]*sp[k2,p2]*m - 8*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 - 64*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*
      m - 8*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 + 96*sp[k1,p1]*sp[k2,k3]*
      sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,p1]*sp[
      k2,p1]*sp[k2,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 192*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 80*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*
      m - 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m^2 - 64*sp[k1,p1]*sp[k2,p2]^
      2 + 48*sp[k1,p1]*sp[k2,p2]^2*m - 8*sp[k1,p1]*sp[k2,p2]^2*m^2 + 
      192*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p1]*m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 64*sp[k1,p1]*sp[
      k2,p2]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*sp[k1,
      p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 
      192*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 112*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 64*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2] + 48*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,
      p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]^2 - 64*sp[
      k1,p2]*sp[k2,p1]^2*m + 8*sp[k1,p2]*sp[k2,p1]^2*m^2 - 64*sp[k1,p2]
      *sp[k2,p1]*sp[k2,p2] + 48*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 8*sp[
      k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1
      ] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 8*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p1]*m^2 + 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 - 192
      *sp[k1,p2]*sp[k2,p2]*sp[k3,p1] + 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1
      ]*m - 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[9,5]*color[ - 
      Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p1]]*
      den[sp[k1 - p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[320*sp[
      k1,k2]*sp[k2,k3]*sp[p1,p2] - 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m
       + 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p1]*
      sp[k3,p2] + 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1] - 256*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 160*sp[k1,
      k2]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p2]*sp[p1,p2]*m^2
       - 256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*
      sp[k3,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]
      *sp[k3,p2]*sp[p1,p2] - 640*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 480*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 112*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 
      128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 96*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 320*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] + 160*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 16*sp[k1
      ,k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]
       + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m - 16*sp[k1,p1]*sp[k2,k3]*
      sp[k2,p2]*m^2 + 256*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 256*sp[k1,p1]
      *sp[k2,k3]*sp[k3,p2]*m + 80*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 8
      *sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m^3 + 128*sp[k1,p1]*sp[k2,p2]^2 - 
      96*sp[k1,p1]*sp[k2,p2]^2*m + 16*sp[k1,p1]*sp[k2,p2]^2*m^2 + 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*
      m + 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 - 256*sp[k1,p2]*sp[k2,k3
      ]*sp[k2,p1] + 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*
      sp[k2,k3]*sp[k2,p1]*m^2 + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 384
      *sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 64*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2] - 32*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 128*sp[k1
      ,p2]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 
      16*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m^2 - 128*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[9,6]*color[Cf*Na*Tf^2]*
      den[sp[ - k1 + p2]]*den[sp[k1 - p2]]*den[sp[k2 + k3]]^2*num[ - 
      128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2]*m + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 192*sp[k1,p2]
      *sp[k2,k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2] + 
      amp[9,7]*color[1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1 - p2
      ]]*den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*num[32*sp[k1,k2]^2*sp[p1,
      p2] + 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] - 32*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2] - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 96*sp[k1,k2]*sp[k1
      ,p2]*sp[k2,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 64*sp[k1,k2
      ]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p1]*sp[p1,p2
      ] + 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k2]*sp[k2,p2]*
      sp[p1,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3
      ,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 16*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 32*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2
      ]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*
      sp[k2,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 16*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]
       + 96*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 16*sp[k1,p1]*sp[k2,
      k3]*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*sp[k1,
      p1]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 64
      *sp[k1,p1]*sp[k2,p1]*sp[k2,p2] + 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m - 32*sp[k1,p1]*sp[k2,p2]^2 + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]
       - 16*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 32*sp[k1,p1]*sp[k2,p2]*
      sp[k3,p2] - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2
      ,k3]*sp[k2,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m - 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32
      *sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,p2]*sp[k2,p1]^2 + 32
      *sp[k1,p2]*sp[k2,p1]^2*m + 96*sp[k1,p2]*sp[k2,p1]*sp[k2,p2] - 32*
      sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1] + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,p1]
      *sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m] + amp[9,8]*
      color[Cf*Na*Tf^2 - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p2]]*den[sp[k1
       - p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[
      k2,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,
      k2]*sp[k2,p1]*sp[p1,p2] - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] - 128
      *sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]
      *m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] - 128*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[
      k2,p1]*sp[k2,p2] + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 
      128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,
      p1]*m + 64*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 128*sp[k1,p1]*sp[k2,k3
      ]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 128*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2] - 128*sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 64*sp[
      k1,p1]*sp[k2,p1]*sp[k3,p2] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] - 
      256*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k2,
      p1]*m + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 256*sp[k1,p2]*sp[k2,
      k3]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 + 256*sp[
      k1,p2]*sp[k2,p1]^2 - 64*sp[k1,p2]*sp[k2,p1]^2*m + 256*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m] + amp[9
      ,9]*color[1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[k1 - p2]]*
      den[sp[ - k2 + p1]]*den[sp[k2 + k3]]*den[sp[ - k3 + p2]]*num[64*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]
       - 32*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k2,p2]*
      sp[k3,p1] - 128*sp[k1,k2]*sp[k2,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 128*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 64*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[
      k1,k3]*sp[k2,p2]*sp[p1,p2] + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 
      64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] + 48*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2]*m - 128*sp[k1,p1]*sp[k2,p2]^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3
      ,p2] - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]
      *sp[k2,p1]*m - 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 32*sp[
      k1,p2]*sp[k2,k3]*sp[p1,p2]*m + 256*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]
       - 64*sp[k1,p2]*sp[k2,p1]*sp[k2,p2]*m + 128*sp[k1,p2]*sp[k2,p1]*
      sp[k3,p2] - 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[9
      ,10]*color[ - Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[
      k1 - p2]]*den[sp[ - k2 + p2]]*den[sp[k2 + k3]]*den[sp[ - k3 + p1]
      ]*num[ - 64*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 320*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2] - 160*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2
      ]*sp[k2,p1]*sp[k3,p2]*m^2 - 256*sp[k1,k2]*sp[k2,p1]*sp[p1,p2] + 
      160*sp[k1,k2]*sp[k2,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k2,p1]*sp[
      p1,p2]*m^2 - 64*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[
      k2,p2]*sp[k3,p1]*m - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 480*sp[
      k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*
      m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2] + 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2
      ]*sp[k3,p1]*sp[p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 
      128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[
      p1,p2]*m^2 - 256*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 128*sp[k1,k3]*
      sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m^2 + 
      128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,k3]*sp[k2,p1]*sp[k3,
      p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k3]*sp[k2
      ,p1]*sp[p1,p2] + 512*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 384*sp[k1,k3
      ]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 
      8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p1]*sp[k2,k3]*sp[
      k2,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2
      ,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 64*sp[k1,p1
      ]*sp[k2,k3]*sp[p1,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m + 128*
      sp[k1,p1]*sp[k2,p1]*sp[k2,p2] - 96*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*
      m + 16*sp[k1,p1]*sp[k2,p1]*sp[k2,p2]*m^2 - 128*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 256*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p2]*sp[k2,k3]*sp[k2
      ,p1] + 96*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m - 16*sp[k1,p2]*sp[k2,k3
      ]*sp[k2,p1]*m^2 + 256*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 256*sp[k1,
      p2]*sp[k2,k3]*sp[k3,p1]*m + 80*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2
       - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 128*sp[k1,p2]*sp[k2,p1]^
      2 - 96*sp[k1,p2]*sp[k2,p1]^2*m + 16*sp[k1,p2]*sp[k2,p1]^2*m^2 + 
      128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,
      p1]*m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[10,1]*color[
       - Cf^2*Na*Tf + 1/2*Ca*Cf*Na*Tf]*den[sp[k1 + k3]]^2*den[sp[ - k2
       + p1]]*den[sp[k2 - p2]]*num[ - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       + 288*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^3 + 128*sp[k1,
      k3]*sp[k2,p1]*sp[k3,p2] - 160*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 
      64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1,k3]*sp[k2,p1]*sp[
      k3,p2]*m^3 + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 160*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1]*m + 64*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3] + amp[10,2]*color[Cf*Na*Tf^2]*
      den[sp[k1 + k3]]^2*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*num[ - 
      128*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 64*sp[k1,k3]*sp[k2,p1
      ]*sp[k3,p2]*m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 192*sp[k1,k3]
      *sp[k2,p2]*sp[k3,p1]*m + 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2] + 
      amp[10,3]*color[ - 1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[
       - k1 + p1]]*den[sp[k1 + k3]]*den[sp[k2 + k3]]*den[sp[k2 - p2]]*
      num[ - 128*sp[k1,k2]^2*sp[p1,p2] - 128*sp[k1,k2]*sp[k1,k3]*sp[p1,
      p2] + 256*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 64*sp[k1,k2]*sp[k1,p1]*
      sp[k2,p2]*m + 128*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 32*sp[k1,k2]*
      sp[k1,p1]*sp[k3,p2]*m - 128*sp[k1,k2]*sp[k1,p2]*sp[k2,p1] - 64*
      sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]
       - 64*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k2,p2]*sp[
      k3,p1] - 32*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2] + 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m + 128*sp[k1,k3
      ]*sp[k1,p1]*sp[k2,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]
       - 48*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*
      sp[k2,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2] + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m - 
      64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,
      k3]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 32*sp[k1,p1]*sp[k2,k3
      ]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*
      sp[k2,k3]*sp[k3,p2]*m - 64*sp[k1,p2]*sp[k2,k3]*sp[k2,p1] - 64*sp[
      k1,p2]*sp[k2,k3]*sp[k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m]
       + amp[10,4]*color[ - 1/2*Ca*Na*Tf^2]*den[sp[ - k1 + p1]]*den[sp[
      k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*num[ - 32*sp[k1,k2
      ]^2*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m + 96*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 32*sp[
      k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m
       - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 32*sp[k1,k2]*sp[k1,p2]*sp[
      k2,p1] - 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 32*sp[k1,k2]*sp[k1,
      p2]*sp[p1,p2] - 32*sp[k1,k2]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k2]*
      sp[k2,p1]*sp[k3,p2] - 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 16*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1]*sp[p1,p2] + 
      16*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 64*sp[k1,k3]*sp[k1,p1]*sp[k2
      ,p2] - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m - 64*sp[k1,k3]*sp[k1,p2
      ]*sp[k2,p1] + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m - 16*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m - 96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 32*sp[
      k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m + 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,k3]*sp[k2
      ,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2]*m + 128*sp[k1,p1]^2*sp[k2,p2] - 32*sp[k1,p1
      ]^2*sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m - 64*sp[k1,
      p1]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] + 32*
      sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m + 96*sp[k1,p1]*sp[k2,k3]*sp[k2,p2
      ] - 32*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 128*sp[k1,p1]*sp[k2,k3]*
      sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 16*sp[k1,p1]*sp[
      k2,k3]*sp[p1,p2]*m - 16*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m
       - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[
      k3,p2]*m + 32*sp[k1,p2]^2*sp[k2,p1] - 64*sp[k1,p2]*sp[k2,k3]*sp[
      k3,p1] + 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 32*sp[k1,p2]*sp[k2,
      k3]*sp[p1,p2] - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 16*sp[k1,p2]*
      sp[k2,p1]*sp[k3,p1]*m + 32*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]] + amp[
      10,5]*color[1/4*Ca*Na*Tf^2 + d33[cOlpR1,cOlpR2]]*den[sp[ - k1 + 
      p1]]*den[sp[k1 + k3]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[64
      *sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       - 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 64*sp[k1,k2]*sp[k1,p2]*
      sp[k3,p1] - 128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 64*sp[k1,k2]*sp[
      k3,p1]*sp[k3,p2] - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2] - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32*
      sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 128*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1] + 64*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] - 16*sp[k1,k3]*sp[k2,k3]*
      sp[p1,p2]*m - 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 48*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m - 128*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1
      ,k3]*sp[k2,p2]*sp[k3,p1]*m - 64*sp[k1,k3]*sp[k2,p2]*sp[p1,p2] + 
      32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m - 128*sp[k1,p1]*sp[k1,p2]*sp[
      k2,k3] + 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m + 256*sp[k1,p1]*sp[k1
      ,p2]*sp[k2,p2] - 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m - 128*sp[k1,
      p1]*sp[k2,k3]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 
      128*sp[k1,p1]*sp[k2,p2]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,p2]*sp[k3,
      p2]*m - 128*sp[k1,p2]^2*sp[k2,p1] + 64*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1] - 16*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m - 64*sp[k1,p2]*sp[k2,k3]
      *sp[p1,p2] - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] + 128*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1] - 32*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m] + amp[
      10,6]*color[ - Cf^2*Na*Tf + 3/2*Ca*Cf*Na*Tf - 1/2*Ca^2*Na*Tf]*
      den[sp[ - k1 + p2]]*den[sp[k1 + k3]]*den[sp[k2 + k3]]*den[sp[k2
       - p2]]*num[ - 256*sp[k1,k2]^2*sp[p1,p2] + 160*sp[k1,k2]^2*sp[p1,
      p2]*m - 16*sp[k1,k2]^2*sp[p1,p2]*m^2 - 256*sp[k1,k2]*sp[k1,k3]*
      sp[p1,p2] + 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 16*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2]*m^2 + 128*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 96*
      sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k2,p2
      ]*m^2 + 256*sp[k1,k2]*sp[k1,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k1,
      p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 128*sp[
      k1,k2]*sp[k1,p2]*sp[k2,p1] - 96*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m
       + 16*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m^2 - 128*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 256*sp[k1,k2]*
      sp[k2,k3]*sp[p1,p2] + 160*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 16*
      sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m^2 + 256*sp[k1,k2]*sp[k2,p1]*sp[k3
      ,p2] - 128*sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k2,
      p1]*sp[k3,p2]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 32*sp[k1,
      k2]*sp[k2,p2]*sp[k3,p1]*m - 896*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 
      608*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 128*sp[k1,k2]*sp[k3,p1]*sp[
      k3,p2]*m^2 + 8*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 128*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2] + 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m + 256*
      sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m + 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 640*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2] + 320*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 32*sp[k1,k3
      ]*sp[k2,k3]*sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 
      96*sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2
      ,p2]*m^2 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 128*sp[k1,k3]*sp[
      k2,p1]*sp[k3,p2]*m + 16*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 + 640*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 480*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
      *m + 112*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2
      ]*sp[k3,p1]*m^3 - 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] + 96*sp[k1,p1
      ]*sp[k1,p2]*sp[k2,k3]*m - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 
      256*sp[k1,p1]*sp[k2,k3]*sp[k2,p2] - 128*sp[k1,p1]*sp[k2,k3]*sp[k2
      ,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 256*sp[k1,p1]*sp[
      k2,k3]*sp[k3,p2] - 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1
      ,p1]*sp[k2,k3]*sp[k3,p2]*m^2 - 128*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]
       + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 640*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1] - 480*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 112*sp[k1,p2]*
      sp[k2,k3]*sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3] + 
      amp[10,7]*color[1/2*Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + 
      p2]]*den[sp[k1 + k3]]*den[sp[ - k2 + p1]]*den[sp[k2 - p2]]*num[
       - 160*sp[k1,k2]^2*sp[p1,p2] + 80*sp[k1,k2]^2*sp[p1,p2]*m - 8*sp[
      k1,k2]^2*sp[p1,p2]*m^2 - 32*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 48*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m - 8*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]
      *m^2 + 160*sp[k1,k2]*sp[k1,p1]*sp[k2,p2] - 80*sp[k1,k2]*sp[k1,p1]
      *sp[k2,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k2,p2]*m^2 - 16*sp[k1,k2]
      *sp[k1,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m^2 + 
      128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 64*sp[k1,k2]*sp[k1,p1]*sp[p1,
      p2]*m + 8*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 + 96*sp[k1,k2]*sp[k1,
      p2]*sp[k2,p1] - 48*sp[k1,k2]*sp[k1,p2]*sp[k2,p1]*m + 8*sp[k1,k2]*
      sp[k1,p2]*sp[k2,p1]*m^2 - 16*sp[k1,k2]*sp[k1,p2]*sp[k3,p1]*m - 
      128*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 80*sp[k1,k2]*sp[k1,p2]*sp[p1,
      p2]*m - 8*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 160*sp[k1,k2]*sp[k2
      ,k3]*sp[p1,p2] + 80*sp[k1,k2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k2]
      *sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,k2]*sp[k2,p1]*sp[k3,p2] - 80
      *sp[k1,k2]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,k2]*sp[k2,p1]*sp[k3,p2
      ]*m^2 - 128*sp[k1,k2]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,k2]*sp[k2,p2
      ]*sp[k3,p1]*m - 8*sp[k1,k2]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,
      k2]*sp[k3,p1]*sp[k3,p2] + 64*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 8*
      sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 288*sp[k1,k2]*sp[k3,p1]*sp[p1
      ,p2] - 144*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m + 16*sp[k1,k2]*sp[k3,
      p1]*sp[p1,p2]*m^2 + 64*sp[k1,k2]*sp[k3,p2]*sp[p1,p2] - 16*sp[k1,
      k2]*sp[k3,p2]*sp[p1,p2]*m - 32*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 32
      *sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]
      *m + 8*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 192*sp[k1,k3]*sp[k2,k3
      ]*sp[p1,p2] + 96*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,k3]*sp[k2,p1]*sp[k2,p2] + 112
      *sp[k1,k3]*sp[k2,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k2,p1]*sp[k2,
      p2]*m^2 + 64*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,k3]*sp[k2,
      p1]*sp[k3,p2]*m + 8*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 96*sp[k1,
      k3]*sp[k2,p1]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,p1]*sp[p1,p2]*m + 
      192*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,k3]*sp[k2,p2]*sp[k3
      ,p1]*m + 16*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 64*sp[k1,k3]*sp[
      k2,p2]*sp[p1,p2] - 48*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 8*sp[k1,
      k3]*sp[k2,p2]*sp[p1,p2]*m^2 - 128*sp[k1,p1]^2*sp[k2,p2] + 64*sp[
      k1,p1]^2*sp[k2,p2]*m - 8*sp[k1,p1]^2*sp[k2,p2]*m^2 + 32*sp[k1,p1]
      *sp[k1,p2]*sp[k2,k3]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 32
      *sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m - 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p1
      ]*m^2 + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 48*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p2]*m + 8*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 288*sp[k1,p1
      ]*sp[k2,k3]*sp[k2,p2] - 144*sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m + 16*
      sp[k1,p1]*sp[k2,k3]*sp[k2,p2]*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[k3,
      p2] - 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 160*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] + 80*sp[k1,p1]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p1]*
      sp[k2,k3]*sp[p1,p2]*m^2 + 192*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] - 80*
      sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 8*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]
      *m^2 - 128*sp[k1,p1]*sp[k2,p2]*sp[k3,p1] + 64*sp[k1,p1]*sp[k2,p2]
      *sp[k3,p1]*m - 8*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 - 128*sp[k1,p1
      ]*sp[k2,p2]*sp[k3,p2] + 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m - 8*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*m^2 + 64*sp[k1,p2]^2*sp[k2,p1] - 48
      *sp[k1,p2]^2*sp[k2,p1]*m + 8*sp[k1,p2]^2*sp[k2,p1]*m^2 - 96*sp[k1
      ,p2]*sp[k2,k3]*sp[k2,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k2,p1]*m + 
      64*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 48*sp[k1,p2]*sp[k2,k3]*sp[k3,
      p1]*m + 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^2 - 192*sp[k1,p2]*sp[k2
      ,k3]*sp[p1,p2] + 96*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m - 8*sp[k1,p2]
      *sp[k2,k3]*sp[p1,p2]*m^2 - 192*sp[k1,p2]*sp[k2,p1]*sp[k3,p1] + 
      112*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m - 16*sp[k1,p2]*sp[k2,p1]*sp[
      k3,p1]*m^2 + 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 48*sp[k1,p2]*sp[
      k2,p1]*sp[k3,p2]*m + 8*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 192*
      sp[k1,p2]*sp[k2,p2]*sp[k3,p1] - 112*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]
      *m + 16*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m^2] + amp[10,8]*color[ - 
      Cf^2*Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[ - k1 + p2]]*
      den[sp[k1 + k3]]*den[sp[k2 - p2]]*den[sp[ - k3 + p1]]*num[ - 64*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 320*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]
       - 160*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m + 16*sp[k1,k2]*sp[k1,p1]*
      sp[k3,p2]*m^2 - 256*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] + 160*sp[k1,k2]
      *sp[k1,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p1]*sp[p1,p2]*m^2 - 
      64*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] + 32*sp[k1,k2]*sp[k1,p2]*sp[k3,
      p1]*m - 640*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 480*sp[k1,k2]*sp[k3,
      p1]*sp[k3,p2]*m - 112*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 8*sp[k1
      ,k2]*sp[k3,p1]*sp[k3,p2]*m^3 - 320*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]
       + 160*sp[k1,k2]*sp[k3,p1]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*
      sp[p1,p2]*m^2 - 128*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 96*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2 + 
      128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 32*sp[k1,k3]*sp[k1,p2]*sp[k2,
      p1]*m - 256*sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 128*sp[k1,k3]*sp[k2,
      k3]*sp[p1,p2]*m - 16*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*sp[
      k1,k3]*sp[k2,p1]*sp[k3,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m
       + 64*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p1]*sp[
      p1,p2]*m + 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1] - 256*sp[k1,k3]*sp[
      k2,p2]*sp[k3,p1]*m + 80*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 - 8*sp[
      k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 128*sp[k1,p1]^2*sp[k2,p2] - 96*
      sp[k1,p1]^2*sp[k2,p2]*m + 16*sp[k1,p1]^2*sp[k2,p2]*m^2 - 256*sp[
      k1,p1]*sp[k1,p2]*sp[k2,k3] + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m
       - 16*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*m^2 + 128*sp[k1,p1]*sp[k1,p2]
      *sp[k2,p1] - 96*sp[k1,p1]*sp[k1,p2]*sp[k2,p1]*m + 16*sp[k1,p1]*
      sp[k1,p2]*sp[k2,p1]*m^2 + 128*sp[k1,p1]*sp[k2,k3]*sp[k3,p2] - 96*
      sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m + 16*sp[k1,p1]*sp[k2,k3]*sp[k3,p2
      ]*m^2 + 64*sp[k1,p1]*sp[k2,k3]*sp[p1,p2] - 128*sp[k1,p1]*sp[k2,p1
      ]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p1]*sp[k3,p2]*m + 128*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] - 96*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[
      k1,p1]*sp[k2,p2]*sp[k3,p1]*m^2 + 512*sp[k1,p2]*sp[k2,k3]*sp[k3,p1
      ] - 384*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 96*sp[k1,p2]*sp[k2,k3]*
      sp[k3,p1]*m^2 - 8*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m^3 + 256*sp[k1,
      p2]*sp[k2,p1]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m + 
      16*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]*m^2] + amp[10,9]*color[ - Cf^2*
      Na*Tf + Ca*Cf*Na*Tf - 1/4*Ca^2*Na*Tf]*den[sp[k1 + k3]]*den[sp[ - 
      k2 + p1]]*den[sp[k2 - p2]]*den[sp[ - k3 + p2]]*num[320*sp[k1,k2]*
      sp[k1,k3]*sp[p1,p2] - 160*sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m + 16*
      sp[k1,k2]*sp[k1,k3]*sp[p1,p2]*m^2 - 64*sp[k1,k2]*sp[k1,p1]*sp[k3,
      p2] + 32*sp[k1,k2]*sp[k1,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k1,p2]
      *sp[k3,p1] - 256*sp[k1,k2]*sp[k1,p2]*sp[p1,p2] + 160*sp[k1,k2]*
      sp[k1,p2]*sp[p1,p2]*m - 16*sp[k1,k2]*sp[k1,p2]*sp[p1,p2]*m^2 - 
      256*sp[k1,k2]*sp[k3,p1]*sp[k3,p2] + 128*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2]*m - 16*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m^2 + 64*sp[k1,k2]*sp[
      k3,p2]*sp[p1,p2] - 256*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 128*sp[k1,
      k3]*sp[k1,p1]*sp[k2,p2]*m - 16*sp[k1,k3]*sp[k1,p1]*sp[k2,p2]*m^2
       - 128*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] + 96*sp[k1,k3]*sp[k1,p2]*sp[
      k2,p1]*m - 16*sp[k1,k3]*sp[k1,p2]*sp[k2,p1]*m^2 - 640*sp[k1,k3]*
      sp[k2,k3]*sp[p1,p2] + 480*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m - 112*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*m^2 + 8*sp[k1,k3]*sp[k2,k3]*sp[p1,
      p2]*m^3 + 256*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] - 256*sp[k1,k3]*sp[k2
      ,p1]*sp[k3,p2]*m + 80*sp[k1,k3]*sp[k2,p1]*sp[k3,p2]*m^2 - 8*sp[k1
      ,k3]*sp[k2,p1]*sp[k3,p2]*m^3 + 512*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]
       - 384*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 96*sp[k1,k3]*sp[k2,p2]*
      sp[k3,p1]*m^2 - 8*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^3 + 64*sp[k1,k3
      ]*sp[k2,p2]*sp[p1,p2] - 32*sp[k1,k3]*sp[k2,p2]*sp[p1,p2]*m + 128*
      sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 32*sp[k1,p1]*sp[k1,p2]*sp[k2,k3]*
      m + 128*sp[k1,p1]*sp[k1,p2]*sp[k2,p2] - 96*sp[k1,p1]*sp[k1,p2]*
      sp[k2,p2]*m + 16*sp[k1,p1]*sp[k1,p2]*sp[k2,p2]*m^2 + 128*sp[k1,p1
      ]*sp[k2,k3]*sp[k3,p2] - 32*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 128*
      sp[k1,p1]*sp[k2,p2]*sp[k3,p2] + 32*sp[k1,p1]*sp[k2,p2]*sp[k3,p2]*
      m + 128*sp[k1,p2]^2*sp[k2,p1] - 96*sp[k1,p2]^2*sp[k2,p1]*m + 16*
      sp[k1,p2]^2*sp[k2,p1]*m^2 + 128*sp[k1,p2]*sp[k2,k3]*sp[k3,p1] - 
      96*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*m + 16*sp[k1,p2]*sp[k2,k3]*sp[k3
      ,p1]*m^2 - 320*sp[k1,p2]*sp[k2,k3]*sp[p1,p2] + 160*sp[k1,p2]*sp[
      k2,k3]*sp[p1,p2]*m - 16*sp[k1,p2]*sp[k2,k3]*sp[p1,p2]*m^2 + 128*
      sp[k1,p2]*sp[k2,p1]*sp[k3,p2] - 96*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*
      m + 16*sp[k1,p2]*sp[k2,p1]*sp[k3,p2]*m^2 + 256*sp[k1,p2]*sp[k2,p2
      ]*sp[k3,p1] - 128*sp[k1,p2]*sp[k2,p2]*sp[k3,p1]*m + 16*sp[k1,p2]*
      sp[k2,p2]*sp[k3,p1]*m^2] + amp[10,10]*color[Cf*Na*Tf^2 - 1/2*Ca*
      Na*Tf^2]*den[sp[k1 + k3]]*den[sp[ - k2 + p2]]*den[sp[k2 - p2]]*
      den[sp[ - k3 + p1]]*num[64*sp[k1,k2]*sp[k1,k3]*sp[p1,p2] + 64*sp[
      k1,k2]*sp[k1,p1]*sp[k3,p2] - 128*sp[k1,k2]*sp[k1,p1]*sp[p1,p2] - 
      128*sp[k1,k2]*sp[k1,p2]*sp[k3,p1] - 128*sp[k1,k2]*sp[k3,p1]*sp[k3
      ,p2] + 32*sp[k1,k2]*sp[k3,p1]*sp[k3,p2]*m - 64*sp[k1,k2]*sp[k3,p1
      ]*sp[p1,p2] - 256*sp[k1,k3]*sp[k1,p1]*sp[k2,p2] + 64*sp[k1,k3]*
      sp[k1,p1]*sp[k2,p2]*m + 64*sp[k1,k3]*sp[k1,p2]*sp[k2,p1] - 128*
      sp[k1,k3]*sp[k2,k3]*sp[p1,p2] + 32*sp[k1,k3]*sp[k2,k3]*sp[p1,p2]*
      m - 128*sp[k1,k3]*sp[k2,p1]*sp[k3,p2] + 32*sp[k1,k3]*sp[k2,p1]*
      sp[k3,p2]*m + 128*sp[k1,k3]*sp[k2,p1]*sp[p1,p2] + 512*sp[k1,k3]*
      sp[k2,p2]*sp[k3,p1] - 256*sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m + 32*
      sp[k1,k3]*sp[k2,p2]*sp[k3,p1]*m^2 + 256*sp[k1,p1]^2*sp[k2,p2] - 
      64*sp[k1,p1]^2*sp[k2,p2]*m + 64*sp[k1,p1]*sp[k1,p2]*sp[k2,k3] - 
      128*sp[k1,p1]*sp[k1,p2]*sp[k2,p1] + 256*sp[k1,p1]*sp[k2,k3]*sp[k3
      ,p2] - 64*sp[k1,p1]*sp[k2,k3]*sp[k3,p2]*m - 64*sp[k1,p1]*sp[k2,k3
      ]*sp[p1,p2] - 64*sp[k1,p1]*sp[k2,p1]*sp[k3,p2] + 256*sp[k1,p1]*
      sp[k2,p2]*sp[k3,p1] - 64*sp[k1,p1]*sp[k2,p2]*sp[k3,p1]*m - 128*
      sp[k1,p2]*sp[k2,k3]*sp[k3,p1] + 32*sp[k1,p2]*sp[k2,k3]*sp[k3,p1]*
      m - 64*sp[k1,p2]*sp[k2,p1]*sp[k3,p1]])
